"use client";

// app/sigap/delego/lapor/page.tsx
//
// (26 Okt 2026) Lapor harian (HP-first). Satu laporan per delegasi per tanggal; mengirim lagi memperbarui laporan tanggal itu.
// Terlambat hanya ditandai, tidak diblokir. PML dapat melapor mewakili mitra (ditandai "diwakili").
// Bukti: foto (ambil atau galeri, dikecilkan di HP; BuktiFoto.tsx) dan/atau teks/tautan; tersimpan pada keu_dlg_laporan.bukti.
// Delegasi berjenis (pekerjaan teknis, tahap 39) melapor dalam JUMLAH satuan (mis. 3 dokumen); poin = jumlah x poin per satuan dihitung basis data
// (keu_dlg_lapor_jumlah). Delegasi lain tetap melapor dalam poin/satuan bebas.

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { angka, bulat, ringkasHariIni, tambahHari, tglPendek } from "@/lib/delego/hitung";
import { berjenis, jumlahDariPoin, poinDariJumlah, teksJumlah } from "@/lib/delego/teknis";
import { bacaDaftar, muatDiBatas, untukSimpan } from "@/lib/delego/bukti";
import { NAMA_PERAN, type Delegasi } from "@/lib/delego/tipe";
import { aksiKeu, useKirim, useSaya } from "../data";
import { PenyuntingBukti, type ButirForm } from "../BuktiFoto";
import { useKonteksDelego } from "../konteks";
import { KELAS } from "../merek";
import { Galat, Halaman, Info, Kartu, Kosong, Medan, Memuat, Peringatan, fmt } from "../ui";
import SelectCari from "@/app/components/SelectCari";

type Hasil = { id: number; tanggal: string; terlambat: boolean; mewakili: boolean };

export default function Lapor() {
  const { hari, hak } = useKonteksDelego();
  const q = useSearchParams();
  const s = useSaya();
  const d = s.data;
  const pilihan = useMemo<Delegasi[]>(() => (d ? [...d.delegasi.filter((x) => x.status === "baru" || x.status === "berjalan"), ...d.diwakili] : []), [d]);
  const semuaLaporan = useMemo(() => (d ? [...d.laporan, ...d.laporan_diwakili] : []), [d]);

  const [id, setId] = useState<number | null>(null);
  const [tanggal, setTanggal] = useState(hari);
  const [poin, setPoin] = useState(""); // untuk delegasi berjenis: jumlah satuan
  const [uraian, setUraian] = useState("");
  const [kendala, setKendala] = useState("");
  const [menit, setMenit] = useState(""); // jam kerja nyata (menit), opsional: bahan kalibrasi skor
  const [bukti, setBukti] = useState<ButirForm[]>([]);
  const [hasil, setHasil] = useState<Hasil | null>(null);
  const kirim = useKirim(s.muat);

  // pilih delegasi awal: dari ?delegasi=, kalau tidak yang pertama belum lapor hari ini, kalau tidak yang pertama
  useEffect(() => {
    if (!d || id !== null || pilihan.length === 0) return;
    const dariUrl = Number(q?.get("delegasi") ?? "");
    const awal = pilihan.find((x) => x.id === dariUrl) ?? pilihan.find((x) => !semuaLaporan.some((l) => l.delegasi_id === x.id && l.tanggal === hari)) ?? pilihan[0];
    setId(awal.id);
  }, [d, id, pilihan, q, semuaLaporan, hari]);

  const terpilih = pilihan.find((x) => x.id === id) ?? null;
  const ada = terpilih ? semuaLaporan.find((l) => l.delegasi_id === terpilih.id && l.tanggal === tanggal) ?? null : null;
  useEffect(() => {
    // isi ulang formulir dengan laporan yang sudah ada untuk delegasi dan tanggal ini
    const pp = terpilih ? angka(terpilih.poin_per_satuan) : 0;
    setPoin(ada ? (pp > 0 ? String(ada.jumlah !== null && ada.jumlah !== undefined ? angka(ada.jumlah) : jumlahDariPoin(pp, angka(ada.poin))) : String(angka(ada.poin))) : "");
    setUraian(ada?.uraian ?? "");
    setKendala(ada?.kendala ?? "");
    setMenit(ada?.menit_nyata ? String(ada.menit_nyata) : "");
    setBukti(bacaDaftar(ada?.bukti).map((b) => ({ ket: b.ket, path: b.path })));
    setHasil(null);
  }, [ada?.id, terpilih?.id, tanggal]); // eslint-disable-line react-hooks/exhaustive-deps

  const r = terpilih && d ? ringkasHariIni(terpilih, semuaLaporan, tanggal) : null;
  const mewakili = !!terpilih && !!d && terpilih.penerima_akun !== d.akun.id;
  const batasAwal = hak.semua || hak.beri_ro.length > 0 ? (terpilih?.mulai ?? tambahHari(hari, -7)) : tambahHari(hari, -7);
  const jenis = !!terpilih && berjenis(terpilih);
  const pps = terpilih ? angka(terpilih.poin_per_satuan) : 0;
  const isiAngka = Number(poin.replace(",", "."));
  const poinAngka = jenis ? poinDariJumlah(pps, isiAngka) : isiAngka;
  const buktiSimpan = untukSimpan(bukti);
  const sah = !!terpilih && poin.trim() !== "" && Number.isFinite(isiAngka) && isiAngka >= 0 && Number.isFinite(poinAngka) && poinAngka <= 1000 && tanggal >= batasAwal && tanggal <= hari && muatDiBatas(buktiSimpan);

  async function kirimLaporan() {
    if (!terpilih || !sah) return;
    setHasil(null);
    await kirim.jalankan(async () => {
      const dasar = { p_delegasi: terpilih.id, p_tanggal: tanggal, p_uraian: uraian.trim(), p_kendala: kendala.trim(), p_bukti: buktiSimpan };
      const res = jenis
        ? await aksiKeu<Hasil>("keu_dlg_lapor_jumlah", { ...dasar, p_jumlah: isiAngka })
        : await aksiKeu<Hasil>("keu_dlg_lapor", { ...dasar, p_poin: poinAngka });
      if (res.ok) {
        setHasil(res.data);
        const m = Math.round(Number(menit.replace(",", ".")));
        if (menit.trim() !== "" && Number.isFinite(m) && m >= 1 && m <= 1440) {
          const r2 = await aksiKeu("keu_dlg_menit_nyata", { p_laporan: res.data.id, p_menit: m });
          if (!r2.ok) return r2;
        }
      }
      return res;
    });
  }

  return (
    <Halaman judul="Lapor harian" sub={`Tanggal laporan: ${tglPendek(tanggal)}`}>
      {s.memuat && !d && <Memuat />}
      {s.galat && !d && <Galat>{s.galat}</Galat>}
      {d && pilihan.length === 0 && (
        <Kosong>
          Tidak ada delegasi yang berjalan untuk dilaporkan. <Link href="/sigap/delego/saya" className="font-semibold text-[#0F6B63] underline">Kembali ke Delegasi saya</Link>.
        </Kosong>
      )}
      {d && terpilih && (
        <div className="mx-auto grid grid-cols-1 max-w-3xl gap-4">
          <Kartu>
            <div className="space-y-3">
              <Medan label="Delegasi">
                <SelectCari className={KELAS.isian} value={id ?? ""} onChange={(e) => setId(Number(e.target.value))}>
                  <optgroup label="Tugas saya">
                    {pilihan.filter((x) => x.penerima_akun === d.akun.id).map((x) => (
                      <option key={x.id} value={x.id}>{x.judul}</option>
                    ))}
                  </optgroup>
                  {d.diwakili.length > 0 && (
                    <optgroup label="Mitra yang saya wakili">
                      {d.diwakili.map((x) => (
                        <option key={x.id} value={x.id}>{x.penerima_nama} · {x.judul}</option>
                      ))}
                    </optgroup>
                  )}
                </SelectCari>
              </Medan>
              {mewakili && <Info>Anda melapor mewakili <b>{terpilih.penerima_nama}</b>. Laporan akan ditandai &quot;diwakili&quot;.</Info>}
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <Medan label="Tanggal" bantu="Laporan susulan boleh sampai 7 hari ke belakang.">
                  <input type="date" className={KELAS.isian} value={tanggal} min={batasAwal} max={hari} onChange={(e) => setTanggal(e.target.value || hari)} />
                </Medan>
                <Medan
                  label={jenis ? `Jumlah (${terpilih.satuan})` : `Capaian (${terpilih.satuan})`}
                  bantu={r ? `Target ${r.hariKerjaIni ? (jenis ? `${fmt(jumlahDariPoin(pps, r.targetHariIni), 1)} ${terpilih.satuan} (${fmt(r.targetHariIni, 1)} poin)` : fmt(r.targetHariIni, 1)) : "0 (bukan hari kerja)"}${r.hutangKemarin > 0 ? `; hutang sebelumnya ${fmt(bulat(r.hutangKemarin), 1)} poin` : ""}.` : undefined}
                >
                  <input type="number" inputMode="decimal" min={0} max={jenis ? undefined : 1000} step="any" className={KELAS.isian} value={poin} onChange={(e) => setPoin(e.target.value)} placeholder="0" />
                </Medan>
              </div>
              {r && r.sisaHariIni > 0 && (
                <button type="button" className={KELAS.tombolKecil} onClick={() => setPoin(String(jenis ? jumlahDariPoin(pps, r.targetHariIni) : r.targetHariIni))}>
                  Isi sesuai target ({jenis ? `${fmt(jumlahDariPoin(pps, r.targetHariIni), 1)} ${terpilih.satuan}` : fmt(r.targetHariIni, 1)})
                </button>
              )}
              {jenis && poin.trim() !== "" && Number.isFinite(isiAngka) && (
                <Info>{fmt(isiAngka, 2)} {terpilih.satuan} × {fmt(pps, 1)} = <b>{fmt(poinAngka, 1)} poin</b>.</Info>
              )}
              {terpilih.insidental && terpilih.perlu_hasil && (
                <Info>Pekerjaan mendadak: cukup <Link href="/sigap/delego/saya" className="font-semibold underline">serahkan hasil di Delegasi saya</Link>; laporan hari ini dibuat otomatis.</Info>
              )}
              <Medan label="Uraian pekerjaan">
                <textarea className={KELAS.isian} rows={3} maxLength={1000} value={uraian} onChange={(e) => setUraian(e.target.value)} placeholder="Apa yang dikerjakan hari ini" />
              </Medan>
              <Medan label="Kendala" bantu="Tulis bila beban terlalu berat atau ada hambatan di lapangan agar Ketua Tim dapat membantu.">
                <textarea className={KELAS.isian} rows={2} maxLength={500} value={kendala} onChange={(e) => setKendala(e.target.value)} placeholder="Kosongkan bila tidak ada" />
              </Medan>
              <Medan label="Jam kerja nyata (menit, boleh dikosongkan)" bantu="Membantu Ketua Tim memeriksa apakah skor pekerjaan ini wajar. Tidak memengaruhi poin laporan.">
                <input type="number" inputMode="numeric" min={1} max={1440} step={1} className={KELAS.isian} value={menit} onChange={(e) => setMenit(e.target.value)} placeholder="Mis. 90" />
              </Medan>
              <PenyuntingBukti delegasi={terpilih.id} butir={bukti} onUbah={setBukti} mati={kirim.mengirim} />
              {tanggal < hari && !ada && <Peringatan>Laporan untuk {tglPendek(tanggal)} akan ditandai terlambat.</Peringatan>}
              {ada && ada.tinjau_status === "ditolak" && <Peringatan><b>Perlu revisi.</b> {ada.tinjau_alasan || "Ketua Tim meminta perbaikan."} Perbarui lalu kirim ulang.</Peringatan>}
              {ada && ada.tinjau_status === "disanggah" && <Peringatan>Laporan ini sedang disanggah dan tidak dapat diubah. Jawab sanggahan di Delegasi saya.</Peringatan>}
              {ada && <Info>Sudah ada laporan {tglPendek(tanggal)} ({teksJumlah(terpilih, angka(ada.poin), (n) => fmt(n, 1))}). Mengirim akan memperbarui laporan itu.</Info>}
              {kirim.galat && <Galat>{kirim.galat}</Galat>}
              {hasil && (
                <Info>
                  Laporan tersimpan{hasil.terlambat ? " (ditandai terlambat)" : ""}{hasil.mewakili ? " (diwakili)" : ""}. <Link href="/sigap/delego/saya" className="font-semibold underline">Kembali ke Delegasi saya</Link>.
                </Info>
              )}
              <button type="button" className={`${KELAS.tombolUtama} w-full`} disabled={!sah || kirim.mengirim} onClick={() => void kirimLaporan()}>
                {kirim.mengirim ? "Mengirim..." : ada ? "Perbarui laporan" : "Kirim laporan"}
              </button>
              <p className="m-0 text-[12px] text-[#3B4A57]">{NAMA_PERAN[terpilih.peran_penerima]} · batas lapor 23:59 WIB pada hari yang sama.</p>
            </div>
          </Kartu>
        </div>
      )}
    </Halaman>
  );
}
