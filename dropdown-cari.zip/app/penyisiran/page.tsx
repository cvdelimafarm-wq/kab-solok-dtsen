"use client";

// app/penyisiran/page.tsx
//
// Halaman TERPISAH utk fitur penyisiran undercoverage usaha SE2026 --
// awalnya "Penyisiran Usaha" adalah tab di /seruti, dipindah ke sini (atas
// permintaan) supaya tidak mengganggu tab-tab utama Seruti Triwulan III
// (beda konteks: ini SE2026, bukan Susenas/Seruti).
//
// Ada 5 tab di sini (lihat lib/penyisiranAuth.ts utk skema sesi/PIN):
//  - "Penyisiran Usaha": checklist petugas lapangan -- login PERSONAL
//    (nama lengkap + tanggal lahir, dicocokkan ke tabel
//    petugas_penyisiran_akun -- TABEL SAMA dgn "Identifikasi Jorong" di
//    bawah, cuma role token beda: "penyisiran_petugas") --
//    MENGGANTIKAN PIN bersama yg dulu dipakai tab ini. Krn loginnya
//    personal, sistem otomatis tahu siapa yg mengisi (dipakai dasar
//    hitungan tab "Monitoring Petugas Penyisiran" & skor prioritas
//    berbasis jarak, lihat app/seruti/penyisiran-usaha.tsx) --
//    nama+alamat+GPS+bukti DUTP/DTSEN/PNM. Badge Info PPL/Jorong/Tetangga
//    + tombol Edit per-kartu sudah DIHAPUS dari kartu (field & skor
//    prioritas yg memakainya ttp ada di backend, cuma tdk bisa diubah lg
//    lewat tab ini) -- tombol "Edit Semua" (global) msh ada, skrg cuma
//    dipakai utk unlock "Tandai Pasti". Kolom
//    "Identifikasi PPL" (badge) DIBEKUKAN read-only di sini --
//    satu-satunya cara mengubahnya adalah lewat salah satu dari TIGA tab
//    Identifikasi di bawah (lihat app/api/penyisiran/identifikasi/route.ts,
//    role "penyisiran"/"penyisiran_petugas" SENGAJA tidak lagi diizinkan
//    menulis ke kolom itu). PIN admin lama ("penyisiran", env
//    PENYISIRAN_PIN) TETAP ADA tapi sekarang cuma dipakai DUA tab
//    Monitoring di bawah, bukan lagi tab ini.
//  - "Identifikasi PPL": dibagikan ke PPL/mantan pendata SE2026, login
//    PERSONAL (nama lengkap + tanggal lahir, dicocokkan ke tabel
//    ppl_akun, role "identifikasi_ppl") -- cuma nama+alamat+wilayah,
//    tanpa bukti/GPS, dan cuma bisa mengisi Ada/Tidak Ada/Ragu utk
//    wilayah yang dialokasikan ke PPL itu saja.
//  - "Identifikasi Jorong": SAMA BENTUK dgn Identifikasi PPL di atas,
//    tapi login pakai akun "petugas penyisiran" (tabel
//    petugas_penyisiran_akun, TERPISAH dari ppl_akun, role
//    "identifikasi_jorong") & filter kartu MANUAL per Kecamatan/Nagari/
//    Sub SLS (bukan auto-scope per petugas) -- krn tugasnya menyisir per
//    Jorong, bukan per wilayah alokasi pribadi.
//  - "Identifikasi Tetangga/Lainnya": SAMA PERSIS cara kerjanya dgn
//    Identifikasi Jorong (login personal, filter manual), tapi akun
//    SENDIRI lagi (tabel tetangga_akun, role "identifikasi_tetangga") --
//    sumber informasinya tetangga/pihak lain, bukan petugas penyisiran.
//
//    KETIGA tab Identifikasi di atas menulis ke kolom yang SAMA
//    (penyisiran_usaha.identifikasi_ppl + identifikasi_ppl_oleh utk
//    menandai siapa yang mengisi), jadi otomatis ter-update/sync juga di
//    tab Penyisiran Usaha tanpa sinkronisasi tambahan apa pun.
//  - "Monitoring Identifikasi PPL": rekap progres pengisian tab
//    Identifikasi PPL DI ATAS, per PPL -- pakai PIN & sesi yang SAMA
//    dengan tab Penyisiran Usaha (role "penyisiran", internal staf saja,
//    BUKAN utk dibagikan ke PPL).
//  - "Monitoring Petugas Penyisiran": rekap per petugas penyisiran (Nama |
//    Diidentifikasi Jorong | Diidentifikasi Tetangga/Lainnya | Didata |
//    Dikunjungi) -- pakai PIN/sesi yang sama jg. Ada fitur "Kelola Petugas
//    Penyisiran" (aktifkan/nonaktifkan akun) yang DEFAULT DISEMBUNYIKAN &
//    minta PIN lagi sebelum tombolnya aktif -- lihat
//    app/penyisiran/monitoring-petugas.tsx.
//  - "Alokasi Sampel": form rekomendasi wilayah tugas -- login PERSONAL
//    menumpang akun & role "penyisiran_petugas" YANG SAMA dgn tab
//    "Penyisiran Usaha" (token localStorage sama, jadi otomatis sudah
//    login kalau sudah login di tab itu). Isinya checklist maks 5 SLS/
//    Jorong, diurutkan skor prioritas akhir PERSONAL (beda tiap petugas,
//    krn faktor jarak dari lokasi rumah masing-masing) tertinggi ke
//    terendah -- rumus skor (Skor Sumber DUTP/DTSEN/PNM + Skor
//    Identifikasi Ada-PPL/Jorong/Keduanya + Bonus Volume potensi KK -
//    Penalti Jarak ke centroid SLS) SUDAH dikonfirmasi user, lihat migrasi
//    supabase/migrations/20260918_alokasi_sampel.sql. Sesudah submit,
//    matriks gabungan petugas x Jorong x Nagari x Kecamatan dimunculkan
//    (HANYA Jorong yg sudah dipilih min. 1 petugas -- lihat
//    app/penyisiran/alokasi-sampel.tsx).
//
// Tab "Penyisiran Usaha" jg punya tombol "📍 Tetapkan Lokasi Rumah Saya"
// (Geolocation API, disimpan ke petugas_penyisiran_akun.lat/lng lewat
// akun personal yg sedang login) utk skor prioritas berbasis jarak, dan
// tombol "🎯 Tandai Pasti" per kartu utk override manual skor prioritas
// jadi maksimal.
//
// Komponen sesungguhnya utk tab Penyisiran Usaha (PIN gate, daftar, peta)
// TETAP di app/seruti/penyisiran-usaha.tsx + penyisiran-map.tsx -- file
// itu sendiri sudah lepas dari tab bar Seruti, cuma nama foldernya belum
// dipindah (aman direname/dipindah manual nanti kalau mau lebih rapi,
// tidak wajib).

import { useCallback, useEffect, useRef, useState } from "react";
import PenyisiranUsahaTab, {
  apiFetch,
  getToken,
  IS_PML_KEY,
  NAMA_KEY,
  BUKA_FILTER_TAG_PML_KEY,
  LoginForm,
  simpanLoginPetugas,
  ModalRencanaBesok,
  TabelRencanaBesokHead,
  TabelRencanaBesokRow,
  type RencanaBesokRow,
} from "../seruti/penyisiran-usaha";
import { apakahIqbalHadi } from "@/lib/manajemenTargetAkses";
import IdentifikasiJorongTab from "./identifikasi-jorong";
import MonitoringPetugasTab from "./monitoring-petugas";
import MonitoringTerpaduTab from "./monitoring-terpadu";
import ManajemenTargetTab from "./manajemen-target";
import MasterPetugasTab from "./master-petugas";
import AdministrasiSpjTab from "./administrasi-spj";
import PerencanaanLapanganTab from "./perencanaan-lapangan";
import SelectCari from "@/app/components/SelectCari";

// "identifikasi" (Identifikasi PPL), "tetangga" (Identifikasi
// Tetangga/Lainnya), & "monitoring" (Monitoring Identifikasi PPL) SENGAJA
// DIHAPUS dari sini (permintaan user, "sudah tidak dipakai") -- tombol
// tab-nya jg dihapus di bawah (bukan cuma disembunyikan via CSS). File
// komponennya (identifikasi-ppl.tsx/identifikasi-tetangga.tsx/
// monitoring-ppl.tsx) TETAP ada di disk (tidak dihapus), cuma tidak lagi
// diimpor/dirender dari sini -- aman dikembalikan lagi nanti kalau perlu.
type TabKey =
  | "usaha"
  | "jorong"
  | "monitoring_petugas"
  | "monitoring_terpadu"
  | "target"
  | "master_petugas"
  | "spj"
  | "perencanaan";

// Gerbang login BERSAMA -- permintaan user "pindah tempat login sebelum
// masuk ke tab, kemudian setelah login otomatis masuk ke tab penyisiran" +
// "cukup 1 login dan semua bisa masuk menu sesuai role". SEBELUM ini, tab
// bar SELALU tampil (bisa diklik-klik walau belum login sama sekali) &
// SETIAP tab (Penyisiran Usaha/Identifikasi Jorong/Administrasi/dst)
// mengelola login sendiri-sendiri (kadang minta nama+tanggal lahir lagi
// walau akunnya SAMA) -- SEKARANG login terjadi SATU KALI di sini, di
// level halaman, SEBELUM tab bar & isi tab apa pun dirender. Begitu
// berhasil, tab default "usaha" (Penyisiran Usaha) langsung tampil --
// tab-tab lain yg akunnya SAMA (Identifikasi Jorong/Administrasi lewat
// token turunan, Perencanaan Lapangan/Master Petugas/Manajemen Target lewat
// key localStorage yg SAMA PERSIS, Monitoring Petugas Penyisiran/Monitoring
// lewat role "penyisiran_petugas" yg SEKARANG jg diterima backend-nya --
// lihat komentar di masing-masing file) otomatis ikut jalan TANPA login
// ulang, krn semuanya membaca localStorage yg sama & tidak lagi menampilkan
// form login sendiri (kondisinya sudah terpenuhi begitu gerbang ini lolos).
//
// LoginForm & simpanLoginPetugas diimpor dari app/seruti/penyisiran-usaha.tsx
// (SATU-SATUNYA form login personal petugas di seluruh app sekarang) --
// lihat komentar panjang di sana soal turunan otomatis token
// "identifikasi_jorong" (kecuali PML).
function useSudahLoginPetugas(): [boolean | null, () => void] {
  const [sudahLogin, setSudahLogin] = useState<boolean | null>(null);

  const cek = useCallback(() => {
    setSudahLogin(!!getToken());
  }, []);

  useEffect(() => {
    cek();
    // Poll ringan (pola sama dgn bar2 lain di halaman ini) -- supaya kalau
    // token dihapus dari DALAM salah satu tab (mis. tombol "Keluar" di tab
    // Penyisiran Usaha, atau kedaluwarsa), gerbang ini ikut kembali ke
    // layar login TANPA perlu reload manual (React 'storage' event TIDAK
    // terpicu utk perubahan dari tab/window yang sama, jadi polling adalah
    // satu-satunya cara praktis di sini). `cek` jg dipanggil LANGSUNG
    // (bukan nunggu polling) sesaat setelah login berhasil di bawah, spy
    // transisi ke tab bar terasa instan.
    const id = setInterval(cek, 30000);
    return () => clearInterval(id);
  }, [cek]);

  return [sudahLogin, cek];
}

export default function PenyisiranPage() {
  const [sudahLogin, cekUlangLogin] = useSudahLoginPetugas();

  // Default dibuka ke tab "Penyisiran Usaha" (internal BPS, dipakai
  // sehari-hari oleh tim) -- DIUBAH atas permintaan user dari default lama
  // "Identifikasi PPL" (link yg dibagikan ke PPL/mantan pendata biasanya
  // dibuka lewat link langsung ke tab itu, jadi tidak terlalu terpengaruh
  // tab default berubah). Tab "Administrasi" (SPJ) jg dipindah ke urutan
  // KEDUA (persis di samping "Penyisiran Usaha") -- lihat urutan TabButton
  // di bawah, BUKAN lagi di dekat "Perencanaan Lapangan" spt sebelumnya.
  // TETAP jadi default SETELAH login jg (lihat useSudahLoginPetugas di
  // atas) -- persis permintaan user "setelah login otomatis masuk ke tab
  // penyisiran".
  const [tab, setTab] = useState<TabKey>("usaha");

  if (sudahLogin === null) return null; // hindari kedip layar login sebelum cek localStorage

  if (!sudahLogin) {
    return (
      <main className="mx-auto flex min-h-screen max-w-sm flex-col items-center justify-center px-5 py-6">
        <div className="mb-4 text-center">
          <p className="font-sans text-[13px] font-black italic tracking-tight text-navy-900">
            BADAN PUSAT STATISTIK KABUPATEN SOLOK
          </p>
          <p className="mt-0.5 text-xs font-medium text-navy-400">
            Sensus Ekonomi 2026 &middot; Penyisiran Undercoverage Usaha
          </p>
        </div>
        <div className="w-full">
          <LoginForm
            onLoggedIn={(t, n, id, lat, lng, isPml) => {
              simpanLoginPetugas(t, n, id, lat, lng, isPml);
              setTab("usaha");
              cekUlangLogin(); // langsung tampilkan tab bar, tidak nunggu polling 30 detik
            }}
          />
        </div>
      </main>
    );
  }

  return (
    <main className="mx-auto min-h-screen max-w-6xl overflow-x-hidden px-5 py-6">
      {/* Floating warning "belum merencanakan 8 kunjungan besok" -- SENGAJA
          dipasang di sini (level halaman, LUAR blok {tab === "usaha" && ...}
          di bawah) supaya tampil di TAB MANA PUN petugas sedang berada,
          bukan cuma saat tab "Penyisiran Usaha" aktif -- lihat komentar
          panjang di RencanaBesokWarningBar. DIBUNGKUS bareng
          DitandaiPmlWarningBar (permintaan user: "warning muncul di layar
          ppl akibat ada flag, tambahkan tombol navigasi") dlm SATU wrapper
          fixed+flex-col spy tidak saling menumpuk kalau KEDUANYA aktif
          sekaligus -- pola sama dgn wrapper fixed+bottom utk 2 bar bawah
          di bawah ini. */}
      <div className="fixed inset-x-0 top-0 z-50 flex flex-col">
        <DitandaiPmlWarningBar
          onLihatFlag={() => {
            if (typeof window !== "undefined") localStorage.setItem(BUKA_FILTER_TAG_PML_KEY, "1");
            setTab("usaha");
          }}
        />
        <RencanaBesokWarningBar onRencanakan={() => setTab("usaha")} />
        {/* Warning "Monitoring Assignment FASIH" -- BARU, permintaan user:
            "tampilkan warning khusus akun saya M. Iqbal Hadi" -- lihat
            komentar panjang di FasihMismatchWarningBar di bawah. */}
        <FasihMismatchWarningBar onLihat={() => setTab("perencanaan")} />
      </div>
      {/* Bar BARU terpisah di BAWAH layar (permintaan user, SENGAJA bar
          TERPISAH dari RencanaBesokWarningBar di atas -- yg lama TETAP
          spt semula, cuma tampil saat BELUM 8/8) -- lihat komentar
          panjang di FloatBarRencanaBesok di bawah. DIBUNGKUS bareng
          FloatBarSpjBelumLengkap (bar KUNING BARU, permintaan user
          "diletakkan di bawah perencanaan 8 KK tadi") dlm SATU wrapper
          fixed+flex-col -- FloatBarSpjBelumLengkap ditaruh SESUDAHNYA
          (anak flex terakhir) supaya kalau dua2nya tampil sekaligus,
          bar SPJ ini yg nempel di tepi bawah layar & bar Rencana Besok
          persis di atasnya. Kalau salah satu return null, wrapper tetap
          rapat (tidak ada kotak kosong). */}
      <div className="fixed inset-x-0 bottom-0 z-40 flex flex-col">
        {/* Khusus akun PML (lihat komentar panjang di FloatBarDitandaiPml di
            bawah) -- mutually exclusive dgn 2 bar di bawahnya (keduanya
            return null utk sesi PML), jadi aman ditumpuk di wrapper yg sama. */}
        <FloatBarDitandaiPml />
        <FloatBarRencanaBesok />
        <FloatBarSpjBelumLengkap onBukaAdministrasi={() => setTab("spj")} />
      </div>
      <p className="font-sans text-[13px] font-black italic tracking-tight text-navy-900">
        BADAN PUSAT STATISTIK KABUPATEN SOLOK
      </p>
      <p className="mt-0.5 text-xs font-medium text-navy-400">
        Sensus Ekonomi 2026 &middot; Penyisiran Undercoverage Usaha
      </p>

      {/* overflow-x-auto + flex-nowrap (bukan flex-wrap) SENGAJA dipakai --
          dgn 6 tab & beberapa labelnya panjang ("Monitoring Petugas
          Penyisiran"), kalau dibiarkan flex biasa baris tab ini melebar
          menembus lebar layar & mendorong SELURUH halaman jadi lebih lebar
          dari layar HP (dilaporkan user: tampilan berantakan/tidak
          otomatis ikut lebar layar di HP). Dengan overflow-x-auto,
          kelebihan lebarnya digulir SENDIRI di baris tab ini saja (bisa
          digeser ke samping), tidak lagi memaksa seluruh halaman ikut
          melebar. shrink-0+whitespace-nowrap di TabButton mencegah label
          tab terpotong/mengecil. */}
      <div className="mt-4 flex gap-2 overflow-x-auto border-b border-line">
        <TabButton active={tab === "usaha"} onClick={() => setTab("usaha")}>
          Penyisiran Usaha
        </TabButton>
        {/* "Administrasi" -- SPJ Translok (Kwitansi/Surat Tugas/Visum/
            Laporan/Dokumentasi/Surat Keterangan). Login menumpang akun
            Identifikasi Jorong ATAU Tetangga (PPL tidak ikut), lihat
            komentar lengkap di administrasi-spj.tsx & lib/spjAuth.ts.
            DIPINDAH ke urutan kedua (persis di samping "Penyisiran Usaha")
            atas permintaan user -- sebelumnya di dekat "Perencanaan
            Lapangan" di ujung baris tab. */}
        <TabButton active={tab === "spj"} onClick={() => setTab("spj")}>
          Administrasi
        </TabButton>
        <TabButton active={tab === "jorong"} onClick={() => setTab("jorong")}>
          Identifikasi Jorong
        </TabButton>
        <TabButton active={tab === "monitoring_petugas"} onClick={() => setTab("monitoring_petugas")}>
          Monitoring Petugas Penyisiran
        </TabButton>
        {/* "Monitoring" (terpadu) -- tab BARU, gabungan 7 area monitoring
            lintas tab yg tadinya tersebar/belum ada (kualitas kunjungan,
            konsistensi lintas sumber identifikasi, realisasi vs rencana,
            kelengkapan SPJ, beban kerja petugas, progres vs tenggat,
            konflik alokasi PPL) -- lihat komentar lengkap di
            app/penyisiran/monitoring-terpadu.tsx. Pakai PIN/sesi yg sama
            dgn 2 tab Monitoring di atas. */}
        <TabButton active={tab === "monitoring_terpadu"} onClick={() => setTab("monitoring_terpadu")}>
          Monitoring
        </TabButton>
        {/* "Manajemen Target" -- tab BARU, ditaruh paling akhir (area
            internal BPS bukan utk PPL/tetangga). Tombolnya tampil ke SEMUA
            orang (sama spt tab lain), tapi ISINYA dibatasi ke 4 nama
            tertentu -- lihat komentar akses di
            app/penyisiran/manajemen-target.tsx. */}
        <TabButton active={tab === "target"} onClick={() => setTab("target")}>
          Manajemen Target
        </TabButton>
        {/* "Master Petugas" -- tab BARU, perluasan data petugas yg sudah
            ada (email/alamat/status kepegawaian/pengawas) -- lihat
            komentar akses & isi lengkap di app/penyisiran/master-petugas.tsx.
            Akses dibatasi ke 4 nama yg sama dgn "Manajemen Target". */}
        <TabButton active={tab === "master_petugas"} onClick={() => setTab("master_petugas")}>
          Master Petugas
        </TabButton>
        {/* "Perencanaan Lapangan" (dulu "Alokasi Sampel") -- tab BARU,
            2 bagian: (1) Identifikasi Hari Tugas (checklist hari dalam
            seminggu yg bisa turun bertugas) & (2) Identifikasi Wilayah
            Sampel SLS (checklist SLS/Jorong per petugas Penyisiran
            berdasarkan skor prioritas personal, jarak dari lokasi rumah
            petugas). Login menumpang akun & role "penyisiran_petugas" yg
            SAMA dgn tab "Penyisiran Usaha" (lihat komentar lengkap di
            perencanaan-lapangan.tsx). */}
        <TabButton active={tab === "perencanaan"} onClick={() => setTab("perencanaan")}>
          Perencanaan Lapangan
        </TabButton>
      </div>

      <div className="mt-4">
        {tab === "usaha" && <PenyisiranUsahaTab />}
        {tab === "jorong" && <IdentifikasiJorongTab />}
        {tab === "monitoring_petugas" && <MonitoringPetugasTab />}
        {tab === "monitoring_terpadu" && <MonitoringTerpaduTab />}
        {tab === "target" && <ManajemenTargetTab />}
        {tab === "master_petugas" && <MasterPetugasTab />}
        {tab === "spj" && <AdministrasiSpjTab />}
        {tab === "perencanaan" && <PerencanaanLapanganTab />}
      </div>
    </main>
  );
}

// Floating warning bar MERAH -- "ada X keluarga ditandai PML" (permintaan
// user: "warning muncul di layar ppl akibat ada flag, tambahkan tombol
// navigasi menuju daftar kk yang kena flag"). Beda dari banner StatTile yg
// sudah ada di dalam tab "Penyisiran Usaha" (app/seruti/penyisiran-
// usaha.tsx, cuma kelihatan saat tab itu aktif) -- bar INI dipasang di
// LEVEL HALAMAN (spt RencanaBesokWarningBar) supaya tampil di TAB MANA PUN
// PPL sedang berada (mis. sedang di tab Identifikasi Jorong), tidak
// menunggu PPL kebetulan membuka tab Penyisiran Usaha dulu baru sadar ada
// flag. HANYA utk akun BUKAN PML (PML sendiri yg membuat tanda, tidak
// perlu diingatkan soal tandanya sendiri) & TIDAK dibatasi jam 17:00 (beda
// dari RencanaBesokWarningBar) krn sifat "perlu segera" tidak menunggu sore.
//
// Tombol "Lihat →" TIDAK bisa langsung membuka filter dari sini (state
// filterTagPml ada jauh di dalam PenyisiranPanel, komponen anak yg beda),
// jadi dipakai sinyal localStorage sekali-pakai (BUKA_FILTER_TAG_PML_KEY,
// lihat komentar panjangnya di app/seruti/penyisiran-usaha.tsx) yg diset
// oleh `onLihatFlag` (diteruskan dari PenyisiranPage) TEPAT SEBELUM pindah
// tab ke "usaha" -- PenyisiranPanel membaca & menyalakan filter itu sendiri
// begitu mount.
function DitandaiPmlWarningBar({ onLihatFlag }: { onLihatFlag: () => void }) {
  const [checked, setChecked] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [isPml, setIsPml] = useState(false);
  const [jumlah, setJumlah] = useState<number | null>(null);

  useEffect(() => {
    function bacaStorage() {
      setToken(getToken());
      setIsPml(typeof window !== "undefined" && localStorage.getItem(IS_PML_KEY) === "1");
      setChecked(true);
    }
    bacaStorage();
    const id = setInterval(bacaStorage, 30000);
    return () => clearInterval(id);
  }, []);

  const muat = useCallback(() => {
    if (!token || isPml) {
      setJumlah(null);
      return;
    }
    apiFetch("/api/penyisiran/summary", token)
      .then((data) => setJumlah(typeof data?.ditandai_pml === "number" ? data.ditandai_pml : null))
      .catch(() => setJumlah(null));
  }, [token, isPml]);

  useEffect(() => {
    muat();
    const id = setInterval(muat, 30000);
    return () => clearInterval(id);
  }, [muat]);

  // Dengar event yg SAMA dgn bar lain -- RowCard men-dispatch ini tiap kali
  // SATU PUN field tersimpan, jadi bar ini ikut update mendekati real-time
  // begitu PML menandai/membatalkan 🚩, tanpa menunggu polling 30 detik.
  useEffect(() => {
    window.addEventListener("penyisiran:rencana-besok-changed", muat);
    return () => window.removeEventListener("penyisiran:rencana-besok-changed", muat);
  }, [muat]);

  if (!checked || !token || isPml || !jumlah) return null;

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 bg-red-700 px-4 py-2 text-center text-xs font-medium text-white shadow-md">
      <span>
        🚩 Ada {jumlah} keluarga ditandai PML &middot; perlu segera didata.
      </span>
      <button
        type="button"
        onClick={onLihatFlag}
        className="shrink-0 rounded-md bg-white px-2.5 py-1 text-[11px] font-semibold text-red-700 hover:bg-red-50"
      >
        Lihat daftarnya →
      </button>
    </div>
  );
}

// Floating warning bar "Monitoring Assignment FASIH" -- permintaan
// lanjutan user atas fitur di tab Perencanaan Lapangan
// (FasihAssignmentPanel/app/penyisiran/perencanaan-lapangan.tsx): "kalau
// ada perbedaan [antara data FASIH yang tersimpan vs "📋 Identifikasi
// Wilayah Sampel SLS" di sistem], tampilkan warning KHUSUS akun saya
// M. Iqbal Hadi -- warning hilang begitu sudah timpa-menimpa match antara
// aplikasi web vs data upload assignment FASIH". Pola SAMA PERSIS dgn
// DitandaiPmlWarningBar di atas (bar level HALAMAN, poll localStorage +
// endpoint tiap 30 detik, tampil di TAB MANA PUN) -- BEDANYA cuma 2:
//  1. Gerbangnya BUKAN "bukan PML" tapi apakahIqbalHadi(nama) --
//     lib/manajemenTargetAkses.ts. Endpoint-nya sendiri (GET
//     /api/penyisiran/alokasi/fasih-compare) tetap boleh dipanggil ke-7
//     pengelola (bolehAksesManajemenTarget di server), tapi BANNER ini
//     sengaja dibatasi 1 akun sesuai permintaan -- pengelola lain tetap
//     bisa lihat hasilnya lewat panel di tab Perencanaan Lapangan sendiri,
//     cuma tidak dapat notifikasi ambient spt ini.
//  2. "Warning hilang begitu sudah timpa-menimpa match" TIDAK perlu logika
//     khusus -- endpoint SELALU menghitung ulang dari data live (tabel
//     penyisiran_fasih_assignment vs penyisiran_alokasi_pilihan SEKARANG),
//     jadi begitu salah satu sisi berubah sampai cocok lagi, polling
//     berikutnya (maks 30 detik) otomatis mengembalikan jumlah 0 & bar ini
//     otomatis hilang sendiri -- tidak ada state "sudah dibaca"/dismiss.
function FasihMismatchWarningBar({ onLihat }: { onLihat: () => void }) {
  const [checked, setChecked] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [tampil, setTampil] = useState(false);
  const [jumlah, setJumlah] = useState(0);

  useEffect(() => {
    function bacaStorage() {
      const t = getToken();
      const nama = typeof window !== "undefined" ? localStorage.getItem(NAMA_KEY) : null;
      setToken(t);
      setTampil(!!t && apakahIqbalHadi(nama));
      setChecked(true);
    }
    bacaStorage();
    const id = setInterval(bacaStorage, 30000);
    return () => clearInterval(id);
  }, []);

  const muat = useCallback(() => {
    if (!token || !tampil) {
      setJumlah(0);
      return;
    }
    apiFetch("/api/penyisiran/alokasi/fasih-compare", token)
      .then((data) => {
        const r = data?.ringkasan;
        const total =
          (Number(r?.jumlah_belum_di_fasih) || 0) +
          (Number(r?.jumlah_sudah_tidak_ada_di_sistem) || 0) +
          (Number(r?.jumlah_beda_pencacah) || 0);
        setJumlah(total);
      })
      .catch(() => setJumlah(0));
  }, [token, tampil]);

  useEffect(() => {
    muat();
    const id = setInterval(muat, 30000);
    return () => clearInterval(id);
  }, [muat]);

  if (!checked || !tampil || jumlah === 0) return null;

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 bg-amber-600 px-4 py-2 text-center text-xs font-medium text-white shadow-md">
      <span>🔄 Ada {jumlah} selisih data Assignment FASIH vs sistem &middot; perlu dicek.</span>
      <button
        type="button"
        onClick={onLihat}
        className="shrink-0 rounded-md bg-white px-2.5 py-1 text-[11px] font-semibold text-amber-700 hover:bg-amber-50"
      >
        Lihat →
      </button>
    </div>
  );
}

// Floating warning bar "belum merencanakan 8 kunjungan besok" -- muncul
// OTOMATIS mulai jam 17.00 (WIB, dari jam browser petugas -- app ini
// dipakai internal BPS Kab Solok, semua di WIB, sama spt pola jam lain di
// app ini yg tidak konversi TZ eksplisit di FE) kalau kuota harian (8
// keluarga berstatus "Jadwalkan Besok" utk BESOK) belum tercapai. HANYA
// utk akun "penyisiran_petugas" (login personal tab Penyisiran Usaha) yg
// BUKAN PML (PML tidak pernah mengisi status/menjadwalkan sendiri, lihat
// komentar isPml di app/seruti/penyisiran-usaha.tsx) -- kalau belum login
// sama sekali/PIN admin/role identifikasi_* lain, bar ini tidak tampil.
//
// Dipasang di LEVEL HALAMAN (bukan di dalam tab Penyisiran Usaha) supaya
// tetap kelihatan di tab mana pun petugas sedang bekerja (mis. sedang di
// tab Identifikasi Jorong) -- makanya komponen ini baca localStorage &
// panggil /api/penyisiran/summary SENDIRI (lewat getToken/apiFetch yg
// diekspor dari app/seruti/penyisiran-usaha.tsx, bukan duplikat logika),
// bukan menerima token lewat props dari tab manapun.
//
// Login/logout terjadi di komponen SAUDARA (tab Penyisiran Usaha) yg
// tidak otomatis memicu render ulang bar ini -- makanya localStorage
// dipoll ringan tiap 30 detik (bukan cuma sekali saat mount), cukup utk
// warning ambient spt ini (bukan kebutuhan real-time).
function RencanaBesokWarningBar({ onRencanakan }: { onRencanakan: () => void }) {
  const KUOTA = 8;
  const [checked, setChecked] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [isPml, setIsPml] = useState(false);
  const [jumlah, setJumlah] = useState<number | null>(null);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    function bacaStorage() {
      setToken(getToken());
      setIsPml(typeof window !== "undefined" && localStorage.getItem(IS_PML_KEY) === "1");
      setChecked(true);
    }
    bacaStorage();
    const id = setInterval(bacaStorage, 30000);
    return () => clearInterval(id);
  }, []);

  // Jam SAAT INI -- dicek ulang tiap 30 detik jg, supaya bar ini otomatis
  // muncul begitu jam menyentuh 17.00 tanpa perlu reload halaman.
  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 30000);
    return () => clearInterval(id);
  }, []);

  // Kuota "direncanakan_besok" -- dari RPC yg SAMA dipakai StatTile "📅
  // Dijadwalkan Besok" di tab Penyisiran Usaha (lihat migrasi
  // 20260920_penyisiran_jadwalkan_besok.sql), jadi angkanya SELALU
  // konsisten dgn yg dilihat petugas di tab itu. Dimuat ulang tiap kali
  // token berubah & diulang tiap 2 menit selama sesi aktif.
  useEffect(() => {
    if (!token || isPml) {
      setJumlah(null);
      return;
    }
    let batal = false;
    function muat() {
      apiFetch("/api/penyisiran/summary", token as string)
        .then((data) => {
          if (!batal) setJumlah(typeof data?.direncanakan_besok === "number" ? data.direncanakan_besok : null);
        })
        .catch(() => {
          if (!batal) setJumlah(null);
        });
    }
    muat();
    const id = setInterval(muat, 120000);
    return () => {
      batal = true;
      clearInterval(id);
    };
  }, [token, isPml]);

  if (!checked || !token || isPml || jumlah == null) return null;

  const jamSekarang = new Date(nowMs).getHours();
  if (jamSekarang < 17 || jumlah >= KUOTA) return null;

  // "fixed inset-x-0 top-0 z-50" DIPINDAH ke wrapper pembungkus di
  // PenyisiranPage (bareng DitandaiPmlWarningBar) -- div INI SENDIRI
  // sekarang cuma elemen flex biasa spy 2 bar atas bisa ditumpuk rapi
  // pakai flex-col, tidak saling menimpa di posisi fixed yg sama.
  return (
    <div className="flex flex-wrap items-center justify-center gap-2 bg-rust-700 px-4 py-2 text-center text-xs font-medium text-white shadow-md">
      <span>
        ⚠ Kamu belum merencanakan {KUOTA} kunjungan untuk besok (baru {jumlah}/{KUOTA}).
      </span>
      <button
        type="button"
        onClick={onRencanakan}
        className="shrink-0 rounded-md bg-white px-2.5 py-1 text-[11px] font-semibold text-rust-700 hover:bg-rust-50"
      >
        Rencanakan →
      </button>
    </div>
  );
}

// Bar BARU (permintaan user) di BAWAH layar, TERPISAH dari
// RencanaBesokWarningBar di atas (yg TETAP spt semula -- cuma tampil saat
// BELUM 8/8, mulai jam 17:00). Bar ini:
//  - Tampil SELALU jam 17:00-23:59 (bukan cuma saat belum tercapai), warna
//    berubah sesuai progres (merah <50%, kuning 50-99%, hijau 100%+) --
//    padam sendiri jam 00:00-16:59 (jamSekarang<17, sama spt bar di atas).
//  - Angka "x/8" ini SELALU per PETUGAS YANG LOGIN SAJA (dari RPC
//    penyisiran_summary_wilayah, wilayah personal petugas ybs) -- BUKAN
//    direkap per SLS/Kecamatan (sesuai permintaan user).
//  - Update MENDEKATI real-time: selain polling 30 detik spt bar di atas,
//    jg mendengarkan custom event "penyisiran:rencana-besok-changed" yg
//    di-dispatch RowCard (app/seruti/penyisiran-usaha.tsx) SETIAP KALI
//    checklist berhasil disimpan -- begitu ada kartu yg statusnya berubah
//    jadi/dari "Dijadwalkan Besok", angka di bar ini langsung diperbarui
//    tanpa menunggu interval polling berikutnya.
//  - Tombol "📤 Kirim ke WA PML": DI HP (yg dukung Web Share API dgn file --
//    Chrome Android, Safari iOS 15+), pakai navigator.share() supaya
//    gambar rencana besok LANGSUNG "nempel" siap dikirim persis spt share
//    bukti transfer dari BRImo/aplikasi bank -- layar Share bawaan HP
//    kebuka, user tinggal ketuk ikon WhatsApp, PILIH chat PML-nya (WhatsApp
//    SENGAJA mewajibkan ini, BUKAN sesuatu yg bisa dilewati/diotomatisasi
//    dari web manapun termasuk BRImo -- itu jg cuma share ke OS, bukan
//    kirim otomatis), gambar SUDAH terpasang di kotak chat, tinggal tekan
//    Kirim. TIDAK ADA LAGI langkah salin-tempel manual di jalur ini.
//    Kalau Web Share API dgn file TIDAK didukung (kebanyakan browser
//    desktop) atau gagal/dibatalkan karena sebab lain, jatuh ke cara LAMA:
//    salin gambar ke clipboard (html2canvas, pola SAMA dgn
//    ModalRencanaBesok) + buka tab WhatsApp ke nomor PML (dari kolom
//    "No. HP" Master Petugas, via pengawas_id -- lihat
//    /api/penyisiran/summary) -- di jalur fallback ini tersisa SATU
//    langkah manual: klik kotak chat lalu Ctrl+V (atau tekan-tahan lalu
//    Tempel di HP), baru Kirim.
function FloatBarRencanaBesok() {
  const KUOTA = 8;
  const [checked, setChecked] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [isPml, setIsPml] = useState(false);
  const [jumlah, setJumlah] = useState<number | null>(null);
  const [pmlNama, setPmlNama] = useState<string | null>(null);
  const [pmlNoHp, setPmlNoHp] = useState<string | null>(null);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  // "selesai_share" (JALUR 1, Web Share API) vs "selesai_salin" (JALUR 2,
  // fallback clipboard) DIBEDAKAN krn pesan sukses ke user beda -- lihat
  // kirimKeWaPml & label tombol di bawah.
  const [kirimStatus, setKirimStatus] = useState<
    "idle" | "menyiapkan" | "selesai_share" | "selesai_salin" | "error"
  >("idle");
  // Modal "📅 Dijadwalkan Besok" (komponen ASLI yg sama dgn StatTile di tab
  // Penyisiran Usaha, diimpor -- BUKAN diduplikasi) -- SEKARANG ikut dibuka
  // saat tombol "Kirim ke WA" ditekan (permintaan user: "keluar modalnya yg
  // di atas, karena gambar itu lebih bagus"), supaya petugas bisa LIHAT
  // dulu daftarnya sebelum/sambil gambar disalin & tab WA terbuka.
  const [showModal, setShowModal] = useState(false);
  const gambarRef = useRef<HTMLDivElement | null>(null);
  // Baris utk gambar off-screen -- SENGAJA dimuat bersamaan dgn `jumlah`
  // (poll periodik yg sama, lihat muatRingkasan di bawah), BUKAN baru
  // di-fetch saat tombol "Kirim ke WA" ditekan -- supaya gambarRef SUDAH
  // ter-render duluan & html2canvas bisa langsung dipanggil synchronous
  // dari klik tombol, tanpa race condition menunggu fetch+render selesai.
  // Tipe baris & tanggal SEKARANG SAMA PERSIS dgn ModalRencanaBesok
  // (RencanaBesokRow, bukan bentuk ringkas {kode_identitas,idsubsls,nama}
  // spt sebelumnya) -- permintaan user: desain gambar WA harus SAMA PERSIS
  // dgn gambar di modal itu (ada subjudul Nagari/SLS di bawah nama tiap
  // baris), makanya komponen tabelnya (TabelRencanaBesokHead/Row) diimpor
  // LANGSUNG dari sana, bukan ditulis ulang.
  const [rowsUntukGambar, setRowsUntukGambar] = useState<RencanaBesokRow[]>([]);
  const [tanggalRencana, setTanggalRencana] = useState<string | null>(null);

  useEffect(() => {
    function bacaStorage() {
      setToken(getToken());
      setIsPml(typeof window !== "undefined" && localStorage.getItem(IS_PML_KEY) === "1");
      setChecked(true);
    }
    bacaStorage();
    const id = setInterval(bacaStorage, 30000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 30000);
    return () => clearInterval(id);
  }, []);

  const muatRingkasan = useCallback(() => {
    if (!token || isPml) {
      setJumlah(null);
      return;
    }
    apiFetch("/api/penyisiran/summary", token)
      .then((data) => {
        setJumlah(typeof data?.direncanakan_besok === "number" ? data.direncanakan_besok : null);
        setPmlNama(typeof data?.pml_nama === "string" ? data.pml_nama : null);
        setPmlNoHp(typeof data?.pml_no_hp === "string" ? data.pml_no_hp : null);
      })
      .catch(() => {
        setJumlah(null);
      });
    apiFetch("/api/penyisiran/rencana-besok", token)
      .then((data) => {
        setRowsUntukGambar(Array.isArray(data?.rows) ? data.rows : []);
        setTanggalRencana(typeof data?.tanggal === "string" ? data.tanggal : null);
      })
      .catch(() => {
        setRowsUntukGambar([]);
        setTanggalRencana(null);
      });
  }, [token, isPml]);

  // SAMA PERSIS dgn tanggalLabel() di ModalRencanaBesok (app/seruti/
  // penyisiran-usaha.tsx) -- diulang di sini (bukan diekspor, cuma beberapa
  // baris) supaya judul gambar off-screen di bawah konsisten formatnya.
  function tanggalLabel(): string {
    if (!tanggalRencana) return "besok";
    const [y, m, d] = tanggalRencana.split("-").map(Number);
    if (!y || !m || !d) return tanggalRencana;
    return new Date(y, m - 1, d).toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" });
  }

  useEffect(() => {
    muatRingkasan();
    const id = setInterval(muatRingkasan, 30000);
    return () => clearInterval(id);
  }, [muatRingkasan]);

  // Dengar event real-time dari RowCard -- lihat komentar panjang di atas.
  useEffect(() => {
    window.addEventListener("penyisiran:rencana-besok-changed", muatRingkasan);
    return () => window.removeEventListener("penyisiran:rencana-besok-changed", muatRingkasan);
  }, [muatRingkasan]);

  function nomorWaInternasional(raw: string): string {
    const digit = raw.replace(/\D/g, "");
    if (digit.startsWith("62")) return digit;
    if (digit.startsWith("0")) return `62${digit.slice(1)}`;
    return digit;
  }

  // Catat ke server bahwa gambar rencana besok BERHASIL dibagikan/disalin
  // hari ini (permintaan user: kolom "Kirim Rencana Besok" di kartu #1 tab
  // Monitoring) -- "fire and forget", TIDAK menunggu/menggagalkan alur
  // kirim/salin gambar yg sedang berjalan kalau endpoint ini error (sekadar
  // bookkeeping, bukan bagian inti fitur). Lihat komentar lengkap di
  // /api/penyisiran/rencana-besok-kirim/route.ts.
  function catatTerkirim(metode: "share" | "salin") {
    if (!token) return;
    apiFetch("/api/penyisiran/rencana-besok-kirim", token, {
      method: "POST",
      body: JSON.stringify({ metode }),
    }).catch(() => {
      // Sengaja diabaikan -- lihat komentar di atas.
    });
  }

  async function kirimKeWaPml() {
    // Buka modal ASLI "📅 Dijadwalkan Besok" sekalian (permintaan user) --
    // TIDAK menunggu ini selesai sebelum lanjut menyiapkan gambar (dua-duanya
    // jalan bersamaan: modal utk dilihat, share/clipboard+tab WA di bawah).
    setShowModal(true);
    if (!gambarRef.current) return;
    setKirimStatus("menyiapkan");
    try {
      const html2canvas = (await import("html2canvas")).default;
      const canvas = await html2canvas(gambarRef.current, { backgroundColor: "#ffffff", scale: 2 });
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (!blob) {
        setKirimStatus("error");
        setTimeout(() => setKirimStatus("idle"), 2500);
        return;
      }

      // Rakit nama file gambar sekali di sini (dipakai JALUR 1 di bawah).

      // JALUR 1 (lebih baik, tapi cuma didukung browser HP): Web Share API
      // dgn file gambar -- lihat komentar panjang di atas komponen ini soal
      // kenapa ini bikin pengalamannya SAMA spt share bukti tf dari BRImo,
      // & kenapa WhatsApp TETAP minta pilih chat sendiri (bukan kurangnya
      // implementasi di sini). navigator.canShare dicek dulu krn beberapa
      // browser PUNYA navigator.share tapi TIDAK mendukung { files }.
      const file = new File([blob], `rencana-besok-${tanggalRencana || "besok"}.png`, { type: "image/png" });
      const dukungShareFile =
        typeof navigator.share === "function" &&
        typeof navigator.canShare === "function" &&
        navigator.canShare({ files: [file] });

      if (dukungShareFile) {
        try {
          await navigator.share({ files: [file], title: `Rencana Kunjungan ${tanggalLabel()}` });
          setKirimStatus("selesai_share");
          catatTerkirim("share");
          setTimeout(() => setKirimStatus("idle"), 4000);
          return;
        } catch (err) {
          // User menekan "Batal" di layar Share bawaan HP -- BUKAN error,
          // hormati pembatalan itu, JANGAN lanjut ke jalur 2 (nanti malah
          // tetap buka tab WA padahal user memang tidak jadi kirim).
          if (err instanceof Error && err.name === "AbortError") {
            setKirimStatus("idle");
            return;
          }
          // Gagal karena sebab lain (jarang) -> lanjut ke JALUR 2 di bawah.
        }
      }

      // JALUR 2 (fallback -- desktop, atau Web Share API gagal): cara LAMA,
      // salin gambar ke clipboard + buka tab WA ke nomor PML. Tab WA tetap
      // dibuka meski clipboard gagal -- user tinggal pakai tombol "Salin
      // sebagai Gambar" di modal 📅 Dijadwalkan Besok sbg cadangan.
      let disalin = false;
      try {
        await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
        disalin = true;
      } catch {
        disalin = false;
      }
      if (pmlNoHp) {
        const nomor = nomorWaInternasional(pmlNoHp);
        window.open(`https://wa.me/${nomor}`, "_blank", "noopener,noreferrer");
      }

      if (disalin) catatTerkirim("salin");
      setKirimStatus(disalin ? "selesai_salin" : "error");
      setTimeout(() => setKirimStatus("idle"), 4000);
    } catch {
      setKirimStatus("error");
      setTimeout(() => setKirimStatus("idle"), 2500);
    }
  }

  if (!checked || !token || isPml || jumlah == null) return null;

  const jamSekarang = new Date(nowMs).getHours();
  if (jamSekarang < 17) return null;

  const pct = jumlah / KUOTA;
  // Latar bar SOLID PUTIH (permintaan user) -- warna status (hijau/kuning/
  // merah) SEBELUMNYA ada di latar bar penuh, sekarang dipindah ke teks/
  // ikon supaya tetap kelihatan status-nya tanpa latar berwarna.
  const warnaTeks = pct >= 1 ? "text-moss-700" : pct >= 0.5 ? "text-[#8A6A12]" : "text-rust-700";

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 border-t border-line bg-white px-4 py-2 text-center text-xs font-medium shadow-md">
      <span className={`font-semibold ${warnaTeks}`}>
        📅 Rencana Besok: {jumlah}/{KUOTA}
      </span>
      {pmlNoHp ? (
        <button
          type="button"
          onClick={kirimKeWaPml}
          disabled={kirimStatus === "menyiapkan"}
          className="shrink-0 rounded-md bg-navy-700 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-navy-900 disabled:opacity-60"
        >
          {kirimStatus === "menyiapkan"
            ? "Menyiapkan..."
            : kirimStatus === "selesai_share"
            ? "✓ Dibagikan -- pilih chat WA & tekan Kirim"
            : kirimStatus === "selesai_salin"
            ? "✓ Tersalin -- tempel (Ctrl+V) di WA"
            : kirimStatus === "error"
            ? "Gagal, coba lagi"
            : `📤 Kirim ke WA ${pmlNama ?? "PML"}`}
        </button>
      ) : (
        <span className="text-[10px] italic text-ink/40">
          (Nomor WA PML belum diisi di Master Petugas)
        </span>
      )}

      {/* Klon tersembunyi off-screen utk html2canvas -- diisi
          `rowsUntukGambar` (dipoll bersamaan dgn `jumlah`, lihat
          muatRingkasan di atas, supaya SUDAH ter-render duluan saat
          tombol "Kirim ke WA" ditekan). Markup tabel (judul + head + baris)
          SEKARANG memakai komponen ASLI yg SAMA dgn ModalRencanaBesok
          (TabelRencanaBesokHead/TabelRencanaBesokRow, diimpor) -- permintaan
          user, supaya desain gambarnya PERSIS sama (ada subjudul Nagari/SLS
          di bawah nama tiap baris), bukan versi ringkas terpisah spt
          sebelumnya. */}
      <div style={{ position: "fixed", top: -99999, left: -99999, width: 640 }}>
        <div ref={gambarRef} className="bg-white p-4">
          <p className="mb-2 text-sm font-bold text-navy-900">
            Rencana Kunjungan {tanggalLabel()} -- Penyisiran Undercoverage Usaha SE2026
          </p>
          <table className="w-full text-xs">
            <TabelRencanaBesokHead />
            <tbody>
              {rowsUntukGambar.map((r) => (
                <TabelRencanaBesokRow key={r.kode_identitas} row={r} />
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal ASLI "📅 Dijadwalkan Besok" -- ikut terbuka begitu tombol
          "Kirim ke WA" ditekan (lihat kirimKeWaPml), supaya petugas bisa
          lihat daftarnya jg (bukan cuma tersalin diam2 ke clipboard). Modal
          ini fetch data sendiri (independen dari rowsUntukGambar di atas). */}
      {showModal && (
        <ModalRencanaBesok
          token={token}
          onClose={() => setShowModal(false)}
          onSessionExpired={() => setToken(null)}
        />
      )}
    </div>
  );
}

interface PplDiawasi {
  petugas_id: number;
  nama: string;
  no_hp: string | null;
}

// Bar BARU (permintaan user: "DARI PML, kirim daftar flag ke PPL MIRIP
// DENGAN KIRIM RENCANAKAN BESOK DARI PPL") -- KEBALIKAN dari
// FloatBarRencanaBesok di atas: itu PPL->PML (rencana kunjungan besok),
// ini PML->PPL (daftar keluarga yg ditandai 🚩 "Perlu Segera", tag_pml).
// Pola kirimnya SENGAJA disamakan persis (Web Share API dgn file gambar +
// fallback salin clipboard/buka tab WA) -- lihat komentar panjang di
// FloatBarRencanaBesok soal kenapa dua jalur itu diperlukan, TIDAK diulang
// di sini.
//
// Beda dari FloatBarRencanaBesok:
//  - TIDAK dibatasi jam 17:00 -- kartu yg ditandai PML sifatnya "perlu
//    segera", jadi bar ini tampil kapan saja selama masih ada >=1 baris
//    tag_pml=true (jumlah>0) di wilayah PML ybs.
//  - Daftar isi gambar = SEMUA baris tag_pml=true di SELURUH wilayah tim
//    PML (gabungan wilayah SELURUH PPL yg diawasi, lihat /api/penyisiran/
//    list?tag_pml=1 & daftarIdUntukSesi) -- BUKAN dipilah per-PPL (belum
//    ada cara murah memetakan tiap baris ke SATU PPL spesifik pemilik
//    Sub SLS itu, beda dgn skema alokasi "Kontak PPL Wilayah Ini" yg pakai
//    tabel lain). PML memilih SENDIRI PPL tujuan lewat dropdown (kalau
//    mengawasi >1 PPL) -- sama spt WhatsApp yg toh selalu minta pilih chat
//    tujuan sendiri, jadi tidak menambah langkah manual yg baru.
//  - Nomor WA & nama PPL tujuan dari field BARU `ppl_diawasi`
//    (/api/penyisiran/summary, KEBALIKAN dari pml_nama/pml_no_hp yg sudah
//    ada) -- diisi dari kolom No. HP di Master Petugas, PERSIS sumber yg
//    sama dgn pml_no_hp.
function FloatBarDitandaiPml() {
  const [checked, setChecked] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [isPml, setIsPml] = useState(false);
  const [jumlah, setJumlah] = useState<number | null>(null);
  const [pplDiawasi, setPplDiawasi] = useState<PplDiawasi[]>([]);
  const [pplTerpilih, setPplTerpilih] = useState<number | null>(null);
  const [kirimStatus, setKirimStatus] = useState<
    "idle" | "menyiapkan" | "selesai_share" | "selesai_salin" | "error"
  >("idle");
  const gambarRef = useRef<HTMLDivElement | null>(null);
  const [rowsUntukGambar, setRowsUntukGambar] = useState<RencanaBesokRow[]>([]);

  useEffect(() => {
    function bacaStorage() {
      setToken(getToken());
      setIsPml(typeof window !== "undefined" && localStorage.getItem(IS_PML_KEY) === "1");
      setChecked(true);
    }
    bacaStorage();
    const id = setInterval(bacaStorage, 30000);
    return () => clearInterval(id);
  }, []);

  const muatRingkasan = useCallback(() => {
    if (!token || !isPml) {
      setJumlah(null);
      return;
    }
    apiFetch("/api/penyisiran/summary", token)
      .then((data) => {
        setJumlah(typeof data?.ditandai_pml === "number" ? data.ditandai_pml : null);
        const daftar: PplDiawasi[] = Array.isArray(data?.ppl_diawasi) ? data.ppl_diawasi : [];
        setPplDiawasi(daftar);
        // Pertahankan pilihan PPL yg sedang aktif kalau masih ada di daftar
        // terbaru (mis. abis di-Master Petugas nya no_hp-nya baru diisi) --
        // cuma reset ke PPL pertama kalau pilihan lama sudah tidak valid.
        setPplTerpilih((prev) => {
          if (prev != null && daftar.some((p) => p.petugas_id === prev)) return prev;
          return daftar.length > 0 ? daftar[0].petugas_id : null;
        });
      })
      .catch(() => setJumlah(null));
    // Isi gambar: SEMUA baris tag_pml=true di wilayah tim PML -- endpoint yg
    // SAMA dgn filter toggle "🚩 Ditandai PML" di tab Penyisiran Usaha
    // (app/seruti/penyisiran-usaha.tsx), supaya daftar yg dikirim via WA
    // SELALU konsisten dgn yg kelihatan kalau PML membuka filter itu sendiri.
    apiFetch("/api/penyisiran/list?tag_pml=1", token)
      .then((data) => {
        setRowsUntukGambar(Array.isArray(data?.rows) ? data.rows : []);
      })
      .catch(() => setRowsUntukGambar([]));
  }, [token, isPml]);

  useEffect(() => {
    muatRingkasan();
    const id = setInterval(muatRingkasan, 30000);
    return () => clearInterval(id);
  }, [muatRingkasan]);

  // Dengar event yg SAMA dgn FloatBarRencanaBesok -- RowCard men-dispatch
  // ini tiap kali SATU PUN field tersimpan (bukan cuma rencana besok), jadi
  // ikut memperbarui bar ini mendekati real-time begitu PML menandai/
  // membatalkan 🚩 dari kartu manapun, tanpa menunggu polling 30 detik.
  useEffect(() => {
    window.addEventListener("penyisiran:rencana-besok-changed", muatRingkasan);
    return () => window.removeEventListener("penyisiran:rencana-besok-changed", muatRingkasan);
  }, [muatRingkasan]);

  function nomorWaInternasional(raw: string): string {
    const digit = raw.replace(/\D/g, "");
    if (digit.startsWith("62")) return digit;
    if (digit.startsWith("0")) return `62${digit.slice(1)}`;
    return digit;
  }

  async function kirimKeWaPpl() {
    const ppl = pplDiawasi.find((p) => p.petugas_id === pplTerpilih);
    if (!gambarRef.current) return;
    setKirimStatus("menyiapkan");
    try {
      const html2canvas = (await import("html2canvas")).default;
      const canvas = await html2canvas(gambarRef.current, { backgroundColor: "#ffffff", scale: 2 });
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
      if (!blob) {
        setKirimStatus("error");
        setTimeout(() => setKirimStatus("idle"), 2500);
        return;
      }

      const file = new File([blob], `ditandai-pml-${new Date().toISOString().slice(0, 10)}.png`, {
        type: "image/png",
      });
      const dukungShareFile =
        typeof navigator.share === "function" &&
        typeof navigator.canShare === "function" &&
        navigator.canShare({ files: [file] });

      if (dukungShareFile) {
        try {
          await navigator.share({ files: [file], title: "Daftar Ditandai PML - Perlu Segera" });
          setKirimStatus("selesai_share");
          setTimeout(() => setKirimStatus("idle"), 4000);
          return;
        } catch (err) {
          if (err instanceof Error && err.name === "AbortError") {
            setKirimStatus("idle");
            return;
          }
          // Gagal karena sebab lain -> lanjut ke jalur fallback di bawah.
        }
      }

      let disalin = false;
      try {
        await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
        disalin = true;
      } catch {
        disalin = false;
      }
      if (ppl?.no_hp) {
        const nomor = nomorWaInternasional(ppl.no_hp);
        window.open(`https://wa.me/${nomor}`, "_blank", "noopener,noreferrer");
      }

      setKirimStatus(disalin ? "selesai_salin" : "error");
      setTimeout(() => setKirimStatus("idle"), 4000);
    } catch {
      setKirimStatus("error");
      setTimeout(() => setKirimStatus("idle"), 2500);
    }
  }

  if (!checked || !token || !isPml || !jumlah) return null;

  const pplAktif = pplDiawasi.find((p) => p.petugas_id === pplTerpilih) ?? null;

  return (
    <div className="flex flex-wrap items-center justify-center gap-2 border-t border-red-300 bg-red-50 px-4 py-2 text-center text-xs font-medium shadow-md">
      <span className="font-semibold text-red-700">🚩 Ditandai PML: {jumlah} keluarga perlu segera didata</span>

      {/* Dropdown pemilih PPL tujuan -- cuma tampil kalau PML mengawasi
          LEBIH DARI 1 PPL (kalau cuma 1, langsung dipakai tanpa perlu
          dipilih, lihat pplTerpilih default di muatRingkasan). */}
      {pplDiawasi.length > 1 && (
        <SelectCari
          value={pplTerpilih ?? ""}
          onChange={(e) => setPplTerpilih(Number(e.target.value))}
          className="rounded-md border border-red-300 bg-white px-2 py-1 text-[11px] text-navy-900"
        >
          {pplDiawasi.map((p) => (
            <option key={p.petugas_id} value={p.petugas_id}>
              {p.nama}
            </option>
          ))}
        </SelectCari>
      )}

      {pplDiawasi.length === 0 ? (
        <span className="text-[10px] italic text-ink/40">(Belum ada PPL yang diawasi)</span>
      ) : pplAktif?.no_hp ? (
        <button
          type="button"
          onClick={kirimKeWaPpl}
          disabled={kirimStatus === "menyiapkan"}
          className="shrink-0 rounded-md bg-red-600 px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-red-700 disabled:opacity-60"
        >
          {kirimStatus === "menyiapkan"
            ? "Menyiapkan..."
            : kirimStatus === "selesai_share"
            ? "✓ Dibagikan -- pilih chat WA & tekan Kirim"
            : kirimStatus === "selesai_salin"
            ? "✓ Tersalin -- tempel (Ctrl+V) di WA"
            : kirimStatus === "error"
            ? "Gagal, coba lagi"
            : `📤 Kirim ke WA ${pplAktif.nama}`}
        </button>
      ) : (
        <span className="text-[10px] italic text-ink/40">
          (Nomor WA {pplAktif?.nama ?? "PPL"} belum diisi di Master Petugas)
        </span>
      )}

      {/* Klon tersembunyi off-screen utk html2canvas -- pola SAMA PERSIS dgn
          FloatBarRencanaBesok, memakai komponen tabel ASLI yg sama
          (TabelRencanaBesokHead/Row) supaya desain gambar konsisten. */}
      <div style={{ position: "fixed", top: -99999, left: -99999, width: 640 }}>
        <div ref={gambarRef} className="bg-white p-4">
          <p className="mb-2 text-sm font-bold text-navy-900">
            Daftar Ditandai PML &middot; Perlu Segera Didata -- Penyisiran Undercoverage Usaha SE2026
          </p>
          <table className="w-full text-xs">
            <TabelRencanaBesokHead />
            <tbody>
              {rowsUntukGambar.map((r) => (
                <TabelRencanaBesokRow key={r.kode_identitas} row={r} />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Bar KUNING BARU (permintaan user), diletakkan DI BAWAH FloatBarRencanaBesok
// di atas (lihat wrapper fixed+flex-col di PenyisiranPage) -- pengingat
// "SPJ hari ini belum lengkap" utk petugas yg SEDANG LOGIN sendiri.
//  - Sumbernya field spj_ada_st_hari_ini/spj_laporan_ok/spj_dokumentasi_ok
//    dari /api/penyisiran/summary (lihat komentar panjang di
//    app/api/penyisiran/summary/route.ts) -- dihitung dari RPC
//    penyisiran_monitoring_kinerja_hari_ini() yg SAMA dipakai seksi
//    "Monitoring Kinerja PPL Hari Ini" (tab Monitoring), jadi definisi
//    "lengkap" (Laporan ada + Dokumentasi >=3 foto/hari) SELALU konsisten
//    dgn yg dilihat pengelola.
//  - TIDAK tampil kalau petugas belum punya Surat Tugas yg mencakup hari
//    ini (spj_ada_st_hari_ini false) -- memang tidak ada kewajiban SPJ hari
//    itu, bukan berarti "sudah lengkap".
//  - SENGAJA TIDAK dibatasi jam 17:00 spt FloatBarRencanaBesok (bar itu soal
//    rencana BESOK, jadi wajar baru relevan sore; bar ini soal SPJ HARI INI
//    yg bisa/boleh diisi kapan saja sepanjang hari) -- tampil sepanjang hari
//    selama masih ada bagian yg kurang, padam otomatis begitu Laporan &
//    Dokumentasi hari ini sudah lengkap.
//  - Tombol "Isi di Administrasi →" langsung memindahkan tab aktif ke
//    "Administrasi" (tab "spj") lewat prop onBukaAdministrasi, supaya
//    petugas tidak perlu cari sendiri tab mana yg dituju.
function FloatBarSpjBelumLengkap({ onBukaAdministrasi }: { onBukaAdministrasi: () => void }) {
  const [checked, setChecked] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [isPml, setIsPml] = useState(false);
  const [adaSt, setAdaSt] = useState(false);
  const [laporanOk, setLaporanOk] = useState<boolean | null>(null);
  const [dokumentasiOk, setDokumentasiOk] = useState<boolean | null>(null);

  useEffect(() => {
    function bacaStorage() {
      setToken(getToken());
      setIsPml(typeof window !== "undefined" && localStorage.getItem(IS_PML_KEY) === "1");
      setChecked(true);
    }
    bacaStorage();
    const id = setInterval(bacaStorage, 30000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!token || isPml) {
      setAdaSt(false);
      setLaporanOk(null);
      setDokumentasiOk(null);
      return;
    }
    let batal = false;
    function muat() {
      apiFetch("/api/penyisiran/summary", token as string)
        .then((data) => {
          if (batal) return;
          setAdaSt(!!data?.spj_ada_st_hari_ini);
          setLaporanOk(typeof data?.spj_laporan_ok === "boolean" ? data.spj_laporan_ok : null);
          setDokumentasiOk(typeof data?.spj_dokumentasi_ok === "boolean" ? data.spj_dokumentasi_ok : null);
        })
        .catch(() => {
          if (!batal) {
            setAdaSt(false);
            setLaporanOk(null);
            setDokumentasiOk(null);
          }
        });
    }
    muat();
    const id = setInterval(muat, 120000);
    return () => {
      batal = true;
      clearInterval(id);
    };
  }, [token, isPml]);

  if (!checked || !token || isPml || !adaSt) return null;
  if (laporanOk && dokumentasiOk) return null;

  const kurang = [!laporanOk ? "Laporan" : null, !dokumentasiOk ? "Dokumentasi (min. 3 foto)" : null].filter(
    Boolean
  );

  return (
    // Latar bar SOLID PUTIH (permintaan user, sama spt FloatBarRencanaBesok
    // di atas) -- warna kuning (permintaan awal) dipindah ke teks/ikon &
    // tombol, bukan lagi ke latar bar penuh.
    <div className="flex flex-wrap items-center justify-center gap-2 border-t border-line bg-white px-4 py-2 text-center text-xs font-medium shadow-md">
      <span className="font-semibold text-[#8A6A12]">
        ⚠ SPJ hari ini belum lengkap: {kurang.join(" & ")} belum diisi.
      </span>
      <button
        type="button"
        onClick={onBukaAdministrasi}
        className="shrink-0 rounded-md bg-[#CA8A04] px-2.5 py-1 text-[11px] font-semibold text-white hover:bg-[#A9720A]"
      >
        Isi di Administrasi →
      </button>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`-mb-px shrink-0 whitespace-nowrap border-b-2 px-3 py-2 text-sm font-semibold transition ${
        active ? "border-navy-700 text-navy-900" : "border-transparent text-ink/50 hover:text-navy-700"
      }`}
    >
      {children}
    </button>
  );
}
