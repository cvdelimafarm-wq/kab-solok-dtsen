"use client";

import { useCallback, useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Narasi } from "./anomali-cepat";
import SelectCari from "@/app/components/SelectCari";

// ============================================================================
// Halaman ini didesain ulang total (UI/UX) mengikuti brief:
//   "Konfirmasi PPL – Temuan Anomali" — kartu accordion, mobile-first,
//   dikelompokkan per tema, rincian fleksibel dgn highlight merah.
// TIDAK ADA perubahan pada logic backend, query dasar, struktur data,
// aturan anomali, atau proses konfirmasi — murni tampilan & interaksi.
// Satu-satunya tambahan data: kolom `rekomendasi` di kp_anomali_pengaturan
// (sudah ada tabelnya dari fitur Upload Aturan sebelumnya; cuma nambah 1
// kolom opsional utk teks "Catatan BPS Kabupaten" di bawah).
// ============================================================================

type StatusKonfirmasi = "pending" | "sesuai" | "perlu_koreksi" | "salah_entry" | "resolved";

interface Temuan {
  id: number;
  kode_anomali: string;
  kelompok: string | null;
  nks: string | null;
  nurt: string | null;
  nourutkomo: number | null;
  nama_krt: string | null;
  keterangan: string | null;
  nama_lainnya: string | null;
  banyak: number | null;
  nilai: number | null;
  detail: Record<string, unknown> | null;
  narasi: string | null;
  status: StatusKonfirmasi;
  catatan_ppl: string | null;
  nama_ppl: string | null;
  rekomendasi_manual: string | null;
}

const fmtNum = (v: number | null | undefined) =>
  v === null || v === undefined ? "" : v.toLocaleString("id-ID");
const fmtRp = (v: number | null | undefined) =>
  v === null || v === undefined ? "" : "Rp" + v.toLocaleString("id-ID");

// Label + rujukan kode rincian + format angka per key. Dipetakan eksplisit
// satu-satu (bukan tebak-tebakan regex) supaya tidak salah format (dulu ada
// bug: "banyakHitung" ikut diformat Rupiah krn regex mendeteksi kata
// "hitung", padahal itu satuan banyaknya, bukan rupiah).
//
// PENTING soal nomor kolom yang ditampilkan (field `kode` di bawah):
// utk KP-01/KP-23/KP-24 (komoditas No.1-225, tabel 3 & 4), nomornya mengacu
// ke KOLOM CETAK di kuesioner fisik (Kolom 4=Sumber Perolehan [khusus ART],
// 5=Banyak Beli, 6=Nilai Beli, 7=Banyak Nonbeli, 8=Nilai Nonbeli,
// 9=Banyak Total, 10=Nilai Total) — BUKAN nama field database (KOLOM1-6) —
// supaya PPL bisa langsung cocokkan ke kertas kuesioner tanpa bingung.
// Utk kode lain (KP-02, KP-10, dst, tabel 5/No.226-347) nomor kolom cetak &
// nama field database KEBETULAN sama, jadi tidak perlu dibedakan.
const DETAIL_META: Record<string, { label: string; kode: string; format: "rp" | "num" }> = {
  banyakTotal: { label: "Banyaknya Total tercatat", kode: "Kolom 9", format: "num" },
  banyakHitung: { label: "Banyaknya seharusnya (Beli + Nonbeli)", kode: "Kolom 5 + Kolom 7", format: "num" },
  nilaiTotal: { label: "Nilai Total tercatat", kode: "Kolom 10", format: "rp" },
  nilaiHitung: { label: "Nilai seharusnya (Beli + Nonbeli)", kode: "Kolom 6 + Kolom 8", format: "rp" },
  sumberPerolehan: { label: "Kode Sumber Perolehan", kode: "Kolom 4", format: "num" },
  banyakBeli: { label: "Banyak Beli", kode: "Kolom 5", format: "num" },
  nilaiBeli: { label: "Nilai Beli", kode: "Kolom 6", format: "rp" },
  banyakNonbeli: { label: "Banyak Nonbeli", kode: "Kolom 7", format: "num" },
  nilaiNonbeli: { label: "Nilai Nonbeli", kode: "Kolom 8", format: "rp" },
  satuan: { label: "Satuan", kode: "KOLOM9", format: "num" },
  nomorUrutArt: { label: "Nomor Urut ART", kode: "R401", format: "num" },
  kolom5: { label: "Sebulan Terakhir", kode: "KOLOM5", format: "rp" },
  kolom6: { label: "Setahun Terakhir", kode: "KOLOM6", format: "rp" },
  kolom6Total: { label: "Nilai Total Pelayanan Kesehatan", kode: "KOLOM6", format: "rp" },
  oopA: { label: "Biaya OOP (sub-a)", kode: "KOLOM10", format: "rp" },
  oopC: { label: "Biaya OOP (sub-c)", kode: "KOLOM12", format: "rp" },
  jmlKomoditas: { label: "Jumlah Komoditas Terisi", kode: "-", format: "num" },
  bumbuBumbuan: { label: "Nilai Bumbu-bumbuan", kode: "B432R11K5", format: "rp" },
  padiPadian: { label: "Nilai Padi-padian", kode: "B432R1K5", format: "rp" },
};

interface RincianRow {
  label: string;
  kode: string;
  value: string;
  bad: boolean;
}

// "Data yang dianalisis" — dibangun fleksibel dari field yang benar-benar ada
// di temuan (detail / banyak / nilai / nama_lainnya), BUKAN kolom tetap.
// `bad` menandai rincian mana yang jadi pemicu anomali (bukan semua rincian
// ditandai merah, cuma yang memang jadi sumber masalah). Baris pertama
// selalu No.Urut Komoditas (kalau ada) supaya PPL tahu rincian yg dimaksud.
function buildRincian(t: Temuan): RincianRow[] {
  const rows: RincianRow[] = [];
  const d = (t.detail ?? {}) as Record<string, any>;
  const kode = t.kode_anomali;
  const badKeys = new Set<string>();

  if (kode === "KP-01" || kode === "KP-23") {
    if (d.banyakTotal !== d.banyakHitung) badKeys.add("banyakTotal");
    if (d.nilaiTotal !== d.nilaiHitung) badKeys.add("nilaiTotal");
  } else if (kode === "KP-24") {
    const ket = String(t.keterangan ?? "");
    if (ket.includes("pembelian terisi")) badKeys.add("banyakBeli");
    if (ket.includes("tidak terisi")) badKeys.add("banyakNonbeli");
    badKeys.add("sumberPerolehan");
  } else if (kode === "KP-02") {
    if (d.kolom5 != null) badKeys.add("kolom5");
    if (d.kolom6 != null) badKeys.add("kolom6");
  } else if (kode === "KP-10") {
    badKeys.add(String(t.keterangan ?? "").includes("3a") ? "oopA" : "oopC");
  } else if (kode === "KP-19") {
    badKeys.add("bumbuBumbuan");
  } else if (kode === "KP-07" || kode === "KP-08" || kode === "KP-09") {
    badKeys.add("jmlKomoditas");
  }

  if (t.nourutkomo != null) {
    rows.push({ label: "Nomor Urut Komoditas", kode: "NOURUTKOMO", value: fmtNum(t.nourutkomo), bad: false });
  }

  for (const [k, v] of Object.entries(d)) {
    if (v === null || v === undefined || typeof v === "object") continue;
    const meta = DETAIL_META[k] ?? { label: k, kode: k, format: "num" as const };
    rows.push({
      label: meta.label,
      kode: meta.kode,
      value: typeof v === "number" ? (meta.format === "rp" ? fmtRp(v) : fmtNum(v)) : String(v),
      bad: badKeys.has(k),
    });
  }
  if (t.banyak != null) rows.push({ label: "Banyaknya", kode: "KOLOM5", value: fmtNum(t.banyak), bad: true });
  if (t.nilai != null) rows.push({ label: "Nilai", kode: "KOLOM6", value: fmtRp(t.nilai), bad: true });
  if (t.nama_lainnya) rows.push({ label: 'Isian "Lainnya"', kode: "KOLOM8", value: t.nama_lainnya, bad: true });
  return rows;

}

const STATUS_META: Record<StatusKonfirmasi, { label: string; badge: string }> = {
  pending: { label: "Belum Dikonfirmasi", badge: "bg-gold-100 text-gold-600" },
  sesuai: { label: "Sesuai", badge: "bg-moss-100 text-moss-700" },
  perlu_koreksi: { label: "Perlu Koreksi", badge: "bg-rust-100 text-rust-700" },
  salah_entry: { label: "Salah Entry", badge: "bg-navy-400 text-white" },
  resolved: { label: "Selesai", badge: "bg-navy-100 text-navy-600" },
};

// Warna badge kode, bervariasi per kelompok (A/B/C/D/E) supaya kartu mudah
// dipindai sekilas — bukan indikator status, cuma pembeda kategori.
function kodeBadgeClass(kelompok: string | null): string {
  const huruf = (kelompok ?? "").charAt(0);
  switch (huruf) {
    case "A":
      return "bg-rust-500 text-white";
    case "B":
      return "bg-gold-600 text-white";
    case "C":
      return "bg-navy-700 text-white";
    case "D":
      return "bg-moss-500 text-white";
    default:
      return "bg-navy-400 text-white";
  }
}

export default function KonfirmasiPplTab() {
  const [supabase] = useState(() => createClient());

  const [temuan, setTemuan] = useState<Temuan[]>([]);
  const [ringkasan, setRingkasan] = useState({
    total: 0,
    pending: 0,
    sesuai: 0,
    perlu_koreksi: 0,
    salah_entry: 0,
    selesai: 0,
  });
  const [rekomendasiMap, setRekomendasiMap] = useState<Map<string, string>>(new Map());
  const [openIds, setOpenIds] = useState<Set<number>>(new Set());
  const [openGroups, setOpenGroups] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [debugError, setDebugError] = useState<string | null>(null);

  // ---------- 2 filter wajib dipilih dulu sebelum daftar anomali muncul ----------
  // (dulu 3, termasuk pilih Batch Anomali satu-satu -- sekarang Batch SELALU
  // rekap gabungan semua batch, lihat `filterBatch` di bawah, permintaan
  // Bapak Iqbal supaya PPL tidak bingung pilih batch & tidak ada anomali yg
  // "ketinggalan" krn masih di batch lama yg belum dikonfirmasi.)
  // `namaPpl` per opsi NKS -- dipakai utk otomatis mengisi field nama_ppl saat
  // menyimpan konfirmasi (kolom pilih "Nama Anda (PPL)" DIHAPUS atas arahan
  // Bapak Iqbal 17/9: siapapun yang mengedit konfirmasi utk NKS tsb dianggap
  // PPL yang jadi penanggung jawab NKS itu di kp_nks_jorong).
  const [nksOptions, setNksOptions] = useState<{ nks: string; label: string; namaPpl: string | null }[]>([]);
  const [filterNks, setFilterNks] = useState("");
  // "Batch Anomali" TIDAK LAGI bisa dipilih PPL (dulu dropdown per-batch) --
  // atas arahan Bapak Iqbal, sekarang SELALU rekap gabungan seluruh batch
  // yg pernah muncul (nilai "REKAP" tetap, tidak pernah berubah) supaya PPL
  // tidak bingung harus pilih batch mana & tidak ada anomali yg "hilang"
  // krn ketinggalan batch lama yg belum dikonfirmasi.
  const filterBatch = "REKAP";
  const [filterKuesioner, setFilterKuesioner] = useState<"" | "KP" | "M">("");
  const siapTampil = Boolean(filterNks && filterKuesioner);

  // ---------- muat opsi dropdown NKS (dari NKS yg PERNAH punya temuan --
  // termasuk yg semua temuannya sudah dikonfirmasi/selesai, BUKAN cuma yg
  // masih pending, supaya NKS yg sudah selesai semua tidak "hilang" dari
  // dropdown) + nama jorong & nama PPL penanggung jawab dari kp_nks_jorong.
  const loadNksOptions = useCallback(async () => {
    const { data: allRows } = await supabase.from("kp_anomali_temuan").select("nks");
    const uniqueNks = [...new Set((allRows ?? []).map((r) => r.nks).filter(Boolean))] as string[];
    const { data: jorongRows } = await supabase.from("kp_nks_jorong").select("nks, nama_jorong, nama_ppl");
    const jorongMap = new Map(
      (jorongRows ?? []).map((j) => [j.nks, { namaJorong: j.nama_jorong as string | null, namaPpl: j.nama_ppl as string | null }])
    );
    const opts = uniqueNks
      .map((nks) => {
        const info = jorongMap.get(nks);
        return {
          nks,
          label: info?.namaJorong ? `${nks} - ${info.namaJorong}` : `${nks} (belum ada nama jorong)`,
          namaPpl: info?.namaPpl ?? null,
        };
      })
      .sort((a, b) => a.nks.localeCompare(b.nks));
    setNksOptions(opts);
  }, [supabase]);

  const loadRekomendasi = useCallback(async () => {
    const { data } = await supabase.from("kp_anomali_pengaturan").select("kode, rekomendasi");
    setRekomendasiMap(new Map((data ?? []).map((r) => [r.kode, r.rekomendasi as string | null])) as Map<string, string>);
  }, [supabase]);

  const loadData = useCallback(async () => {
    if (!siapTampil) {
      setTemuan([]);
      setRingkasan({ total: 0, pending: 0, sesuai: 0, perlu_koreksi: 0, salah_entry: 0, selesai: 0 });
      return;
    }
    setLoading(true);

    // Ringkasan dihitung dari hasil query yg SAMA (sudah difilter NKS+Kuesioner),
    // bukan dari RPC global — supaya angkanya sesuai konteks yg dipilih PPL.
    // Batch SELALU direkap gabungan (semua anomali yg PERNAH muncul utk NKS
    // ini, termasuk yg sudah selesai/teratasi) -- tidak lagi difilter per
    // last_seen_upload_id (lihat catatan `filterBatch` di atas).
    let query = supabase.from("kp_anomali_temuan").select("*").eq("nks", filterNks);
    query = filterKuesioner === "KP" ? query.like("kode_anomali", "KP-%") : query.like("kode_anomali", "M-%");
    const { data: rows, error } = await query.order("kelompok").order("kode_anomali").order("nurt");
    if (error) {
      console.error("loadData (konfirmasi) error:", error);
      setDebugError(`Gagal membaca temuan: ${error.message} (code: ${error.code})`);
    } else {
      setDebugError(null);
    }
    const all = (rows ?? []) as Temuan[];
    setRingkasan({
      total: all.length,
      pending: all.filter((t) => t.status === "pending").length,
      sesuai: all.filter((t) => t.status === "sesuai").length,
      perlu_koreksi: all.filter((t) => t.status === "perlu_koreksi").length,
      salah_entry: all.filter((t) => t.status === "salah_entry").length,
      selesai: all.filter((t) => t.status === "resolved").length,
    });
    // Temuan yang SUDAH dikonfirmasi tetap ditampilkan (tidak disaring hilang)
    // -- kartunya diberi warna hijau kalau sudah selesai (lihat AnomaliCard),
    // sesuai arahan Bapak Iqbal 17/9, supaya PPL tetap bisa melihat riwayat
    // konfirmasinya sendiri per NKS, bukan cuma yg masih pending.
    setTemuan(all);
    setOpenGroups(new Set(all.map((t) => t.kelompok ?? "Lainnya"))); // default semua tema terbuka
    setLoading(false);
  }, [supabase, siapTampil, filterNks, filterKuesioner]);

  useEffect(() => {
    loadRekomendasi();
    loadNksOptions();
  }, [loadRekomendasi, loadNksOptions]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function confirmFinding(id: number, status: "sesuai" | "perlu_koreksi" | "salah_entry", catatan: string) {
    // Nama PPL TIDAK LAGI dipilih manual -- otomatis diambil dari PPL
    // penanggung jawab NKS yang sedang dibuka (kp_nks_jorong.nama_ppl),
    // siapapun yang login dianggap PPL yang bersangkutan.
    const namaPplOtomatis = nksOptions.find((o) => o.nks === filterNks)?.namaPpl ?? null;
    await supabase
      .from("kp_anomali_temuan")
      .update({
        status,
        catatan_ppl: catatan || null,
        nama_ppl: namaPplOtomatis,
        confirmed_at: new Date().toISOString(),
      })
      .eq("id", id);

    const statusLama = temuan.find((t) => t.id === id)?.status ?? "pending";
    // Kartu TETAP ditampilkan (diupdate di tempat), tidak dihilangkan dari
    // daftar -- sesuai arahan Bapak Iqbal 17/9 supaya PPL tetap bisa melihat
    // temuan yang sudah dikonfirmasi (kartunya berubah warna, lihat AnomaliCard).
    setTemuan((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status, catatan_ppl: catatan || null, nama_ppl: namaPplOtomatis } : t))
    );
    setOpenIds((prev) => {
      const n = new Set(prev);
      n.delete(id);
      return n;
    });
    setRingkasan((prev) => {
      const next = { ...prev };
      if (statusLama === "pending") next.pending = Math.max(0, next.pending - 1);
      else if (statusLama === "sesuai") next.sesuai = Math.max(0, next.sesuai - 1);
      else if (statusLama === "perlu_koreksi") next.perlu_koreksi = Math.max(0, next.perlu_koreksi - 1);
      else if (statusLama === "salah_entry") next.salah_entry = Math.max(0, next.salah_entry - 1);
      else if (statusLama === "resolved") next.selesai = Math.max(0, next.selesai - 1);
      if (status === "sesuai") next.sesuai += 1;
      else if (status === "perlu_koreksi") next.perlu_koreksi += 1;
      else if (status === "salah_entry") next.salah_entry += 1;
      return next;
    });
  }

  function toggleCard(id: number) {
    setOpenIds((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  }
  function toggleGroup(g: string) {
    setOpenGroups((prev) => {
      const n = new Set(prev);
      if (n.has(g)) n.delete(g);
      else n.add(g);
      return n;
    });
  }

  const grouped = new Map<string, Temuan[]>();
  for (const t of temuan) {
    const g = t.kelompok ?? "Lainnya";
    if (!grouped.has(g)) grouped.set(g, []);
    grouped.get(g)!.push(t);
  }

  return (
    <div className="space-y-3 pb-6">
      {/* ---------- Header ---------- */}
      <div>
        <h1 className="text-base font-bold text-navy-900 sm:text-lg">Konfirmasi PPL &ndash; Temuan Anomali</h1>
        <p className="mt-0.5 text-xs text-ink/60 sm:text-sm">
          Pilih NKS dan kuesioner di bawah dulu, baru daftar temuan muncul.
        </p>
      </div>

      {/* ---------- 2 filter wajib (Batch tidak lagi dipilih -- selalu rekap) ---------- */}
      <div className="space-y-2 rounded-lg border border-line bg-white p-3">
        <div>
          <label className="text-xs font-semibold text-navy-900">1. NKS &ndash; Nama Jorong</label>
          <SelectCari
            value={filterNks}
            onChange={(e) => setFilterNks(e.target.value)}
            className="mt-1 w-full rounded-md border border-line px-2.5 py-2 text-sm"
          >
            <option value="">-- Pilih NKS --</option>
            {nksOptions.map((o) => (
              <option key={o.nks} value={o.nks}>
                {o.label}
              </option>
            ))}
          </SelectCari>
        </div>
        <div className="flex items-start gap-2 rounded-md border border-navy-100 bg-navy-50 px-2.5 py-2 text-[11px] text-navy-700">
          <span className="mt-0.5 shrink-0">📋</span>
          <span>
            <span className="font-semibold">Batch Anomali:</span> selalu ditampilkan rekap gabungan SELURUH batch yang
            pernah muncul untuk NKS ini (termasuk yang sudah selesai/teratasi) — tidak perlu pilih batch satu-satu lagi.
          </span>
        </div>
        <div>
          <label className="text-xs font-semibold text-navy-900">2. Kuesioner</label>
          <SelectCari
            value={filterKuesioner}
            onChange={(e) => setFilterKuesioner(e.target.value as "" | "KP" | "M")}
            className="mt-1 w-full rounded-md border border-line px-2.5 py-2 text-sm"
          >
            <option value="">-- Pilih Kuesioner --</option>
            <option value="KP">VSEN26.KP (Konsumsi/Pengeluaran)</option>
            <option value="M">VSEN26.M (Sosial Budaya/KOR)</option>
          </SelectCari>
        </div>
      </div>

      {!siapTampil ? (
        <p className="rounded-lg border border-line bg-white p-6 text-center text-sm text-ink/50">
          Pilih NKS &amp; kuesioner di atas untuk menampilkan daftar temuan.
        </p>
      ) : (
        <>
          {debugError && (
            <p className="rounded-lg border border-rust-100 bg-rust-100/40 p-3 text-xs text-rust-700">⚠ {debugError}</p>
          )}

          {/* ---------- Ringkasan singkat (sesuai filter yg dipilih) ---------- */}
          <div className="grid grid-cols-6 gap-2 text-center">
            <SummaryBox label="Total" value={ringkasan.total} className="bg-navy-50 text-navy-900" />
            <SummaryBox label="Belum" value={ringkasan.pending} className="bg-gold-100 text-gold-600" />
            <SummaryBox label="Koreksi" value={ringkasan.perlu_koreksi} className="bg-rust-100 text-rust-700" />
            <SummaryBox label="Salah Entry" value={ringkasan.salah_entry} className="bg-navy-100 text-navy-600" />
            <SummaryBox label="Sesuai" value={ringkasan.sesuai} className="bg-moss-100 text-moss-700" />
            <SummaryBox label="Selesai" value={ringkasan.selesai} className="bg-line/40 text-ink/60" />
          </div>

          {/* ---------- Daftar temuan, dikelompokkan per tema ---------- */}
          {loading ? (
            <p className="py-6 text-center text-sm text-ink/40">Memuat...</p>
          ) : temuan.length === 0 ? (
            <p className="rounded-lg border border-line bg-white p-6 text-center text-sm text-ink/50">
              🎉 Tidak ada temuan yang perlu dikonfirmasi untuk filter ini.
            </p>
          ) : (
            [...grouped.entries()].map(([g, list]) => (
              <div key={g} className="overflow-hidden rounded-lg border border-line bg-white">
                <button
                  onClick={() => toggleGroup(g)}
                  className="flex w-full items-center justify-between gap-2 bg-navy-50 px-3 py-2.5 text-left"
                >
                  <span className="text-xs font-bold uppercase tracking-wide text-navy-900 sm:text-sm">
                    {g} <span className="font-normal text-navy-400">({list.length})</span>
                  </span>
                  <Chevron open={openGroups.has(g)} />
                </button>
                {openGroups.has(g) && (
                  <div className="space-y-2 p-2">
                    {list.map((t) => (
                      <AnomaliCard
                        key={t.id}
                        temuan={t}
                        isOpen={openIds.has(t.id)}
                        onToggle={() => toggleCard(t.id)}
                        rekomendasi={t.rekomendasi_manual || rekomendasiMap.get(t.kode_anomali) || null}
                        onConfirm={confirmFinding}
                      />
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </>
      )}
    </div>
  );
}

function SummaryBox({ label, value, className }: { label: string; value: number; className: string }) {
  return (
    <div className={`rounded-lg px-1.5 py-2 ${className}`}>
      <div className="text-lg font-bold leading-none sm:text-xl">{value}</div>
      <div className="mt-0.5 text-[10px] font-medium leading-none sm:text-[11px]">{label}</div>
    </div>
  );
}

function Chevron({ open }: { open: boolean }) {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`shrink-0 text-ink/50 transition-transform ${open ? "rotate-180" : ""}`}
    >
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}

function AnomaliCard({
  temuan,
  isOpen,
  onToggle,
  rekomendasi,
  onConfirm,
}: {
  temuan: Temuan;
  isOpen: boolean;
  onToggle: () => void;
  rekomendasi: string | null;
  onConfirm: (id: number, status: "sesuai" | "perlu_koreksi" | "salah_entry", catatan: string) => void;
}) {
  const [catatan, setCatatan] = useState("");
  const [busy, setBusy] = useState(false);
  const meta = STATUS_META[temuan.status];
  const rincian = buildRincian(temuan);
  // Sudah dikonfirmasi (status apapun selain pending) -> kartu hijau, supaya
  // kelihatan sekilas mana yang sudah selesai tanpa perlu disembunyikan
  // (arahan Bapak Iqbal 17/9).
  const sudahSelesai = temuan.status !== "pending";

  async function handle(status: "sesuai" | "perlu_koreksi" | "salah_entry") {
    setBusy(true);
    await onConfirm(temuan.id, status, catatan);
  }

  return (
    <div
      className={`overflow-hidden rounded-lg border-2 ${
        sudahSelesai ? "border-moss-500 bg-moss-50" : "border-line bg-white"
      }`}
    >
      {/* ---------- Header kartu (selalu tampil, collapsed & expanded) ---------- */}
      <button
        onClick={onToggle}
        className={`flex w-full items-start gap-2.5 p-3 text-left ${sudahSelesai ? "bg-moss-50" : "bg-white"}`}
      >
        <span
          className={`mt-0.5 shrink-0 rounded-md px-2 py-1 text-[11px] font-bold ${kodeBadgeClass(temuan.kelompok)}`}
        >
          {temuan.kode_anomali}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm font-semibold text-navy-900">Anomali {temuan.id}</p>
            <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${meta.badge}`}>
              {meta.label}
            </span>
          </div>
          <p className="mt-0.5 truncate text-xs text-ink/70 sm:text-sm">{temuan.keterangan}</p>
          <p className="mt-1 text-[11px] text-ink/50">
            Sampel {temuan.nks ?? "-"} &middot; RT {temuan.nurt ?? "-"}
            {temuan.nama_krt ? ` \u00b7 ${temuan.nama_krt}` : ""}
          </p>
        </div>
        <Chevron open={isOpen} />
      </button>

      {/* ---------- Detail (accordion) ---------- */}
      {isOpen && (
        <div className="space-y-3 border-t border-line bg-paper/30 p-3">
          {/* Data yang dianalisis — jumlah baris fleksibel, bukan tabel lebar */}
          {rincian.length > 0 && (
            <div>
              <p className="mb-1.5 text-xs font-bold text-navy-900">Data yang dianalisis</p>
              <div className="overflow-hidden rounded-md border border-line">
                {rincian.map((r, i) => (
                  <div
                    key={i}
                    className={`flex items-center justify-between gap-3 px-2.5 py-1.5 text-xs sm:text-sm ${
                      i > 0 ? "border-t border-line" : ""
                    } ${r.bad ? "bg-rust-100/60" : "bg-white"}`}
                  >
                    <span className="text-ink/60">
                      {r.label}
                      {r.kode !== "-" && (
                        <span className="ml-1 text-[10px] font-mono text-ink/35">({r.kode})</span>
                      )}
                    </span>
                    <span className={`text-right font-medium ${r.bad ? "text-rust-700" : "text-ink"}`}>
                      {r.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Keterangan (narasi dari sistem, angka ditebalkan) */}
          {temuan.narasi && (
            <div className="flex gap-2 rounded-md border border-gold-400 bg-gold-100 p-2.5">
              <span className="mt-0.5 shrink-0 text-gold-600">&#9888;</span>
              <div>
                <p className="text-xs font-bold text-gold-600">Keterangan</p>
                <p className="mt-0.5 text-xs leading-relaxed text-ink/80 sm:text-sm">
                  <Narasi text={temuan.narasi} />
                  {temuan.nama_lainnya ? ` — isian: "${temuan.nama_lainnya}"` : ""}
                </p>
              </div>
            </div>
          )}

          {/* Catatan BPS Kabupaten (rekomendasi, informatif) */}
          {rekomendasi && (
            <div className="flex gap-2 rounded-md border border-navy-100 bg-navy-50 p-2.5">
              <span className="mt-0.5 shrink-0 text-navy-700">&#128214;</span>
              <div>
                <p className="text-xs font-bold text-navy-900">Catatan BPS Kabupaten</p>
                <p className="mt-0.5 text-xs leading-relaxed text-ink/80 sm:text-sm">{rekomendasi}</p>
              </div>
            </div>
          )}

          {/* Penjelasan PPL */}
          <div>
            <p className="mb-1 text-xs font-bold text-navy-900">Penjelasan PPL</p>
            <textarea
              placeholder="Tulis penjelasan di sini..."
              value={catatan}
              onChange={(e) => setCatatan(e.target.value)}
              className="min-h-[56px] w-full rounded-md border border-line bg-white px-2.5 py-2 text-sm outline-none focus:border-navy-400 focus:ring-1 focus:ring-navy-400"
            />
          </div>

          {/* Sudah dikonfirmasi -- tombol di bawah tetap aktif kalau PPL mau
              membetulkan/mengubah keputusan sebelumnya. */}
          {sudahSelesai && (
            <p className="text-center text-[11px] text-moss-700">
              &#10003; Sudah dikonfirmasi sebagai &quot;{meta.label}&quot;
              {temuan.nama_ppl ? ` oleh ${temuan.nama_ppl}` : ""}. Tombol di bawah tetap bisa dipakai untuk mengubah.
            </p>
          )}

          {/* Tombol konfirmasi — besar, mudah disentuh jempol */}
          <div className="flex gap-2">
            <button
              disabled={busy}
              onClick={() => handle("sesuai")}
              className="flex-1 rounded-md bg-moss-500 py-3 text-sm font-semibold text-white transition hover:bg-moss-700 disabled:opacity-50"
            >
              &#10003; Sesuai
            </button>
            <button
              disabled={busy}
              onClick={() => handle("perlu_koreksi")}
              className="flex-1 rounded-md bg-rust-500 py-3 text-sm font-semibold text-white transition hover:bg-rust-700 disabled:opacity-50"
            >
              &#10007; Perlu Koreksi
            </button>
          </div>
          {/* Salah Entry — kasus terpisah: bukan anomali lapangan, tapi salah ketik/salah
              pilih kode saat entri, jadi cukup dibetulkan di kantor tanpa perlu konfirmasi
              ulang ke responden. Ditaruh di baris sendiri (bukan disamakan ukurannya dgn
              2 tombol utama) supaya tidak keliru dianggap tombol utama. */}
          <button
            disabled={busy}
            onClick={() => handle("salah_entry")}
            className="w-full rounded-md border border-navy-700 py-2.5 text-sm font-semibold text-navy-700 transition hover:bg-navy-50 disabled:opacity-50"
          >
            &#9003; Salah Entry
          </button>
        </div>
      )}
    </div>
  );
}
