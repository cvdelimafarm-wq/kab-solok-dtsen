// lib/sigapTes.ts
//
// (7 Okt 2026) SIGAP > Pelatihan: pretest & posttest. Fungsi MURNI (tanpa database) yang dipakai
// bersama oleh server (API) dan klien (halaman kelola/pengerjaan): status menurut jam, skor,
// pembersihan jawaban, serta baca/validasi template Excel soal.
//
// Aturan waktu (dipilih user): hitung mundur per orang + batas tutup.
//   - Tes boleh DIMULAI hanya pada [buka_at, tutup_at).
//   - batas_at sesi = LEAST(mulai + durasi_menit, tutup_at)  -> yang telat mulai mendapat waktu lebih sedikit.
//   - Sesudah batas_at, jawaban yang tersimpan otomatis dinilai (finalisasi lazy di server).
// Hasil (skor + pembahasan benar/salah) baru tampil setelah tutup_at; sebelum itu hanya "jawaban tersimpan".

export const KODE_KEGIATAN_PELATIHAN = "pelatihan_psp_pascabencana_2026";

export type JenisTes = "pretest" | "posttest";
export const DAFTAR_JENIS_TES: JenisTes[] = ["pretest", "posttest"];
export const LABEL_JENIS_TES: Record<JenisTes, string> = { pretest: "Pretest", posttest: "Posttest" };

export function jenisTesValid(x: unknown): x is JenisTes {
  return x === "pretest" || x === "posttest";
}

export type Opsi = { kode: string; teks: string };
/** Soal lengkap (hanya utk admin & pembahasan sesudah tes ditutup). */
export type SoalLengkap = { nomor: number; teks: string; opsi: Opsi[]; kunci: string; bobot: number };
/** Soal yang dikirim ke peserta saat mengerjakan: TANPA kunci & bobot. */
export type SoalPeserta = { nomor: number; teks: string; opsi: Opsi[] };

export type TesBaris = {
  id: number;
  kegiatan_id: number;
  jenis: JenisTes;
  judul: string;
  buka_at: string;
  durasi_menit: number;
  tutup_at: string;
  aktif: boolean;
  /** (8 Okt 2026) Jumlah percobaan maksimal per peserta; 1 = tidak boleh mengulang. Hanya berlaku utk posttest (kecuali wajib_lulus). */
  ulang_maks: number;
  /** (31 Okt 2026) Nilai lulus 0-100 dan setelan wajib lulus. Kolom belum ada (SQL 20261031k belum dijalankan) = undefined = perilaku lama. */
  nilai_lulus?: number | null;
  wajib_lulus?: boolean;
  /** (2 Nov 2026) "Wajib 100": peserta boleh mengulang tanpa batas jumlah sampai mencapai 100, selama tes masih dibuka. Kolom belum ada (SQL 20261102zl belum jalan) = undefined = tidak wajib 100. */
  wajib_100?: boolean;
};

export type SesiBaris = {
  id: number;
  tes_id: number;
  akun_id: number;
  mulai_at: string;
  batas_at: string;
  selesai_at: string | null;
  jawaban: Record<string, string>;
  skor: number | null;
  benar: number | null;
  total: number | null;
  diubah_at: string;
  /** (8 Okt 2026) Percobaan ke-berapa yang sedang/terakhir dikerjakan (mulai 1). */
  percobaan: number;
  /** Skor tertinggi dari percobaan SEBELUMNYA (yang sudah diarsipkan); null bila belum pernah mengulang. */
  skor_terbaik: number | null;
  /** (2 Nov 2026) Skor PERCOBAAN PERTAMA (SQL 20261102zl); diisi saat percobaan pertama dinilai. undefined/null = belum ada / kolom belum dibaca. */
  skor_awal?: number | null;
};

/** Status tes bagi seorang peserta. */
export type StatusTes = "nonaktif" | "soal_belum_ada" | "belum_buka" | "buka" | "mengerjakan" | "selesai" | "terlewat";

export const LABEL_STATUS_TES: Record<StatusTes, string> = {
  nonaktif: "Tidak aktif",
  soal_belum_ada: "Soal belum tersedia",
  belum_buka: "Belum dibuka",
  buka: "Sedang dibuka",
  mengerjakan: "Sedang dikerjakan",
  selesai: "Selesai",
  terlewat: "Terlewat",
};

/** Toleransi (detik) utk simpan jawaban yg tiba sedikit setelah batas (jaringan lambat). */
export const TOLERANSI_DETIK = 5;

/** batas_at = LEAST(sekarang + durasi, tutup_at). */
export function hitungBatas(sekarang: Date, durasiMenit: number, tutupAt: string | Date): Date {
  const b = new Date(sekarang.getTime() + durasiMenit * 60_000);
  const t = new Date(tutupAt);
  return b.getTime() < t.getTime() ? b : t;
}

/** Sudah melewati batas (dgn toleransi opsional)? */
export function lewatBatas(sekarang: Date, batasAt: string | Date, toleransiDetik = 0): boolean {
  return sekarang.getTime() > new Date(batasAt).getTime() + toleransiDetik * 1000;
}

export function statusTes(
  tes: Pick<TesBaris, "aktif" | "buka_at" | "tutup_at">,
  jumlahSoal: number,
  sesi: Pick<SesiBaris, "batas_at" | "selesai_at"> | null,
  sekarang: Date
): StatusTes {
  if (sesi) {
    if (sesi.selesai_at || sekarang.getTime() >= new Date(sesi.batas_at).getTime()) return "selesai";
    return "mengerjakan";
  }
  if (!tes.aktif) return "nonaktif";
  if (jumlahSoal <= 0) return "soal_belum_ada";
  const t = sekarang.getTime();
  if (t < new Date(tes.buka_at).getTime()) return "belum_buka";
  if (t < new Date(tes.tutup_at).getTime()) return "buka";
  return "terlewat";
}

export const ULANG_MAKS_TERTINGGI = 5;
/** Sisa waktu minimal (detik) sebelum tutup_at agar mengulang masih ditawarkan. */
export const SISA_ULANG_MIN_DETIK = 60;

/** Nilai resmi seorang peserta = skor tertinggi dari semua percobaan (yang berjalan dihitung bila sudah selesai). */
export function skorResmi(s: Pick<SesiBaris, "selesai_at" | "skor" | "skor_terbaik"> | null | undefined): number | null {
  if (!s) return null;
  const a = s.selesai_at && s.skor != null ? Number(s.skor) : null;
  const b = s.skor_terbaik != null ? Number(s.skor_terbaik) : null;
  if (a === null) return b;
  if (b === null) return a;
  return Math.max(a, b);
}

// ---------------------------------------------------------------------------------------------
// (31 Okt 2026) Wajib lulus. Pengaturan per tes: centang wajib_lulus + nilai_lulus (bawaan 70).
// Bila wajib: skor resmi (tertinggi dari semua percobaan) di bawah nilai lulus -> peserta boleh mengulang sampai lulus, maksimal 3 percobaan,
// selama jadwal tes terbuka (berlaku untuk pretest maupun posttest). Sudah lulus -> tombol ulang hilang. Kuis (Adu Sigap) tidak termasuk.
// Kelulusan hanya penanda/analisis; tidak memblokir penempatan ke pendataan.
// ---------------------------------------------------------------------------------------------
export const NILAI_LULUS_BAWAAN = 70;
export const PERCOBAAN_WAJIB_LULUS = 3;

export const wajibLulus = (t: Pick<TesBaris, "wajib_lulus">): boolean => t.wajib_lulus === true;

// ---------------------------------------------------------------------------------------------
// (2 Nov 2026) Wajib 100. Pengaturan per tes (pretest / posttest): peserta mengulang berapa kali pun sampai skornya mencapai 100, selama jadwal tes terbuka.
// Langkah dianggap SELESAI begitu skor tertinggi mencapai 100. Nilai yang dicatat tetap nilai pertama pada aturan versi 2 (lib/sigapAturanTes.ts).
// Bila wajib 100 dan wajib lulus sama-sama menyala, wajib 100 yang berlaku.
// ---------------------------------------------------------------------------------------------
export const NILAI_PENUH = 100;
/** Angka "tanpa batas" untuk percobaan wajib 100 (dipakai agar bentuk data tidak berubah). */
export const PERCOBAAN_TANPA_BATAS = 999;
export const wajib100 = (t: Pick<TesBaris, "wajib_100">): boolean => t.wajib_100 === true;
/** Sudah pernah mencapai 100 pada percobaan mana pun (percobaan yang sedang berjalan dihitung bila sudah selesai). */
export function sudahPenuh(s: Pick<SesiBaris, "selesai_at" | "skor" | "skor_terbaik"> | null | undefined): boolean {
  const n = skorResmi(s);
  return n !== null && n >= NILAI_PENUH;
}
/** Langkah tes tuntas: wajib 100 = skor tertinggi 100; selain itu = ada percobaan yang selesai. */
export function tesTuntas(t: Pick<TesBaris, "wajib_100">, s: Pick<SesiBaris, "selesai_at" | "skor" | "skor_terbaik"> | null | undefined): boolean {
  if (!s) return false;
  return wajib100(t) ? sudahPenuh(s) : !!s.selesai_at || s.skor_terbaik != null;
}

/** Nilai lulus 0-100; kosong/rusak jatuh ke bawaan 70. */
export function nilaiLulus(t: Pick<TesBaris, "nilai_lulus">): number {
  const n = t.nilai_lulus === null || t.nilai_lulus === undefined ? NaN : Number(t.nilai_lulus);
  return Number.isFinite(n) && n >= 0 && n <= 100 ? n : NILAI_LULUS_BAWAAN;
}

/** Jumlah percobaan maksimal per peserta: wajib lulus = 3; selain itu posttest mengikuti ulang_maks, pretest 1. */
export function percobaanMaks(t: Pick<TesBaris, "jenis" | "ulang_maks" | "wajib_lulus" | "wajib_100">): number {
  if (wajib100(t)) return PERCOBAAN_TANPA_BATAS;
  if (wajibLulus(t)) return PERCOBAAN_WAJIB_LULUS;
  if (t.jenis !== "posttest") return 1;
  const n = Number(t.ulang_maks);
  return Number.isInteger(n) ? Math.min(ULANG_MAKS_TERTINGGI, Math.max(1, n)) : 1;
}

export type StatusLulus = "tidak_wajib" | "belum_dinilai" | "lulus" | "belum_lulus";
export const LABEL_STATUS_LULUS: Record<StatusLulus, string> = { tidak_wajib: "Tidak wajib lulus", belum_dinilai: "Belum dinilai", lulus: "Lulus", belum_lulus: "Belum lulus" };

/** Kelulusan menurut skor resmi (null = belum ada percobaan yang selesai). Tes yang tidak wajib lulus selalu "tidak_wajib". */
export function statusLulus(t: Pick<TesBaris, "wajib_lulus" | "nilai_lulus">, skor: number | null): StatusLulus {
  if (!wajibLulus(t)) return "tidak_wajib";
  if (skor === null || skor === undefined || !Number.isFinite(Number(skor))) return "belum_dinilai";
  return Number(skor) >= nilaiLulus(t) ? "lulus" : "belum_lulus";
}

type TesUlang = Pick<TesBaris, "jenis" | "aktif" | "buka_at" | "tutup_at" | "ulang_maks" | "nilai_lulus" | "wajib_lulus" | "wajib_100">;
type SesiUlang = Pick<SesiBaris, "selesai_at" | "percobaan" | "skor" | "skor_terbaik">;

/**
 * Tawarkan "Ulangi"? Percobaan sebelumnya sudah selesai, kuota belum habis, jadwal tes masih terbuka, dan:
 *   - tes biasa: hanya posttest yang diberi kesempatan ulang (ulang_maks > 1);
 *   - tes wajib lulus (pretest/posttest): hanya selama skor resmi belum mencapai nilai lulus.
 */
export function bisaUlang(tes: TesUlang, sesi: SesiUlang | null, jumlahSoal: number, sekarang: Date): boolean {
  if (!sesi || !sesi.selesai_at) return false;
  if (!tes.aktif || jumlahSoal <= 0) return false;
  if (!wajib100(tes) && !wajibLulus(tes) && tes.jenis !== "posttest") return false;
  if (sesi.percobaan >= percobaanMaks(tes)) return false;
  if (wajib100(tes)) {
    if (sudahPenuh(sesi)) return false;
  } else if (statusLulus(tes, skorResmi(sesi)) === "lulus") return false;
  const t = sekarang.getTime();
  return t >= new Date(tes.buka_at).getTime() && new Date(tes.tutup_at).getTime() - t >= SISA_ULANG_MIN_DETIK * 1000;
}

/** Pesan bila "ulang" ditolak (urutan pemeriksaan mengikuti bisaUlang). */
export function alasanTakBisaUlang(tes: TesUlang, sesi: SesiUlang): string {
  if (!wajib100(tes) && !wajibLulus(tes) && (tes.jenis !== "posttest" || percobaanMaks(tes) <= 1)) return "Tes ini tidak membuka kesempatan mengulang.";
  if (!sesi.selesai_at) return "Selesaikan percobaan yang sedang berjalan terlebih dahulu.";
  if (wajib100(tes) && sudahPenuh(sesi)) return "Anda sudah mencapai nilai 100, tidak perlu mengulang.";
  if (!wajib100(tes) && statusLulus(tes, skorResmi(sesi)) === "lulus") return "Anda sudah mencapai nilai lulus, tidak perlu mengulang.";
  if (sesi.percobaan >= percobaanMaks(tes)) return `Kesempatan mengulang sudah habis (maksimal ${percobaanMaks(tes)} percobaan).`;
  return "Waktu tes sudah hampir/ sudah ditutup, tidak bisa mengulang lagi.";
}

/** Hasil (skor & pembahasan) boleh ditampilkan setelah tes ditutup utk semua peserta. */
export function hasilBolehTampil(tes: Pick<TesBaris, "tutup_at">, sekarang: Date): boolean {
  return sekarang.getTime() >= new Date(tes.tutup_at).getTime();
}

/** Buang jawaban yg nomor/kodenya tidak ada di soal; kosong = dihapus. Kode disamakan ke huruf besar. */
export function bersihkanJawaban(input: unknown, soal: { nomor: number; opsi: Opsi[] }[]): Record<string, string> {
  const out: Record<string, string> = {};
  if (!input || typeof input !== "object") return out;
  const peta = new Map(soal.map((s) => [String(s.nomor), new Set(s.opsi.map((o) => o.kode))]));
  for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
    const kodeOpsi = peta.get(k);
    if (!kodeOpsi || typeof v !== "string") continue;
    const kode = v.trim().toUpperCase();
    if (kodeOpsi.has(kode)) out[k] = kode;
  }
  return out;
}

/** Jawaban berbentuk sah (nomor: huruf A-E) untuk nomor yang TIDAK ada di daftar soal berlaku, yaitu soal yang dinonaktifkan. */
export function jawabanSoalLain(input: unknown, soal: readonly { nomor: number }[]): Record<string, string> {
  const out: Record<string, string> = {};
  if (!input || typeof input !== "object") return out;
  const ada = new Set(soal.map((s) => String(s.nomor)));
  for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
    if (ada.has(k) || !/^\d{1,3}$/.test(k) || typeof v !== "string") continue;
    const kode = v.trim().toUpperCase();
    if (/^[A-E]$/.test(kode)) out[k] = kode;
  }
  return out;
}

export type RincianJawab = { nomor: number; jawab: string | null; kunci: string; benar: boolean; bobot: number };
export type HasilSkor = { benar: number; total: number; skor: number; rincian: RincianJawab[] };

/** Skor = jumlah bobot soal benar / jumlah bobot semua soal x 100 (2 desimal). */
export function hitungSkor(soal: { nomor: number; kunci: string; bobot: number }[], jawaban: Record<string, string>): HasilSkor {
  let bobotBenar = 0;
  let bobotTotal = 0;
  let benar = 0;
  const rincian: RincianJawab[] = [];
  for (const s of soal) {
    const j = jawaban[String(s.nomor)] ?? null;
    const ok = j !== null && j === s.kunci;
    bobotTotal += s.bobot;
    if (ok) {
      bobotBenar += s.bobot;
      benar++;
    }
    rincian.push({ nomor: s.nomor, jawab: j, kunci: s.kunci, benar: ok, bobot: s.bobot });
  }
  const skor = bobotTotal > 0 ? Math.round((bobotBenar / bobotTotal) * 10000) / 100 : 0;
  return { benar, total: soal.length, skor, rincian };
}

// ======================================================================
// Template Excel soal
// ======================================================================

export const KODE_OPSI = ["A", "B", "C", "D", "E"] as const;
export const MAKS_SOAL = 100;
export const HEADER_TEMPLATE = ["No", "Soal", "A", "B", "C", "D", "E", "Kunci", "Bobot"];

/** Baris contoh utk template yang diunduh (lembar "Soal"). */
export function barisTemplate(): (string | number)[][] {
  return [
    HEADER_TEMPLATE,
    [1, "Contoh: Apa kepanjangan PSP dalam kegiatan ini?", "Pendataan Status Pemulihan", "Pendataan Sensus Penduduk", "Pemutakhiran Status Petugas", "Pencacahan Sampel Panel", "", "A", 1],
    [2, "Contoh: Aplikasi yang dipakai petugas untuk mengisi kuesioner adalah ...", "SIGAP", "FASIH", "Zoom", "WhatsApp", "", "B", 1],
  ];
}

export const PETUNJUK_TEMPLATE = [
  "Petunjuk pengisian template soal",
  "1. Isi lembar 'Soal' mulai baris ke-2 (baris 1 = judul kolom, jangan diubah). Hapus dua baris contoh sebelum diunggah.",
  "2. Kolom No = nomor soal (angka, unik). Kolom Soal = teks pertanyaan.",
  "3. Kolom A–E = pilihan jawaban. Minimal diisi A dan B; kolom yang kosong dianggap tidak ada (boleh hanya sampai C atau D).",
  "4. Kolom Kunci = huruf jawaban benar (A/B/C/D/E) dan harus menunjuk pilihan yang terisi.",
  "5. Kolom Bobot = nilai soal (angka > 0). Kosong dianggap 1.",
  `6. Maksimal ${MAKS_SOAL} soal per tes. Soal tidak dapat diganti setelah ada peserta yang mulai mengerjakan.`,
];

export type HasilBacaSoal = { soal: SoalLengkap[]; galat: string[] };

function teksSel(v: unknown): string {
  if (v === null || v === undefined) return "";
  return String(v).replace(/\r\n?/g, "\n").trim();
}

/** Validasi kumpulan soal "mentah" (baris-baris sel Excel DAN/ATAU objek JSON dari klien). */
function rakitSoal(mentah: { baris: number; nomor: unknown; teks: unknown; opsi: unknown[]; kunci: unknown; bobot: unknown }[]): HasilBacaSoal {
  const galat: string[] = [];
  const soal: SoalLengkap[] = [];
  const nomorTerpakai = new Set<number>();
  for (const m of mentah) {
    const awal = `Baris ${m.baris}`;
    const nomor = Number(teksSel(m.nomor));
    if (!Number.isInteger(nomor) || nomor <= 0) {
      galat.push(`${awal}: nomor soal harus bilangan bulat > 0.`);
      continue;
    }
    if (nomorTerpakai.has(nomor)) {
      galat.push(`${awal}: nomor ${nomor} dipakai dua kali.`);
      continue;
    }
    nomorTerpakai.add(nomor);
    const teks = teksSel(m.teks);
    if (!teks) {
      galat.push(`${awal} (soal ${nomor}): teks soal kosong.`);
      continue;
    }
    const opsi: Opsi[] = [];
    KODE_OPSI.forEach((kode, i) => {
      const t = teksSel(m.opsi[i]);
      if (t) opsi.push({ kode, teks: t });
    });
    if (opsi.length < 2) {
      galat.push(`${awal} (soal ${nomor}): minimal dua pilihan jawaban (A dan B).`);
      continue;
    }
    const kunci = teksSel(m.kunci).toUpperCase();
    if (!opsi.some((o) => o.kode === kunci)) {
      galat.push(`${awal} (soal ${nomor}): kunci "${teksSel(m.kunci) || "kosong"}" tidak sesuai pilihan yang terisi (${opsi.map((o) => o.kode).join("/")}).`);
      continue;
    }
    const bobotTeks = teksSel(m.bobot);
    const bobot = bobotTeks === "" ? 1 : Number(bobotTeks.replace(",", "."));
    if (!Number.isFinite(bobot) || bobot <= 0 || bobot > 1000) {
      galat.push(`${awal} (soal ${nomor}): bobot harus angka > 0.`);
      continue;
    }
    soal.push({ nomor, teks, opsi, kunci, bobot });
  }
  if (soal.length === 0 && galat.length === 0) galat.push("Tidak ada soal yang terbaca. Isi mulai baris ke-2 lembar 'Soal'.");
  if (mentah.length > MAKS_SOAL) galat.push(`Terlalu banyak soal (${mentah.length}); maksimal ${MAKS_SOAL}.`);
  soal.sort((a, b) => a.nomor - b.nomor);
  return { soal, galat };
}

/**
 * Baca baris-baris lembar Excel (array of array, mis. XLSX.utils.sheet_to_json(ws,{header:1,defval:""})).
 * Baris judul dikenali bila sel pertamanya "No"; baris kosong dilewati.
 */
export function bacaBarisSoal(baris: unknown[][]): HasilBacaSoal {
  const mentah: Parameters<typeof rakitSoal>[0] = [];
  baris.forEach((r, i) => {
    const sel = Array.isArray(r) ? r : [];
    if (sel.every((c) => teksSel(c) === "")) return;
    if (i === 0 && teksSel(sel[0]).toLowerCase() === "no") return; // judul kolom
    mentah.push({ baris: i + 1, nomor: sel[0], teks: sel[1], opsi: sel.slice(2, 7), kunci: sel[7], bobot: sel[8] });
  });
  return rakitSoal(mentah);
}

/** Validasi ulang di server atas JSON dari klien: [{nomor,teks,opsi:[{kode,teks}],kunci,bobot}]. */
export function validasiSoalJson(input: unknown): HasilBacaSoal {
  if (!Array.isArray(input)) return { soal: [], galat: ["Format soal tidak valid."] };
  const mentah: Parameters<typeof rakitSoal>[0] = input.map((x, i) => {
    const o = (x ?? {}) as Record<string, unknown>;
    const opsiArr = Array.isArray(o.opsi) ? (o.opsi as Record<string, unknown>[]) : [];
    const opsi = KODE_OPSI.map((k) => opsiArr.find((p) => String(p?.kode ?? "").toUpperCase() === k)?.teks ?? "");
    return { baris: i + 1, nomor: o.nomor, teks: o.teks, opsi, kunci: o.kunci, bobot: o.bobot };
  });
  return rakitSoal(mentah);
}

// ======================================================================
// Pemberitahuan lokasi pembukaan (modal PERHATIAN di halaman Langkah) -- permintaan user 7 Okt 2026
// ======================================================================
export const PEMUKAAN = {
  tempat: "Ully Hotel Solok",
  jarak: "450 meter dari Mami Hotel",
  maps: "https://maps.app.goo.gl/cfrCpteizYPPxDju8?g_st=iw",
} as const;

// ======================================================================
// Info Undangan (sumber: Undangan B-409/13030/VS.230/2026 tanggal 6 Okt 2026)
// ======================================================================
export const UNDANGAN = {
  nomor: "B-409/13030/VS.230/2026",
  tanggal_surat: "6 Oktober 2026",
  hal: "Undangan Pelatihan Petugas Pendataan Pascabencana Sumatera 2026",
  hari_tanggal: "Kamis, 8 Oktober 2026",
  tanggal_iso: "2026-10-08",
  pukul: "08.00–16.00 WIB",
  tempat: "Mami Hotel Solok",
  pakaian: "Pakaian sopan dan rapi: batik pada pembukaan dan penutupan; pakaian bebas dan rapi selama pelatihan berlangsung.",
  ketentuan: [
    "Hadir tepat waktu pada kelas yang telah ditetapkan dan mengikuti seluruh rangkaian kegiatan sesuai jadwal.",
    "Seluruh biaya pelaksanaan kegiatan dibebankan pada DIPA BPS Kabupaten Solok sesuai ketentuan yang berlaku.",
    "Seluruh peserta dibayarkan transpor lokal sehingga wajib melampirkan 5 (lima) foto dengan time stamp: saat akan berangkat, saat sampai di lokasi, saat mengikuti kegiatan, saat akan pulang, dan saat tiba kembali di domisili.",
    "Seluruh foto diunggah melalui aplikasi SIGAP (menu Transport Lokal).",
    "Informasi lebih lanjut dikoordinasikan dengan panitia pelaksana/petugas yang ditunjuk.",
  ],
  pdf: "/api/sigap/pelatihan/undangan",
  jadwal: [
    { waktu: "08.00–08.30", materi: ["Registrasi"], ket: "" },
    { waktu: "08.30–08.45", materi: ["Pembukaan"], ket: "Pimpinan" },
    { waktu: "08.45–09.15", materi: ["Penjelasan Umum Pendataan Status Pemulihan 2026", "Organisasi Lapangan"], ket: "Inda" },
    { waktu: "09.15–10.00", materi: ["FASIH"], ket: "" },
    { waktu: "10.00–10.15", materi: ["Istirahat"], ket: "" },
    { waktu: "10.15–11.00", materi: ["Kuesioner Keluarga: Blok I-II"], ket: "Inda" },
    { waktu: "11.00–12.30", materi: ["Kuesioner Keluarga: Blok III - Keterangan Perumahan", "Kondisi Ketenagakerjaan - Aset"], ket: "Inda" },
    { waktu: "12.30–13.30", materi: ["Istirahat"], ket: "" },
    { waktu: "13.30–14.15", materi: ["Kuesioner Keluarga: Blok III - Bantuan dan Mitigasi Bencana"], ket: "Inda" },
    { waktu: "14.15–15.45", materi: ["Kuesioner Keluarga: Blok III - Dampak Bencana"], ket: "Inda" },
    { waktu: "15.45–16.00", materi: ["Penutupan dan administrasi"], ket: "Pimpinan" },
  ],
  ttd: { jabatan: "Kepala BPS Kabupaten Solok", nama: "Bambang Suryanggono" },
} as const;

// ======================================================================
// (31 Okt 2026) Pelatihan per kegiatan: info undangan umum + pembaca parameter ?kegiatan=ID (murni, bisa diuji)
// ======================================================================
/** Bentuk umum info undangan. UNDANGAN (PSP Pascabencana) memenuhinya; pelatihan lain disusun `undanganDariKegiatan`. */
export type InfoUndangan = {
  nomor: string;
  tanggal_surat: string;
  hal: string;
  hari_tanggal: string;
  tanggal_iso: string;
  pukul: string;
  tempat: string;
  pakaian: string;
  ketentuan: readonly string[];
  pdf: string;
  jadwal: readonly { waktu: string; materi: readonly string[]; ket: string }[];
  ttd: { jabatan: string; nama: string };
  /** true = disusun otomatis dari data kegiatan (bukan surat undangan resmi); layar menyembunyikan bagian yang kosong. */
  turunan?: boolean;
};

/** Angka kegiatan dari parameter ?kegiatan=ID; null bila kosong/tidak valid. */
export function kegiatanDariParam(v: string | null | undefined): number | null {
  if (v === null || v === undefined || !/^\d{1,12}$/.test(v.trim())) return null;
  const n = Number(v.trim());
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}

const NAMA_HARI_ID = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const NAMA_BULAN_ID = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

/** "2026-10-08" -> "Kamis, 8 Oktober 2026"; "" bila bukan tanggal yang benar. */
export function tanggalPanjangId(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!m) return "";
  const [y, mo, d] = [Number(m[1]), Number(m[2]), Number(m[3])];
  const dt = new Date(Date.UTC(y, mo - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d) return "";
  return `${NAMA_HARI_ID[dt.getUTCDay()]}, ${d} ${NAMA_BULAN_ID[mo - 1]} ${y}`;
}

const jamWib = (iso: string | null | undefined): string => {
  const t = iso ? Date.parse(iso) : NaN;
  if (!Number.isFinite(t)) return "";
  const w = new Date(t + 7 * 3_600_000);
  return `${String(w.getUTCHours()).padStart(2, "0")}.${String(w.getUTCMinutes()).padStart(2, "0")}`;
};

/**
 * Info undangan untuk pelatihan selain PSP Pascabencana: hanya memuat yang diketahui dari data kegiatan dan pengaturan presensi.
 * Nomor surat, jadwal acara, ketentuan, dan PDF dibiarkan kosong (tidak mengarang); layar menyembunyikannya.
 */
export function undanganDariKegiatan(
  k: { nama: string; tanggal_mulai: string | null },
  p: { tempat?: string | null; presensi_buka_at?: string | null; presensi_tutup_at?: string | null } | null,
  hariIniWib: string,
): InfoUndangan {
  const tgl = k.tanggal_mulai && tanggalPanjangId(k.tanggal_mulai) ? k.tanggal_mulai : hariIniWib;
  const buka = jamWib(p?.presensi_buka_at);
  const tutup = jamWib(p?.presensi_tutup_at);
  return {
    nomor: "",
    tanggal_surat: "",
    hal: k.nama,
    hari_tanggal: tanggalPanjangId(tgl),
    tanggal_iso: tgl,
    pukul: buka && tutup ? `${buka}\u2013${tutup} WIB` : "",
    tempat: (p?.tempat ?? "").trim(),
    pakaian: "",
    ketentuan: [],
    pdf: "",
    jadwal: [],
    ttd: { jabatan: "", nama: "" },
    turunan: true,
  };
}
