# Status tahap 33: Usulan RAB, rencana realisasi, dan jendela pencairan dari identifikasi (26 Okt 2026)

Butir 1 dari usulan pembangunan: modul hilir mulai membaca identifikasi. Bagian A, B, dan C sudah di-push dan diuji di produksi (lihat bagian Uji produksi); tiga perbaikan kecil menunggu commit. SQL bagian C sudah dijalankan pengguna.

## Keputusan pengguna
1. Cara sambung: kartu "Usulan dari identifikasi" di tab RAB. Volume dan satuan dari identifikasi; harga diisi pengguna bila tarif belum ada. Disalin ke RAB hanya lewat tombol, per usulan, tidak menimpa baris yang ada.
2. Bulan cair: disarankan dari jadwal identifikasi, dapat diubah.
3. **Tarif kebijakan bukan aturan tunggal, melainkan batas tertinggi** untuk aturan internal. Harga di bawah batas boleh (mis. batas translok 170, survei mengisi 160 = sah).
4. **Pencairan paling lambat H+5 sesudah hari terakhir pelaksanaan**; contoh selesai tgl 10, dijadwalkan sekitar tgl 8-15. (cek aturan.)
5. **Batas awal pencairan tidak diatur** (26 Okt, 05.10): hanya batas lambat yang dicek; tidak ada batas awal.
6. **Penjagaan konsistensi sederhana** (26 Okt, 05.10): hanya mengecek apakah anggaran akun itu ADA pada POK RO atau BELUM ADA, berapa pun nilainya; nominal tidak dibandingkan dengan pagu.
7. **Jendela pencairan jadi parameter lembar kebijakan** (26 Okt): dipakai kartu usulan dan rencana realisasi.

## A. Usulan RAB (kartu "Usulan dari identifikasi")
| Berkas | Isi |
|---|---|
| `lib/keu/usulanRab.ts` (baru) | Logika murni: `usulanDari`, `acuanSelesai`, `saranCair`, `periksaCair`, `periksaHarga`, `kandidatItem`, `sudahDisalin`, `ringkasUsulan`, `isianDari`, `labelSumber` |
| `app/sigap/ro/[kode]/UsulanIdentifikasi.tsx` (baru) | Dua kartu pada tab RAB; baca `keu_v_ident_acuan` dan `keu_v_kebijakan_berlaku`; tulis lewat `keu_rab_item` dan `keu_rab_baris` yang sama dengan tab RAB |
| `app/sigap/ro/[kode]/Rab.tsx` (diubah 2 baris) | Impor dan sisip `<UsulanIdentifikasi ... editable={editable} />` sebelum daftar item |

Perilaku:
- Sumber: lanjutan terbaru bila ada (Final atau Draf; Draf diberi peringatan), jika tidak identifikasi awal yang sah. Bila RO punya lebih dari satu identifikasi, pengguna memilih.
- Satuan: keterangan dalam kurung dibuang, maks. 20 huruf. Volume kosong bila identifikasi belum tahu; pengguna mengisi.
- Harga: diisi dari tarif lembar kebijakan sebagai **batas tertinggi**, boleh diturunkan; di atas batas muncul peringatan (tidak memblokir). Tanpa tarif: kosong, wajib diisi sebelum salin.
- Jadwal cair: bulan dan minggu yang memuat hari terakhir pelaksanaan (kelas untuk baris pelatihan, akhir pendataan untuk lainnya; tanggal kosong: bulan berjalan, minggu 3). Minggu: 1-7, 8-14, 15-21, 22 dst. Peringatan hanya bila minggu yang dipilih pasti sesudah batas lambat.
- Tujuan: item POK RO dengan akun enam angka sama, bukan "Selesai", bukan "RAB = Item". Satu kandidat otomatis; banyak kandidat dipilih pengguna. Item RAB dibuat bila belum ada.
- Usulan yang sudah disalin dikenali dari keterangan baris RAB (diawali uraian + " · identifikasi lanjutan vN") dan tidak ditawarkan lagi.
- Kartu usulan hanya tampil bila RAB dapat diubah pengguna; hak tetap ditegakkan basis data.

## B. Rencana realisasi (kartu "Rencana realisasi dari identifikasi", hanya baca)
Tampil untuk semua yang melihat tab RAB. Tidak menulis apa pun.
- **Penjagaan anggaran:** per akun yang dibutuhkan identifikasi, status "Ada" atau "Belum ada" pada POK RO (berapa pun nilainya, nol dan item "Selesai" tetap dihitung ada). Akun yang belum ada diberi catatan kuning.
- **Perkiraan pencairan:** tabel bulan x minggu (M1-M4) berisi jumlah baris, jumlah rupiah (volume x harga awal), baris tanpa harga (tidak masuk jumlah), dan berapa yang sudah menjadi baris RAB. Total terhitung adalah batas atas karena harga awal = batas tertinggi kebijakan.
- Menampilkan kegiatan berakhir paling akhir dan batas lambat pencairan.
- Fungsi di `usulanRab.ts`: `jagaAnggaran`, `rencanaBulanan`.

## C. Jendela pencairan = parameter `hari_cair_maks` (26 Okt)
- Parameter ke-22 pada lembar kebijakan, grup "Lain-lain": "Batas hari pencairan setelah kegiatan", satuan hari (H+), aturan 5 dan kebijakan 5 (cek aturan). Kebijakan sama atau lebih ketat dari aturan (boleh lebih kecil). Bilangan bulat 0 sampai 60. Kosong pada aturan dan kebijakan = tanpa batas hari.
- **Opsional, bukan wajib:** `KODE_PARAM` tetap 21 parameter wajib; `KODE_PARAM_OPSIONAL = ["hari_cair_maks"]`. Lembar tanpa parameter ini (lembar lama, draf lama, uji 50) tetap sah. Lembar baru dari angka predefined (aplikasi versi baru) sudah memuatnya. Alasan: tidak merusak lembar berlaku yang terkunci dan tidak perlu menambal draf.
- Hilir: `jendelaCair(isiLembar)` memakai nilai KEBIJAKAN; tanpa lembar atau tanpa parameter memakai bawaan H+5 dengan label "(bawaan, cek aturan)"; dari lembar berlabel "(lembar kebijakan)". `saranCair`, `periksaCair`, `usulanDari` menerima jumlah hari; `UsulanBaris.hariCair` baru. Nilai tak sah (bukan bulat 0..60) diabaikan (bawaan).
- SQL `20261026a_keu_kebijakan_hari_cair.sql`: menambal `keu_kebijakan_periksa` lewat `pg_get_functiondef` (putaran pemeriksa jenis mencakup parameter opsional + aturan bulat 0..60). Aman diulang, tanpa DELETE/DROP, tidak mengubah data. Uji `55_uji_hari_cair.sql`: 37 kasus vektor `kebijakan.vektor.json` (27 lama + 10 baru) dan lembar 21 parameter tetap sah; rollback di akhir.
- Berkas yang berubah: `kebijakan.ts`, `usulanRab.ts`, `UsulanIdentifikasi.tsx`, `Anggaran.tsx` dan `page.tsx` kebijakan (teks "22 parameter"), `kebijakan.test.ts`, `kebijakan.vektor.json` (basis 22 parameter, 37 kasus), `usulanRab.test.ts`.

## Verifikasi
- Vitest 2.1.9 di folder uji sementara: `usulanRab.test.ts` 26 tes dan `kebijakan.test.ts` 63 tes lulus. `tsc` strict: tanpa galat pada kode ini (hanya modul yang tidak ada di folder uji).
- Postgres 16 lokal: fungsi pemeriksa dari 20261025zd + tambalan 20261026a, dijalankan dua kali (aman diulang), `55_uji_hari_cair.sql` LULUS 37 kasus. SQL TS dan SQL sepaham pada vektor yang sama.
- Belum diuji di produksi dan belum `next build` penuh. Uji disarankan sesudah deploy dengan RO fiktif (identifikasi fiktif id 1, RO 2903.BMA.009): salin satu usulan ke RAB draf, lihat kartu rencana, lalu hapus barisnya.

## Uji produksi (26 Okt 2026, Chrome pengguna, akun 354; data fiktif)
- Kode terpasang: layar kebijakan menampilkan parameter ke-22; validasi layar menolak 2,5 ("harus bilangan bulat 0 sampai 60").
- Lembar kebijakan: lembar id 1 (uji lama) berstatus Dibatalkan. Lembar **versi 2** dibuat (draf lewat SQL `keu_kebijakan_buat` karena bug di bawah), diisi lewat layar (rapat 2026-01-05, "UJI Notulen 02/BPS-1303/2026", tujuan mutu), `hari_cair_maks` kebijakan diubah 5 -> 4, disimpan, diajukan, disetujui lewat layar oleh akun 354 (memegang Ketua, PPK, KPA; hanya akun ini yang aktif). Status **Berlaku**; `keu_v_kebijakan_berlaku` memuat 1 baris. Penambalan `keu_kebijakan_periksa` diterima basis data.
- RAB: "Susun RAB" membuat RAB nomor 1 (Draf) untuk RO 2903.BMA.009. Kartu usulan dan rencana realisasi tampil. Tarif dari lembar v2 (translok < 8 jam Rp 170.000, konsumsi Rp 40.000); jadwal "pencairan paling lambat H+4 (lembar kebijakan): 2026-04-04". Harga 180.000 memunculkan "Harga melebihi batas tertinggi kebijakan (Rp 170.000)"; harga 160.000 diterima.
- Salin ke RAB: baris RAB id 11 pada item id 9 (Transport lokal petugas pendataan Survei Harga Kemahalan Konstruksi): volume 4 x Rp 160.000 = Rp 640.000, Mar minggu 4, keterangan "Translok PML (kurang dari 8 jam) · identifikasi lanjutan v1". Kartu menandai "Sudah disalin"; rencana menampilkan "(1 di RAB)"; Jumlah RAB Rp 640.000.
- Halaman tahap 29-32 dimuat tanpa galat dan tanpa galat konsol: identifikasi lanjutan (menampilkan "lembar kebijakan versi 2" dan tarif dari lembar), dokumen, pelaksanaan, Gap, notifikasi.
- Data uji yang tersisa: RAB nomor 1 (Draf) dengan 1 baris (id 11) pada RO 2903.BMA.009; lembar kebijakan v2 Berlaku. Tidak dihapus.

## Temuan dari uji dan perbaikannya (di laptop, menunggu commit dan push)
1. **Bug:** bila satu-satunya lembar berstatus Dibatalkan, tombol "Buat lembar dari angka predefined" tidak muncul (syarat `versi.length === 0`). Perbaikan di `kebijakan/page.tsx`: tampil bila semua versi Dibatalkan.
2. **Teks salah:** kartu menulis "belum ada lembar kebijakan yang berlaku" padahal lembar v2 berlaku, karena memakai `kebijakan_ver` acuan (versi lembar saat lanjutan disusun). Perbaikan di `UsulanIdentifikasi.tsx`: memakai versi lembar yang berlaku sekarang ("tarif dan jendela dari lembar kebijakan versi N").
3. **Ringkasan:** "siap disalin" menghitung usulan yang volumenya masih kosong. Sekarang menunggu volume atau harga dihitung sebagai "menunggu volume atau harga" (tes ditambah).
4. **Perkiraan pencairan:** semula memakai isian awal usulan (1 x Rp 170.000) walau sudah disalin. Sekarang usulan yang sudah disalin dihitung dari baris RAB-nya (jumlah Rp 640.000 dan bulan/minggu baris itu); fungsi `barisSalinan` baru, tes ditambah (90 tes lulus). Baris RAB bernilai nol dihitung "tanpa harga".

## Batas dan catatan
- Volume yang bergantung jumlah hari atau peserta rapat (translok, konsumsi) tetap diisi pengguna; identifikasi belum mencatat hari.
- "Rencana realisasi" di sini berarti perkiraan pencairan dan penjagaan anggaran pada tab RAB RO. Halaman Perencanaan lama (`/sigap/kelola/perencanaan`, bagian "Rencana realisasi" kegiatan x bulan) masih uji coba yang menyimpan data di browser dan tidak diubah.
- Harga awal semua baris masih kosong sampai ada lembar kebijakan berlaku di produksi.
- Lembar berlaku yang dibuat SEBELUM parameter ini ada tidak memuatnya; revisinya (salinan lembar berlaku) juga tidak, dan itu sah. Untuk memunculkan parameter, buat lembar baru dari angka predefined atau tambahkan pada revisi menyusul bila perlu.

## Antrean berikutnya
1. Commit dan push perbaikan 1-4 di atas, lalu uji ulang singkat di produksi (kartu rencana harus menampilkan Rp 640.000 pada Mar M4 untuk baris yang sudah disalin).
2. Sisa lama: uji lanjutan dengan identifikasi ber-H-15 masa depan; form identifikasi awal (Q-02..Q-30); hal kecil (label "Ubah / Isi ST", peringatan Gap ke Kelola translok, teks `RabInline.tsx`, padanan baris POK impor, R-06); tabel rujukan SBM/transport menunggu berkas.
