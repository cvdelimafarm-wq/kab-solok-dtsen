# Catatan SQL Fase A kertas kerja revisi POK (24 Okt 2026)

Status: **siap dijalankan di produksi oleh Bapak; belum diterapkan.** Diuji di database sandbox (PostgreSQL 16, tabel stub meniru kolom produksi `sigap_akun`, `sigap_audit`). Semua uji lulus, termasuk dijalankan ulang (idempoten).

## Berkas (urutan jalan)
Folder `claude/skema-sql/fase-a/`:
1. `20261024a_keu_master.sql` — 19 tabel: peran, kewenangan (+matriks), kelompok, pola dokumen, akun, satuan (+alias), prioritas, waktu, profil penarikan, skor (+riwayat), struktur level, jalur penambahan, registri RO, penugasan, akses Administrasi, pemberian kewenangan; fungsi `keu_boleh`, `keu_peran_akun`, `keu_jalur`, `keu_satuan_baku`, `keu_kelompok_akun`; penjaga hak, jejak ke `sigap_audit`, RLS; data awal dari mockup (akun 43, satuan 20, level 8, jalur 26, RO 35).
2. `20261024b_keu_master_dokumen.sql` — tabel `keu_master_dok` + 297 dokumen (32 pola + 265 skema).
3. `20261024c_keu_pok.sql` — `keu_tahun_anggaran`, `keu_pok_versi`, `keu_pok_node`, `keu_pok_detail`, `keu_kunci_alias`; view `keu_v_pok_selisih`, `keu_v_pok_node_tampil`; fungsi `keu_pok_berlakukan`.
4. `20261024z_cek_kesehatan_keu.sql` — hanya membaca; semua baris P0 harus 0.
Folder `claude/skema-sql/fase-a/uji/`: stub, uji, `jalan.sh`, `gen_a.js` (pembuat data awal dari `claude/referensi/kk-adm.js`).

## Cara kerja hak akses
- Aplikasi (service role) mengisi `select set_config('app.akun_id','<id>', true)` per transaksi. Penjaga tabel lalu memeriksa `keu_boleh(akun, kewenangan, ro)`. Bila kosong (SQL editor/migrasi) penulisan tidak diperiksa.
- Peran lingkup `ro` (ketua tim, admin RO, PBJ) harus ditugaskan per RO; lingkup `global` tanpa RO. Satu ketua tim aktif per RO, satu PPK dan satu KPA pada satu waktu (exclusion constraint, bermasa berlaku). Pergantian: akhiri yang lama, mulai yang baru.
- Tata Usaha baru berwenang verifikasi bila PPK memberi (`keu_pemberian`); pemberi hak verifikasi = pemegang kewenangan `sahkan` (PPK); kewenangan lain hanya Admin Aplikasi.
- Tidak ada hapus dari aplikasi (penjaga menolak DELETE saat `app.akun_id` terisi).

## Temuan saat menulis
1. **Kode RO nyata tidak selalu angka** (`2902.FAN.ZZ1`, `2886.EBA.956`): SQL menerima 3 huruf/angka. Diputuskan Bapak (D-32); mockup papan 16 sudah diperbaiki (Versi 47).
2. **Penetapan ketua tim**: hanya Admin Aplikasi (D-31); satu orang boleh banyak peran, jadi PPK yang merangkap Admin bisa. SQL sudah mendukung (uji `12_uji_rangkap_peran.sql`); teks mockup sudah diperbaiki.
3. `keu_pok_node` mendapat kolom `kemunculan` (KRO/subkomponen kembar), `ro_kode`, `volume`/`satuan` RO; `keu_pok_detail.jumlah` kini disimpan (bukan volume x harga) dengan `selisih_pembulatan`; `nomor_item` resmi terpisah dari `kunci_stabil`.
4. `harga_satuan` dibuat numeric(18,2) (bukan 0 desimal) agar harga berpecahan tidak ditolak.
5. Belum ada isi: penugasan nyata (ketua tim per RO), POK 30 Sep 2026 (menunggu parser PDF/Excel, Fase D), pemberian kewenangan. Sampai penugasan diisi, hak aplikasi tidak berjalan di DB.

## Berikutnya
Fase B (RAB, jadwal, kertas kerja, geseran) sudah ditulis dan diuji: lihat `claude/catatan-sql-fase-b-24okt.md`; menunggu Fase A dijalankan di produksi. Draf lama `20261022b_keu_anggaran.sql` tidak boleh dijalankan (digantikan; bergantung `tkl_*` yang tidak ada di produksi).
