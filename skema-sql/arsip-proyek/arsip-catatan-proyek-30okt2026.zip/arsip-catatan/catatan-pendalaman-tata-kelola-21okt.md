# Catatan pendalaman tata kelola: mockup dan skema (21 Okt 2026)

Permintaan user: "detilkan 10 kali lipat skema dan mockupnya, buat lebih reliable detil, gunakan seluruh ilmu cerdas tentang tata kelola kantor dari hukum hingga hilir". Status: MOCKUP di artifact "Kelola Pendataan SIGAP" (kanvas Design, versi 18). Kode aplikasi belum dibangun. SQL belum diterapkan ke Supabase.

## Halaman baru (16), lebar 1360, tinggi perkiraan (belum dirender)
Tata kelola: Tata-Kelola-Beranda (3300), Register-Regulasi (2900), Matriks-Kewenangan (3900), Risiko-SPIP (6000), Pelindungan-Data (3300), Audit-dan-Bukti (3600).
Anggaran dan SDM: Anggaran-Akun (2150), Anggaran-Kontrol (4300), SDM-Kinerja (5200).
Kelola Mitra: Mitra-Kontrak (5700), Mitra-Seleksi (5900), Mitra-Indikator (4200), Mitra-Keadilan (4300).
Lintas: Keadaan-Khusus (6500), Peluncuran-Bertahap (5600), Skema-Data (4700).
Menu Main punya grup baru "Tata kelola"; halaman Anggaran-POK-RAB, Mitra-Beranda, Tatakelola-Mitra, Ruang-Keputusan menautkan ke halaman baru.

## Status regulasi (jujur)
Terverifikasi dalam penelusuran: PMK 62/2023 jo 107/2024 jo 41/2026; Perpres 46/2025; UU 27/2022 (RPP pelaksana dan lembaga PDP: cek ulang Okt 2026); PermenPANRB 6/2022; Perpres 86/2007; UU 16/1997; PP 51/1999; Peraturan BPS 65/2024; Peraturan BPS 7/2025.
Pengetahuan umum, perlu dicek tim: UU 17/2003, 1/2004, 15/2004; PP 60/2008 (SPIP); UU 20/2023; PP 94/2021; UU 43/2009; UU 11/2008 jo 1/2024; Perpres 95/2018 dan 39/2019; UU 14/2008; PMK 168/2023; SBM tahunan.
Tidak terverifikasi: peraturan BPS khusus mitra (nomor, batas honor bulanan, bentuk perjanjian). Dimodelkan sebagai parameter `belum_diisi` di `tkl_parameter` (7 parameter menunggu isian admin dari ketentuan resmi). Pasal dan batas waktu revisi anggaran juga diisi admin dari teks terbaru.

## Keputusan rancangan yang diambil sendiri (untuk dinilai user)
- Pemisahan tugas: PPK, PPSPM, Bendahara tiga orang berbeda; pengecualian maksimal 90 hari (pagar buatan, bukan angka resmi).
- Dugaan kecurangan tidak pernah memutus otomatis; keputusan tetap di manusia.
- Persetujuan, log akses, bukti pajak bersifat append-only.
- Risiko: rendah 1–5, sedang 6–11, tinggi 12–19, ekstrem ≥20; hanya KPA boleh menerima risiko tinggi (maks 1 triwulan). R18 "satu orang merangkap kewenangan" sengaja dibiarkan tinggi.
- Pemantauan keadilan memakai agregat kelompok oleh pengelola data pribadi; atribut sensitif tidak masuk skor atau penempatan.
- Peluncuran bertahap: mode bayangan dahulu, uji penerimaan 26 skenario.
- Komitmen dan realisasi anggaran disimpan sebagai jenis `keu_transaksi`; profil mitra = `sigap_akun`.

## Skema SQL
Berkas: `claude/skema-sql/` (10 migrasi + stub master untuk uji). Urutan: a, b, c, d, e, f, h, i, j, k (tidak ada g; k menggantikannya).
Hasil uji di Postgres 17.6 dengan master tiruan: 113 tabel + 10 view = 123 objek, 156 kasus uji, 0 temuan P0, 281 FK, 449 CHECK, 9 EXCLUDE, 95 trigger, rantai jejak utuh.
Acuan: `claude/acuan-skema-portal.md` (orang = sigap_akun.id, kegiatan = sigap_kegiatan.id, wilayah = kode BPS, RLS aktif, tanpa hapus permanen, audit ke sigap_audit).
Prefix modul: keu_, kual_, mitra_, sdm_, tkl_.

## Langkah berikut yang disarankan
1. Tinjau SQL (khususnya RLS dan trigger) sebelum diterapkan; terapkan dulu ke cabang/branch Supabase.
2. Kalibrasi bobot Skor Jejak, ambang tingkat, dan jangka waktu bersama tim.
3. Isi 7 parameter `belum_diisi` dari ketentuan resmi.
4. Tim memverifikasi teks peraturan yang bertanda "perlu dicek".
5. Render dan koreksi tinggi artboard; uji klik semua halaman.
