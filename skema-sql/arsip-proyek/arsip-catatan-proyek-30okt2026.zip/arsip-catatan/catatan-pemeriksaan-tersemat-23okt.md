# Catatan 23 Okt 2026 (tahap 2 dan 3): Kelola Pendataan menyematkan isi halaman (tab 5, 2, dan 6)

Lanjutan dari catatan-kelola-pendataan-sidebar-tab-23okt.md. Kode SUDAH ditulis ke repo laptop; tsc/vitest penuh/build dijalankan user. Tanpa SQL, tanpa API baru.

## Yang berubah
- Tab Pemeriksaan kini punya tiga sub-pilihan tersemat: **Identifikasi SLS · Lapangan per petugas · Foto & dokumentasi**. Alamat: `/sigap/kelola/pendataan?tab=pemeriksaan&sub=identifikasi|lapangan|foto` (Identifikasi = tanpa `sub`). `lib/sigapPendataanTab.ts`: `SUB_PEMERIKSAAN`, `bacaSubPemeriksaan`, `urlSubPemeriksaan`; `?sub` dibuang saat pindah tab lain. Tes 16 lulus (di sandbox).
- Isi tiga halaman lama dipindah ke komponen (aturan Next.js 15: page tidak boleh mengekspor selain default): `pendataan/MonIdentifikasi.tsx`, `MonLapangan.tsx`, `KelolaFoto.tsx` dengan prop `tertanam` (menyembunyikan tautan balik/judul besar/latar halaman penuh). `identifikasi/page.tsx`, `lapangan/page.tsx`, `foto/page.tsx` kini hanya membungkus komponen itu, jadi alamat lama tetap hidup.
- `pendataan/Pemeriksaan.tsx` (baru) = pemilih sub + komponen + item "segera hadir" (Sanggahan dan pengawasan PML, Penutupan wilayah) dari `PintuMasuk`. `PINTU_TAB.pemeriksaan` tinggal item "segera".
- Foto & dokumentasi tetap hanya untuk akun super / izin MENU_ADMIN_FOTO (pesan galat tampil di dalam tab bagi yang tidak berhak).

## Tahap 3 (tab 2 dan tab 6)
- Komponen tab Admin Transport Lokal (`app/sigap/admin/TabPenugasan|TabMonitoring|TabVerifikasi|TabKegiatan.tsx`) ternyata sudah berupa komponen mandiri (hanya butuh `kegiatanId`; Monitoring juga `kegiatan` + `hariIni`), jadi disematkan langsung untuk kegiatan Pendataan (`KEGIATAN_PENDATAAN` = 1 = `KEGIATAN_PENDATAAN_ID`).
- `pendataan/TransportLokal.tsx` (baru): memanggil `ambil("ringkas")`, mengecek izin `translok.*` untuk kegiatan 1 lewat `bolehKlien`, lalu menggambar tab; tanpa izin = pesan info. Server tetap memeriksa tiap panggilan.
- Tab 2 `Tim.tsx`: sub **Alokasi & pelatihan** (pintu masuk /bencana + Kelola Pelatihan) dan **Penugasan & ST** (TabPenugasan). Tab 6 `Administrasi.tsx`: sub **Monitoring transport lokal**, **Verifikasi & Kunci**, **Kegiatan & Tarif** (tersemat) dan **Anggaran & pengadaan** (pintu masuk perencanaan, pengadaan + item "segera").
- Alamat: `?tab=tim|administrasi&sub=...` (sub pertama = tanpa `sub`). `lib/sigapPendataanTab.ts`: `SUB_TIM`, `SUB_ADMINISTRASI`, `SUB_PER_TAB`, `bacaSubDari`, `urlSubDari`; `urlTabPendataan` mempertahankan `?sub` hanya bila tab tidak berpindah (bug awal tertangkap tes). `useSubTab.tsx` = hook + tombol sub bersama. `PINTU_TAB` tinggal item yang masih tautan. Tes 21 lulus di sandbox; alamat lama /sigap/kelola/translok (-> /sigap/admin) tetap hidup.
- Catatan: `TabKegiatan` di sini `bolehBuat={false}` (tidak membuat kegiatan baru; itu tetap di Admin Transport Lokal).

## Tahap 4 (Pengadaan & kontrak di tab 6)
- Isi `/sigap/kontrak` dipindah ke `pendataan/Pengadaan.tsx` (prop `tertanam`; mode tertanam = tombol Paket/Master tahun/Penyedia + pilih TA tanpa Bingkai). `kontrak/page.tsx` kini pembungkus, jadi `/sigap/kontrak` dan `/sigap/kelola/pengadaan` tetap hidup.
- Tab 6 kini lima sub: Monitoring transport lokal · Verifikasi & Kunci · Kegiatan & Tarif · **Pengadaan & kontrak** (tersemat) · Anggaran & lainnya (pintu masuk Perencanaan + item "segera"). `PINTU_TAB.administrasi` kehilangan item pengadaan. Tes 21 lulus (sandbox).
- Perencanaan (`/sigap/kelola/perencanaan`, 94 KB, uji coba, data localStorage, alamat sendiri `?ro=&keg=&tahap=&bagian=`) SENGAJA tidak disematkan: parameter alamatnya bentrok dengan `?tab`/`?sub`.

## Masih tersisa
- Masih berupa pintu masuk (halaman berat): /bencana (555 KB; alokasi/papan tim), Kelola Pelatihan, Perencanaan (94 KB).
- Fitur baru tab 5-6 (sanggahan/pengawasan PML butuh migrasi 20261019c; penutupan wilayah; paket SPJ; honor; dinas) belum ada.
- Konfirmasi user: tujuan "Beranda".

## Uji setelah deploy
/sigap/kelola/pendataan?tab=pemeriksaan: tiga tombol sub; Identifikasi (buka baris PML, Ekspor Excel); Lapangan (saringan tanggal, Unduh Excel, tabel melebar bisa digeser di HP); Foto (saklar per kegiatan, periksa foto); ubah tab lalu kembali, `?sub` ikut; alamat lama /sigap/kelola/identifikasi, /lapangan, /foto masih terbuka.

## Uji tambahan tahap 3
?tab=tim&sub=penugasan (daftar petugas, unggah ST); ?tab=administrasi: Monitoring, Verifikasi & Kunci (pratinjau SPJ, kunci), Kegiatan & Tarif (tarif Pendataan terbaca); akun tanpa izin translok melihat pesan izin; pindah tab lalu kembali memulai dari sub pertama.
