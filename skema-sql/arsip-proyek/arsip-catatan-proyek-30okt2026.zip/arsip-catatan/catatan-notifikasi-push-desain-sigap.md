# Notifikasi push + desain SIGAP (8 Okt 2026)

## Notifikasi push (Web Push / VAPID)
- Tabel: `sigap_push_langganan` + riwayat kirim (migrasi `20261008l_sigap_push.sql`, tabel SUDAH diterapkan di DB).
- Server: `lib/sigapPush.ts` (kirim ke akun, TTL 6 jam, urgensi tinggi, 10 paralel), `lib/sigapPushUtil.ts` (validasi: hanya host layanan push resmi, tautan internal saja, judul <=80, isi <=240).
- API peserta: `app/api/sigap/push/route.ts` (GET status, POST daftar/batal/uji). API panitia: `app/api/sigap/pelatihan/admin/push/route.ts` (izin `pelatihan.kelola`).
- Klien: `app/portal/pushKlien.ts`, `AktifkanNotifikasi.tsx` (kartu di Beranda portal dan halaman Langkah Pelatihan); keluar akun -> `matikanPush` (lepas langganan perangkat).
- Panitia: Kelola Pelatihan > tab Notifikasi (`kelola/notifikasi.tsx`).
- Service worker `public/sw.js` versi `sigap-v2` (handler push + notificationclick).
- WAJIB diatur di Railway: `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` (buat dengan `npx web-push generate-vapid-keys`), opsional `VAPID_SUBJECT`. Tanpa ini tombol Aktifkan tidak muncul.
- Tiap peserta harus menekan "Aktifkan notifikasi" sekali setelah deploy. iPhone: harus Add to Home Screen dulu.
- Belum diuji langsung di perangkat. Posttest 8 Okt sudah ditutup 21.00, jadi pengingat malam itu tidak relevan.

## Desain (identitas visual, mockup artifact 2ShXk3TgW5NeeZ5QPLtuAt)
- Palet: biru aksi #1F5FD1, navy #0F2A52, emas #F4B400, latar #F5F8FE; hijau #13794B/#19A463, kuning #8A6200 di #FFF4D6, merah #B42329 di #FDE8E8.
- Header: gradasi #1A4590 -> #0F2A52, petak putih berisi lambang S (`public/sigap-logo.png`) + "SIGAP / SISTEM INTEGRASI KEGIATAN BPS" (di `app/sigap/admin/ui.tsx` HeaderAdmin, dipakai semua halaman SIGAP).
- PWA: `app/manifest.ts` (short_name SIGAP, theme #0F2A52), ikon di `public/icons/*`, `app/favicon.ico|icon.png|apple-icon.png`, `layout.tsx` (themeColor, applicationName).
- Halaman HP pelatihan (Langkah, Undangan, Instrumen, Tes): kartu 18 px berbayangan lembut, lencana status, kartu "Langkah berikutnya" (ikon gradasi + tombol biru penuh), bar progres bersegmen per langkah, tombol 13 px.
- Belum: desain "backoffice padat" laptop (baris 34 px, panel kanan 340 px), recolor seluruh halaman Kelola/Admin, halaman kuis live, offline penuh/install prompt, logo vektor, layar login PWA.
- File ber-warna lama (#1F6FD1, #0E2A47, #D9971F) masih ada di halaman lain; selisihnya kecil dan tidak merusak.

## Berkas ikut commit (semua sudah ditulis ke laptop, belum di-commit/push)
package.json + package-lock.json (web-push), manifest.ts, layout.tsx, sw.js, portal/(Masuk, Beranda, GantiPinCepat, AktifkanNotifikasi, pushKlien), sigap/admin/(api.ts, ui.tsx), sigap/pelatihan/(page, komponen, pulsa, pengumumanUi, instrumen, undangan, tes/[jenis], kelola/page, kelola/notifikasi), api/sigap/push, api/sigap/pelatihan/admin/push, lib/sigapPush*.ts, aset ikon.
