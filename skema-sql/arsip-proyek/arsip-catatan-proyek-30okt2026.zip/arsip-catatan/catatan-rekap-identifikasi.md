# Catatan: Rekap Hasil Identifikasi (tombol di tahap Pendataan)

Dibuat 11 Okt 2026. Permintaan user: tombol di pojok kanan bawah pada tahap 3 (Pendataan), bisa dilihat PPL dan PML; rekap seluruh hasil identifikasi, ekspor Excel, salin sebagai gambar per nagari atau per kecamatan; yang tampil hanya Sub SLS dan statusnya.

## Status yang ditampilkan (diperbarui 11 Okt 2026 sore)
Tiga status: Terdampak (hijau), Tidak terdampak (biru), Belum diidentifikasi (abu-abu). Sub SLS yang belum diidentifikasi ikut tampil atas permintaan user.
- Cakupan "belum": semua Sub SLS pada SLS yang sudah dialokasikan ke PML (`bencana_identifikasi_alokasi`) = 621 Sub SLS, 33 nagari, 12 kecamatan; saat dibuat 156 sudah (79 terdampak, 77 tidak) dan 465 belum. SLS yang belum dialokasikan tidak ikut (belum jadi tanggung jawab siapa pun). Total Sub SLS di database 1.084.
- Data "sudah" berasal dari hasil identifikasi PML (`bencana_identifikasi_subsls.diisi_at`), 10 Okt 86 baris/16 akun dan 11 Okt 70 baris/10 akun.

## Target & realisasi per PML (ditambah 11 Okt 2026 malam; pesan user "Monitoring target realisasi")
- Tab ketiga "Per PML" di dialog rekap: kartu total (realisasi/target, persen, jumlah PML selesai), urutan "Terendah dulu" atau "Nama", per PML batang progres + terdampak/tidak/belum + pendamping. Tombol Salin gambar membuat gambar tabel per PML; Excel mendapat sheet "Target-Realisasi PML".
- Definisi: target PML = Sub SLS pada SLS yang dialokasikan kepadanya sebagai PELAKSANA (tiap SLS satu pelaksana, jadi total = 621 tanpa ganda); realisasi = dari target itu yang sudah diidentifikasi, siapa pun yang mengisi. Peran pendamping dihitung terpisah (target/realisasi pendamping), tidak masuk total. Persen dibulatkan ke bawah. Saat dibuat: 19 PML pelaksana, 12 pendamping; realisasi pelaksana 158 dari 621.
- Migrasi `20261011j_rekap_pml.sql` (fungsi `bencana_rekap_pml()`, SECURITY DEFINER, hanya service_role; sudah diterapkan). API rekap kini mengembalikan `pml`; kegagalan baca PML tidak menggagalkan rekap utama.
- Belum ada di halaman admin Monitoring Lapangan (usul: tampilkan kartu yang sama di sana).

## Yang dibangun
- Migrasi `20261011g` (fungsi lama `bencana_rekap_identifikasi()`, hanya yang sudah diisi) dan `20261011h` (fungsi BARU `bencana_rekap_identifikasi_v2()` dengan kolom `sudah`; SECURITY DEFINER, hanya service_role). Keduanya sudah diterapkan di Supabase. DROP fungsi lama macet (timeout) sehingga dibuat versi `_v2`; fungsi lama tak dipakai lagi dan boleh di-drop belakangan.
- API `GET /api/portal/identifikasi/rekap` + `lib/portal/rekapIdentifikasi.ts` (memanggil `_v2` dan `bencana_rekap_pml`): boleh bagi petugas aktif (pml/ppl/korwil atau organik) dan admin `bencana.admin`.
- `lib/rekapIdentifikasi.ts` (logika murni, 19 uji): pengelompokan per nagari/kecamatan, hitungan terdampak/tidak/belum, baris gambar, kolom Excel, ringkasan dan urutan PML.
- UI: `RekapIdentifikasi.tsx` (tombol melayang + dialog), `gambarRekap.ts` (canvas -> PNG; nagari satu kolom 680 px, kecamatan dua kolom 420 px, per PML tabel 760 px), disambung di `page.tsx` tahap (modul `identifikasi` atau `pendataan`, tahap tak terkunci).

## Status pemasangan
- tsc bersih, 131 uji lulus (7 berkas); gambar nagari/kecamatan/per PML sudah dirender dan dilihat (data contoh).
- Seluruh berkas fitur, termasuk Per PML (migrasi j), sudah tertulis ke folder proyek laptop (11 Okt 2026, setelah laptop tersambung lagi). Belum di-commit git/push/deploy.
- Belum diuji di HP/peramban sungguhan (salin gambar ke clipboard di Android/iOS).
