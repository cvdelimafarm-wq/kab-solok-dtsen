# Catatan plotting 12 jorong tambahan (PDF verifikasi) & screening NTP — 4 Okt 2026

Status: CATATAN SARAN, belum ada alokasi PPL yang ditulis ke `bencana_alokasi_subsls`.

## Komposisi wilayah kerja (sampel = 228 Sub SLS)
- 192 Sub SLS dari identifikasi jorong oleh mitra/PPL (`bencana_identifikasi_jorong`, selain baris PDF): 169 berada di 29 nagari alokasi awal pusat (`bencana_wilayah.daftar_awal`), 23 di luar.
- 36 Sub SLS dari 12 jorong "REKAP DATA VERIFIKASI 4-6 JANUARI 2026" (PDF; baris `nama_mitra = 'Rekap Verifikasi 4-6 Jan 2026 (PDF)'`, id 243-254), semua di nagari alokasi awal pusat.
- `daftar_awal` = alokasi awal pusat: 29 nagari, 636 Sub SLS (nagari-level; bukan otomatis masuk wilayah kerja).
- Balai Gadang (idsls 13031300050002): KK terdampak 135,5/Sub SLS karena isian lama Sri Wellia (lahan_ternak 40 + efek_berantai 200) ikut terjumlah; PDF = 31 KK. Keputusan A (override 15,5) / B (biarkan) menunggu user.

## Aturan rangkap NTP (arahan user)
- PPL SPDT NTP 2026 tidak boleh rangkap bencana (kecuali Lia Angraini). PML NTP boleh rangkap tetapi dihindari.
- Kolom baru `bencana_petugas_kegiatan_lain.peran_kegiatan` (PPL/PML) dan `catatan` (migrasi `bencana_kegiatan_lain_peran`).
- Flag SPDT NTP 2026 kini 59 petugas (53 berperan terisi: 38 PPL, 15 PML). Belum cocok di roster: Lingga Ayunda Pradipta, Hadisty Nelva. Ber-flag tetapi tidak ada di PDF: Aidil Ode Pitra, Annisa Musri, Halimah Tusa'diah, Meigi Yeliza, Shinta Julfitri, Silki Ikrima (belum dikonfirmasi user).

## Rencana penugasan <5 km (tentatif)
Weza Deftalia -> Aia Tawa Selatan 01-04; Idora Atia -> Balai Tangah 01-02; Ayang Syafriani (pengganti Mirvan, NTP PPL) -> Balai Tangah 03; Yogi Eka Putra -> Kampung Tangah 00; Nelva Roza Oktakia -> Kapondong 00; Bayu Pratama -> Balai Gadang 01; Agri Renta Falusia -> Balai Gadang 02; Nurul Vani Fatia -> Mudik 02; Mira Apridayanti -> Jaruai 00 & Karimbang 03; Fenny Anda Listi -> Karimbang 01.
Belum terpenuhi (21 Sub SLS): Kampuang Dalam Tangah 7, Pasa 6, Rimbo Data 5, Batu Putih 1, Mudik 01, Karimbang 02. Mitra baru bersih NTP: Desi Warni, Filzah Asyet (Solvia = PML NTP; Bukhtiar = PPL NTP, tidak boleh).
PPL bencana yang bentrok NTP dan masih memegang alokasi: Zahria Fitri Andini (5 Sub SLS), Aniza Nurzanah (2), Mirvan Harvia (2), Sherli Handayani (1, sudah menolak).
