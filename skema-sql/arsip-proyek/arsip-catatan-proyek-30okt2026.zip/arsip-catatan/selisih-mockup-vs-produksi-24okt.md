# Selisih mockup "Kertas Kerja Revisi POK SIGAP" vs web produksi (24 Okt 2026)

Mockup: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap (16 papan). Pembanding: https://bps-solokkab.up.railway.app (RO fiktif 2906.BMA.005, akun 354). Diperiksa dari sumber mockup (struktur, kolom, aturan) dan tangkapan layar produksi.

## Papan 1: Kertas kerja, RAB, RAB bulanan (selisih TERBESAR)
Mockup: satu halaman lebar penuh "Kertas Kerja Revisi POK, TA 2026" di bawah Anggaran > Revisi POK (alamat Keuangan/Revisi Anggaran/Kertas kerja), berskala satker/KRO (contoh KRO 2903.BMA: 3 RO, 80 detail, Rp 640.959.000), dengan tiga sub-tab Kertas kerja | RAB | RAB bulanan.
- Kepala halaman: Program/Kegiatan/KRO, status "Draf, belum diterapkan", tombol "Kembali ke semula"; kartu KPI Kelengkapan RAB, Realisasi TA lalu, Realisasi resmi SPAN, Pagu KRO (Semula/Menjadi/Selisih); pilihan Jenis revisi + saran sistem + tenggat Pasal 175.
- Panel "Pemeriksaan kesesuaian R-01 sampai R-17" dengan hitung merah/kuning/hijau/info.
- Panel "Kecukupan KRO terhadap RAB": faktor kebutuhan K, toleransi, per kelompok (51, 524, 52 lain, 53), status Kurang/Tipis/Cukup/Lebih, POK usulan, kategori prioritas (urutan, nama, boleh ditunda), buku selisih (kebutuhan belum terdanai), jalur DIPA, contoh isian dan skenario.
- Matriks 15 kolom berhierarki RO (biru tua) > Komponen > Akun (kuning) > Item: kolom SEMULA (Vol, Sat, Harga, Jumlah) | MENJADI (Vol, Sat, Harga, Jumlah; bisa diketik, rumus =18*2 diterima) | PERUBAHAN (Selisih, Pemicu) | KETERSEDIAAN (Booked, Realisasi, Cek). Lajur Semula biru, Menjadi hijau; sel berubah kuning, baris baru hijau, RO penerima luar KRO ungu.
- Setiap kolom punya urut, filter, dan pencarian; kotak centang baris/akun/RO membuka bilah aksi massal (Ganti akun, Batalkan pindah akun, Tambah item di akun, Tandai selesai, Buka kembali, Tampilkan RAB, Hanya yang dipilih); Ciutkan sampai RO / Buka semua; Hapus filter dan urutan kolom.
- Tombol "Turunkan item yang boleh ditunda", "Terapkan RAB dalam batas pagu", "Terapkan RAB penuh (Revisi DIPA)".
- Baris "Dana penggenap" per akun (akun 524: Perjalanan dinas Kabupaten), tidak boleh minus, harus tepat pagu (R-17); baris pindahan akun dengan penanda asal/tujuan.
- Sub-tab RAB: versi v1 Salinan POK dan v2 Penyesuaian kebutuhan, rincian per item (Vol/Sat/Harga/Jumlah, mulai, tag minggu, periode, per bulan, catatan, tautan), status RAB per item, alasan versi minimal 10 karakter. Sub-tab RAB bulanan: matriks item x 12 bulan dengan tag minggu, format, perkiraan pencairan per bulan.
Produksi (4f): tab "Kertas kerja" DI DALAM satu RO; kartu KPI 4 buah; tabel per komponen/akun dengan kolom isian Menjadi; tombol per baris (Ganti akun/redaksi, Kosongkan, Hapus); form Item baru dan Dana penggenap; buku geseran; kartu kecukupan KRO; kartu R-xx. Tidak ada: matriks 15 kolom berwarna, filter/urut per kolom, aksi massal/kotak centang, Booked/Realisasi/Cek, jenis revisi + saran, tenggat, KPI SPAN/TA lalu, faktor K + kategori prioritas + buku selisih, sub-tab RAB rinci dan RAB bulanan, halaman satker/KRO.

## Papan 9, 10, 11 (navigasi, peran, jadwal)
- Papan 11 (Jadwal dan pengesahan): sudah SERUPA di produksi (kartu POK berlaku, pengingat Pasal 175, riwayat versi, daftar jadwal, tambah jadwal). Perlu cek: form sah (nomor + tanggal), laporan ke KPA, 12 jadwal bawaan 2027.
- Papan 9 (Navigasi RO): tab mockup = Ringkasan, Anggaran, Revisi, Administrasi, Tim dan akses; lencana; Kembali menyebut tujuan; alamat membawa dari=. Produksi: Ringkasan, Anggaran, RAB, Administrasi, Kertas kerja, Kekurangan RAB; tombol "Daftar RO"; tidak ada tab Revisi (usulan per RO) dan Tim dan akses; parameter dari= belum ada.
- Papan 10 (Peran, akses, persetujuan): alur persetujuan usulan RO (ketua tim > PPK > KPA lapor) belum terlihat di UI produksi.

## Papan 12, 13, 15 (POK resmi, Administrasi, Kekurangan)
- Papan 13 Administrasi: produksi sudah memuat dokumen per item; selisih: daftar dua kolom (item kiri, dokumen kanan), filter status, "Hanya bagian saya", "Buat semua yang dapat dibuat SIGAP", pihak/keterangan per dokumen, riwayat.
- Papan 15 Kekurangan: produksi punya pencatatan, kesempatan tambahan pagu, keputusan; periksa kesamaan tata letak dan ringkasan 4 kartu.
- Papan 12: realisasi mingguan (GLP039) dan skor RAB ada; unggah PDF POK resmi + pencocokan dengan POK sistem BELUM dibangun.

## Belum dibangun sama sekali
Papan 2 Alur, 3 Pemicu (tampil sebagai label P-xx di kertas kerja), 4 Lampiran (draf surat), 5 Status/riwayat, 6 Impor POK hasil penetapan, 7 Versi/RPD/dampak, 8 Peta KRO Satker, 14 Master data (edit), 16 Struktur level baru.

## Saran urutan (menunggu keputusan Bapak)
1. Papan 1 sub-tab Kertas kerja sebagai halaman satker/KRO (matriks + panel), memakai ulang SQL 4f.
2. Papan 1 sub-tab RAB dan RAB bulanan.
3. Papan 9/10: tab Revisi dan Tim, dari=, persetujuan usulan RO.
4. Papan 12 (PDF POK), 8 (Peta), 14 (Master), 16 (Struktur), lalu 6, 7, 4, 5.
