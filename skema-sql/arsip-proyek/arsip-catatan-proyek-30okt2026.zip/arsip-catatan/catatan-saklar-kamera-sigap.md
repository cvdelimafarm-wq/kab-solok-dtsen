# Saklar Kamera SIGAP (19 Okt 2026)

Pelengkap `claude/rancangan-kamera-sigap-berbagi-foto.md`. Status (diperbarui 19 Okt 2026): kode dan SQL sudah ditulis, BELUM dipasang atau dijalankan. Lihat `claude/catatan-kamera-sigap-implementasi.md`. Mockup layar 8 di kanvas "Cap Foto & Berbagi Foto SIGAP" (https://claude.ai/artifact/7gtrHsoRqMu31D32guxHAg).

## Keputusan user
- Seluruh ketentuan Kamera SIGAP (kamera dalam aplikasi, cap, tag dan berbagi foto, verifikasi kode/QR, tingkat kepercayaan) dapat dihidupkan atau dimatikan.
- Dimatikan = kembali ke ketentuan sekarang: petugas memilih berkas foto dan mengunggahnya.
- Tingkat saklar: per kegiatan, dengan bawaan global; kegiatan bisa menimpa (Ikuti bawaan / Kamera SIGAP / Unggah foto).
- Fase kode dan SQL disetujui 19 Okt 2026; user yang menjalankan SQL, commit, dan push.

## Aturan
- Perubahan saklar berlaku untuk foto berikutnya; foto yang sudah ada tidak berubah dan tidak dihapus.
- Tiap baris `sigap_dokumentasi` menyimpan sumbernya (`kamera` / `unggah`), jadi keduanya bisa berdampingan dalam satu kegiatan.
- Setiap perubahan saklar dicatat ke `sigap_audit` (aksi `foto.saklar`: tingkat, dari, ke, siapa, kapan).
- Yang bisa mengubah: akun super atau izin `translok.verifikasi` level kelola (konstanta `MENU_ADMIN_FOTO`).
- Penghapusan foto tetap hanya setelah persetujuan user.

## Implementasi (belum dipasang)
- Tabel `sigap_foto_pengaturan` (satu baris, `mode_bawaan` default `unggah`, jadi migrasi tidak mengubah perilaku) dan `sigap_foto_pengaturan_kegiatan` (mode ikuti/kamera/unggah).
- API `/api/sigap/foto/pengaturan` (GET/POST, admin) dan `/api/sigap/foto/mode` (GET, petugas). Halaman Kelola `/sigap/kelola/foto`.
- Gerbang tampilan `FotoKegiatan`: mode unggah atau saklar gagal dibaca menampilkan komponen unggah lama (prop `fallback`); kamera tidak pernah dipaksa.
- Route kamera menolak (403) kegiatan bermode unggah. Route unggah lama tidak diubah dan tidak diblokir.
- Pemulihan darurat lewat SQL: `update sigap_foto_pengaturan set mode_bawaan='unggah' where id=1;` dan `update sigap_foto_pengaturan_kegiatan set mode='unggah';`.
