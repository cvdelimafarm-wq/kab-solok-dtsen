# Catatan: Nomor foto Transport Lokal, kisi + tukar + konfirmasi dan peringatan hanya soal jam (23 Okt 2026)

Cakupan: hanya tampilan dan alur interaksi panel "Nomor foto N/5" (SusunFoto). Aturan penomoran, penyimpanan foto, foto cadangan, dan penghitungan SPJ tidak diubah. Tidak ada migrasi SQL.

## Keputusan pemilik yang diterapkan
1. Peringatan ⚠ di panel ini HANYA soal jam: foto bernomor lebih kecil tercatat lebih akhir daripada foto bernomor lebih besar. Jam dibandingkan pada ketelitian menit (yang tampil di layar); jam yang sama tidak dianggap salah. Unggahan manual (tanpa jam), nomor kosong, foto tahanan, dan foto cadangan tidak dinilai.
2. Alasan satu kalimat di bawah kisi: "Jam foto 4 (13.55) lebih akhir dari foto 5 (13.48)". Maksimal tiga baris, sisanya "+N lagi". Pasangan berdekatan didahulukan.
3. Lencana kepercayaan ("Wajar" / "Perlu perhatian") DIHAPUS dari panel ini, termasuk baris foto tahanan dan foto cadangan. Foto cadangan hanya menampilkan jam.
4. Kriteria lain tidak memunculkan peringatan di tampilan ini.

## Hasil audit: dari mana label "Perlu perhatian" / "Wajar" berasal
Label berasal dari `LABEL_KEPERCAYAAN` (lib/sigapFoto.ts): hijau = "Wajar", kuning = "Perlu perhatian", merah = "Ditahan, perlu diperiksa". Tingkat dihitung `nilaiKepercayaan()` saat potret. Kuning bila salah satu: bendera waktu (token tidak ada / jam server), jam HP beda > 2 menit, akurasi GPS > 300 m, posisi GPS basi (> 2 menit), titik 5-10 km dari KK wilayah dan rumah (luar_wilayah_dekat), titik > 10 km (jauh_dari_wilayah, sejak 23 Okt kuning bukan merah), koordinat identik dengan foto hari lain, gambar mirip foto lain (dHash <= 10). Merah bila: waktu token tidak wajar, jam HP beda > 1 jam, perpindahan > 120 km/jam. Tidak ada kriteria urutan jam di dalamnya.
Kasus PPL Yola (foto 2 pukul 12.45 dan foto 3 pukul 12.57 berlabel "Perlu perhatian" padahal urutan jam benar): penyebabnya `jauh_dari_wilayah` (kuning), bukan jam.
Tempat lain yang memakai kriteria/label yang sama dan TIDAK diubah: PeriksaFoto (PML/admin), Foto saya (`statusPemeriksaan`: "Wajar", "Menunggu diperiksa", "Ditahan, menunggu diperiksa"), KameraSigap (pratinjau/hasil kirim), SPJ/Kwitansi/laporan admin, dan penahanan foto merah di API susun. Hanya panel SusunFoto yang tidak lagi memakainya.

## Alur baru (SusunFoto.tsx)
- Kisi 3 + 2: thumbnail, nomor, peran singkat (Berangkat, Tiba di lokasi, Mendata/Pelatihan, Pulang, Tiba di rumah/kediaman), jam. ⚠ di kedua slot yang bentrok. Satu kalimat petunjuk tetap; panduan panjang dilipat ("Lihat panduan").
- Tukar: ketuk foto A (bingkai + teks "Pilih foto yang mau ditukar"; ketuk lagi = batal), ketuk foto B -> modal konfirmasi: judul "Apakah Anda yakin mengubah urutan 2 foto ini?", dua foto + ⇄ + nomor + jam, satu baris akibat ("Foto N akan menjadi '<peran>' (nomor M), ..."), kalimat akibat jam ("Setelah ditukar, urutan jam sesuai dan peringatan ⚠ hilang." / "Urutan jam masih terbalik pada foto N dan M." / "akan menjadi terbalik"), tombol "Ya, tukar" dan "Batal". Penukaran tetap boleh walau jam masih terbalik. Tombol dinonaktifkan saat menyimpan. Gagal (offline/konflik): pesan jelas di modal, urutan di layar tidak berubah.
- Ketuk di luar modal tidak melakukan apa pun (tidak mengonfirmasi, tidak menutup). Hanya Batal / Esc yang menutup.
- Hasil selalu tukar. Tujuan nomor kosong = pindah (judul modal "memindahkan foto N ke nomor M").
- "Urutkan sesuai jam": pratinjau modal (pasangan yang bertukar + urutan sesudahnya), tombol "Ya, urutkan" / "Batal". Jam sama pada ketelitian menit = urutan lama dipertahankan. Unggahan manual dan nomor kosong tidak bergeser.
- Foto cadangan: baris kecil di bawah kisi; ketuk cadangan lalu ketuk nomor (atau sebaliknya) -> modal "Foto di nomor N akan pindah ke cadangan."
- Detail satu foto (lembar bawah): foto besar, jam, koordinat + "Buka di peta", alasan ⚠ terkait, "Tukar dengan…", "Ambil ulang foto" (+ "Foto lama tersimpan sebagai cadangan."), Tutup. Dibuka lewat tombol "Detail foto" pada pilihan di bawah kisi (ketuk foto yang sama lagi = batal pilihan, sesuai butir B).
- Istilah seragam: "Tukar urutan", "Ambil ulang foto", "Foto cadangan". KameraSigap.tsx: tombol "Rapikan nomor foto" -> "Tukar urutan foto", mode/konfirmasi "ganti foto" -> "ambil ulang foto", petunjuk "dipindah atau ditukar" -> "ketuk dua foto untuk menukar urutannya". FotoKegiatan.tsx: "merapikan nomor foto" -> "menukar urutan foto".

## Berkas
Baru: `lib/sigapUrutanFoto.ts` (murni: bentrok jam, alasan, kalimat akibat, rencana urut), `lib/__tests__/sigapUrutanFoto.test.ts` (24 tes).
Diubah: `app/sigap/foto/SusunFoto.tsx` (ditulis ulang), `app/api/sigap/foto/susun/route.ts`, `lib/__tests__/fotoSusunRoute.test.ts` (+12 tes), `app/sigap/foto/KameraSigap.tsx` dan `FotoKegiatan.tsx` (hanya teks).

## API susun (perubahan, kompatibel mundur)
- Aksi baru `urutkan`: rencana dihitung server dengan fungsi yang sama dengan klien; semua cek (termasuk batas wilayah nomor 2-4 `diLuarWilayah`) dilakukan sebelum menulis; dijalankan sebagai rangkaian `sigap_foto_pindah_nomor`; bila satu langkah gagal, langkah yang sudah jalan dibalik (urutan tidak pernah setengah berubah); audit `foto.diurutkan_jam`.
- `pindah`/`pasang`/`urutkan` menerima `harap_*` opsional (apa yang dilihat petugas). Bila server sudah berbeda (mis. diubah dari HP lain) -> 409 "Susunan foto sudah berubah..." dan tidak ada yang diubah.
- GET: foto di nomor/cadangan kini membawa `lat`,`lng` (untuk lembar detail; tidak dipakai menilai apa pun).

## Keputusan yang saya ambil sendiri (mohon ditinjau)
1. Foto cadangan tidak boleh dipasang ke nomor yang berisi UNGGAHAN MANUAL (akan menimpa dan foto manual tidak tersimpan sebagai cadangan). Kisi menampilkan petunjuk. Sebelumnya "Pasang di nomor" boleh. Alasan: butir "tidak pernah menimpa". Bila perlu, bisa dilonggarkan dengan peringatan keras.
2. Foto merah/menunggu diperiksa (tahan) hanya bisa dipesankan ke nomor yang masih kosong; sebelumnya boleh ke nomor terisi tetapi pesanan tidak terlihat (tertulis di tag, tidak tampil di kisi).
3. Tujuan "nomor kosong" tetap didukung lewat alur tukar (pindah); kalau tidak, kemampuan lama memindah foto ke nomor kosong hilang.
4. Ikon kecil per foto untuk membuka detail tidak dibuat (kisi 3 kolom di 360 px terlalu sempit untuk target 44 px); detail dibuka lewat tombol "Detail foto" setelah foto dipilih.
5. Seret-lepas tidak dibuat (opsional di rancangan).
6. Modal "Tugas hari ini" yang memuat istilah lama tidak ditemukan di berkas yang bisa saya baca (hanya label kartu "TUGAS HARI INI" di kegiatan/[id]/page.tsx). Teks "Rapikan nomor foto" yang ditemukan hanya di tombol banner KameraSigap (layar kamera). Bila modal itu ada di berkas lain, istilahnya masih lama.

## Pengujian
- Unit (vitest): sigapUrutanFoto 24 tes + fotoSusunRoute 36 tes lolos (aturan jam minute-resolution, kasus Yola tanpa peringatan, rencana urut, balik-langkah saat gagal, 409 layar usang, 422 wilayah).
- Render di lebar HP 360 px (Chromium, data tiruan; belum di server asli): tidak ada scroll horizontal; semua tombol >= 44 px dan tanpa patah baris; ketuk di luar modal tidak mengonfirmasi dan tidak menutup; offline -> pesan jelas dan urutan tidak berubah (tidak ada POST terkirim); kasus 5 nomor terisi + 1 foto cadangan; kasus nomor manual + kosong + tahan; kasus urutan jam benar -> tanpa ⚠ dan tanpa teks "Wajar/Perlu perhatian".
- Belum diuji: di HP sungguhan sebagai PPL (mode "Lihat sebagai") setelah deploy, termasuk offline sungguhan.
