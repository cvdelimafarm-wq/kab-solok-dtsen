# Catatan: mockup Kertas Kerja Revisi POK (contoh KRO 2903.BMA), 23 Okt 2026

Status: HANYA MOCKUP. Tidak ada SQL, migrasi, atau kode aplikasi yang dijalankan atau diubah. Permintaan pengguna: "Buatkan dulu mockupnya jangan eksekusi dulu" dan "Dengan contoh salah satu kro".

## Yang dibuat
Kanvas Design: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap ("Kertas Kerja Revisi POK SIGAP"), 7 artboard:

1. Main: kertas kerja berbentuk lembar kerja (kolom Semula, Menjadi, Selisih, Pemicu, Booked, Realisasi, Cek) dan tab Matriks semula menjadi. Sel Menjadi dapat diketik (rumus sederhana diterima), ada tombol Terapkan RAB, ciutkan/buka RO-komponen-akun, tambah item, pilihan jenis revisi, kartu saran jenis, tenggat, dan R-01 sampai R-14. Ada 9 contoh isian (RAB, T-01, T-03, T-04, T-05, antar-Program, T-06, T-07, T-15).
2. Alur: sebelum (A1-A6), saat (siklus status B1-B4), sesudah (C1-C4).
3. Pemicu: P-01 sampai P-08 dengan contoh baris nyata, tangga tingkat 1-5 dan jenis yang disarankan.
4. Lampiran: tenggat Pasal 175 dengan hari acuan yang bisa diganti, lampiran L01-L12 per jenis, draf isi surat.
5. Status: siklus Diterapkan, Disetujui KPA, Diajukan, hasil resmi; peran Operator, KPA, Pembaca; riwayat.
6. Impor: pencocokan berkas penetapan lewat kunci baris (sama, berubah, baru, hilang, di luar usulan) dan keputusan operator.
7. Versi: versi berurutan v0-v1-v2 dan perbandingannya, RPD per bulan, dampak ke Booked dan Realisasi.

Berkas pendukung (diunggah ke kanvas): kk-data.js (80 baris POK nyata KRO 2903.BMA dari RKKS 30 Sep 2026), kk-logic.js (logika), kk.css. Salinan sumber ada di sandbox sesi (/home/claude/kk/out/) dan bisa diminta ulang.

## Contoh yang dipilih
Program 054.01.GG, Kegiatan 2903 Statistik Harga, KRO 2903.BMA: 3 RO (007, 008, 009), 80 detail, Rp 640.959.000. POK seluruh Satker TA 2026 sudah diurai dan cocok ke Rp 13.431.536.000, jadi cakupan penuh bisa dipakai pada tahap bangun.

## Angka ILUSTRASI (bukan data nyata)
RAB v4, Booked, Realisasi, pola RPD, hasil impor Kanwil, dan nomor surat. Hanya kolom Semula yang berasal dari POK nyata.

## Uji logika (node, sandbox)
T-01 saran POK tingkat 2; T-03 DJPb tingkat 4 (campuran); T-04 DJPb (lintas jenis); T-05 DJA (R-01 dan R-11 merah); antar-Program DJA tingkat 5; T-06 DJPb campuran; T-07 R-06 merah; T-15 POK redaksi saja. Tenggat: DJA 31 Okt jatuh Sabtu, efektif Jum 30 Okt 2026, sisa 5 hari kerja dari 23 Okt; POK 27 Des jatuh Minggu, efektif 23 Des 2026 karena 24-25 Des libur (SKB 3 Menteri 1497/2025). Render di browser BELUM diperiksa (tidak diminta).

## Celah skema yang ditemukan terhadap Draf 4 dan 20261022b_keu_anggaran.sql
1. Kode KRO bisa ganda dalam satu Kegiatan pada POK nyata; kunci yang hanya memakai kode KRO tidak unik.
2. Kolom jumlah dibuat generated (volume x harga), padahal POK nyata memuat jumlah yang sudah dibulatkan (29 baris tidak persis sama dengan volume x harga). Perlu kolom jumlah tersimpan atau toleransi pembulatan.
3. kunci_stabil perlu indeks kemunculan (occurrence) untuk baris dengan uraian dan akun kembar dalam satu komponen.
4. Belum ada fungsi untuk mengarahkan ulang (re-point) kunci baris setelah impor hasil penetapan, padahal alur C1 membutuhkannya.
5. Tabel keu_revisi_jendela, keu_revisi_langkah, keu_revisi_berkas (20261022h) dan keu_aturan_validasi tumpang tindih sebagian dengan kebutuhan status, riwayat, dan lampiran di mockup; perlu diputuskan mana yang dipakai.
6. Kolom yang belum ada: volume RO (R-02), kolom "sesudah" per item (volume, harga, uraian, akun), dan penanda pemicu P-01 sampai P-08.

## Belum / menunggu keputusan pengguna
- Persetujuan mockup ("setuju") sebelum ada kode atau migrasi.
- Q-26: penanda RO Khusus, blokir, dan klasifikasi Belanja Operasional pada POK Solok (R-08, R-10 masih berstatus info).
- R-09 Dana penggenap: dasar hukum tidak ditemukan di tiga PMK; tanyakan Kanwil atau APIP.

## Tambahan (permintaan pengguna 23 Okt: "RAB nya mana?" dan RAB rinci)
Tab RAB di artboard 1 dirombak. Berkas pendukung baru: kk-rab.js (model RAB rinci; sumber di /home/claude/kk/out/).
- Tiap item POK boleh dirinci jadi beberapa baris (contoh: PML 2 x 170.000, PPL 10 x 170.000); jumlah rincian masuk ke item.
- Tiap baris rincian punya keterangan, volume, satuan, harga, bulan dan minggu mulai, lama sebar (minggu), catatan atau spesifikasi, dan tautan.
- Status per item: Belum ada RAB, RAB = Item (bentuk paling sederhana, otomatis salinan item), RAB rinci. Tombol: RAB = Item, Hapus RAB, jadikan semua yang belum RAB = Item.
- Perkiraan kebutuhan pencairan per minggu dalam bulan (12 bulan x 4 minggu), dari jadwal baris rincian, bisa difilter per RO. Item tanpa RAB tidak ikut.
- Terapkan RAB ke Menjadi: item ber-RAB masuk dengan jumlah dari rincian (harga = jumlah/volume total), item tanpa RAB tetap POK, sisa negatif ditutup baris Dana penggenap.
- Pembagian PML/PPL, catatan, tautan, dan jadwal pada contoh adalah ILUSTRASI.
- Konsekuensi skema (belum dibuat): perlu tabel rincian RAB per item (keterangan, vol, sat, harga, catatan, tautan, bulan, minggu, sebar), status RAB per item, dan tabel perkiraan pencairan mingguan; RPD bisa diturunkan dari situ.
