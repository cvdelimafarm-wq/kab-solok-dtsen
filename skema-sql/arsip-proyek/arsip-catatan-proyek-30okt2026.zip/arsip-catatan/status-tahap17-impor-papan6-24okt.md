# Tahap 17: Impor POK hasil penetapan (papan 6), 24 Okt 2026

Halaman: `/sigap/revisi/pok` (sudah ada sejak tahap 12; unggah PDF RKKS dan terima/tolak). Papan 6 mockup dipenuhi dengan MENAMBAH pada halaman itu, bukan halaman baru. Berkas mockup yang diunggah adalah Excel; produksi memakai PDF RKKS resmi dari SAKTI (keputusan tahap 12), jadi kolom "Berkas penetapan" = isi PDF.

## Berkas (di repo)
- SQL `skema-sql\20261024s_keu_pok_banding_usulan.sql` (SUDAH diterapkan di produksi lewat migrasi; aman diulang; tanpa DELETE/DROP).
- `lib/keu/pok.ts` (+ tipe BarisRinci, KeputusanUnggah, Saringan; perluKeputusan, cocokSaringan, hitungSaringan, selisihUsulan, catatanBaris, teksKeputusan, argsTandai, argsTandaiSemua; kesiapanTerima menerima `keputusan`).
- `lib/keu/__tests__/pok.test.ts` (+7 uji), `lib/keu/tampilan.ts` (+ keu_v_pok_banding_rinci, keu_v_pok_unggah_keputusan).
- `app/sigap/revisi/pok/Banding.tsx` (ditulis ulang: satu tabel datar), `page.tsx` (muat keputusan, chip, bagian "Jadikan POK semula yang baru").

## SQL s
- Tabel `keu_pok_unggah_tanda` (unggah_id, kunci, tanda pakai|ditanyakan|belum, catatan, oleh). Hanya lewat fungsi; hapus ditolak.
- Tampilan `keu_v_pok_banding_rinci`: banding lama + kunci baris + `jumlah_usulan` (kolom Menjadi kertas kerja jadwal dasar) + `sesuai_usulan` + `tanda` + `otomatis`.
  Aturan sesuai usulan: baru = ada baris kertas kerja (RO, akun, uraian sama) dengan jumlah Menjadi = jumlah berkas; berubah/dipadankan = jumlah Menjadi item itu = jumlah berkas; hilang = item dikosongkan, dipindah akun, atau diganti redaksi. Selain itu "di luar usulan". Tanpa jadwal dasar: tidak ada pembanding (null) dan semua selisih menunggu keputusan.
  Otomatis = sama, dipadankan PPK, atau sesuai usulan.
- Tampilan `keu_v_pok_unggah_keputusan` (n_otomatis, n_menunggu, n_pakai, n_ditanyakan, n_di_luar_usulan).
- Fungsi `keu_pok_unggah_tandai(p_unggah,p_kunci,p_tanda,p_catatan)` dan `keu_pok_unggah_tandai_semua(p_unggah)` (PPK, kewenangan pok_pdf); terdaftar di gerbang `keu_jalankan` (daftar izin ditambah lewat penambalan, bukan tulis ulang).
- Penjaga (trigger `keu_t0b_tanda`): unggahan TIDAK dapat diterima selama ada baris berstatus "ditanyakan".

## Selisih dari mockup (disengaja)
1. Berkas = PDF RKKS (bukan Excel); dibaca di perangkat, tombol "Muat contoh berkas" tidak ada (berkas nyata).
2. Kolom Usulan (Menjadi) hanya bila unggahan punya jadwal dasar.
3. "Menunggu keputusan operator" TIDAK menghalangi penerimaan (hanya peringatan; angka berkas dipakai); yang menghalangi hanya baris "ditanyakan". Alasan: unggahan tanpa jadwal dapat memuat ratusan selisih (mis. POK sementara ke POK resmi), memaksa keputusan satu per satu tidak praktis. Tersedia tombol "Pakai angka berkas untuk semua yang menunggu".
4. Penyaring ditambah "Perlu keputusan" dan "Dipadankan"; pemadanan baris baru-hilang tetap ada.
5. Tombol terima diberi label "Simpan sebagai POK semula berikutnya...".

## Uji
- 309 uji lulus, tsc bersih, uji render komponen (data contoh) lulus.
- SQL diuji di PostgreSQL sandbox dengan skema minimal (13 baris banding, aturan sesuai usulan, tandai, penolakan kunci/tanda salah/bukan PPK, penjaga ditanyakan, hapus ditolak, pasang ulang aman). Uji di produksi lewat transaksi yang dibatalkan TIDAK terlaksana (Supabase menunggu persetujuan yang tidak sampai); produksi diperiksa bersih (tidak ada sisa unggahan uji).
- Belum diuji di produksi dengan unggahan nyata: perlu satu PDF uji pada jadwal fiktif berstatus diterapkan (saat ini tidak ada jadwal diterapkan/sah; jadwal 7 "UJI Kertas kerja fiktif" berstatus dibuka).

## Rencana uji produksi (setelah deploy)
1. Buka `/sigap/revisi/pok`: unggahan lama (#1 ditolak, #2 diterima) tampil tanpa galat; KPI tetap.
2. Bila ada unggahan berstatus diunggah: Lihat pencocokan: chip penyaring berhitungan, kolom Kunci/Catatan/Keputusan, tandai satu baris, batalkan tanda, tombol "semua", tombol terima dimatikan bila ada "ditanyakan".
3. Penerimaan hanya pada data fiktif.

## Urutan berikutnya
Papan 7 (Versi/RPD/dampak), 4 (Lampiran), 5 (Status/riwayat); periksa 11/12/13/15. Nomor berkas SQL berikutnya: t.
