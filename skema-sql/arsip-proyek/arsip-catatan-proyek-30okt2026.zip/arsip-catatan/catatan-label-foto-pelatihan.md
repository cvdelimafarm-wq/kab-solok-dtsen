# Keterangan 5 Foto Transport Lokal — khusus Pelatihan (8 Okt 2026)

Permintaan user: untuk kegiatan pelatihan, keterangan foto diganti: 2. Tiba di lokasi pelatihan · 3. Saat pelatihan · 4. Saat akan pulang · 5. Tiba di kediaman. (Slot 1 tidak disebut -> tetap "Saat akan berangkat".)

- Sumber tunggal: lib/sigapLabelFoto.ts — LABEL_FOTO_PENDATAAN (lama, bawaan semua kegiatan lain) dan LABEL_FOTO_PELATIHAN; labelFoto(jenis) memilih berdasarkan sigap_kegiatan.jenis = 'pelatihan'.
- Dipakai: halaman unggah /sigap/translok/[token] (pilihan jenis foto & keterangan kotak), PDF Dokumentasi (lib/pdf/sigap/dokumentasi.ts, field baru kegiatanJenis, diisi dari lib/sigapDokumen.ts).
- Monitoring pelatihan (lib/sigapPresensi.ts LABEL_SLOT_FOTO, dipakai halaman Langkah peserta & Kelola Pelatihan): Berangkat · Tiba di lokasi pelatihan · Saat pelatihan · Saat akan pulang · Tiba di kediaman.
- Berkas SPJ yang sudah DIKUNCI (beku) tetap memakai keterangan lama; yang baru dicetak/dikunci memakai keterangan baru.
