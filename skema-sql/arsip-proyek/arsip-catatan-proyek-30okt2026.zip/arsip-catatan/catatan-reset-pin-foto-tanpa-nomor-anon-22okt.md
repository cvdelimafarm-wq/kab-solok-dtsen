# Catatan 22 Okt 2026: perbaikan reset PIN mandiri, konfirmasi foto tanpa nomor sendiri, audit anon

Status: kode SUDAH ditulis ke repo laptop (belum tsc/vitest/commit oleh Pak Iqbal pada saat catatan ini ditulis). Tidak ada perubahan database.

## 1. Reset PIN mandiri ("Lupa PIN?") — kasus Riva
Akar masalah: data pembanding di sistem kurang (mitra tanpa NIK/email/tanggal lahir) sehingga aturan "minimal 2 data cocok" mustahil terpenuhi, dan SETIAP percobaan dihitung gagal sampai akun terkunci.
Perbaikan:
- `lib/sigapLupaPin.ts` (baru, logika murni): `nilaiKolomLupa`, `putusanLupa` (salah / kurang / lolos), `pesanDataKurang`, `normNip`, `nipValid` (9-18 digit), `MIN_COCOK_RESET = 2`. Tes: `lib/__tests__/sigapLupaPin.test.ts` (14 tes lulus di sandbox).
- NIP (opsional) jadi pembanding keempat, dibandingkan dengan `sigap_akun.nip` (baru 14 akun yang punya NIP, semua 9 digit). Aturan tetap minimal 2 data pribadi benar-benar cocok.
- Putusan "kurang" (tak ada data yang SALAH, tetapi cocok < 2) TIDAK memanggil `catatGagal`: tidak mengurangi sisa percobaan dan tidak mengunci. Respons: `ok:false, kurang_data:true, error:<pesan>`. Data yang SALAH (termasuk nama tak dikenal dan NIP salah) tetap dihitung, jadi menebak tetap terbatas.
- `app/api/sigap/masuk/route.ts` (blok `lupa_verifikasi`) dan `app/sigap/masuk/page.tsx` (kolom NIP opsional + label "NIP" di ringkasan kolom).
- Jalan keluar segera tetap: admin memakai Log Login > buka baris > "Reset PIN" (PIN sementara 24 jam).
- Tidak dikerjakan (opsional): daftar "akun yang tak bisa reset mandiri" di Log Login; melengkapi email/tanggal lahir mitra dari sumber resmi.

## 2. Foto SIGAP yang tidak masuk nomor sendiri
- `app/sigap/foto/KameraSigap.tsx`: bila foto HANYA dibagikan ke rekan (`nomor === null`, `tag.length > 0`) padahal masih ada nomor kosong (`saran !== null`), tombol Kirim membuka konfirmasi: "Pakai Foto N untuk saya juga" / "Kirim ke rekan saja" / "Kembali". Ada juga catatan kuning di atas tombol. Perilaku lain (hitung mundur 10 detik, cadangan saat semua nomor penuh) tidak berubah.
- Belum dikerjakan: penanda "ada foto menunggu ditempatkan" di Beranda (bagian "Menunggu diterima" di Foto saya sudah ada). Pemulihan kasus lama (foto id 69 akun 699; foto id 154): petugas menempatkan lewat Foto saya > Menunggu, atau admin `sigap_foto_tempatkan`.

## 3. Penutupan akses anon (SQL belum dijalankan)
`claude/sql-penguatan/20261022_tutup_akses_anon_fungsi_view.sql` tetap belum dijalankan. Syarat: pastikan tidak ada pemakaian kunci anon (`NEXT_PUBLIC_SUPABASE_ANON_KEY`) untuk memanggil 25 fungsi atau 2 view itu (perintah pencarian PowerShell diberikan di percakapan), ambil snapshot, lalu jalankan sendiri.
