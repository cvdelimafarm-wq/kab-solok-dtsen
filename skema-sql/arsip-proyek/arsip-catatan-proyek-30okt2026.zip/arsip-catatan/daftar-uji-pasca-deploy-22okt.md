# Daftar uji pasca-deploy (disusun 22 Okt 2026)

Konteks: deploy tertahan insiden Railway (build dijeda). Commit terbaru `df8ff36` (tsc bersih, 56 berkas / 722 tes lulus). Deploy SEKALI saja saat build pulih; jangan memicu deployment berulang (antrean).

Cara pakai: centang berurutan dari atas. Kalau satu butir gagal, catat jalur halaman + pesan galat + jam, lalu kabari Claude.

## A. Dasar (lakukan pertama)
- [ ] Deploy selesai tanpa galat build; beranda portal `/` terbuka.
- [ ] Masuk dengan akun admin; menu sidebar muncul sesuai peran.
- [ ] Kelola > Pendataan: tabel dan Monitoring memuat data (ini memanggil fungsi RPC yang haknya sudah dicabut dari anon pada 22 Okt; harus tetap jalan karena memakai service_role).
- [ ] Alokasi PSP (peta/tabel/beban) memuat data.
- [ ] Log Supabase 24 jam: tidak ada permintaan REST non-2xx baru (minta Claude memeriksa).

## B. Kebocoran memori Railway (klien Supabase bersama)
- [ ] Pantau grafik memori Railway 1-2 hari: target stabil sekitar 300-600 MB, tidak merayap naik terus.
- [ ] Bila memori tetap naik: kabari Claude; catatan acuan `claude/catatan-kebocoran-memori-railway.md`.

## C. Reset PIN mandiri (Lupa PIN)
- [ ] `/sigap/masuk?mode=lupa` menampilkan kolom "NIP (opsional, bila punya)".
- [ ] Akun dengan data pembanding kurang (kasus Riva): isi data -> muncul pesan "Data Anda belum cukup..." dan sisa percobaan TIDAK berkurang (coba dua kali; tidak terkunci).
- [ ] Akun dengan data lengkap: 2+ data cocok -> lanjut buat PIN baru -> masuk.
- [ ] Salah satu data sengaja salah -> sisa percobaan berkurang (kunci tetap bekerja).
- [ ] Akun yang punya NIP (14 akun): NIP benar + 1 data lain cocok -> lolos.
- [ ] Admin: Log Login > buka baris > "Reset PIN" tetap menghasilkan PIN sementara.

## D. Kamera SIGAP
- [ ] Potret, JANGAN pilih nomor sendiri, bagikan ke satu rekan, tekan Kirim -> muncul dialog "Foto ini belum masuk nomor Anda" dengan tiga pilihan.
- [ ] "Pakai Foto N untuk saya juga" -> nomor terpilih, foto terkirim dengan nomor itu.
- [ ] "Kirim ke rekan saja" -> terkirim; foto muncul di Foto saya > Menunggu milik rekan.
- [ ] Foto dengan nomor sendiri (jalur biasa, hitung mundur 10 detik) tidak terganggu dialog.
- [ ] Kasus lama: foto id 69 (Widya, akun 699) dan id 154 (Puspita) ditempatkan lewat Foto saya > Menunggu atau oleh admin.

## D2. Sisa uji 20-21 Okt yang belum dikerjakan
- [ ] QR pada foto baru mengarah ke domain portal (bukan localhost); kode bisa dicari di `/verifikasi?k=<kode>`.
- [ ] Kirim Siaran "Perubahan target harian" (target 60 poin berlaku 20 Okt) dari Kelola > Pendataan > Siaran.
- [ ] Yeni Siswanti mencoba tombol Aktifkan notifikasi di HP.
- [ ] Unduh SPJ satu hari (Laporan + Dokumentasi) dan rentang.
- [ ] Rujukan lanjutan: `claude/catatan-perubahan-20okt-2026.md`, `claude/catatan-tombol-rapikan-nomor-foto-21okt.md`, `claude/catatan-nomor-foto-otomatis-pengaman-kirim-21okt.md`, `claude/catatan-batalkan-keluarga-baru-21okt.md`, `claude/catatan-tab-belum-diajukan-tugaskan-21okt.md`, `claude/catatan-editor-siaran-bergaya-word-21okt.md`, `claude/catatan-jendela-susulan-21okt-2026.md`.

## E. Keamanan (sudah dijalankan di database 22 Okt)
- [x] 25 fungsi dicabut dari anon/authenticated; verifikasi: semua `false/false/true`.
- [ ] `dashboard_progress` dan `seruti_progress` BELUM dicabut dari anon (halaman `/dashboard` dan `/seruti` memakai kunci anon). Putuskan: masih dipakai atau tidak.
- [ ] Rotasi kunci Supabase/variabel Railway + cabut kunci lama: tunda sampai build stabil.
