# Catatan: Uji alur per peran di aplikasi nyata (19 Okt 2026)

Cara uji: Claude in Chrome, akun super "Melihat sebagai" (mode simulasi, tidak menulis ke server) sebagai korwil (Nurafiza Thamrin), PML (Budi Pernandes), PPL (Minda Susanti). Tidak ada kode yang diubah. Menunggu "setuju" per fase; perubahan beranda/navigasi dibuat mockup dulu.

Arah yang diminta user: korwil = monitoring + hasil pemeriksaan PML; PML = tetap (pengajuan, monitoring, dst; periksa tombol prioritas di tengah beranda); PPL = fokus pendataan; navigasi ke translok dan ikutannya harus mudah dan jelas.

## Temuan
Korwil
1. Kartu tugas utama beranda dan kartu tahap menunjuk "Pilih hari kerja" (translok, "Langkah 2 dari 2") bukan Monitoring Korwil. Penyebab: Monitoring berstatus "Berjalan" sehingga kalah prioritas dari translok "Perlu dilengkapi"; langkah 1 tidak pernah tampil di beranda.
2. "Hasil pemeriksaan PML" belum ada (lembar pengawasan PML F1 belum dibangun; butuh migrasi). Usul: tab ketiga di Monitoring Korwil.
3. Hitungan tahap beda antar peran: korwil 3 tahap (Perencanaan, Pendataan, Evaluasi; tahap Pelatihan tidak ada), PML/PPL 4 tahap. Kartu menyebut "Tahap 1 dari 3" padahal pekerjaan ada di Tahap 2.
4. Pengumuman Gantuang Ciri (instruksi untuk PML, tombol "Buka Kolam Wilayah") tampil juga bagi korwil.
5. Bug kecil header Monitoring Korwil: nama korwil terpotong dengan gelar/koma ("Deswaty, Sst. & Nurafiza Thamrin,").
PML
6. Dua sinyal prioritas berbeda: kartu beranda = Lembar Pendataan KK; baris kegiatan dan kartu tahap = "2/5 · Foto kurang 5" (translok).
7. Angka tim tiga versi untuk Budi: 254/535 (beranda, kartu tahap, halaman tahap PPL), 183/458 (header Lembar Pendataan), 183/461 (Monitoring Korwil). Penyebab: Sub SLS Gando 01 dipegang 2 tim. 254/535 menghitung seluruh KK Gando 01 (termasuk 71 KK yang didata tim Megawati); 458 mengeluarkan Gando 01; 461 = proporsional (rumus user). Usul: satu fungsi hitung proporsional untuk semuanya.
8. "1 dari 4 bagian" di kartu tahap vs "Ada 3 tugas · 1 selesai" di halaman tahap (Wilayah tugas tim dihitung tetapi tidak tampil sebagai tugas bagi PML).
PPL
9. Halaman tahap PPL: panel "Tim Anda" + 7 Sub SLS + unduh peta memanjang di atas; tugas bernomor (Lembar Pendataan KK) ada di paling bawah (sekitar 2 layar gulir).
10. Tombol melayang "Rekap identifikasi" tampil bagi PML/PPL di halaman tahap (kemungkinan hanya relevan bagi PML/admin; perlu konfirmasi).
11. Label "2/5 · Lembar belum ada hasil" tanpa penjelasan: 2/5 adalah langkah translok.
Umum
12. Tiga skala penomoran berdampingan: "Tahap 3 dari 4" (kegiatan), "Langkah 2 dari 3" (beranda/tahap), "Langkah 3 dari 5" (translok).
13. Navigasi translok: hub `translok-73` jelas (Tugas hari ini, "Juga belum lengkap", 5 langkah) dan tombol kembali (?dari=) bekerja. Tetapi jalur ke translok hanya lewat tahap Pendataan (tugas terakhir) atau kartu utama bila kebetulan teratas; tidak ada pintasan tetap.

## Usulan urutan per peran
- Korwil: tugas utama = Monitoring Korwil (Lapangan, Administrasi, Pemeriksaan PML bila dibangun); translok = strip "Juga belum lengkap".
- PML: tugas utama = Lembar Pendataan KK (pengajuan + monitoring), kekurangan translok (foto) sebagai strip kedua.
- PPL: tugas utama = Lembar Pendataan KK di bagian atas halaman tahap; panel wilayah tim dilipat.
- Semua: satu penomoran; pintasan "Transport Lokal" tetap di beranda dan halaman tahap.
