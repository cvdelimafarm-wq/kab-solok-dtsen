# Foto terbalik: kamera depan miring ke samping (26 Okt 2026, malam)

Status: kode ditulis ke laptop (KameraSigap.tsx, lib/sigapFotoPutar.ts, tes). Lulus 19 tes dan tsc pada berkas yang disentuh. BELUM di-commit/deploy, BELUM diuji di HP. Tanpa SQL baru.

## Temuan (dari 181 diagnosa `sigap_audit` aksi `foto.orientasi`, 26 Okt 11.13-15.38 WIB)
- Kamera BELAKANG: s0 benar semua; s1 (HP miring kiri) 5 dari 5 benar tanpa koreksi (putaran dasar 3).
- Kamera DEPAN, HP miring kiri (s1): 27 foto dari 14+ HP; 21 harus diputar 180 derajat oleh petugas (manual=2), 1 diputar 270, 5 dibiarkan/dipelajari. Depan tegak (s0): 124 foto, tidak butuh koreksi. Layar landscape (l90, l270): benar.
- Miring kanan (s-1) dan terbalik (s2) tidak pernah muncul di data.
- Penyebab: bingkai kamera depan bertukar arah putar saat HP miring ke samping. Pembelajaran per HP lama memakai kunci yang sama untuk depan dan belakang, sehingga HP yang belajar dari kamera depan ikut membalik kamera belakang.

## Perubahan
- `lib/sigapFotoPutar.ts`: `kuartalDasarKamera(arah, depan)` (depan dan miring kiri/kanan: +180 derajat), `kunciKondisi(..., depan)` memberi awalan "d" untuk kamera depan (ds1, dl90).
- `KameraSigap.tsx`: memakai keduanya; simpanan belajar dipindah ke `sigap-foto-belajar2:<akun>` (belajar lama dibuang, karena tercampur depan/belakang); baris diagnosa "v5".
- Asumsi: miring kanan (s-1) kamera depan diperlakukan sama dengan miring kiri; belajar per HP meluruskan bila ternyata beda.

## Sesudah deploy
Cek lagi: `select detail->>'hadap' hadap, detail->>'kunci' kunci, detail->>'kuartal_manual' manual, count(*) from sigap_audit where aksi='foto.orientasi' and id > <id terakhir sebelum deploy> group by 1,2,3;` Target: kamera depan s1 (kunci `ds1`) manual=0.
Foto lama yang sudah terbalik tidak ikut diperbaiki.
