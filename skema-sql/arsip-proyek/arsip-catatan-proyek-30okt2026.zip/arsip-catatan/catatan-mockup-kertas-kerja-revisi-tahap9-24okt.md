# Catatan mockup Kertas Kerja Revisi POK, tahap 9 (24 Okt 2026): jawaban konfirmasi tahap 8

Status: MOCKUP saja (artifact Design, Versi 38). Belum ada SQL atau kode aplikasi sampai Pak Iqbal menyatakan "setuju". Catatan ini MENGGANTIKAN poin 4 (Dana penggenap otomatis dihapus) dan poin prioritas tetap pada catatan tahap 8.

## Jawaban Pak Iqbal atas tiga pertanyaan tahap 8
1. Faktor K = RAB dibagi 0,9: Pak Iqbal bertanya maksudnya. Penjelasan yang diberikan: RAB dianggap angka rencana yang pas-pasan, kebutuhan riil diperkirakan RAB dibagi faktor (RAB Rp 900.000 berarti kebutuhan riil sekitar Rp 1.000.000); faktor dapat diubah (1,0 berarti RAB dianggap sama dengan kebutuhan riil) dan hanya mempengaruhi status Tipis, Cukup, Lebih. Keputusan nilai faktor menunggu Pak Iqbal.
2. Sisa dana TIDAK dibiarkan di item asal. Ketentuan kantor (sudah disepakati sebelumnya): sisa ditampung baris Dana penggenap per akun. Jika akunnya 524 (perjalanan), dimasukkan ke "Perjalanan dinas Kabupaten"; jika akun 52 lain (belanja barang), dibuat item sesuai akun ditambah "Kabupaten" (mis. Belanja Bahan Kabupaten, Persediaan Konsumsi Kabupaten).
3. Urutan prioritas bawaan (Inti, Penting, Dapat ditunda) tidak sesuai kebiasaan kantor, tetapi kategori boleh ditambah dan diubah nanti.

## Yang diubah di mockup
- Dana penggenap dikembalikan: setelah geseran minimal, sisa di atas RAB (per item ber-RAB: POK dikurangi RAB atau Booked + Realisasi, mana yang lebih besar) ditampung baris Dana penggenap, dikelompokkan per RO, komponen, dan akun. Uraian dapat diedit. Total KRO tetap seimbang. Jendela geseran punya kotak centang "Tampung sisa ke Dana penggenap" (bawaan aktif) beserta pratinjau baris yang dibuat. Semua skenario geseran memakainya.
- Dana penggenap ikut dihitung sebagai bagian POK jenis belanjanya pada status kecukupan, dan menjadi donor pertama bila nanti ada item yang kurang (RAB naik).
- RAB penuh (Revisi DIPA) tetap tanpa penggenap: selisih menjadi perubahan pagu.
- R-09 tetap menyala (kuning) selama ada baris penggenap; dasar hukum belum ditemukan di tiga PMK, tanyakan Kanwil atau APIP.
- Kategori prioritas dapat diatur: tambah, ganti nama, naik atau turun urutan, tandai "boleh ditunda atau dikurangi", hapus (item kembali ke kategori bawaan per akun). Kategori per item tetap dipilih di tab RAB. Jalur penutup "turunkan volume" memakai kategori yang bertanda boleh ditunda.
- Penjelasan faktor ditambahkan di panel Kecukupan.

## Akibat bagi skema (menambah catatan tahap 8)
- Kategori prioritas: tabel kategori per Satker (nama, urutan, boleh_ditunda) dan kolom kategori per item; bawaan per akun dapat diubah.
- Baris penggenap: penanda penggenap pada baris, aturan penamaan per akun (524 menjadi Perjalanan dinas Kabupaten; 52 lain menjadi nama akun + Kabupaten), fungsi penyapu sisa yang dijalankan saat geseran diterapkan.

## Catatan teknis dan batas
- Penggenap dikelompokkan per akun yang sama dengan sumber sisanya (tidak memindahkan antar-akun), sehingga tidak ada pemicu pindah akun. Akibatnya satu RO bisa memiliki beberapa baris "Perjalanan dinas Kabupaten" dengan kode akun berbeda (524111, 524113, 524119). Bila kantor ingin satu baris saja, perlu keputusan akun penampung.
- Pengujian: model dan interaksi Main lulus di node (t20 sampai t24); render Chromium lokal Main dan papan lain tanpa galat; belum diuji di peramban pada artifact terbit.
- tsc, build, commit, deploy: oleh Pak Iqbal.
