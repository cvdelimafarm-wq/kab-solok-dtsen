# Catatan: Ulang Posttest (8 Okt 2026)

Fitur: peserta boleh mengulang Posttest sendiri; panitia mengatur di Kelola Pelatihan > Soal & Jadwal > kartu Posttest.

## Aturan (pilihan user)
- Pemicu: peserta mengulang sendiri (tombol "Ulangi Posttest"), bukan reset oleh panitia.
- Kuota: `sigap_tes.ulang_maks` (1 = mati/bawaan; 2–5). Diatur lewat checkbox "Peserta boleh mengulang" + pilihan jumlah percobaan maksimal. Hanya Posttest.
- Berlaku selama jadwal posttest terbuka (sebelum `tutup_at`, sisa minimal 60 detik). Panitia bisa memperpanjang tutup di jadwal yang sama.
- Nilai resmi = skor tertinggi dari semua percobaan (`skorResmi` = max(skor percobaan berjalan yang selesai, `skor_terbaik`)). Dipakai nilai akhir, laporan, monitoring.
- Percobaan lama DIARSIPKAN (tidak dihapus) di `sigap_tes_sesi_arsip` (unik sesi_id+percobaan). Baris `sigap_tes_sesi` di-reset: percobaan+1, skor_terbaik = max, mulai/batas/jawaban/skor dikosongkan.
- Skor & pembahasan tetap tersembunyi sampai `tutup_at` (mengulang tanpa melihat hasil). Setelah tutup, pembahasan dari percobaan terbaik.

## Teknis
- Migrasi `20261008i_sigap_tes_ulang.sql` (sudah diterapkan ke Supabase).
- API peserta: POST `/api/sigap/pelatihan/tes/posttest` `{aksi:"ulang"}`. Admin: `atur_jadwal` menerima `ulang_maks`.
- File: lib/sigapTes.ts (skorResmi, bisaUlang), lib/sigapTesDb.ts (mulaiUlang, susunKeadaan), sigapNilai.ts, sigapAdministrasi.ts, tes route + page, admin route, kelola/page.tsx, hub route/page, komponen.tsx.
- Belum diuji di browser/data live. Setelah deploy: aktifkan di Kelola (bawaan mati).
