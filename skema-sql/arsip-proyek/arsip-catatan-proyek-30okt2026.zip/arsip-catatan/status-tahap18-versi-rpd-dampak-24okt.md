# Status tahap 18: papan 7 (Versi berurutan, RPD sebelum dan sesudah, Dampak) - 24 Okt 2026

Halaman baru `/sigap/revisi/versi?tab=versi|rpd|dampak&jadwal=<id>`. Hanya baca; TIDAK ada migrasi SQL baru (huruf SQL berikutnya tetap `t`). Tautan ditambahkan di `/sigap/revisi` ("Versi, RPD, dan dampak sesudah revisi").

## Berkas (di repo `D:\02 BPS Kabupaten Solok\2026\13 Usul DTSEN`)
- `app/sigap/revisi/versi/page.tsx` (21640 B), baru.
- `lib/keu/versi.ts` (13463 B), baru: logika murni.
- `lib/keu/__tests__/versi.test.ts` (7911 B), baru: 12 tes. Seluruh `lib/keu`: 321 tes lulus, tsc bersih, uji render tiga tab lulus (data tiruan).
- `app/sigap/revisi/page.tsx` (15359 B): hanya menambah satu tautan.

## Rancangan per tab (dan beda dari mockup)
1. Versi berurutan: kartu versi dari `keu_pok_versi` (urut nomor revisi, label "Revisi N", chip Terbaru bila berlaku, total = simpul program). Banding dua versi: pasangan berurutan + pertama ke terakhir; tabel per RO dikelompokkan per KRO, hanya RO yang berbeda (kotak centang untuk semua), total dari SEMUA RO; rincian baris beda dipasangkan lewat `kunci_stabil` (RO dan akun ditelusuri dari simpul induk). Beda dari mockup: mockup memakai "Versi 0/1/2" ilustrasi di satu KRO; produksi memakai versi POK sistem (hasil PDF resmi yang diterima) seluruh Satker. Revisi yang masih kertas kerja belum menjadi versi sampai POK resminya diterima.
2. RPD: baris kertas kerja jadwal terpilih (`keu_v_kk_baris`) disebar ke 12 bulan menurut pola pencairan RAB baris yang sama (`keu_v_rab_jadwal_item`, dicocokkan `pok_kunci`; pembulatan dijaga agar jumlah tepat). Baris tanpa pola TIDAK ditebak: baris "Belum ada pola" hanya menghitung baris yang berubah. Bulan beda ditandai "Bergeser". Beda dari mockup: mockup memakai pola tetap per komponen (ilustrasi).
3. Dampak: baris kertas kerja yang berubah/baru; ruang = pagu Menjadi - realisasi terbaru (`keu_v_realisasi_terbaru`, dipasangkan lewat `detail_id`). Status Aman / Di bawah realisasi / Belum ada realisasi. Booked belum punya sumber data: kolom "-", tidak dihitung, dinyatakan di catatan layar. Beda dari mockup: mockup memakai Booked dan Realisasi ilustrasi dan memblokir persetujuan KPA; produksi baru menandai, belum memblokir.

## Fakta data produksi saat dibangun
- POK sistem: versi id 2 (revisi 1, digantikan, Rp13.431.536.000) dan id 3 (revisi 2, berlaku, Rp13.430.319.000): selisih -Rp1.217.000; RO 38 dan 35; detail 677 dan 625 baris.
- `keu_v_kk_baris`: hanya jadwal 7 (fiktif), 154 baris, 3 berubah. Pola RAB: 5 baris jadwal untuk 3 kunci. `keu_v_realisasi_terbaru`: kosong, jadi tab Dampak awalnya semua "Belum ada realisasi".

## Uji produksi yang disarankan setelah deploy (data fiktif saja)
1. Tab Versi: dua kartu, total 13.431.536.000 dan 13.430.319.000, pasangan "Revisi 1 ke 2", total selisih -1.217.000, rincian baris beda tampil.
2. Tab RPD pilih jadwal 7: ada baris "Belum ada pola" untuk baris berubah tanpa pola; bulan bergeser hanya bila baris berpola ikut berubah.
3. Tab Dampak pilih jadwal 7: 3 baris, semua "Belum ada realisasi".

## Belum dikerjakan
Booked (butuh sumber data), pemblokiran persetujuan KPA bila di bawah realisasi, versi dari kertas kerja yang diterapkan, ekspor. Urutan berikutnya: papan 4 (Lampiran), papan 5 (Status/riwayat), cek papan 11/12/13/15, lalu perbarui `selisih-mockup-vs-produksi-24okt.md`.

---
## Hasil uji produksi (25 Okt 2026, setelah deploy; hanya baca, tidak ada tulis)
- Tab Versi: dua kartu (Revisi 1 Rp13.431.536.000 Tersimpan; Revisi 2 Rp13.430.319.000 Terbaru), banding "Revisi 1 ke 2": 10 RO beda dari 35, total selisih -Rp1.217.000, tepat sama dengan selisih program. Tanpa galat konsol.
- Catatan temuan: di rincian baris beda banyak pasangan "Tidak ada di Revisi 2" + "Baru di Revisi 2" yang sebenarnya uraian sama tetapi kunci_stabil berbeda karena pemenggalan uraian di PDF (contoh "Honor pemeriksa lapangan sensus (PML)", "Perjalanan ... ke kecamatan"), dan satu uraian tercemar teks catatan PDF ("Catatan : 1. U = Komponen Utama ..."). Ini celah lama "padanan 52 baru / 104 hilang POK": penyelesaiannya padanan manual di Banding (papan 6), bukan di papan 7.
- Tab RPD jadwal 7: 3 dari 154 baris berpola; Okt 2.534.000 -> 2.704.000, Nov dan Des 170.000 -> 340.000, ditandai Bergeser; baris "Belum ada pola" (2 baris) -250.000; total 3.124.000 -> 3.384.000 (+260.000), jumlah bulan cocok.
- Tab Dampak jadwal 7: 3 baris berubah, semua "Belum ada realisasi" (realisasi produksi kosong), Booked "-", catatan tampil.

## Lebar halaman (25 Okt 2026)
Permintaan: semua halaman berkartu dibatasi selebar laptop sesuai perangkatnya. `Shell.tsx` kini SELALU membatasi isi `max-w-7xl lg:max-w-[1440px]` dan menengahkannya; prop `penuh` tidak berpengaruh lagi (dilepas dari kertas, peta, versi). Layar < lg tetap selebar perangkat dengan gutter 12/20 px. Halaman mobile mandiri sudah dibatasi (max-w-xl/lg/md) dan portal admin/dashboard max-w-6xl/5xl. Berkas: app/sigap/admin/Shell.tsx, app/sigap/kontrak/Bingkai.tsx (komentar), revisi/kertas|peta|versi/page.tsx. Perlu uji visual di monitor lebar setelah deploy.
