# Catatan SQL berkas n: tampilan `keu_v_rab_baris` dan `keu_v_rab_jejak`
Tanggal 24 Okt 2026. Berkas: `20261024n_keu_v_rab_baris.sql`, `20261024z9_cek_kesehatan_keu_n.sql`, uji `46_uji_rab_baris.sql` dan `47_uji_alur_editor_rab.sql`, pelari `jalan_n.sh`. Tidak menambah tabel (tetap 53). Hanya membuat dua tampilan; aman diulang. Belum dijalankan di produksi.

## Mengapa ada
Editor RAB di halaman RO (tab RAB) perlu membaca rincian RAB per RAB dan jejak aksinya. Tabel `keu_rab_baris` tidak memuat `rab_id` (hanya `item_id`), sehingga sulit dibaca per RAB tanpa tampilan. Tabel riwayat mentah tetap tidak dibuka ke aplikasi (aturan daftar putih).

## Isi
- `keu_v_rab_baris`: rincian lengkap dengan `rab_id`, `pok_kunci`, `jumlah_dikunci` (jumlah mengikuti POK, bukan volume x harga), jadwal (`periode`, `bulan_mulai`, `bulan_sampai`, `minggu`).
- `keu_v_rab_jejak`: aksi RAB (buat, ajukan, setuju_ketua, sahkan, kembalikan, batalkan) dengan nama pelaku dan catatan. Tanpa NIK, NIP, dan id akun.
- Keduanya `security_invoker = true`; dicabut dari `anon` dan `authenticated`; `select` hanya untuk `service_role`.

## Cek dan uji
`z9` baris 1 sampai 4 harus 0 (baris 5 info). Uji 46: hak, kesesuaian jumlah dan kolom dengan tabel sumber, tanpa kolom pribadi. Uji 47 mengirim muatan persis seperti yang dibangun aplikasi lewat `keu_tulis` dan `keu_jalankan`: menyusun RAB (pegawai biasa ditolak, hanya satu RAB aktif per RO), RAB = Item (jumlah dikunci ke POK, jadwal diratakan), rincian dengan jadwal bulanan, ubah dan hapus rincian, tandai selesai, serta alur ajukan, dikembalikan (alasan wajib), diajukan ulang, disahkan PPK, salinan revisi, dan batalkan. Seluruhnya dibatalkan (rollback) sehingga tidak meninggalkan data. Rangkaian a-f, h, i, j, k, l, m, n dijalankan ulang dari nol.
