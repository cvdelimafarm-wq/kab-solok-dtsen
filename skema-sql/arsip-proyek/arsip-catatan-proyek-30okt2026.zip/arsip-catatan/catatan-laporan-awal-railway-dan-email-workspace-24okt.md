# Catatan 24 Okt 2026: laporan awal insiden Railway dan email "workspace may be at risk"

Sumber: blog.railway.com/p/preliminary-report-october-security-incident (laporan awal, forensik masih berjalan) dan email Railway ke admin workspace (tangkapan layar, 24 Okt 01.00).

## Isi email ke workspace Pak Iqbal
- Railway tidak bisa memastikan apakah kredensial di workspace diakses, tetapi memberi tahu karena environment variables di workspace cocok dengan pola yang dicari penyerang (kunci API AI dan cloud provider).
- Ini bukan insiden baru; pembaruan dari pengungkapan 21 Okt. Yang sudah merotasi kredensial tidak perlu tindakan tambahan.
- Tindakan yang diminta: rotasi kredensial sensitif (kunci API, sandi database, token) di variabel Railway; perbarui variabel dan redeploy layanan terkait; periksa log aktivitas penyedia (GitHub, registry seperti Docker Hub) terutama kunci AI.

## Ringkasan laporan awal (dari ringkasan halaman; cek rincian di halaman aslinya)
- Jendela serangan: 20 Okt 13.58 UTC sampai 22 Okt 03.32 UTC. Awal: eskalasi hak akses di infrastruktur build.
- Secret terenkripsi berhasil diambil; sebagian didekripsi memakai kredensial CI yang dicuri. Kueri tidak sah ke tabel environment variable terenkripsi. Penyerang mencari nama kunci API AI dan platform (diduga untuk distilasi model).
- Maksimal 1,85% workspace (sekitar 100.000) berpotensi variabelnya terkompromi; Railway tidak bisa memastikan variabel mana, sehingga semua pelanggan diminta merotasi.
- Akun pengguna tidak diakses; akses ke kode sumber pengguna belum bisa dipastikan (menunggu laporan akhir). Semua token Railway dicabut, kredensial storage bucket dan GitHub App installation dirotasi, sesi pengguna diinvalidasi. Deployment yang berjalan tetap online.
- Rekomendasi pelanggan: cabut dan ganti variabel sensitif yang tersimpan sebelum 21 Okt; hapus akses jaringan publik ke database; periksa audit log GitHub dan akses aplikasi terpasang; periksa audit log registry; periksa akses anomali di AWS dan GCP. Pemberitahuan pencabutan kunci dari vendor tidak otomatis berarti kunci kita terdampak. IOC (IP, hash) tidak dipublikasikan.

## Dampak ke rencana rotasi 23 Okt
- Status naik dari "disarankan" menjadi "dilakukan": workspace ditandai Railway. Rencana langkah 1-8 pada catatan 23 Okt tetap berlaku.
- Prioritas: SUPABASE_SERVICE_ROLE_KEY (beralih ke kunci sb_secret_ baru lalu nonaktifkan kunci legacy), lalu variabel lain (VAPID, SIGAP_CRON_SECRET, PIN Penyisiran, kode browser SIGAP) dan variabel lain di tab Variables yang tidak terlihat dari kode.
- Periksa juga GitHub (audit log, aplikasi terpasang; GitHub App Railway dirotasi sehingga mungkin perlu otorisasi ulang) dan apakah proyek Railway punya layanan database/Redis dengan akses TCP publik (basis data utama ada di Supabase, bukan Railway).
- Pertanyaan terbuka: dua IP Telkomsel pemakai service_role (182.9.193.176 dan 182.9.200.85) belum dikonfirmasi; ada kunci AI atau cloud lain di Railway atau tidak.
