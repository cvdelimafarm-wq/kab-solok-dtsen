# Status tahap 27: Identifikasi survei diterapkan ke web (25 Okt 2026)

## Status
Kode dan SQL SUDAH ditaruh di laptop, BELUM di-commit/deploy dan BELUM ada di produksi. Jangan dianggap terbit sampai pengguna mengetik "sudah deploy" dan uji produksi selesai.

## Isi
- Menu: Perencanaan > Identifikasi survei (`/sigap/kelola/perencanaan/identifikasi`, detail `/[id]`), sesudah Alur GSBPM, terbuka bagi semua akun organik; hak tulis ditegakkan basis data.
- SQL (folder `Pengisiran\SQL\Claude outputs`): `20261025za_keu_identifikasi.sql` (migrasi), `20261025zb_cek_kesehatan_keu_ident.sql` (cek, semua p0 = 0), `49_uji_identifikasi.sql` (uji, "LULUS 49").
- Kode (repo laptop): `lib/keu/identifikasi.ts`, `identifikasiHilir.ts`, tes + `identifikasi.vektor.json` (558 vektor paritas TS-SQL), folder `app/sigap/kelola/perencanaan/identifikasi/*`; diedit: `lib/sigapMenuV2.ts`, `app/sigap/admin/Shell.tsx`, `lib/keu/gerbang.ts`, `lib/keu/tampilan.ts`, `lib/__tests__/sigapMenuV2.test.ts`.
- Tes lokal: 44 (identifikasi) + 18 (menu) lulus; tsc bersih untuk berkas identifikasi.
- Baru: periode Ad-hoc (diisi seperti Tahunan, satu periode "Ad-hoc"); bagian E untuk Ad-hoc menanyakan honor tim (Ketua tim/Wakil/Anggota) -> akun 521213 paket 521213-P.

## Urutan deploy
1. Jalankan `20261025za` di Supabase (aman diulang), lalu `20261025zb` (semua p0 = 0).
2. Commit dan push repo (Shell, menu, gerbang, tampilan, halaman baru, tes).
3. Ketik "sudah deploy" -> uji produksi dengan akun IH (data fiktif).

## Aturan ringkas
Draf -> (menunggu ketua bila dikirim Admin RO) -> PPK -> Tata Usaha -> KPA berurutan -> Sah. Kembalikan wajib catatan >= 5 huruf. Revisi: alasan >= 10 huruf, isian harus beda dari versi Sah. Pelaksana Kirim/revisi/H-15 = ketua tim, Admin RO, PPK. H-15: geser <= 7 hari pada mulai DAN selesai langsung; lebih dari itu lewat revisi. KPA menyetujui identifikasi saja.

## Permintaan baru (belum dibangun): Lembar identifikasi lanjutan
Identifikasi umumnya dibuat di awal tahun (tidak wajib). H-15 pelaksanaan lapangan perlu lembar identifikasi lanjutan per periode: jadwal pelatihan dari rentang/jendela menjadi tanggal FIX; metode pelatihan; bila luring/hybrid: jumlah OH, tempat (kantor / hotel dalam kota / hotel luar kota), paket (fullday / fullboard); jumlah petugas fix organik dan mitra; jabatan; nama (boleh menyusul); sumber mitra (rekrutmen/seleksi atau daftar kepka). Isian Fix memicu undangan pelatihan, surat pengantar kegiatan ke nagari, surat tugas/SPK, dan administrasi detail lain. Usulan dan keputusan terbuka: T40-T47 pada `Lembar_Pematangan_Identifikasi.xlsx`.

## Keputusan terbuka
24 butir (T10, T22, T26-T47) di lembar pematangan, dengan usulan bawaan dan kolom Konfirmasi.

## Catatan
Mockup Version 7 belum diperbarui untuk Ad-hoc dan lembar lanjutan. Tes menu lama sudah diselaraskan dengan versi laptop terkini. Lama: Balai Panjang Sub 03 menunggu `1303.csv`; tugas #141 dan #145.
