# Catatan: Kortim & Kelompok Pendataan Pascabencana (12 Okt 2026)

Permintaan user: akun tim dijadikan **kortim**, berlaku hanya mulai identifikasi-pendataan, tidak memengaruhi peran di pelatihan.

- Tabel baru `bencana_kelompok_tim` (migrasi 20261012a, sudah diterapkan): kegiatan_id (=1 Pendataan Pascabencana), kelompok 1-6, peran kortim|pml, akun_id (sigap_akun), urutan, aktif. RLS aktif tanpa policy.
- Isi: 12 kortim + 18 PML. K1 Adriyanto+Adrianus | Budi Pernandes, Usyenti, Megawati. K2 Deswaty+Nurafiza | Lia Angraini, Ayu Sepriani, Widya Elvera. K3 Lucia+Faisal | Dessy Meiyarni, Saputra Ebel Feri, Yurneti. K4 Riva+Riko | Ferianto, Widya Verawati, Mega Nana Yulianti. K5 Dina+Muzahar | Hariston, Yeni Siswanti, Lucky Melan Sari. K6 Arini+Kafsal | Irawita, Ardial Jaraf, Ilham.
- sigap_penugasan TIDAK diubah (pelatihan kegiatan 3 tetap pml/ppl). Faisal (akun 200) dan Muzahar (akun 410) tidak punya baris bencana_petugas; Faisal tidak punya penugasan kegiatan 1.
- Beda dengan peran lama `korwil` (12 organik di bencana_petugas; Uci & Witria korwil tapi bukan kortim; Faisal & Muzahar kortim tapi bukan korwil). Peran korwil tidak diubah.
- BELUM ada kode aplikasi yang membaca tabel ini (hak akses/tampilan kortim, mis. pantau kelompoknya di Monitoring Lapangan). Perlu keputusan hak kortim.
