# Tahap 14: Master data (papan 14), 24 Okt 2026

Halaman baru `/sigap/master?bagian=<akun|struktur|satuan|kelompok|waktu|skor|kew|pola|lain>`. Tautan masuk: tombol "Master data" di Jadwal revisi (`/sigap/revisi`).

## Berkas
- `lib/keu/master.ts` + `lib/keu/__tests__/master.test.ts` (19 uji): validasi isian, ringkasan, skor, kewenangan, riwayat.
- `app/sigap/master/page.tsx` (rangka, KPI, navigasi 3 grup, pemuatan data), `Akun.tsx` (akun, satuan), `Anggaran.tsx` (struktur, kelompok + prioritas + parameter kecukupan, waktu, skor), `Lainnya.tsx` (kewenangan, dokumen, tim/peran/status, riwayat, aturan M1-M6).
- `lib/keu/tampilan.ts`: ditambah keu_master_satuan_alias dan keu_v_master_riwayat. `baca.test.ts`: pengecualian eksplisit untuk satu tampilan riwayat master.
- SQL `20261024q_keu_v_master_riwayat.sql` (SUDAH dijalankan di produksi): tampilan riwayat khusus tabel master (keu_master_*, keu_struktur_level), hanya service_role.

## Hak mengubah (ditegakkan basis data, bukan hanya tombol)
- kewenangan "master" (Admin Aplikasi, PPK): akun, satuan, alias, parameter, waktu, kelompok, dokumen, struktur.
- kewenangan "bobot" (PPK): bobot dan ambang skor RAB.
- Pembaca lain melihat saja. Tidak ada hapus; akun/satuan dinonaktifkan.

## Yang dapat diubah dari halaman
Akun (pola, aktif, tambah), satuan (arti, status konfirmasi, tambah satuan, tambah alias), subkomponen tampil/sembunyi, parameter faktor kebutuhan dan toleransi Cukup, tenggat (tanggal) dan teks waktu, bobot + ambang skor dengan pratinjau langsung (tiga RO tertinggi/terendah), tanda "dapat dibuat SIGAP" per dokumen.

## Selisih dari mockup (disengaja)
1. Matriks kewenangan baca saja: mencabut kewenangan butuh fungsi basis data khusus (tabel master tanpa hapus); menambah juga ditunda agar Admin tidak mengunci diri (M6).
2. "Sudah dikoreksi" pada dokumen kelengkapan tidak ada: di mockup hanya status sesi, tidak ada kolom basis data.
3. Daftar "Tim kegiatan" tidak ada: tidak ada sumbernya di master (tim diatur di Penugasan peran).
4. Waktu: profil penarikan, tahun anggaran, masa penugasan dikunci (dibaca bagian lain dari sumber sendiri). Hanya tenggat bertanggal dan teks bebas yang bisa diubah.
5. Riwayat dibaca dari jejak sebenarnya (bukan "sesi ini"), 100 terbaru.
6. Skor: komponen yang belum dapat dinilai (penarikan, saat ini belum ada data) tidak ikut menimbang.
7. Status catatan kekurangan memakai nilai basis data: tercatat, ditunda, dipenuhi, ditolak, ditarik.

## Uji
`npx vitest run lib/keu` = 275 lulus; `tsc` bersih; uji render komponen (sementara, tidak disertakan) lulus. Belum diuji di produksi: menunggu deploy.

## Rencana uji di produksi (setelah deploy)
1. Buka `/sigap/master` sebagai Iqbal (354, PPK): KPI terisi, 9 bagian terbuka, riwayat muncul.
2. Akun: ubah pola satu akun lalu kembalikan; tidak menambah akun produksi kecuali disetujui.
3. Skor: ubah satu bobot di isian saja, lihat pratinjau berubah, jangan simpan (atau simpan lalu kembalikan nilai awal 35/25/20/20, 85/70).
4. Waktu: ubah tenggat DIPA DJA lalu kembalikan ke 30 Oktober 2026.
5. Akun non-PPK: tombol ubah tidak muncul.

## Urutan berikutnya (menggantikan bagian "Urutan berikutnya" pada status-bangun-kertas-kerja-revisi-24okt.md)
Setelah deploy 4n + papan 8 + papan 14 dan uji di Chrome: papan 16 (Struktur level baru; keu_master_jalur, jalur penutup), lalu 6 (Impor), 7 (Versi/RPD/dampak), 4 (Lampiran), 5 (Status/riwayat); periksa 11/12/13/15 terhadap mockup.
Celah terbuka: alasan versi RAB (butuh SQL), jalur penutup, pengurangan realisasi SPAN pada RAB bulanan, padanan 52 baru/104 hilang POK, jadwal 7 masih memakai POK lama, konfirmasi "sppkrt" = SPDT NTP 2903.BMA.008, pencabutan kewenangan (butuh fungsi basis data).
Nomor berkas SQL berikutnya: r (o = keu_v_rab_jadwal_item, p = keu_usulan_buat, q = keu_v_master_riwayat).
