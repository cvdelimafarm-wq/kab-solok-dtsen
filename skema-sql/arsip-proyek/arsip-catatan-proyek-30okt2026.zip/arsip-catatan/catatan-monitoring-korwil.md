# Catatan: Monitoring Korwil di HP (19 Okt 2026)

Permintaan user (dari sketsa tangan): layar korwil di HP dengan (1) Progres Lapangan per tim PML (daftar petugas, wilayah, Target/Realisasi) dan (2) Progres Administrasi (matriks PPL & PML x tanggal H1, H2, ...). Hanya-baca.

## Keputusan user (mockup disetujui)
1. Tahap 1 = Monitoring ini, tahap 2 = Transport Lokal. (Tafsir saya: modul `monitoring_korwil` jadi langkah 1 di tahap Pendataan Pascabencana, translok langkah 2. Bila maksudnya induk/tahap terpisah seperti spdt_ntp, cukup ubah data `sigap_tahap` lewat SQL; kode tetap sama karena berbasis katalog modul.)
2. Hanya-baca; korwil (kortim) melihat kelompoknya sendiri; akun dengan izin `bencana.admin` melihat semua kelompok.
3. Target = KK pada daftar Sub SLS tim; Realisasi = KK didata.
4. Sub SLS yang dipegang >1 PML: target diproporsikan. Realisasi tiap tim = KK yang didata akun anggota timnya; sisa = max(0, total - jumlah didata tim) dibagi rata ke tim pemegang (ganjil: +1 ke tim dengan realisasi lebih besar, seri id PML terkecil). Contoh Gando 01: 77 KK, 71 didata (Budi 30 / Megawati 41) -> target 33 / 44. Jumlah target tim = total KK, sehingga angka kelompok = jumlah angka tim.
5. Wilayah: rekap per nagari bawaan + tombol Daftar Sub SLS.
6. H1 = 10 Okt 2026; kolom bertambah tiap hari.

## Berkas (repo laptop)
- Baru: `lib/korwilMonitor.ts` (murni), `lib/portal/korwilMonitor.ts` (server, memo 45 dtk; `ringkasModulKorwil` murah memo 60 dtk), `app/api/portal/korwil/monitoring/route.ts`, `app/sigap/korwil/{page,KorwilLapangan,KorwilAdministrasi}.tsx`, uji `lib/__tests__/korwilMonitor.test.ts` dan `sigapTahapKorwil.test.ts`, `supabase/migrations/20261019b_tahap_modul_monitoring_korwil.sql`.
- Diubah: `lib/sigapTahap.ts` (modul `monitoring_korwil`), `lib/sigapPrioritas.ts` (`adalahTugas`), `lib/sigapNavigasi.ts` (`/sigap/korwil` -> kegiatan pascabencana), `lib/portal/induk.ts` (field `korwil`), `app/portal/dataBersama.ts` (PROFIL segar 45 dtk).
- API: `GET /api/portal/korwil/monitoring[?kelompok=n][&segar=1]`; 401 tanpa sesi, 403 bila bukan kortim dan bukan admin.

## Aturan data
- Hierarki: `bencana_kelompok_tim` (kegiatan 1, kelompok 1-6, peran kortim/pml); PPL = `bencana_petugas` peran ppl atasan = PML; Sub SLS = `bencana_alokasi_subsls.pml_id`; nonaktif (`bencana_wilayah.nonaktif`) dikeluarkan; KK dari RPC `bencana_pendataan_ringkas(p_pml)`; "tidak ditemukan" dipisah dari didata.
- Administrasi: PPL dinilai aturan tab Monitoring (hasil+laporan+foto); PML hanya laporan+foto; hari ini yang belum lengkap = "berjalan" (belum dihitung).
- Realisasi per wilayah (per Sub SLS) bisa beda dari angka per petugas (mis. Budi 254 per Sub SLS vs 213 setelah proporsi / 183 atas nama PPL-nya) karena siapa pun yang mendata Sub SLS satu tim dihitung ke tim itu.

## Data uji (Kelompok 1, 19 Okt 2026)
Target 1.965, didata 681 (34,7%), 25 Sub SLS; Budi 491/213, Megawati 364/177, Usyenti 1.112/291. Uji: 49 lulus (vitest), tsc bersih.

## Urutan pasang (dilakukan user)
1. Jalankan `20261019a_korwil_kelompok_hierarki.sql` (hubungkan Faisal/Muzahar dan hierarki korwil) lebih dulu.
2. Jalankan `20261019b_tahap_modul_monitoring_korwil.sql` (aman sebelum/sesudah deploy).
3. Commit + push, lalu uji lewat "masuk sebagai" akun kortim.
