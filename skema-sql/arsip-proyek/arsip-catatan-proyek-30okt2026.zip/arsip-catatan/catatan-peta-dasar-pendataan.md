# Catatan: peta dasar (jalan) di tab Peta Lembar Pendataan

Dibuat 20 Okt 2026. Mockup disetujui: https://claude.ai/artifact/XjnvEs48YBefH6FBEBXgGq. Cakupan: jalur 1 (peta jalan vektor offline) dan jalur 2 (online dari berkas yang sama). Satelit TIDAK ikut (hanya online, belum ada penyedia yang disetujui).

## Cara kerja
- Satu berkas PMTiles per tim PML (kunci = `bencana_petugas.id` PML = `DataTimPendataan.pml.id`). Sumber OSM lewat build harian Protomaps, dipotong di laptop (`scripts/peta/potong-peta.mjs`) dan diunggah ke bucket Storage publik `peta-dasar` bersama `manifest.json` `{versi,dibuat,tim:{id:{berkas,ukuran,versi}}}`.
- Penampil: MapLibre GL sebagai LATAR di bawah SVG `PetaKk`. `PetaKk` tetap mengurus geser, cubit, dan pilih titik; peta dasar `interactive:false` dan kameranya dikunci mengikuti `Pandang` SVG (`kameraDariPandang` di `lib/petaDasar.ts`).
- Offline: atas ketukan petugas ("Unduh sekarang") berkas disimpan di Cache Storage `sigap-peta-v1` pada kunci `/peta-cache/dasar/<berkas>` (header X-Disimpan, X-Versi, X-Ukuran), dibaca langsung oleh halaman (`SumberBlob`), service worker tidak diubah. Huruf peta: `public/peta/glyphs/Plus Jakarta Sans {Regular,Bold}` (rentang 0-255, 256-511, 8192-8447), lewat protokol `sigapg://`.
- Sumber dipilih: salinan di HP bila versinya cocok atau luring; selain itu online dari Storage; selain itu kanvas titik seperti biasa. Gagal muat 15 dtk atau galat sumber -> kembali ke titik, ada pesan kecil.
- Pilihan lapisan (Jalan / Titik saja) diingat per HP: `localStorage sigap_peta_lapisan_v1`. Tim tanpa berkas dan tanpa salinan tidak melihat kontrol sama sekali.

## Berkas
`lib/petaDasar.ts` (+ `lib/__tests__/petaDasar.test.ts`, 11 uji), `app/portal/petaDasarOffline.ts`, `app/sigap/pendataan/{PetaDasar.tsx,useDasar.ts,KontrolPetaDasar.tsx}`, edit `PetaKk.tsx` (prop `tanpaLatar`) dan `page.tsx`, `scripts/peta/{potong-peta.mjs,wilayah.mjs,wilayah-spdt.mjs,wilayah-tim.json,README.md}`, migrasi `20261020b_peta_dasar_bucket.sql`.
Paket baru: `maplibre-gl`, `pmtiles`, `@protomaps/basemaps` (WAJIB `npm i` lalu commit `package.json` + `package-lock.json`; kasus `qrcode` pernah gagal build Railway karena lock tertinggal).

## Wilayah tim
18 tim PML, sel grid 0,01 derajat berisi KK aktif berkoordinat, diperlebar +-1 sel (`--pad`). Ada sel pencilan (mis. tim 159 dan 431) yang menjadi persegi kecil terpisah. Kueri pembuatan ulang ada di `scripts/peta/README.md`. Status 20 Okt 2026 pagi: 18 berkas + `manifest.json` sudah diunggah ke Storage (total sekitar 14 MB, tiap berkas 0,5-1,2 MB).

## Lembar SPDT NTP (20 Okt 2026 malam)
- Gejala: peta Lembar Pendataan SPDT NTP (contoh akun Rabiatul Fauziah, 25 KK) masih titik di atas kisi kosong, karena `app/sigap/spdt/PetaSpdt.tsx` terpisah dan tidak ikut disambungkan pada 20 Okt (hanya lembar bencana).
- Perbaikan: `page.tsx` SPDT memakai `PetaDasar`, `useDasarTim`, dan `KontrolPetaDasar` yang sama; `PetaSpdt` punya prop `tanpaLatar`. Berkas yang sama (bucket, manifest, unduhan offline), kunci angka sendiri lewat `kunciPetaSpdt` di `lib/petaDasar.ts`: PPL = 9.100.000 + akun PPL (hanya KK miliknya), PML = 9.200.000 + akun PML (KK semua PPL-nya), Supervisor = 9.300.000 (seluruh wilayah). Tidak bentrok dengan id tim bencana (<= 460).
- Wilayah dihitung langsung dari tabel `sigap_spdt_kk` oleh `scripts/peta/wilayah-spdt.mjs` (811 KK, 393 sel grid, kotak 100,52-101,05 BT dan -1,31 s.d. -0,53 LS; 56 berkas: 40 PPL, 15 PML, 1 supervisor). Perintah: `node scripts/peta/potong-peta.mjs --spdt --tim=9100498 --unggah` (coba satu PPL), lalu `--spdt --unggah`. Manifest yang diunggah kini digabung dengan manifest yang sudah ada di Storage (tim bencana tidak hilang).
- Sampai berkasnya diunggah, petugas SPDT tetap melihat titik di kanvas (tanpa kontrol peta). Belum diuji di HP/OSM nyata; berkas supervisor (seluruh wilayah) bisa lebih besar, periksa dengan `--perkiraan`.
- Status: kode ditulis ke laptop (page.tsx, PetaSpdt.tsx, petaDasar.ts + tes, potong-peta.mjs, wilayah-spdt.mjs, README), BELUM di-commit/push dan berkas peta SPDT BELUM dibuat.

## Batas yang diketahui
- Belum diuji dengan data OSM nyata atau di HP; ukuran berkas baru diketahui saat `--perkiraan`. Batas unggah paket gratis Supabase 50 MB per berkas.
- Membuka aplikasi dari nol tanpa sinyal tetap "Tidak ada sinyal" (service worker tidak men-cache halaman/JS; audit #6).
- Cakupan OSM di Solok tidak selengkap Google. Safari/iOS menghapus data situs yang tidak dibuka 7 hari kecuali aplikasi dipasang ke layar utama.
- Google melarang menyimpan ubin; OpenFreeMap dan MapTiler tidak cocok untuk offline massal, sebab itu berkas sendiri.
