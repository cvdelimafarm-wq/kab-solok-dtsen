# QC Pemahaman Petugas: status 26 Okt 2026 (malam)

**Posisi:** semua kode sudah ada di repo laptop (belum di-commit, belum di-deploy, SQL belum dijalankan di produksi).

## Yang sudah ditulis ke laptop (16 file)
- SQL: `skema-sql/fase-b/20261026k_sigap_qc_pemahaman.sql` (tabel, fungsi `sigap_qc_*`, bank soal dari xlsx) dan uji `61_uji_qc.sql`.
- Logika murni + tes: `lib/sigapQc.ts` (47 tes), `lib/__tests__/sigapQc.test.ts`.
- Server: `lib/portal/qc.ts`; API `app/api/portal/qc/route.ts`, `.../qc/admin/route.ts`, `app/api/sigap/qc/jadwal/route.ts` (cron).
- UI petugas: `app/portal/qc/QcGerbang.tsx` (modal blokir + ulangan + tinjauan), `RekapPml.tsx` (rekap pagi PML), `Sorot.tsx`.
- UI admin: `app/sigap/kelola/pendataan/QcPemahaman.tsx` (sub: Hari ini, Pengaturan, Bank soal).
- Diubah: `lib/sigapPendataanTab.ts` (+tes) tab baru "4 · QC Pemahaman" di tengah (Monitoring jadi 5, Pemeriksaan 6, Administrasi 7), `app/sigap/kelola/pendataan/page.tsx`, `app/layout.tsx` (mount `<QcGerbang />`).
- Verifikasi di sandbox: tsc bersih untuk file QC (dengan stub modul repo), vitest 72 lulus (sigapQc + sigapPendataanTab), SQL diuji di Postgres 16 lokal.

## Aturan yang berlaku
- Peserta: PML dan PPL aktif Pendataan Pascabencana (kegiatan 1). 10 soal sama untuk semua, diundi saat rilis (19.00), semua paket terwakili. Batas 20.00.
- 4 percobaan (1 awal + 3 ulang); wajib diulang sampai 100 atau percobaan habis. Setelah 20.00 modal tetap memblokir sampai diisi.
- **Hari susulan** (permintaan 19.48): hari yang terlewat batas tidak ditandai terlambat, tetap memblokir, diingatkan berkala sampai 100. Otomatis bila QC dinyalakan setelah jam batas pada hari tanpa jawaban; bisa dicabut/ditandai manual di tab Hari ini.
- Pengingat berkala sesudah batas: bawaan 60 menit, 0 = mati, 15-720, tidak dikirim 23.00-05.59.
- Keputusan saya (perlu disetujui): hanya hari rilis terbaru yang memblokir; hari lama yang belum diisi menjadi "tidak mengisi" saat set baru dirilis. Rekap memakai percobaan pertama untuk "soal salah" dan nilai terbaik untuk nilai.
- Batasan: gerbang disembunyikan pada mode "masuk sebagai".

## Langkah milik user
1. Supabase SQL editor: jalankan `20261026k_sigap_qc_pemahaman.sql`, lalu `61_uji_qc.sql` (hasil yang diharapkan: error sengaja `HASIL_UJI: {...}`).
2. Laptop: `npx tsc --noEmit`, `npx vitest run`, `npm run build`, lalu commit + push + deploy.
3. Kelola Pendataan > 4 · QC Pemahaman > Pengaturan: periksa jadwal, centang aktif, simpan. Pakai "Contoh push" untuk uji notifikasi.
4. Railway Cron `*/5 * * * *` → `POST /api/sigap/qc/jadwal?slot=auto` dengan `Authorization: Bearer <SIGAP_CRON_SECRET>` (uji kering: `?uji=1`).
5. Semua PML/PPL perlu mengaktifkan notifikasi (iPhone: Tambahkan ke Layar Utama).

## Catatan
- Project hampir penuh: salinan `QcPemahaman.tsx` dan `lib/sigapPendataanTab.ts` TIDAK tersimpan di Project (ditolak karena ukuran); versi resmi ada di repo laptop.
