# Catatan mockup Kertas Kerja Revisi POK SIGAP, tahap 12 (24 Okt 2026)

Mockup: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap (Versi 41). Papan 1–8 tetap; papan baru 9–13 di kolom kanan kanvas. Belum ada SQL atau kode aplikasi; menunggu kata "setuju" dari Bapak.

## Permintaan yang dijawab
Peran/akses/persetujuan, jadwal dan pengesahan revisi oleh PPK, PDF POK resmi + realisasi mingguan + skor kualitas RAB per RO, serta tab Administrasi per item POK (dari lembar kelengkapan dokumen SME). Navigasi: satu alamat per RO+tab, tombol Kembali yang menyebut tujuannya, GSBPM "Identifikasi kegiatan" merujuk tab yang sama.

## Papan baru
- 9 Navigasi ruang kerja RO: alamat `/sigap/ro/<KODE>?tab=...&dari=...`; Kembali 44px menyebut tujuan; tab sticky dengan lencana; pindah RO hanya RO yang berhak; Ctrl+K; aturan N1–N6.
- 10 Peran, akses, persetujuan: matriks peran x kemampuan; penugasan Ketua Tim / Admin RO / akses tab Administrasi per RO; "Lihat sebagai"; alur RAB dan usulan revisi (draf, admin RO ajukan, ketua tim setujui, PPK setujui; admin RO tidak bisa menyetujui sendiri; PPK yang juga ketua tim lanjut ke KPA).
- 11 Jadwal dan pengesahan revisi: jenis POK/DIPA DJPb/DJA/Administrasi; jadwal bawaan Revisi POK tanggal 10 (bisa dilewati/dipulihkan); siklus terjadwal, dibuka, terkumpul, diterapkan, sah (nomor+tanggal wajib; menghasilkan versi POK baru); pengingat tenggat PMK.
- 12 POK resmi, realisasi, skor: PPK unggah PDF POK resmi dan cocokkan dengan POK sistem (hanya selisih ditampilkan); Bendahara unggah Excel realisasi mingguan; skor kualitas RAB per RO (bobot awal penarikan 35, volume 25, cakupan 20, disiplin 20; PPK dapat mengubah bobot; angka ILUSTRASI; bersifat pembinaan).
- 13 Tab Administrasi per item: tiap item POK dipetakan ke lembar kelengkapan (akun+uraian, bisa diubah lembar/seksi); dokumen per pihak; status Belum, Draf SIGAP, Terunggah, Terverifikasi; "Buat dari SIGAP" / "Buat semua"; hanya pihak bersangkutan dan PPK yang unggah; verifikasi PPK/Bendahara.

## Berkas teknis (di artefak)
kk-adm-data.js (hasil parse Excel + pohon POK) dan kk-adm.js (model peran, alur, jadwal, skor, dokumen) sebagai blob; semua data penugasan, skor, dan penanda "dapat dibuat SIGAP" adalah ILUSTRASI.

## Pertanyaan terbuka untuk Bapak
1. Dokumen mana di Excel yang benar-benar bisa dibuat SIGAP.
2. Siapa memverifikasi dokumen tiap pihak (PPK saja atau bendahara untuk bagiannya).
3. PPK yang merangkap ketua tim: persetujuan RAB-nya ke KPA?
4. Apakah perlu langkah KPA sebelum PPK menyatakan Revisi POK sah.
5. Ketua tim dan admin RO tiap RO sebenarnya (perlu impor); masa berlaku penugasan.
6. Rumus dan bobot skor, serta siapa yang boleh melihat skor.
7. Pembacaan PDF POK otomatis (format RKKS); selisih lewat papan 6 "impor POK hasil penetapan", bukan menimpa langsung.
8. Apakah pemetaan item ke kegiatan diperlukan di tab Administrasi.
9. Item tanpa lembar (belanja pegawai 51, modal 53, akun lain seperti 521252/522111) mau diperlakukan bagaimana.
10. Di Excel ada seksi "D" ganda pada 521213 (saya ubah jadi E) dan beberapa item tidak ada.
11. Tahap sebelumnya: redaksi P-02 vs P-06+P-07 (cek ke Kanwil); apakah penggenap boleh minus sementara; satu akun penggenap per RO atau per akun/komponen; keputusan PPK di paket Revisi DIPA masuk mana.
