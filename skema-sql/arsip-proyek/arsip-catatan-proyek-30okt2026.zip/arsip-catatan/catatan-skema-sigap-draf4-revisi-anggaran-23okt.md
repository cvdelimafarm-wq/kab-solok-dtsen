# Skema SIGAP Draf 4 – Revisi Anggaran (kertas kerja pengusul) — 23 Okt 2026

Dokumen: "Skema SIGAP Draf 4 – Revisi Anggaran (siap bangun)"
Tautan: https://claude.ai/artifact/NbjLfh8GCUmvH9EpG2JbzR

## Arah (dikoreksi Bapak 23 Okt malam)
- SIGAP adalah platform pengelolaan satu kegiatan statistik berbasis GSBPM (anggaran, pelaksanaan anggaran, SPJ, pelatihan, pendataan, dst). Kertas kerja revisi hanya salah satu fiturnya (butir F1-06 pada skema).
- Satker = pengguna layanan revisi, bukan pengelola atau pemutus. Aturan PMK dipakai agar kertas kerja sinkron: menentukan jenis revisi, daftar lampiran, pemeriksaan kesesuaian, pengingat tenggat.
- Dokumen ini hanya menggantikan bagian revisi dari skema Draf 3; bagian lain Draf 3 tetap berlaku.

## Empat jenis revisi yang biasa dipakai
1. Revisi POK (Pasal 173; KPA memutuskan, diunggah di Sistem Informasi)
2. Revisi Administrasi (Pasal 120 ayat 4)
3. Revisi DIPA jalur DJPb (Pasal 172 dan 174; Kanwil)
4. Revisi DIPA jalur DJA (Pasal 165; lewat Eselon I)

## Pemicu dan mode (masukan Bapak 23 Okt 20.33)
- Pemicu revisi di F1 = ketidaksamaan RAB dengan POK: angka berubah, redaksi item berubah, akun berubah, akun ditambah atau dikurangi, item ditambah atau dikurangi atau diubah (P-01 sampai P-08).
- PPK menetapkan jenis. Revisi POK atau Administrasi = Mode Pagu Tetap (pagu terkunci). Revisi DIPA = Mode Revisi DIPA: tiap perubahan pagu dipertimbangkan Disetujui atau Belum disetujui; Terapkan RAB (Ketua Tim) hanya membawa baris Disetujui; yang Belum disetujui tetap di Pagu resmi dan muncul sebagai Belum terpenuhi.
- Pembagian peran (PPK menetapkan jenis dan memberi pertimbangan, KPA menyetujui keseluruhan) masih penafsiran: K-8 dan Q-29.

## Isi dokumen (14 bagian)
Ringkasan; Dasar hukum; Empat jenis revisi; Pemicu revisi dan pemilihan mode; Isi kertas kerja dan lampiran; Tenggat sebagai pengingat; Siklus kertas kerja (diagram); Pemeriksaan kesesuaian R-01 sampai R-14; Integrasi dengan seluruh SIGAP (termasuk peta per fase GSBPM); Model data (migrasi 20261023a_keu_revisi_kertas_kerja.sql, belum dibuat); Layar L-01 sampai L-08; Kasus uji T-01 sampai T-17; Perubahan butir Draf 3 dan Q-23 sampai Q-29; Keputusan K-1 sampai K-8 dan urutan pembangunan.

## Status
- Belum ada kode. Mockup HTML artboard Revisi-Anggaran versi baru harus disetujui dulu; label u1, u2, u4 perlu dikoreksi.
- Fitur tidak mungkin selesai sebelum batas DJA 30 Okt 2026; revisi TA 2026 diurus manual, SIGAP disiapkan untuk TA 2027.
- Dasar perbandingan PMK: catatan-cek-pmk-revisi-anggaran-vs-skema-23okt.md
- Koreksi atas catatan itu: Izin Presiden muncul pada Pasal 165 ayat 1 huruf e angka 7 (kasus BA BUN), bukan syarat RO Khusus.
