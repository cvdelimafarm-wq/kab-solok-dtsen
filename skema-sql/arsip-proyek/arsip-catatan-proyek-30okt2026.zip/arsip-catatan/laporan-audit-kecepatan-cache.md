# Laporan audit kecepatan, cache, prefetch, dan kemudahan SIGAP

Tanggal: 10–11 Okt 2026. Sifat: hanya baca. Pengecualian, dengan izin Anda: ping otomatis tercatat atas nama Valina dan Irawita saat "Melihat sebagai". Tidak ada kode yang diubah, tidak ada data yang ditulis manual, tidak ada pesan yang dikirim.

## 0. Cakupan dan batasan

- **Deploy live TERBUKTI:** header `x-build-id` = `d2ed27c` (commit push 10 Okt 23:23). sw.js = `sigap-v3`. Chunk JS memuat `sigap_cache_v2`.
- **Putaran 1** (tab Chrome tersembunyi): prefetch dan unduhan peta berhenti sesuai desain, jadi angka pindah layer waktu itu (0,75–0,82 dtk) **tidak mewakili**. **Putaran 2** (11 Okt ±05.30 WIB, tab terlihat): angka di bawah ini yang valid.
- Akun: Valina alsisri (PPL), Irawita (PML, 52 Sub SLS identifikasi), dan akun Anda sendiri (admin). Desktop + Wi-Fi; Chrome melaporkan "3g". Angka HP 4.5G akan lebih lambat; pakai sebagai perbandingan relatif.
- Browser bawaan Claude tidak bisa dipakai (situs digolongkan berisiko tinggi, semua permintaan diblokir).

## 1. Tabel ringkas per layer (putaran 2, tab terlihat)

| Layer / perpindahan | Dingin | Hangat | Permintaan | Temuan | Verdict |
|---|---|---|---|---|---|
| Beranda (Layer 1) | **3,4–4,0 dtk** (PML / PPL) | Instan, 0 permintaan data | 4 paralel → 2 berantai (foto_ringkas, rapat) → wilayah-tim + identifikasi | API server lambat (#1) | Dingin TIDAK wajar; hangat wajar |
| Beranda → kegiatan induk | — | **32 ms** | 0 API, 0 RSC (prefetch kena) | — | Wajar (instan) |
| Kegiatan → tahap (Wilayah tugas tim) | — | **50 ms** | 0 | — | Wajar (instan) |
| Kembali (tombol "Kembali ke tahapan" / Back) | — | 27–62 ms | 0 | — | Wajar |
| Beranda/tahap → Lembar Identifikasi (PML) | — | **411 ms** | 1 RSC (316 ms) | Prefetch meleset karena `?dari=` (#5) | Cukup; bisa instan |
| Daftar identifikasi → detail Sub SLS | — | **961 ms** | RSC 328 + chunk 615 ms | Chunk halaman detail tidak di-prefetch (#5) | **Tidak wajar** (> 800 ms) |
| Lembar Peta (PML) | — | **buka 12 ms, lengkap 25 ms** | 0 (16 tautan "di HP") | Target < 300 ms tercapai | Wajar (sangat baik) |
| Berkas peta dari Cache Storage (SW) | — | 4–8 ms per berkas 1,3 MB | 0 | Berkas tak ada → 404 rapi | Wajar |
| Setiap perpindahan halaman | — | +0,3–0,5 dtk latar | tutup + manifest + ikon 22 KB | Sia-sia (#7) | Boros |
| Pemilih "Melihat sebagai" | 15,6 dtk | — | 62 KB, 788 akun | #8 | Tidak wajar |

**Durasi server (ms, 3x berturut-turut, akun Valina):** induk 2727/1866/2285 · beranda 1992/2067/2082 · kegiatan 1510/1413/1820 · pelatihan 2663/2465/2821 · wilayah-tim 738/897/693 · peta 3125/1023/700. **Akun Irawita (sekali):** beranda 2290, identifikasi 2500, induk 2234, kegiatan 2692, wilayah-tim 2174, pelatihan 3784. Kecuali peta, tidak ada yang membaik pada panggilan ulang, jadi biayanya ada di query, bukan cold start.

**Kewajaran data (B):** untuk Irawita, keenam jenis data di cache (umur ±2 menit) **identik** dengan respons segar, setelah mengabaikan stempel waktu. Ganti akun Valina → Irawita → akun Anda: pemilik cache berganti dengan benar (677 → 302 → 354), dan isinya milik akun yang aktif.

**Prefetch (C):** mulai ±0,7 dtk setelah Beranda tampil. 9–14 RSC (±2 KB per RSC) + chunk halaman (±60 KB) diambil **sekaligus**, bukan satu per satu, bersamaan dengan foto_ringkas dan rapat. Ada permintaan ganda (translok-58 dan translok-195 masing-masing dua kali) dan rute yang tidak perlu (tahap "Evaluasi – Belum mulai", /bencana/konfirmasi/...). Hasilnya pindah layer instan. Biayanya kecil (±80 KB).

**Peta (D):** unduhan otomatis mulai ±5 dtk setelah Beranda, 2 berkas paralel, tanpa galat CORS.
- Valina: 23 berkas = 25,9 MB dalam ±9 dtk.
- Irawita: 52 SLS + 8 WA → 80 berkas; 49 berkas baru (±55 MB) dalam ±46 dtk.
- Setelah ganti akun, Cache Storage berisi gabungan dua akun: 72+ berkas, **81 MB**. Berkas akun sebelumnya tidak pernah dibersihkan.
- Tanda "di HP" akurat (dicek ke Cache Storage).

## 2. Delay atau salah persepsi, urut prioritas

### #1 (P1, delay) API utama lambat di server: 1,4–3,8 dtk; Beranda dingin 3,4–4 dtk
- **Bukti:** angka di atas.
- **Dampak:** setiap login pertama, HP baru, setelah "Keluar", atau ganti akun, petugas menunggu ±4–5 dtk (di 4.5G lebih lama). Revalidasi di belakang juga makan 2–4 dtk, jadi data lama tampil selama itu tanpa tanda apa pun (#9).
- **Usulan:** log waktu per query di route (atau Supabase `get_advisors`/`query_logs`), cari query berurutan yang bisa `Promise.all`, N+1, dan indeks yang kurang. Pertimbangkan satu endpoint gabungan untuk Beranda.

### #2 (P1, navigasi rusak, TERBUKTI) "Ganti" diam dan "Kembali ke akun saya" mengeluarkan akun bila sesi asli lama sudah habis
- **Bukti live:** `sigap_sesi_asli_sampai` tetap 10 Okt 18:41 UTC setelah login baru, karena `mulaiLihatSebagai()` hanya menyimpan sesi asli bila belum ada. Akibatnya "Ganti" diklik dua kali tanpa reaksi dan tanpa permintaan jaringan, lalu "Kembali ke akun saya" menghapus semua sesi dan menampilkan halaman Masuk. Setelah login ulang (sesi asli baru), "Kembali ke akun saya" berjalan normal.
- **Bukti tambahan:** saat sesi habis, halaman Masuk tetap menampilkan banner "Melihat sebagai Ayu Sepriani". Pada jalur gagal ini, cache Valina (`sigap_cache_v2`, pemilik 677) **tertinggal di localStorage** setelah semua sesi dihapus.
- **Usulan:** login biasa menghapus semua `KUNCI_ASLI`; `mulaiLihatSebagai` menimpa sesi asli yang kedaluwarsa; banner tidak tampil tanpa sesi aktif; jalur gagal `kembaliKeAkunSaya` ikut membuang `sigap_cache_v2`.

### #3 (P1, salah persepsi, TERBUKTI) "Tidak ada sinyal" tampil padahal internet ada
- **Bukti live:** navigasi pertama di Chrome Anda menampilkan offline.html, padahal fetch API dari halaman yang sama sukses (229 ms). Penyebabnya, sw.js mengubah setiap galat jaringan saat navigasi (server restart, koneksi putus sesaat) menjadi offline.html.
- **Usulan:** coba ulang sekali (±1,5 dtk) sebelum memberi offline.html. Bila `navigator.onLine` true, tampilkan "Server sedang sibuk/diperbarui, coba lagi". "Coba lagi" otomatis saat `online`.

### #4 (P1, salah persepsi, TERBUKTI) PPL mengunduh ±26 MB peta tetapi tidak punya tombol untuk membukanya
- **Bukti live:** halaman Wilayah tugas tim Valina menampilkan "Semua peta wilayah Anda (23 berkas) tersimpan di HP. Bisa dibuka tanpa sinyal.", tetapi di halaman itu tidak ada tombol, tautan, atau baris yang bisa diklik untuk membuka peta. Tombol "Lihat peta …" hanya ada di Lembar Identifikasi (PML).
- **Dampak:** kuota PPL terpakai ±26 MB tanpa manfaat, dan teksnya menjanjikan sesuatu yang tidak bisa dipakai.
- **Usulan:** tambahkan ikon peta per nagari/Sub SLS di Wilayah tugas tim (pakai PetaSheet yang sama), atau jangan unduh peta untuk akun tanpa lembar peta.

### #5 (P2, delay) Detail Sub SLS 961 ms; Lembar Identifikasi 411 ms
- **Bukti live:** daftar → detail = RSC 328 ms lalu chunk halaman detail 615 ms (berantai). Beranda → Lembar Identifikasi: RSC 316 ms karena prefetch mengambil `/sigap/identifikasi` sedangkan tombolnya menuju `/sigap/identifikasi?dari=...`. RSC disimpan per URL lengkap termasuk query, jadi prefetch meleset (`siapkan.ts` membuang query dengan `split("?")[0]`).
- **Usulan:** prefetch dengan URL persis seperti di tombol (termasuk `?dari=`), atau baca `dari` dari sessionStorage, bukan query. Prefetch chunk halaman detail (mis. `router.prefetch` satu detail pertama saat daftar dibuka). `staleTimes.dynamic` 180 dtk.

### #6 (P1, salah persepsi) "Tanpa sinyal tetap tampil" hanya selama aplikasi masih terbuka
- **Bukti (kode):** SW tidak menyimpan halaman, jadi cold start tanpa sinyal → offline.html. Teks "Bisa dibuka tanpa sinyal" di kartu peta terlalu menjanjikan.
- **Usulan:** cache kerangka aplikasi (network-first, fallback cache) untuk Beranda, kegiatan, dan identifikasi. Atau, minimal, ubah teks dan tampilkan daftar peta tersimpan di offline.html.

### #7 (P2, boros, TERBUKTI) Permintaan berulang
- `/api/sigap/tutup` (no-store) di setiap navigasi + setiap 60 dtk, ±0,3–0,6 dtk. Isinya penutupan yang sudah lewat.
- `/api/sigap/rapat` dipanggil **setiap ±20 dtk** di Beranda (tercatat di detik 1,2 dan 21,2).
- `manifest.webmanifest` + `icons/icon-192.png` (22 KB) diunduh ulang di setiap navigasi; `sigap-logo.png` **106 KB** setiap muat penuh. Aset /public `Cache-Control: max-age=0`.
- **Usulan:** tutup dan rapat setiap 5 menit, atau hanya saat ada jadwal; header cache 7 hari untuk /icons, /ikon, logo; kompres logo (< 20 KB).

### #8 (P2, akun super) Pemilih "Melihat sebagai" 15,6 dtk (62 KB, 788 akun; hanya 60 yang ditampilkan)
- **Usulan:** cari di server sambil mengetik (limit 30) atau cache 1 jam.

### #9 (P2, salah persepsi) Tidak ada tanda "sedang memperbarui / data lama"
- **Bukti:** `useData` tidak punya status memperbarui atau umur data, dan galat disembunyikan bila data ada. Revalidasi 2–4 dtk (#1) berarti data lama tampil tanpa tanda. Saat ini isinya identik (lihat B), tetapi saat sinyal buruk data bisa berumur jam sampai hari.
- **Usulan:** label kecil "Diperbarui 3 jam lalu · ketuk untuk coba lagi" bila umur > 2× `segarMs` atau muat terakhir gagal; pelatihan `hariBaru: true`.

### #10 (P2) Peta: ukuran dan pembersihan
- Rata-rata 1,1–1,3 MB per JPEG. PML 80 berkas ≈ 55 MB, PPL ≈ 26 MB. Kompres ke WebP/JPEG q70 (±300–400 KB) agar unduhan 3× lebih cepat dan jarang berhenti karena "sinyal lemah".
- Berkas akun lama tidak dibersihkan (HP bergantian → 81 MB dan terus bertambah). Hapus berkas yang tidak ada di manifest akun aktif setelah unduhan selesai.
- Berkas pengganti dengan nama sama tidak diunduh ulang (kunci = nama). API peta perlu mengirim `updated_at`/etag.

### #11 (P2) Prefetch kurang rapi
- Semua rute diambil sekaligus, ada yang ganda (translok-58/195), ada tahap "Belum mulai" dan halaman bencana/konfirmasi. Usulkan dedup sebelum `router.prefetch` dan lewati tahap belum mulai.

### #12 (P2, dari kode, belum terjadi saat uji) Kebocoran antar-akun saat ganti akun cepat
- `tulisSekarang()` memberi label dengan `pemilikSesi()`, padahal isi memori milik `pemilikMemori`. Bila ganti akun < 800 ms setelah data tiba, data akun lama bisa tersimpan berlabel akun baru. Dua kali ganti akun saat uji: tidak terjadi (pemilik dan isi benar). Perbaikannya kecil (label dengan `pemilikMemori`).

### #13 (P3) Kecil
- Antrean: 408/429 dianggap "ditolak" permanen. 401 dalam mode "Melihat sebagai" ikut menghapus sesi asli.
- Ikon kegiatan bisa berganti saat dingin (ikon terpisah → ikon induk ketika 3 data siap).
- Risiko banner "Pembaruan tersedia" berulang bila SHA commit tidak tersedia; live saat ini konsisten.

## 3. Navigasi, kemudahan, konsistensi (live)

- **Pesan yang bertentangan:** banner "Melihat sebagai … · **aksi tersimpan atas nama akun ini**" dan layar pemilih "Aksi tersimpan atas nama akun tersebut", sedangkan halaman detail identifikasi menulis "Mode masuk sebagai: **hanya untuk melihat tampilan, tombol Simpan dimatikan**". Pilih satu aturan dan samakan teksnya. Bila memang hanya-lihat, ping pemantauan dan antrean juga sebaiknya dimatikan di mode ini.
- **Satu tujuan, banyak nama (akun admin):** `/bencana` = chip "Admin Bencana", chip "Pengelola PSP Pascabencana", ubin "Admin Pendataan Pascabencana". `/sigap/kelola/translok` = "Admin Anggaran" dan "Admin Transport Lokal". `/sigap/kelola/pelatihan` = "Instruktur Pelatihan (Inda)" dan "Kelola Pelatihan". `/dashboard` = "Admin DTSEN" dan "Admin Usulan DTSEN". Pintasan chip boleh tetap ada, tetapi namanya perlu sama dengan ubin tujuannya.
- **Dobel sungguhan:** Seruti muncul di "Menu umum" (Seruti) dan "Pengelolaan" (Admin Seruti) dengan tujuan sama `/seruti`, ditambah chip. Cukup satu ubin.
- **Nama aplikasi tidak konsisten:** header "SIGAP · Sistem Integrasi Kegiatan BPS"; judul tab Beranda "Portal Layanan BPS Kabupaten Solok"; judul Layer 2/3 "SIGAP — Gerak Anggaran & Pertanggungjawaban · BPS Kabupaten Solok · BPS Kabupaten Solok" (kepanjangan berbeda, "BPS Kabupaten Solok" dobel).
- **Label status:** Wilayah tugas tim: "Identifikasi SLS oleh PML: 0 dari 12 selesai", tetapi semua Sub berlabel "Sedang diidentifikasi PML". Usulkan "Menunggu identifikasi PML".
- **Jumlah peta berbeda per halaman:** Valina 23 berkas, Irawita 80. Benar per akun, tetapi kartu "Peta untuk offline" juga tampil untuk PPL yang tidak bisa membuka peta (#4).
- **Baik:** kartu tugas utama jelas (tahap, sisa waktu, satu tombol); jejak "Beranda · Kegiatan saya" dan "Pendataan Pascabencana · Tahapan"; tombol "Kembali ke tahapan" instan; filter PML/PPL di pemilih akun.
- **Tombol "Keluar"** tanpa konfirmasi di header.

## 4. Hal yang sudah baik

- Tujuan utama tercapai: pindah layer hangat **32–62 ms**, lembar peta **25 ms**, kembali **27–62 ms**, semuanya tanpa permintaan data.
- Cache identik dengan data segar; pemilik cache berganti dengan benar saat ganti akun; keluar normal membuang cache.
- Unduhan peta otomatis berjalan, cepat, tanpa galat CORS, 2 paralel, dan ditahan saat lembar peta terbuka. SW melayani peta 4–8 ms, dan berkas yang tidak ada → 404 rapi.
- Mode "Melihat sebagai" mematikan tombol Simpan di identifikasi (aman), dan selisih jam server dihitung benar walau data dari cache.

## 5. Skenario uji manual (HP asli)

1. **Offline (#3/#6):** tunggu peta lengkap → tutup aplikasi → mode pesawat → buka. Saat ini: "Tidak ada sinyal".
2. **Peta di iPhone/Android:** mode pesawat, Lembar Identifikasi → Lihat peta → ketuk tautan "di HP". Di iPhone (aplikasi terpasang), tab baru = Safari terpisah, kemungkinan 404.
3. **Antrean:** mode pesawat → simpan satu Lembar Identifikasi (akun PML asli, bukan "Melihat sebagai") → "menunggu dikirim" → online → terkirim ≤ 1 menit; progres tahap dan Beranda berubah.
4. **Ganti hari:** biarkan aplikasi terbuka melewati 00.00 → kembali → kartu atas dihitung ulang.
5. **Hemat data:** Data Saver aktif → tidak ada unduhan peta/prefetch.
6. **4.5G:** ulangi Beranda dingin dan daftar → detail identifikasi; bandingkan dengan tabel 1.

## 6. Keputusan yang dibutuhkan
- Urutan perbaikan yang disarankan: #2 (ganti akun), #4 (peta PPL), #1 (server), #5 (detail identifikasi), #7 (polling dan cache aset).
- Mode "Melihat sebagai": hanya-lihat atau bertindak atas nama akun? Teks dan perilaku (ping, antrean) mengikuti keputusan ini.
- Mode luring penuh vs ubah teks janji; viewer peta di dalam aplikasi; kompresi peta.

## 7. Status perbaikan (deploy `fca308a`, 11 Okt 2026, diverifikasi live di Chrome)
- #2 Ganti akun: **beres**. "Ganti" membuka pemilih, pindah Irawita → Valina berhasil, sesi asli tetap sah, cache akun sebelumnya terbuang. "Kembali ke akun saya" kembali ke akun super.
- Mode "Melihat sebagai" = **simulasi**: Simpan identifikasi aktif. Hasil tampil di layar (progres 1/52), catatan "Simulasi: tersimpan di layar ini saja" muncul, tidak ada POST ke server, antrean kosong, dan data server tetap kosong (dicek GET segar). Middleware: POST bersesi 4 bagian → tiruan 200 `X-Simulasi: 1`. Ping tidak terkirim.
- #4 Peta PPL: **beres**. 6 tombol "Lihat peta <nagari>" di Wilayah tugas tim; lembar terbuka 16 ms, 4 tautan "di HP".
- Menu: chip = nama ubin, /bencana tidak lagi dobel (8 chip), "Seruti" di Menu umum hilang, judul tab "SIGAP · Sistem Integrasi Kegiatan BPS", label "Menunggu identifikasi PML", tidak ada lagi "Selesai Selesai".
- Belum dikerjakan: #1 (server lambat), #3 (offline palsu), #5 (detail identifikasi 961 ms), #6 (luring penuh), #7 (polling & cache aset), #8 (pemilih akun lambat), #9–#11.

## 8. Akar masalah #1 (server lambat) — 11 Okt 2026
- Supabase berada di **ap-southeast-1 (Singapura)** (get_project).
- Log edge Supabase menunjukkan permintaan dari server aplikasi (user-agent node) datang lewat Cloudflare **AMS/FRA, negara NL**. Jadi server Railway berjalan di **Eropa (Belanda)**: ±234 ribu permintaan dari AMS dan ±46 ribu dari FRA dalam 24 jam.
- Setiap query Supabase menyeberang Eropa ↔ Singapura (±160–250 ms per bolak-balik). Route Beranda menjalankan ±6–8 query berurutan (akunDariSesi → izin/penugasan/aplikasi → bencana_petugas → tentukanTujuan → cocokPenyisiran), jadi totalnya 1,5–2,8 dtk. Ini cocok dengan angka terukur.
- HP petugas di Sumatera juga harus ke Eropa (HTML pertama 2,8 dtk; RSC/ikon 300–500 ms per permintaan).
- **Perbaikan utama:** pindahkan region layanan Railway ke **Southeast Asia (Singapura)**, satu kota dengan Supabase. Perkiraan: query 2–5 ms, API Beranda < 300 ms, dan HP lebih dekat ke server.
- Perbaikan kode (lanjutan, setelah pindah region): paralelkan query yang tidak saling bergantung di `susunBeranda`, `induk`, dan `pelatihan`.
- **Hasil setelah pindah region (11 Okt ±06.50 WIB, log Supabase: permintaan server kini dari SIN):** induk 2,2 → 0,24 dtk; beranda 2,0 → 0,37; kegiatan 1,5 → 0,22; pelatihan 2,6 → 0,26–0,56; wilayah-tim 0,7 → 0,07–0,6. Empat API Beranda paralel (setara Beranda dingin) 4 → 0,45–0,8 dtk. Pemilih "Melihat sebagai" 15,6 → 0,9 dtk. Diukur dari laptop (Wi-Fi), dasar bolak-balik ke server ±150 ms.

## 9. Putaran perbaikan 2 (11 Okt 2026, belum di-push saat ditulis)
- #3 offline palsu: SW `sigap-v4` mencoba ulang navigasi sekali (1,5 dtk) sebelum offline.html. offline.html membedakan "server belum terjangkau" (internet ada) dan "tidak ada sinyal", memuat ulang otomatis, dan **mendaftar peta yang tersimpan di HP** (nama Sub SLS dari simpanan data). Ikon offline diperbaiki (/icons/icon-192.png).
- #5 detail identifikasi: prefetch Beranda kini memakai URL lengkap (`?dari=`), dan baris daftar identifikasi memakai `prefetch={true}` (kode + data detail disiapkan untuk baris yang terlihat). Prefetch rute dijalankan satu per satu (jeda 120 ms).
- #7 permintaan berulang: `/api/sigap/rapat` tiap 20 dtk hanya bila ada rapat (tanpa rapat: 2 menit + saat aplikasi dibuka lagi); `/api/sigap/tutup` tidak lagi di setiap pindah halaman (sekali + tiap 5 menit, atau 1 menit selama penutupan aktif); aset /icons, /ikon, logo di-cache 7 hari, manifest 1 hari.
- Keputusan user: berkas peta **tidak dikompres** (kualitas peta lebih penting).
