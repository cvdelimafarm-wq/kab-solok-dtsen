# Catatan mockup Kertas Kerja Revisi POK, tahap 3 (24 Okt 2026)

Status: MOCKUP saja (artifact Design "Kertas Kerja Revisi POK SIGAP", Versi 20-26). Belum ada SQL, migrasi, atau kode aplikasi. Menunggu kata "setuju".
Peramban belum pernah dipakai untuk memeriksa tampilan; pengujian lewat skrip node (logika + renderVals).

## Yang ditambahkan
1. Ganti akun dari baris akun: kolom isian "ganti akun ini..." pada baris akun menyalin SELURUH item akun itu ke akun baru (skema pasangan: akun lama dikosongkan, akun baru berisi salinan, Semula kosong). Item yang sudah punya Booked/Realisasi hanya dipindah sisanya; item yang realisasinya penuh dilewati. Tombol "Batalkan pindah akun" mengembalikan satu akun sekaligus. Ganti akun per item tetap ada.
2. Kartu atas: Kelengkapan RAB (persen, lalu x/y; y = seluruh item, x = item yang sudah ada RAB; pada contoh 58/82 = 71%), Realisasi TA 2025 (Rp 580.755.000 = 91,7% dari pagu Rp 633.527.000, ANGKA ILUSTRASI), dan Realisasi resmi SPAN.
3. Ikon info di tiap baris akun: membuka baris keterangan realisasi TA 2025 per akun dan item terbesarnya.
4. Judul kolom (kertas kerja, RAB, matriks): ikon cari, urut, filter. Filter bekerja di level item, mengabaikan lipat/buka selama aktif, header akun/RO yang kosong disembunyikan; subtotal akun/RO tidak dihitung ulang oleh filter. Tombol "Hapus filter dan urutan kolom".
5. Matriks: kolom "Semula (POK ke-2)" dan "Menjadi (POK ke-3)". Nomor POK = konstanta mockup (pokSemula 2, pokMenjadi 3); di aplikasi harus dari nomor versi.
6. SPAN: unggah realisasi resmi (contoh data s.d. September 2026) mengunci kolom Realisasi, lalu realisasi mengurangi RAB bulan terdepan (urut FIFO dari bulan paling awal). Baris merah + ikon peringatan berisi keterangan bila: ada realisasi tapi item tanpa RAB; realisasi melebihi RAB; realisasi jatuh di bulan yang tidak dijadwalkan. Spanduk merah "segera perbarui RAB", filter "Tidak cocok SPAN". Pada contoh: 21 item ada realisasi, 11 tidak cocok (Rp 17.404.000). Tab RAB bulanan menampilkan "realisasi -X".
7. Tema SIGAP: sidebar navy #0F2A46 (aktif #173A5E), topbar breadcrumb + pencarian + chip TA 2026, latar #F3F5F8, kartu putih radius 12px, tab aktif biru muda, kartu KPI angka besar, tombol "Beranda", font Inter. Semua papan memakai kk.css baru; shell (sidebar/topbar) hanya di papan Main.

## Konsekuensi skema (bila disetujui)
- Pasangan ganti akun: kolom pindah_dari / pindah_ke per baris, jumlah tersimpan.
- Tabel realisasi SPAN per item per bulan (dengan tanggal unggah, potong data) + aturan cek ketidakcocokan.
- Arsip realisasi TA sebelumnya per akun dan item.
- Nomor versi POK per kolom Semula/Menjadi.

## Asumsi yang perlu dikonfirmasi
- "x" pada kelengkapan RAB = item dengan status selain "belum" (termasuk selesai).
- Aturan SPAN di atas sudah cukup, atau ada aturan tambahan dari Keuangan.
- Pertanyaan lama yang belum dijawab: perlakuan item berstatus selesai saat akunnya dikosongkan.
