# Tahap 8: Peta KRO Satker (papan 8) — DIKOMIT ke repo, MENUNGGU deploy dan uji (24 Okt 2026)

Lanjutan dari claude/status-bangun-kertas-kerja-revisi-24okt.md (tahap 4n masih menunggu deploy dan uji di dokumen itu).

## Isi
Halaman baru /sigap/revisi/peta?jadwal=<id>&dasar=aktif|disetujui&dari=<alamat asal>, tautan dari halaman Jadwal revisi dan dari kepala Kertas Kerja (tombol "Peta KRO Satker"):
- Penjelasan papan, pemilih jadwal (untuk kertas kerja Menjadi dan keputusan), pemilih "RAB yang dibaca" (RAB aktif atau hanya yang disetujui), faktor dan toleransi dari Master (hanya dibaca).
- Jumlah seluruh KRO: POK, RAB, Kebutuhan riil, POK − RAB, POK − kebutuhan riil; catatan cakupan (n KRO punya RAB) dan pagu seluruh Satker.
- Putusan tingkat Satker (hijau bila POK − RAB >= 0, merah bila < 0, abu bila belum ada RAB; peringatan "cadangan tipis" bila POK − kebutuhan < 0).
- Tiga kartu jalur: DJPb tingkat 3 (dalam Kegiatan sama), Eselon I tingkat 4 (antar-Kegiatan), DJA tingkat 5 (pagu tambahan).
- Tabel Kegiatan > KRO dengan status Kurang/Tipis/Cukup/Lebih/Belum ada RAB, POK dibandingkan, RAB, kebutuhan riil, selisih, keterangan.
- Tampilan PPK: daftar KRO yang RAB-nya melebihi POK, keputusan Terima semua / Terima sebagian (jumlah) / Tunda (+ catatan), disimpan lewat keu_kk_putuskan (hak "sahkan"; selain PPK hanya melihat), dan pembagian sumber bagian yang diterima: sisa KRO lain pada Kegiatan sama (DJPb), lalu Kegiatan lain pada Program sama (Eselon I), sisanya DJA. Sisa tiap KRO hanya dipakai sekali. Pratinjau pembagian ikut pilihan yang belum disimpan.

## Sumber angka (tanpa SQL baru)
Struktur dan pagu: keu_v_pok_node_tampil (program, kegiatan, kro, ro) pada POK berlaku; KRO yang muncul dua kali digabung. RAB: RAB tiap RO lewat pilihRab (keu_v_rab_ringkas) dan item keu_v_rab_item. POK pembanding per item: "Menjadi" kertas kerja jadwal terpilih (keu_v_kk_baris, lewat rab_item_id atau kunci POK) bila ada, bila tidak POK berlaku (keu_pok_detail.kunci_stabil). Hanya item yang sudah punya RAB dibandingkan; KRO tanpa RAB berstatus "Belum ada RAB" dan tidak ikut jumlah. Item RAB yang kuncinya tak ada di POK berlaku dilewati dan dihitung ("n item RAB belum terpadan").
Rumus: K = jumlah (selesai ? RAB : RAB/faktor); status = aturan kecukupan yang sama dengan panel Kecukupan (statusKecukupan). Kekurangan = max(0, RAB − POK) pada tingkat KRO (rumusan mockup).

## Selisih dari mockup (jujur)
- Mockup memakai RAB ILUSTRASI untuk KRO selain 2903.BMA dan tombol "Contoh dasar / Contoh RAB naik"; di produksi KRO tanpa RAB ditampilkan apa adanya (Belum ada RAB). Tombol contoh tidak dibuat.
- Mockup mengubah faktor dan toleransi langsung di papan; di produksi nilai itu se-kantor dan diedit di papan 14 (Master data) — di sini hanya dibaca.
- View keu_v_kk_buku_selisih dan keu_v_kk_kecukupan (per kelompok belanja, RAB disahkan) masih kosong karena keu_kk_baris.rab_item_id belum terisi; Peta tidak bergantung pada keduanya. Definisi kekurangan Peta (tingkat KRO) dapat berbeda dari jumlah kekurangan per kelompok di keu_v_kk_buku_selisih bila kelompok saling mengimbangi.
- Keputusan tersimpan per (jadwal, KRO); tombol "Menunggu" tidak ada karena keputusan tidak dapat dikosongkan di basis data (cukup pilih ulang).

## Berkas
Baru: lib/keu/peta.ts (+ __tests__/peta.test.ts, 22 tes), app/sigap/revisi/peta/page.tsx. Diubah: app/sigap/revisi/page.tsx (tautan), app/sigap/revisi/kertas/page.tsx (tautan). Tes sandbox 256 lulus, tsc bersih.

## Rencana uji produksi (setelah deploy)
Buka /sigap/revisi/peta: struktur 24 KRO, jumlah per Kegiatan, KRO ber-RAB (RAB uji RO 2906.BMA.005, RO 2900.BMA.005 milik pengguna lain) tampil berstatus; pilih "Hanya RAB yang disetujui" (semua KRO kembali Belum ada RAB). Keputusan PPK hanya diuji pada KRO fiktif (2906.BMA) bila ada kekurangan; kalau tidak ada KRO kurang, bagian itu belum teruji.
