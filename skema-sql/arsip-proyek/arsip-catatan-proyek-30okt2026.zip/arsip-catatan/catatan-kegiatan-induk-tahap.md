# Kegiatan induk + tahap proses bisnis SIGAP (9 Okt 2026)

Struktur navigasi 3 layer yang baru (mockup disetujui user, 5 papan: https://claude.ai/artifact/HfwKEo7VwkiPqL7Xs6u1CC):

- **Layer 1 (Beranda)**: ikon kegiatan INDUK (Pendataan Pascabencana, dst.) dengan cincin progres + lencana "!" bila ada yang mendesak. Kartu "Tugas Hari Ini" TETAP ada (kartu di dalam aplikasi, bukan push) dengan tombol langsung ke halaman isian aslinya.
- **Layer 2** `/sigap/kegiatan/<kode>`: garis waktu vertikal tahap proses bisnis (Perencanaan, Pelatihan, Pendataan, Evaluasi, + tambahan admin). Diatur admin per kegiatan.
- **Layer 3**: halaman kerja.
  - Tahap Pelatihan = `/sigap/pelatihan` (halaman Langkah yang sudah ada) + kartu "Transport Lokal pelatihan" (`app/sigap/pelatihan/translok.tsx`).
  - Tahap lain = `/sigap/kegiatan/<kode>/<tahap>`; modul "Wilayah tugas per tim" (PML + semua PPL, Sub SLS keroyokan, perkiraan KK & KK terdampak, baris padat) + Transport Lokal/administrasi.
- Transport Lokal yang dibuka dari tahap membawa `?dari=<halaman tahap>` supaya Back pulang ke tahap itu.
- Back: `/sigap/kegiatan/<kode>` -> `/`; `/sigap/kegiatan/<kode>/<tahap>` -> `/sigap/kegiatan/<kode>`; `/sigap/pelatihan` -> `/sigap/kegiatan/pascabencana` (lib/sigapNavigasi.ts).

## Database (sudah diterapkan, migrasi `sigap_induk_tahap_20261009`; salinan di supabase/migrations/20261009a_sigap_induk_tahap.sql)
- `sigap_induk` (kode, nama, pendek, ikon, kegiatan_ids bigint[], urutan, aktif) dan `sigap_tahap` (induk_kode, kode, urutan, nama, uraian, isi text[], buka_mode langsung|setelah_sebelumnya|tanggal, buka_tanggal, aktif, diubah_at, diubah_oleh). RLS aktif, diakses lewat service role.
- Seed: induk `pascabencana` (kegiatan_ids {1,3}); tahap perencanaan {konfirmasi}, pelatihan {pelatihan, translok:3}, pendataan {wilayah_tim, translok:1}, evaluasi {}. SEMUA buka_mode `langsung` (aman); gembok bisa diaktifkan lewat admin.
- Katalog modul: `konfirmasi`, `pelatihan`, `wilayah_tim`, `translok:<kegiatan_id>`.

## Berkas
- Logika murni + uji: `lib/sigapTahap.ts`, `lib/__tests__/sigapTahap.test.ts` (19 uji lulus).
- Server: `lib/portal/induk.ts`; API `/api/portal/induk`, `/api/portal/wilayah-tim`, `/api/portal/admin/tahap` (Admin Aplikasi, izin portal.kelola).
- UI: `app/portal/Beranda.tsx` (Layer 1), `app/sigap/kegiatan/[id]/Induk.tsx` (Layer 2), `.../[id]/[tahap]/page.tsx` + `WilayahTim.tsx` (Layer 3), `app/sigap/kegiatan/useInduk.ts`, admin `app/portal/admin/tahap/page.tsx` (tautan "Atur tahap kegiatan" di /portal/admin).

## Catatan
- Status per Sub SLS hanya "sudah ada laporan" (dari sigap_realisasi.lokasi); SIGAP belum punya data Selesai/Berjalan per Sub SLS.
- Tahap yang berisi modul yang tak berlaku bagi akun (mis. bukan peserta pelatihan) disembunyikan.
- Tahap tidak dihapus permanen: dinonaktifkan.
- BELUM diuji di HP / setelah deploy. Perlu dicek: Beranda (ikon induk menggantikan kartu lama), garis waktu, halaman Pendataan, Back, kartu Transport Lokal di Pelatihan, halaman admin.
