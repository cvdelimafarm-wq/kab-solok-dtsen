# Tombol unduh templat FASIH di tab "Belum diajukan" (24 Okt 2026)

Permintaan: tab Kelola > Pendataan > Permintaan daftar KK ke FASIH > Belum diajukan tidak punya tombol unduh templat (hanya tab Menunggu admin yang punya "Ekspor templat FASIH").

## Perilaku
- Panel di bawah daftar (muncul setelah memilih Sub SLS) punya tombol "Unduh templat FASIH (n Sub SLS)". Berkas Pengawas-Pencacah.xlsx (7 kolom, sheet Sheet0, format sama dengan ekspor Menunggu admin; fungsi `barisTemplatFasih` dipakai ulang).
- Tujuan mengikuti mode yang dipilih: "Ke PML plotting" (PML dan PPL plotting awal) atau "Ke PML/tim lain" (PML + PPL penerima). Email pengawas = PML tujuan, email pencacah = PPL penerima. Sub SLS yang dilewati (tanpa plotting/tujuan belum dipilih) tidak ikut; tombol mati bila 0.
- Hanya membuat berkas, TIDAK menugaskan (pesan mengingatkan). Akun yang hanya boleh melihat juga bisa mengunduh.
- Email: `bencana_petugas.email_fasih` diutamakan, lalu email mitra akun. Baris tanpa email diberi peringatan. Email ditambahkan di server pada `GET ?belum=1` (tim[].pml_email, ppl[].email), tanpa migrasi.

## Berkas (ditulis ke repo laptop, belum commit/push/deploy)
`app/sigap/kelola/pendataan/BelumDiajukan.tsx`, `lib/belumDiajukan.ts` (`emailPilihanTugas`, tipe email), `lib/portal/belumDiajukan.ts` (`denganEmailTim`), `lib/portal/permintaanDaftar.ts` (`emailPerAkun` diekspor), `lib/__tests__/belumDiajukan.test.ts` (+3 uji; 19 lulus di sandbox, tsc bersih untuk berkas lib). Berkas TSX/server belum di-type-check penuh di sandbox: jalankan `npx tsc --noEmit` dan `npm test` di laptop sebelum commit.
