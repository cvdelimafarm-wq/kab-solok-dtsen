# Status tahap 21-22: papan 13 (Administrasi) dan papan 15 (Kekurangan), 25 Okt 2026

## Papan 13 Administrasi (tab Administrasi per RO)
- Tata letak dua kolom mengikuti mockup (daftar item di kiri, panel dokumen di kanan, lebar lebih dari 1100 px); `PanelItem` diekspor.
- Hak per dokumen dibaca dari `keu_adm_boleh_unggah` dan `keu_adm_boleh_verif` (migrasi `20261025v`, sudah diterapkan sebagai `keu_adm_hak_v`, didaftarkan di `keu_jalankan`). Tombol hanya tampil bila hak ada; alasan tanpa aksi ditampilkan (`alasanTanpaAksi`).
- "Buat dari SIGAP" jujur menjadi "Tandai draf siap": SIGAP belum membuat dokumen.
- Logika murni di `lib/keu/adm.ts` (19 tes): saring item, kelompok komponen, ringkasan dokumen, pihak, pilih lembar.

## Papan 15 Kekurangan (tab Kekurangan RAB per RO)
Urutan kartu kini sama dengan mockup: KPI, 1. Daftar (kolom Dicatat berisi tanggal dan nama dari `keu_v_penugasan_ro`, header lengket, gulir), 2. Catat kekurangan baru (selalu tampil; tanpa hak muncul keterangan), 3. Kesempatan saat ada tambahan pagu, Riwayat keputusan, Aturan K1-K6 (K6 ditambah).
- Bagian 3: tautan ke halaman Revisi untuk PPK (pencatatan tambahan tetap di sana), dasar tambahan (jalur, nomor, tanggal) dari `keu_v_tambahan_pagu`, empat kotak meter (Tambahan pagu, Dipenuhi menurut pilihan, Sisa tambahan merah bila minus, Belum diputuskan), tabel Penuhi/Tunda/Tolak per catatan dengan saran sistem (`keu_kekurangan_saran`), tombol "Pakai saran sistem" dan "Terapkan keputusan" (aktif hanya bila semua diputuskan, tolak beralasan, total tidak melebihi tambahan). Non-ketua melihat tabel saja.
- Awal keputusan kosong (mengikuti mockup); sebelumnya terisi otomatis dari saran.
- Riwayat dibentuk dari kolom dicatat_*/diputus_* (`peristiwaKekurangan`); tidak ada tabel baru. Pencatatan tambahan dan pembukaan kesempatan tidak ikut dalam riwayat ini (ada di halaman Revisi).
- Helper baru di `lib/keu/kekurangan.ts`: pilihanDariSaran, ringkasPutus, argsTerapkan, peristiwaKekurangan; 11 tes baru (total 371 tes lib/keu lulus; tsc bersih; render uji lulus untuk tiga keadaan hak).
- Selisih terhadap mockup: kolom RO dan filter RO tidak ada di tab per RO (halaman seluruh satker belum dibuat); nama pencatat yang bukan anggota penugasan RO tampil "Pengguna lain".
- Belum diuji di produksi.

## Papan 11 (Jadwal) dan 12 (POK resmi, realisasi, skor): pemeriksaan 25 Okt 2026
- Papan 11: seluruh bagian mockup sudah ada di /sigap/revisi (POK sistem berlaku, pengingat tenggat Pasal 175, riwayat versi, daftar jadwal dengan usulan RO dan pernyataan sah, tambah jadwal, jadwal bawaan tanggal 10, siklus J1-J5, tambahan pagu). Tidak ada perubahan.
- Papan 12 bagian 1 (PDF POK resmi dan pencocokan): ada di /sigap/revisi/pok. Alurnya sengaja berbeda dari mockup: PDF dibaca di peramban, dicocokkan per RO/akun, lalu diterima atau ditolak (bukan sekadar pembanding). Bagian "Uji baca Excel atau PDF" pada mockup adalah penjelasan dan tidak dibuat sebagai layar.
- Papan 12 bagian 2 (realisasi mingguan): /sigap/realisasi sudah ada.
- Papan 12 bagian 3 (skor kualitas RAB per RO) BARU: `app/sigap/realisasi/Skor.tsx` dipasang di bawah halaman realisasi, helper `lib/keu/skor.ts` (+4 tes). Tabel skor semua RO (skor, penilaian, penarikan, volume, cakupan RAB, disiplin), bobot dalam persen dari `keu_master_skor`, tombol Rincian per RO: grafik batang dan tabel rencana penarikan (jadwal RAB sah, `keu_v_rab_jadwal_item`) lawan realisasi bulanan (`keu_v_realisasi_bulan`) sampai bulan data terakhir, serta cara hitung. Tanpa SQL baru.
- Perbaikan kecil: kategori skor dari view adalah "Perlu pembinaan" (bukan "Kurang"), sehingga chip di tab Ringkasan RO sebelumnya jatuh ke warna abu; kini merah.
- Selisih: mockup menampilkan rincian bulan Jan sampai Sep untuk satu RO sebagai tabel; produksi menambah grafik batang. Rumus skor tetap sementara.
- Total tes lib/keu: 375 lulus; tsc bersih.
