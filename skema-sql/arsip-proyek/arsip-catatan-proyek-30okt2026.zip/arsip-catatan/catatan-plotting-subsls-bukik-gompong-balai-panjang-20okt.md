# Catatan plotting Sub SLS: Bukik Gompong 03 dan Balai Panjang 03 (20 Okt 2026)

Pelengkap `claude/catatan-perubahan-20okt-2026.md` dan `claude/rancangan-kolam-wilayah-kerja.md`.

## 1. Jorong Bukik Gompong Sub 03 (idsubsls 1303080004000703)
- Gejala: tidak muncul di daftar Plotting/pengajuan FASIH milik Irawita.
- Penyebab: Sub SLS ini tidak punya baris alokasi tim (`bencana_alokasi_subsls`) dan tidak ada di kolam statis 16 Okt, jadi tidak tampil di daftar pengajuan siapa pun.
- Tindakan (atas permintaan Pak Iqbal, "plot langsung ke irawita"): menambah baris `bencana_alokasi_subsls` id 5177 (`ppl_id` null, `pml_id` 96, `terkunci` true, `mode_kerja` 'keroyok'). Tidak ada perubahan kode.
- Catatan: Pak Iqbal sempat melaporkan "belum ada" padahal tangkapan layar menunjukkan Sub SLS sudah tampil. Perlu dipastikan lagi di perangkat Irawita (muat ulang) bila masih dikeluhkan.

## 2. Jorong Balai Panjang Sub 03 (idsubsls 1303130005000303)
- Nagari Saniang Baka, Kec. X Koto Singkarak. Sudah dialokasikan ke PPL Jahar Nas (428) dan Nur Aisyah (438) di bawah PML Widya elvera (449), terkunci, mode keroyok.
- Temuan: tidak bisa diajukan ke FASIH karena daftar KK (`bencana_pendataan_kk`) berisi 0 baris. `buatPermintaan` dan `pilihKolam` (`lib/portal/permintaanDaftar.ts`, `lib/portal/kolamWilayah.ts`) menolak dengan pesan "Daftar KK untuk <label> belum diunggah admin." (409). Belum ada permintaan sama sekali.
- Data pendukung: identifikasi mencatat 1 KK terdampak (lahan tertimbun 1, kerusakan barang elektronik dan perabotan 1, aset usaha 1; diisi 12 Okt, diperbarui 18 Okt); wilkerstat 168 KK; koordinat tanpa geotag valid (23 tidak ditemukan, 59 kosong).
- Pembanding: Balai Panjang 01 (60 terdampak, 48 KK di daftar) dan 02 (20 terdampak, 11 KK di daftar) sudah punya daftar KK.
- Tindak lanjut: Pak Iqbal sedang memproses unggah daftar KK (templat `Templat_Unggah_Daftar_KK_Pendataan.xlsx`). Setelah masuk, PPL bisa mengajukan seperti biasa. Tidak ada data KK yang dikarang dan tidak ada perubahan database untuk Sub SLS ini oleh Claude.

## 3. Pola yang perlu diwaspadai
- Sub SLS terdampak yang belum dialokasikan dan tidak masuk kolam statis tidak muncul untuk siapa pun (kasus Bukik Gompong 03). Mirip kemungkinan: Aie Dingin Jorong Data 02 dan Jorong Koto 01 (tim Ilham), belum diperiksa. Usulan: kolam dinamis yang otomatis memuat Sub SLS terdampak tanpa alokasi.
- Sub SLS teralokasi tetapi daftar KK kosong akan tampil di Plotting namun gagal saat diajukan. Usulan: tandai di daftar ("Daftar KK belum diunggah") dan beri pemeriksaan admin untuk Sub SLS teralokasi tanpa daftar KK.
