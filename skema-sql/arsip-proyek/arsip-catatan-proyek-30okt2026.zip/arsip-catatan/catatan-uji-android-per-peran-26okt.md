# Catatan: uji SIGAP lebar HP Android per peran (26 Okt 2026, ±17.00 WIB)

Cara: Claude in Chrome, akun M. Iqbal Hadi (admin + korwil), SIGAP ditampilkan dalam bingkai 412 px. PML (Budi Pernandes) dan PPL (Minda Susanti) lewat "Lihat sebagai" (simulasi, tidak ada data terkirim). Baca-saja. Batas: Chrome desktop, bukan HP asli (scrollbar bergaris panah pada deretan chip adalah artefak desktop, bukan galat SIGAP); kamera, unggah, dan pemeriksaan foto PML tidak diuji.

## Data tidak cocok (perlu ditelusuri)
1. Hari kerja Minda: Monitoring Korwil > Administrasi menampilkan "–" untuk 10-16 Okt dan "✓" 17-25 Okt (9/9); halaman PPL sendiri (Hari Kerja) menampilkan 13-25 Okt lengkap (13 hari, "Hari kerja 31"), 11-12 Okt merah terlewat.
2. PML Budi: Lembar Identifikasi SLS "25 Sub SLS" (halaman tahap), sedangkan Monitoring Korwil dan Lembar Pendataan memberi 9 Sub SLS pendataan. Mungkin beda cakupan, tetapi tidak dijelaskan di layar.
3. Monitoring Korwil: catatan "1 Sub SLS dibagi" (Budi) + "1" (Megawati) + "2" (Usyenti) = 4 penanda, sedangkan ringkasan menyebut 32 vs 31 unik (hanya 1 selisih).
4. Nama: "MINDA SUSANTI" (huruf besar semua) di Beranda dan Lembar, "Minda Susanti" di Monitoring, "Halo, Minda" di translok.

## Bahasa dan label
- Kartu ringkasan Monitoring: "58,6%" berlabel "31 Sub SLS". Seharusnya "Capaian".
- Istilah campur: didata / sudah punya hasil / realisasi; "Tdk" vs "Tidak"; "plotting", "assign", "assignment", "keroyokan", "kolam"; "masuk Kwitansi" (translok terlewat) tidak jelas.
- Lembar Pendataan: jadwal batas 7/9/11 Sub SLS pada 15-17 Okt sudah lewat, tetapi masih tertulis, dua kali.
- "Plotting tim hari ini" tetapi isinya "bukan per hari".
- Peta: legenda "Tdk ditemukan" bertabrakan dengan teks "Warna = PPL". "9/9" di pemilih Sub SLS tanpa penjelasan.
- Beranda tidak menyebut peran (PML/PPL); hanya "Mitra statistik".
- "Foto kurang 1 · +1 lagi" dan baris "Foto kurang 1" mengulang teks sebelahnya.

## Kartu yang perlu ditutup/dibuka
- Lembar Pendataan PML/PPL (2.530 px): panel petunjuk terbuka, daftar "Sudah di-assign ke FASIH" mengulang kartu di atasnya, teks aturan bawah mengulang teks atas. PPL melihat panel PML ("hanya PML yang bisa mengisi").
- Monitoring Korwil Lapangan (1.697 px): tiga kartu tim terbuka penuh dengan rekap nagari.
- Halaman tahap: kotak "Kerjakan satu per satu: 1... 2..." mengulang daftar tepat di bawahnya; "Rekap identifikasi" tidak bernomor di antara tugas bernomor.
- Foto translok: "Lihat panduan" dua kali; kartu foto potret dan lanskap berdampingan menyisakan ruang kosong.

## Ukuran sentuh
Chip Kelompok 30 px, "Rekap nagari/Daftar Sub SLS" 25 px, tombol pilih Sub SLS 24 px, tab peta 34 px, "Keluar" 25-33 px.

## Bersih
Tidak ada luapan ke samping (scrollWidth ≤ lebar), tombol Kembali konsisten, angka KK tim sama di semua layar (412/683 Budi; 2.592/1.520 total), 99/103 hari lengkap cocok dengan jumlah per baris.
