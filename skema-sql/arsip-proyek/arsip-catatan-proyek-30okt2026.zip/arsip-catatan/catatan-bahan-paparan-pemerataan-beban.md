# Bahan paparan: kenapa sebagian petugas mendata lebih jauh (9 Okt 2026)

PPT 35 slide (Bahan_Paparan_Pemerataan_Beban_PSP.pptx), BUKAN untuk diaplikasikan. Membandingkan simulasi "petugas terdekat" dengan plotting existing (v3, sudah diterapkan 9 Okt) dan cadangan sebelum 9 Okt. Data dari DB (228 Sub SLS sampel = 16.327 poin; 70 PPL).

## Simulasi "terdekat"
Tiap Sub SLS utuh ke PPL terdekat (jarak jalan = 1,35 x garis lurus), tanpa ambang kapasitas, tanpa memecah Sub SLS.
- ±25 dari 70 PPL tanpa wilayah (26 pada hitung ulang); 22 PPL > ambang 160; 10 PPL > 480; 4 PPL > 1.000; terberat 2.018 poin (12,6x ambang).
- Median 52, Gini 0,76; 7 PPL teratas pikul 59% beban; jarak rata-rata 2,4 km; 91% poin < 5 km.
## Existing (v3)
- 70 PPL semua kebagian, beban 19-160 (median 148), Gini 0,14; jarak rata-rata 4,4 km; 58% poin < 5 km, 42% 5-10 km, tak ada >= 10 km. 154 Sub SLS terplot (53% pekerjaan); 74 Sub SLS belum + 14 porsi sisa = 88 (47% bantuan keroyokan). Poin jarak = 5,5% dari beban.
- Sub SLS belum diplot disengaja: kapasitas 70x160=11.200 < pendataan 16.327; 52 dekat <5 km, 20 5-10 km, 2 tanpa koordinat; sisa kapasitas 2.021 poin terpecah di 22 PPL.
## Pembayaran (surat B-454/04300/PR.440/2026, 5 Okt 2026, Sekretaris Utama BPS)
Petugas pendataan TIDAK diberi honor; diberi translok sesuai SBM terakhir; laporan tiap kunjungan + dokumentasi + stempel/diketahui Ketua SLS; pelatihan fullboard -> fullday.
**Skema (arahan user 9 Okt): beban 160 poin = 15 hari; 1 hari translok = Rp170.000** -> translok PPL = beban akhir (pendataan + jarak) / (160/15) x Rp170.000 = Rp15.937,5 per poin; maksimum per PPL (ambang) = Rp2,55 jt. (Versi awal "hari kunjungan x tarif" sudah ditinggalkan.)
- Existing: 9.179 poin = 861 hari = Rp146,3 jt; sisa pendataan 7.654 poin = Rp122,0 jt (belum termasuk jarak); seluruh pendataan 16.327 poin = Rp260,2 jt.
- Perbandingan 3 versi (translok per PPL, Rp juta): Cadangan 3-5 Okt (206 Sub SLS, 63 PPL): 0-6,93, median 3,31, Gini 0,27, 45 dari 63 PPL > 160 poin, jarak maks 31,8 km (7 PPL > 10 km), total 202,6. Existing: 0,31-2,55, median 2,36, Gini 0,14, 0 PPL > 160, jarak maks 9,8 km, 7 teratas 12%, total 146,3. Terdekat: 0-32,17, median 0,77, Gini 0,77, 7 teratas 61%, 21 dari 44 PPL > 160, total 266,4.
## Perbandingan antar tim (rata-rata beban akhir per PPL)
Existing 76-157 (2,1x; CV 19%; rata 131); cadangan 79-308 (3,9x; CV 23%); skema "semua PPL ke semua jorong tim, beban dibagi rata" 105-259 (2,5x; CV 24%): jarak menaikkan tim dengan anggota tersebar (Ilham 259, Ayu Sepriani 250).
## Akar masalah
Poin pekerjaan per PPL berdomisili: X Koto Singkarak 411 (12 PPL), Junjung Sirih 379 (9), Lembah Gumanti 308 (3), Kubung 256 (21), Gunung Talang 58 (20 PPL, 1.163 poin). Danau Kembar & Bukit Sundi tanpa PPL domisili.
## Wilayah > 4 km (existing)
80 dari 169 porsi (49 PPL, 16 tim); 51% KK terdampak (2.440 dari 4.797): >4-7 km 38 porsi/983 KK terdampak, >7-10 km 42 porsi/1.457; Selayo (Kubung) 1.199 KK terdampak. Slide rincian satu per tim PML.
## Catatan
Koordinat 5 Sub SLS dan 2 PPL (Febri Handayani, Rini Nofsiska Sari) perkiraan (pusat nagari/kecamatan). Rujukan draf 8 Okt (penuh, hanya di Excel): beban 193-333, 31% poin > 10 km.
