# Pop-up Nomor HP Pengisian Pulsa — Pelatihan (8 Okt 2026)

Permintaan user: pop-up pengisian/update nomor HP petugas untuk pengisian pulsa, ditonjolkan; tampilkan nomor HP asli, petugas konfirmasi atau boleh ganti nomor lain HANYA untuk pulsa.

## Keputusan user
- Untuk peserta pelatihan 8 Okt (bukan semua petugas SIGAP). Wajib konfirmasi (pop-up tidak bisa ditutup sebelum konfirmasi/simpan). Highlight = kartu/modal oranye. Panitia melihat kolom nomor pulsa di Monitoring + ekspor CSV.

## Cara kerja
- Nomor HP ASLI dicari (sigap_akun tidak punya kolom no_hp): bencana_petugas.no_hp -> bencana_mitra.no_telp -> petugas_penyisiran_akun.no_hp (cocok nama persis, hanya bila 1 baris). Dinormalkan ke 08xxxxxxxxxx (terima +62/62/spasi/strip).
- Cakupan data (8 Okt): 81/81 mitra punya nomor; organik 13 orang, ±7 punya nomor dari data penyisiran, ±6 belum (pop-up langsung meminta isi nomor).
- Pop-up: tampil nomor asli besar -> tombol "Ya, nomor ini benar" atau "Pakai nomor lain untuk pulsa" (input; validasi 10–14 digit). Nomor lain HANYA disimpan di sigap_pelatihan_pulsa; nomor HP asli di tabel sumber tidak diubah. Setelah konfirmasi tampil kartu oranye di atas halaman peserta (nomor + "terkonfirmasi" + tombol Ubah).
- Tabel sigap_pelatihan_pulsa (PK kegiatan_id+akun_id): no_hp_asli, no_pulsa, diubah, dikonfirmasi_at; RLS on (migrasi 20261008f_sigap_pelatihan_pulsa.sql, sudah diterapkan).
- Peserta manual (sumber 'administrasi') tidak memunculkan pop-up (bukan peserta tes/kuis).
- Admin: tab Administrasi > kartu angka "Nomor pulsa terkonfirmasi x/y", kolom "No. Pulsa" (chip "lain" bila diganti, "belum" bila belum), tombol "CSV nomor pulsa" (GET administrasi?bagian=pulsa_csv&kelas=N; kolom No HP Pulsa, No HP Tercatat, Status, waktu konfirmasi; nomor ditulis ="08xx" agar angka 0 tidak hilang di Excel).

## Berkas
lib/sigapPulsa.ts (normalisasiHp, tampilHp, nomorAsli, statusPulsa, simpanPulsa, pulsaBanyak) · app/api/sigap/pelatihan/pulsa/route.ts (GET, POST aksi konfirmasi|simpan) · app/sigap/pelatihan/pulsa.tsx (PulsaPeserta, dipasang di Kerangka komponen.tsx) · lib/sigapAdministrasi.ts (pulsa di BarisPeserta, csvPulsaKelas) · administrasi/route.ts · kelola/administrasi.tsx.

## Catatan
- Pop-up ada di Kerangka (halaman Undangan/Langkah/Instrumen); halaman tes/kuis tidak memuatnya.
- Belum diuji tampilan di browser dengan data nyata; fungsi normalisasi nomor diuji 11 kasus.
