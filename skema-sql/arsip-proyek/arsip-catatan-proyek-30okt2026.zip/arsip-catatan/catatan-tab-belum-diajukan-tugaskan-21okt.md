# Catatan: tab "Belum diajukan" + penugasan admin (21 Okt 2026)

Permintaan: pada kartu Kelola > Pendataan > "Permintaan daftar KK ke FASIH" tambahkan tab Sub SLS belum diajukan beserta info plotting awal, lalu admin bisa menugaskan (assign) ke PML plotting atau ke PML/tim lain.

## Perilaku
- Tab baru "Belum diajukan" (paling kiri; 2 kolom di HP). Isi: Sub SLS aktif tanpa permintaan menunggu/sudah keluar yang sudah diplot (ada baris `bencana_alokasi_subsls` ber-PML) atau masih di kolam wilayah. Tiap baris: jorong/sub, nagari, kecamatan, jumlah KK (+ yang sudah didata), "Plotting awal" (PML -> PPL, mode, terkunci), riwayat pengajuan terakhir (mis. dibatalkan, masih perlu dihapus di FASIH).
- Saringan: Semua / Sudah diplot / Di kolam, kecamatan, kata kunci (jorong, nagari, PML, PPL).
- Penugasan (butuh izin kelola `bencana.admin`): mode "Ke PML plotting" (PPL ikut plotting; bila PPL-nya tidak ada di tim, PPL pertama tim; Sub SLS tanpa plotting dilewati) atau "Ke PML/tim lain" (pilih PML + PPL penerima). Ada langkah konfirmasi dan peringatan berapa Sub SLS yang DIPINDAH dari PML plotting lain.
- Hasil = permintaan "menunggu" bertanda `dari_admin` (chip "Ditugaskan admin" di layar admin dan kartu plotting PML). Alur lanjut sama: ekspor templat FASIH -> assign di FASIH -> tandai sudah keluar.
- TIDAK memakai kuota pengajuan PML (7/9/11): `bencana_pendataan_minta_total` dan `PlottingTim.tsx` mengecualikan `dari_kolam` dan `dari_admin`.
- Notifikasi: PML tujuan, PPL penerima, dan PML asal (bila Sub SLS dipindah ke tim lain).
- Bila PML tujuan beda dari plotting awal: alokasi PML lain dipindah (ditolak bila sudah ada KK yang didata); baris lama disimpan di audit `pendataan_admin_tugaskan` (kolom `diganti`).

## Database (SUDAH diterapkan di Supabase nlwkpakyfprugqwklxiu)
- Kolom `bencana_pendataan_permintaan.dari_admin boolean default false`.
- Fungsi (hanya service_role; anon/authenticated dicabut): `bencana_belum_diajukan()`, `bencana_tim_untuk_tugas()`, `bencana_admin_tugaskan(p_akun, p_tanggal, p_pilihan jsonb)`. Penolakan: nonaktif, tidak_ada, tanpa_kk, ppl_bukan_tim, sudah_didata, sudah_diminta, bukan_peserta, kosong.
- Berkas repo: `supabase/migrations/20261021a_belum_diajukan_tugaskan.sql` (sama dengan DB, aman dijalankan ulang).
- Uji di DB (transaksi dibatalkan): tugaskan ke PML plotting OK; ulang -> sudah_diminta; ke PML lain -> alokasi pindah dan `diganti` terisi. Saat uji: 104 Sub SLS belum diajukan (30 diplot, 74 di kolam), 18 tim.

## Kode
- Baru: `lib/belumDiajukan.ts` (+ `lib/__tests__/belumDiajukan.test.ts`, 16 uji), `lib/portal/belumDiajukan.ts`, `app/sigap/kelola/pendataan/BelumDiajukan.tsx`.
- Diubah: `lib/permintaanDaftar.ts` (tipe `dari_admin`), `lib/portal/permintaanDaftar.ts` (ekspor `petaWilayah`, `akunPerPetugas`; kolom `dari_admin`), `route.ts` (GET `?belum=1`, POST aksi `tugaskan`), `PermintaanDaftar.tsx` (tab + chip), `PlottingTim.tsx` (kuota + chip).

## Catatan jaga-jaga
- Mengisi `execute_sql` Supabase MCP dengan kata DELETE secara harfiah membuat panggilan menggantung; fungsi tugaskan dibuat lewat blok DO + `replace(...,'HAPUS','del'||'ete')`.
- Pasca-deploy: cek `npx tsc --noEmit` dan `npm test`, lalu coba tab di produksi (tugaskan 1 Sub SLS uji ke PML plotting, lihat muncul di Menunggu admin, tolak bila hanya uji).
