# Lembar Identifikasi SLS (PML) — catatan rancangan & pembagian awal (10 Okt 2026)

## Tujuan
Tahap Pendataan Pascabencana: tiap PML mengisi hasil identifikasi per Sub SLS di nagari terdampak. Hasilnya kelak menjadi dasar plotting wilayah tugas PPL (pembagian identifikasi sengaja TERPISAH dari plotting PPL).

## Aturan (keputusan pengguna)
- Cakupan: 33 nagari terdampak menurut hasil identifikasi nagari (gate) = 202 SLS / 621 Sub SLS. Nagari tidak terdampak (7) dan yang belum dicek (34) tidak ikut.
- Pembagian per SLS utuh (semua Sub SLS di bawahnya) ke 1 PML pelaksana terdekat + 1 PML pendamping. Tanggung jawab tetap berdua; hasil dipakai bersama, keduanya bisa melihat/mengisi, progres tercatat untuk keduanya.
- Seluruh 20 PML ikut (termasuk Adriyanto dan Rifa Amelia yang belum punya PPL).
- Isian per Sub SLS: total KK terdampak (diisi sendiri, BUKAN penjumlahan kolom), rusak berat/sedang/ringan, lahan pertanian tertimbun, kekeringan, lainnya (+keterangan), aset usaha, lahan ternak, korban jiwa/luka, catatan. Tombol "Tidak terdampak" (angka dikunci nol, diberi warna biru). Total di atas KK tinggal hanya peringatan lunak.
- Ikon peta di samping nama nagari: peta WA (desa) dan peta SLS dari bucket Storage `peta-wilayah`.
  - `sls/<idsubsls 16 digit> n dari m.jpg` (nama berkas apa adanya, mis. `1303040001000100 1 dari 2.jpg`); kode SLS 14 digit juga dikenali.
  - `wa/<kode desa 10 digit>.jpg|png|pdf` (boleh juga dengan akhiran ` n dari m`).

## Data
- `bencana_identifikasi_alokasi` (idsls, pml_pelaksana_id, pml_pendamping_id, jarak_km) — pembagian.
- `bencana_identifikasi_subsls` (kunci idsubsls; pml_id = penyimpan terakhir) — hasil.
- Migrasi: 20261010b (tabel hasil), c (modul tahap Pendataan), d (alokasi + kunci hasil), e (isi pembagian awal).
- Modul `identifikasi` ada di tahap Pendataan (sigap_tahap.isi) dan hanya tampil bagi PML. Halaman: /sigap/identifikasi (PML), /sigap/kelola/identifikasi (monitoring, izin bencana.admin).

## Pembagian awal (dihitung ILP, jarak garis lurus ke koordinat PML)
Batas beban pelaksana 27–35 Sub SLS dan 3.900–5.300 KK; pendamping 26–37 Sub SLS. Rata-rata jarak terbobot pelaksana 13,4 km (tanpa batas beban 9,3 km).
Koordinat cadangan: Yeni siswanti, Hariston, Ardial Jaraf = rata-rata PML Kubung; Ilham = titik Irawita; Adriyanto belum punya lokasi (jarak netral, jarak_km dikosongkan).

| PML | SLS pelaksana | Sub SLS | KK | Jarak rata2 (km) | Sub SLS didampingi |
|---|---|---|---|---|---|
| Adriyanto | 14 | 27 | 3.923 | tanpa lokasi | 26 |
| Irawita | 7 | 35 | 5.280 | 14,9 | 37 |
| Budi Pernandes | 9 | 27 | 3.901 | 7,2 | 26 |
| Megawati | 11 | 27 | 3.927 | 7,8 | 26 |
| usyenti | 12 | 27 | 3.942 | 3,5 | 26 |
| Ferianto | 8 | 35 | 5.248 | 5,6 | 37 |
| Lucky Melan Sari | 7 | 35 | 5.215 | 5,8 | 37 |
| Mega Nana Yulianti | 12 | 35 | 5.200 | 12,2 | 37 |
| Saputra Ebel Feri | 9 | 30 | 4.489 | 18,8 | 28 |
| Widya Verawati | 9 | 35 | 5.211 | 22,6 | 37 |
| Yeni siswanti | 11 | 35 | 4.934 | 15,7 | 37 |
| Yurneti | 4 | 31 | 5.014 | 3,4 | 26 |
| Ayu Sepriani | 10 | 29 | 4.105 | 10,6 | 26 |
| Dessy Meiyarni | 4 | 27 | 4.205 | 10,3 | 26 |
| Lia angraini | 19 | 27 | 3.973 | 8,1 | 26 |
| Rifa Amelia | 15 | 28 | 3.988 | 19,0 | 26 |
| Widya elvera | 8 | 27 | 3.904 | 8,2 | 26 |
| Ilham | 17 | 35 | 5.285 | 11,8 | 37 |
| Hariston | 7 | 34 | 4.997 | 19,2 | 37 |
| Ardial Jaraf | 9 | 35 | 4.924 | 12,5 | 37 |

Catatan: sebagian besar SLS terdampak di selatan (Lolo, Sungai Nanam, Aie Dingin, dst.) jauh dari semua PML (30–70 km), jadi jarak hanya membedakan siapa yang relatif lebih dekat.

## Belum dikerjakan
- Lembar pemeriksaan/pengawasan PML (menunggu uraian pengguna).
- Hasil identifikasi sebagai dasar plotting PPL.
- Pengunggahan berkas peta ke bucket `peta-wilayah` (oleh pengguna).
- Jarak rute nyata (bencana_jarak_rute masih kosong); pembagian memakai garis lurus.
