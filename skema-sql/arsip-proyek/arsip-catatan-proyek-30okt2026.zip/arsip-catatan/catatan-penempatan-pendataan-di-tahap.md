# Penempatan Lembar Pendataan KK di tahap Pendataan (11 Okt 2026)
## Penempatan di aplikasi (11 Okt 2026, siang)
Arahan pengguna: lembar pendataan digabung ke kegiatan Pendataan Pascabencana 2026, bukan menu terpisah.
- Modul baru `pendataan` ("Lembar Pendataan KK") di tahap **Pendataan** (isi: wilayah_tim, identifikasi, pendataan, translok:1). Muncul bagi PML & PPL yang timnya sudah punya daftar KK; status perlu (0 didata) / berjalan / selesai; tautan `/sigap/pendataan?dari=<tahap>`; ikut nomor langkah & kartu Tugas aktif (adalahTugas) dan prefetch (`/api/portal/pendataan`).
- Kartu lepas "Lembar Pendataan" di Beranda diserap kegiatan induk (menyerap `pendataan`). Menu sidebar desktop untuk petugas dibatalkan.
- Unggah daftar KK sengaja HANYA dari laptop: menu "Unggah daftar KK" di sidebar desktop grup Administrasi (izin bencana.admin kelola) + palet Ctrl K; tidak ada kartu di Beranda HP; halaman unggah memberi catatan di layar kecil.
- Migrasi `20261011c_tahap_modul_pendataan.sql` (diterapkan; isi tahap kini wilayah_tim, identifikasi, pendataan, translok:1). Kode: lib/sigapTahap.ts (InfoPendataan, susunModul), lib/portal/induk.ts, lib/portal/pendataan.ts (`ringkasModulPendataan`), lib/sigapPrioritas.ts, app/portal/siapkan.ts. tsc bersih; 22 uji sigapTahap lulus (3 baru).
