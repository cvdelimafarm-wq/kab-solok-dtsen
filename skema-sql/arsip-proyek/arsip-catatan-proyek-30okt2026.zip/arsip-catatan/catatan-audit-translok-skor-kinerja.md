# Audit translok-154 dan usulan skor kinerja harian (14 Okt 2026)

Dokumen lengkap: Claude Docs "Audit Translok-154 dan Skor Kinerja Harian" (https://claude.ai/code/artifact/a1083424-f3a4-4482-b81e-dca1639638eb).

## Temuan prioritas Tinggi (dari kode)
1. Langkah 2 "Pilih hari kerja" dan 5 "Unduh SPJ" di Layer 2 (lib/portal/kegiatan.ts, hrefKerja sama) membuka tab Hari Ini; app/sigap/translok/[token]/page.tsx hanya membaca ?p=, tidak membaca ?tab=.
2. Tanpa sesi, /sigap/kegiatan/translok-154 dialihkan ke "/" tanpa alamat kembali (terlihat di Chrome).
3. Layer 3: galat muat apa pun -> tombol "Masuk kembali" yang menghapus sesi (jaringan lemah = keluar akun).
4. Hari lengkap beda: API translok memakai laporanDianggap, adapter Layer 2 (susunTranslok/kegiatanTranslok) hanya sigap_realisasi.
5. Layer 2 Translok: bila kegiatan[0] kosong -> kerangka abu tanpa henti.
6. Jumlah laporan: HP 3 digit (999) vs server maks 500; 0 boleh; beda dari hasil pendataan tanpa alasan.

## Cek langsung Chrome (14 Okt 20.25 WIB, "Masuk sebagai" simulasi, 1 PPL + 1 PML tim yang sama)
- Seorang PPL berstatus Lengkap 14 Okt dengan laporan 10 KK di satu jorong, padahal Lembar Pendataan mencatat 0 KK atas namanya dan jorong itu 0/39 didata -> bukti perlunya skor dari log pendataan.
- Tab Hari Kerja: kelompok "dasar Kwitansi" 31 hari Rp5.270.000 (termasuk 3 hari terlewat); Arsip: 28 hari Rp4.760.000 (termasuk 27 hari belum dikerjakan).
- Angka KK per Sub SLS berbeda antar layar (perkiraan vs daftar FASIH), mis. 66 vs 39, 159 vs 84.
- PML: Beranda "13 dari 25 Sub SLS" vs kartu tim PPL "9 dari 9 selesai". Halaman tahap menyuruh 3 tugas "satu per satu" padahal paralel.
- Surat Tugas tujuan tidak mencakup seluruh kecamatan wilayah tim.
- Lembar Pendataan bagi PPL dibuka dengan kartu Plotting (khusus PML) terbuka penuh.
- Semua halaman berupa kolom 576 px di layar laptop.

## Navigasi (keluhan user: sering tersesat, tidak jelas Beranda)
- Tombol kembali bergantung ?dari=; Lembar Pendataan dibuka langsung -> kembali ke Beranda (lompat 2 layer). keAtas (app/portal/navigasi.ts) memakai router.replace bila jejak bukan induk.
- Tidak ada tombol Beranda tetap; Beranda dan Masuk sama-sama "/"; Transport Lokal punya navigasi bawah sendiri; tombol Keluar dekat logo.
- Alamat /sigap/translok/<token> memuat kunci akun yang diterima API (akunDariToken) -> risiko jika tautan diteruskan.
- Usulan: alamat bertingkat /kegiatan/<induk>/<tahap>/<halaman>, kembali = naik satu segmen, header tetap (ikon rumah + jejak), satu navigasi bawah Beranda·Tugas·Pengingat·Akun, Keluar di menu Akun.

## Pengingat kekurangan (permintaan user)
Satu "daftar kekurangan" per akun di server dipakai modal, push, lonceng, Beranda. Jenis: pelatihan, translok hari ini, hari terlewat (izin susulan), laporan beda dari pendataan, identifikasi belum disimpan, poin di bawah target, ringkasan tim untuk PML. Modal maks 3 item, Nanti = tunda 2 jam; push maks 3/hari pada jam tetap; tiap item satu tombol ke bagian yang harus diisi.

## Usulan rumus (belum diputuskan user)
- P = T + N/2 + min(J/5, J_maks); target 10 poin/hari; T = KK terdampak, N = KK tidak terdampak, J = km rute (rumah -> titik GPS penandaan urut waktu -> rumah, garis lurus x 1,3, akurasi <= 100 m).
- KK dari log Lembar Pendataan (hasil terakhir berlaku), sekali per KK; jarak hanya dihitung bila >= 1 KK didata; target turun bila sisa KK wilayah < 10 poin; tanpa carry-over.
- Upah Rp170.000/hari bila capaian 100% dan hari lengkap (laporan + foto); usul toleransi 80-99% dengan persetujuan PML; tanpa bayar sebagian.
- Keputusan terbuka: poin "tidak ditemukan", batas poin jarak (usul 4 = 20 km), toleransi, titik awal rute, skor untuk PML.

## Tempat tampil (usulan)
Lembar Pendataan header (pil poin + notifikasi "+1 poin"), Translok tab Hari Ini (kartu capaian), Layer 2 langkah 3, Beranda kartu tugas, tab Hari Kerja (poin per tanggal), Monitoring PML, backoffice (tabel petugas x tanggal + persetujuan), Arsip/Kwitansi.
