# Catatan: Kamera SIGAP bisa dipakai tanpa sinyal, paket token (23 Okt 2026)

Cakupan: Kamera SIGAP tetap memotret dan menyimpan foto di daerah tanpa internet, lalu mengirim otomatis saat sinyal kembali. Aturan penomoran, SPJ, dan tampilan panel "Nomor foto" tidak diubah. Tidak ada migrasi SQL (token paket memakai kolom `sigap_foto.token_nonce` yang sudah ada).

## Skema yang disetujui pemilik ("SETUJU DENGAN SKEMA")
1. Paket token pagi: saat masih ada sinyal HP mengambil 30 token sekali pakai, semuanya bercap waktu server. Waktu foto tanpa sinyal = waktu server saat paket terbit + lama berjalan menurut jam HP sejak paket diterima. Hasilnya SELALU kuning (`waktu_offline`), tidak pernah hijau.
2. Label jujur: "Dipotret 13.20 tanpa sinyal, terkirim 17.05 WIB" (tanggal kirim ikut disebut bila beda hari). Aturan urutan jam memakai waktu dipotret, bukan waktu kirim.
3. Batas hari: foto bertoken paket yang dipotret tepat waktu tetap diterima sampai 2 hari sesudah tanggalnya (`TOLERANSI_KIRIM_HARI`), melewati 23.59 WIB. Hanya untuk foto bertoken paket yang lolos pemeriksaan waktu.
4. Halaman kamera disimpan di HP supaya bisa dibuka dari awal tanpa sinyal.

## Cara kerja
- Server: `buatPaketToken` (lib/sigapFotoServer.ts); nonce token paket berawalan `P~` (base64url tidak pernah memuat "~", awalan ikut ditandatangani sehingga tidak bisa ditambah atau dibuang). Rute baru `GET /api/sigap/foto/paket` -> `{ t, tokens[30], berlaku_ms }`, `Cache-Control: no-store`, tanpa tulis database.
- `waktuResmi` (lib/sigapFoto.ts) cabang `paket`: selang diukur dengan jam dinding HP (jam monotonik hilang bila halaman dimuat ulang atau HP restart), berlaku `UMUR_PAKET_MS` = 48 jam; jam monotonik, bila ada, hanya dipakai mendeteksi jam HP berubah (`jam_hp_berubah_atau_tidur`). Waktu hasil hitung yang lebih akhir dari waktu terima server +5 dtk = `waktu_tidak_wajar` (merah). Selang negatif (jam HP dimundurkan) atau > 48 jam = diperlakukan seperti tanpa token (`waktu_belum_terverifikasi`, waktu = waktu terima).
- POST /api/sigap/foto: `paket: tok.paket` ke `waktuResmi`; bila `w.offline` maka `cekAksesIsian(..., { toleransiOfflineHari: 2 })`. `cekAksesIsian` (lib/sigap.ts) hanya melonggarkan alasan "terlewat"; arsip, SPJ terkunci, bukan hari kerja, dan tanggal masa depan tetap ditolak.
- HP: `lib/sigapPaketOffline.ts` (logika murni) + `app/sigap/foto/paketOffline.ts` (localStorage `sigap-foto-paket:<akun>`). Paket diminta bila tidak ada, sisa < 8 token, atau lebih dari 6 jam; dicoba saat kamera dibuka, saat token online berhasil dimuat, saat sinyal kembali, dan saat kartu kamera dibuka di halaman kegiatan.
- KameraSigap: token online dipakai bila umurnya 0..30 menit lalu LANGSUNG dilepas; selain itu satu token paket. Perbaikan bug lama: sebelumnya token online tidak dilepas sesudah dipakai, sehingga foto kedua yang dipotret tanpa sinyal mengirim token yang sama dan ditolak server (`token_terpakai`, penolakan permanen di antrean).
- Daftar kegiatan bermode kamera (`/api/sigap/foto/mode`) disimpan di localStorage (`sigap-foto-mode:<akun>`) dan dipakai hanya bila permintaan gagal karena tidak ada sambungan; halaman menampilkan keterangan "Tidak ada sinyal. Kamera tetap bisa dipakai".
- Service worker v5 (`public/sw.js`), PENGECUALIAN KEDUA terhadap prinsip 8 Okt "jangan simpan halaman": cache `sigap-app-v1` berisi (a) `/_next/static/*` (cache-first, hash di nama berkas), (b) satu halaman saja `/sigap/foto` (jaringan dulu; gagal, 5xx, atau lebih dari 4 dtk -> salinan; lalu offline.html). Halaman lain dan API tidak disimpan. Halaman kamera juga meminta SW menyimpan halaman + semua chunk yang disebut di dalamnya (pesan `simpan-halaman-kamera`), karena petugas biasanya tiba lewat perpindahan di dalam aplikasi, bukan navigasi penuh. Batas 400 berkas, halaman kamera tidak ikut dibuang.
- SW sebelumnya hanya terdaftar bila petugas mengaktifkan notifikasi. `siapkanHalamanKamera()` kini mendaftarkannya (scope "/") dari layar kamera. Efek samping: navigasi halaman lain ikut melewati pola SW yang sudah ada (jaringan, coba ulang 1,5 dtk, lalu offline.html).
- `public/offline.html`: kartu "Kamera SIGAP" dengan tombol "Buka Kamera SIGAP" muncul bila halaman kamera sudah tersimpan, supaya HP yang dibuka tanpa sinyal tidak mentok di halaman "Tidak ada sinyal".
- Label jujur: `labelFotoTanpaSinyal` (lib/sigapFoto.ts) ditampilkan di hasil kirim kamera, Foto saya, dan Periksa (PML/admin). `diterima_at` ditambahkan ke jawaban GET /api/sigap/foto, POST /api/sigap/foto (ringkasan), dan GET /api/sigap/foto/periksa.

## Berkas
Baru: app/api/sigap/foto/paket/route.ts, lib/sigapPaketOffline.ts, app/sigap/foto/paketOffline.ts, lib/__tests__/{sigapPaketOffline,sigapPaketToken,sigapToleransiOffline,paketOfflineKlien}.test.ts.
Diubah: lib/sigapFoto.ts, lib/sigapFotoServer.ts, lib/sigap.ts, lib/__tests__/sigapFoto.test.ts, app/api/sigap/foto/route.ts, app/api/sigap/foto/periksa/route.ts, app/sigap/foto/{KameraSigap,FotoKegiatan,page,FotoSaya,PeriksaFoto}.tsx, public/sw.js, public/offline.html.

## Keputusan pemilik (23 Okt 2026, dikonfirmasi: nomor 1-3 disetujui)
1. DISETUJUI. Foto berlabel kuning "tanpa sinyal" dianggap layak diterima PML/admin (tetap masuk nomor foto, hanya ditandai). Bila PML sebaiknya wajib memeriksa dulu, itu perubahan terpisah.
2. DISETUJUI. Batas kirim 2 hari (`TOLERANSI_KIRIM_HARI`) dan umur paket 48 jam (`UMUR_PAKET_MS`) adalah angka usulan saya, mudah diubah di lib/sigapFoto.ts.
3. DISETUJUI. Pendaftaran service worker untuk semua pengguna kamera (lihat atas).
4. (Catatan, bukan keputusan) Foto yang tertahan di antrean HP lebih dari 2 hari sesudah tanggalnya akan ditolak 403 dan tetap di antrean dengan catatan galat (perilaku antrean yang sudah ada).

## Keterbatasan
- Jam HP bisa dimajukan petugas antar sesi (mis. setelah paket diterima): server tidak punya jam pembanding sampai foto terkirim. Pagar: waktu tidak boleh melewati waktu terima (merah bila melewati), beda jam HP vs hitungan > 2 menit kuning, > 1 jam merah, dan hasil selalu kuning sehingga PML melihatnya. Memajukan jam menggeser jam foto lebih akhir saja, tidak bisa lebih akhir dari waktu kirim.
- Perlu satu kunjungan ber-sinyal setiap maksimal 48 jam untuk menyegarkan paket; halaman kamera baru tersimpan sesudah sekali dibuka/disiapkan saat ada sinyal sesudah SW v5 aktif.
- Pembaruan versi aplikasi: sebelum petugas ke lapangan sebaiknya buka kamera sekali dengan sinyal agar halaman dan chunk terbaru tersimpan; salinan lama tetap jalan karena chunk lama tidak dibuang.
- Peta dasar, daftar nomor terisi, dan Foto saya butuh sinyal; di kamera tanpa sinyal saran nomor memakai antrean HP.

## Pengujian
- Unit vitest: 81 tes lolos di folder uji (waktuResmi paket, penilaian kuning, labelFotoTanpaSinyal, dalamToleransiKirim, token paket vs biasa termasuk pemalsuan awalan, cekAksesIsian dengan toleransi, logika paket di HP, penyimpanan paket dengan localStorage dan jam palsu). `tsc` bersih pada berkas yang diubah (satu-satunya galat sisa berasal dari modul lain yang tidak ada di folder uji).
- Service worker diuji di Chromium dengan server tiruan (15 skenario): halaman kamera dan chunk tersimpan sesudah kunjungan online, terbuka saat server mati, kartu di offline.html membuka kamera, server 500 dan jaringan lambat > 4 dtk memakai salinan, salinan diperbarui, jalur pesan menyimpan halaman + chunk lazy, halaman lain tidak tersimpan.
- Belum diuji: HP sungguhan dan Next sungguhan (mulai dingin tanpa sinyal, kamera + GPS tanpa sinyal, pengiriman otomatis setelah sinyal kembali); alur ini perlu dicoba setelah deploy. Suite lain di proyek (npx vitest run, npm run build) belum dijalankan di laptop.
