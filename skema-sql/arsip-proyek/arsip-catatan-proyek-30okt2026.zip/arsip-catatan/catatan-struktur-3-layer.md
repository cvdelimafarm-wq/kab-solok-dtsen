# Struktur 3 layer SIGAP (8 Okt 2026)

Permintaan user: halaman "Menu Anda" (/sigap) membingungkan dan tanpa navigasi -> diganti Layer 1 berikon bulat. Mockup disetujui ("Setuju"): papan "Struktur 3 layer" di desain https://claude.ai/artifact/2ShXk3TgW5NeeZ5QPLtuAt

## Layer
- Layer 1 = Beranda "/" (app/portal/Beranda.tsx): kartu Tugas Hari Ini + "Kegiatan saya" (ikon bulat, cincin progres, tanda seru bila mendesak; mendesak di depan, selesai paling bawah) + Menu umum + Pengelolaan.
- Layer 2 = tahapan bernomor satu kegiatan ("Langkah x dari n", kelompok Persiapan/Pelaksanaan/Penyelesaian, kartu "Kerjakan sekarang" di atas, kelompok selesai diringkas).
  - Pelatihan: /sigap/pelatihan (halaman Langkah yang sudah ada; ditambah nomor tahapan + chip "Langkah x dari n"; tab Undangan/Instrumen/Transport Lokal dihapus).
  - Transport Lokal: /sigap/kegiatan/translok-<penugasan_id> (baru), 5 langkah: terima penugasan, pilih hari kerja, laporan & foto harian, rekap & verifikasi admin, unduh SPJ.
  - Pendataan bencana, penyisiran, usulan DTSEN: belum punya tahapan terukur -> ikon langsung membuka halaman kerjanya (cincin putus-putus).
- Layer 3 = halaman kerja yang sudah ada (presensi, tes, unggah foto, undangan, translok, dll).

## Warna ikon (selaras papan Ikon berlatar emas)
merah = mendesak (isi emas solid, tanda seru merah), emas = perlu dilengkapi, biru = berjalan, abu = belum mulai, hijau = selesai.
Urutan: merah, emas, biru, abu, hijau.

## Berkas
lib/sigapKegiatan.ts (tipe, urut, ringkasPelatihan, ringkasDariKartu, tugasDariKegiatan), lib/portal/kegiatan.ts (adapter Transport Lokal, server), app/api/portal/kegiatan/route.ts, app/portal/CincinKegiatan.tsx, app/sigap/kegiatan/[id]/page.tsx, app/sigap/page.tsx (kini redirect ke "/"; PanelSaya.tsx tak dipakai, boleh dihapus dengan `git rm app/sigap/PanelSaya.tsx`).

## Tombol Back
- lib/sigapNavigasi.ts (murni, teruji): indukDari, leluhur, perbaruiJejak, bisaKembali.
- app/components/PenjagaKembali.tsx (di layout): jejak halaman (sessionStorage sigap_jejak); aplikasi terpasang dibuka langsung di halaman dalam (mis. dari notifikasi) -> induk disisipkan ke riwayat; di Beranda (aplikasi terpasang) Back pertama = toast "Tekan sekali lagi untuk keluar", Back kedua dalam 2 detik = keluar.
- app/portal/navigasi.ts: keAtas(router) = naik satu layer. Dipakai tombol panah di header Layer 2/3 (pelatihan Kerangka, translok Header, kegiatan/[id]).
- Penyebab lama: tab pelatihan memakai router.push (riwayat menumpuk) dan halaman yang dibuka dari notifikasi tidak punya halaman di bawahnya.

## Pemantauan pemasangan aplikasi
Tabel sigap_aplikasi_pakai (akun_id, terpasang, pertama_aplikasi_at, terakhir_aplikasi_at, terakhir_browser_at, platform); POST /api/sigap/ping (dibatasi 30 menit per mode) dari app/components/PingAplikasi.tsx; ditampilkan di Kelola Pelatihan > Notifikasi (kartu "Aplikasi terpasang", sasaran belum_pasang / belum_notif).

## Logo SIGAP (9 Okt 2026)
Semua permukaan SIGAP memakai /sigap-logo.png dan logo = tombol ke Beranda "/": sidebar laptop (admin/Shell.tsx), HeaderAdmin (admin/ui.tsx), halaman masuk SIGAP & translok (komponen baru app/components/LogoSigap.tsx), Beranda (gulir ke atas). Ikon offline & PasangAplikasi -> /icons/icon-192.png. Tautan "Portal SIGAP" -> "Beranda SIGAP" ("/"). Logo BPS (BrandBps) sengaja dipertahankan di login lama, atur-pin, dashboard, bencana (aplikasi/halaman BPS lain). Belum diubah: lib/ogImage.tsx (pratinjau tautan masih logo BPS), folder public/ikon lama.

## Belum diuji di HP
Perilaku Back (popstate, penjaga Beranda) dan cincin belum dicoba di perangkat asli. Cek setelah deploy: (1) Beranda -> ikon pelatihan -> Undangan -> Back -> Back -> Beranda; (2) buka dari notifikasi langsung ke Presensi -> Back naik ke Langkah lalu Beranda; (3) di Beranda Back sekali = toast, dua kali = keluar.

## Tahap berikutnya (belum)
Adapter tahapan untuk bencana & penyisiran; mesin kegiatan generik buatan admin (identifikasi wilayah, survei mitra); langkah pilih jadwal, tonton video, tag/update alamat.
