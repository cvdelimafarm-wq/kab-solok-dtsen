# Catatan: tombol Batal di modal "Nomor foto" tertutup bilah navigasi bawah (23 Okt 2026)

Gejala (tangkapan layar HP, mode "Melihat sebagai"): jendela konfirmasi tukar urutan foto menempel di bawah layar, tombol "Batal" terhimpit dan tertutup bilah navigasi Hari Ini / Hari Kerja / Arsip; bilah itu juga tidak ikut meredup.

Penyebab: `Modal` dan `LembarDetail` di `app/sigap/foto/SusunFoto.tsx` memakai `fixed inset-0 z-50` tetapi dirender DI DALAM halaman, sehingga terjebak di konteks susunan induk dan kalah oleh bilah navigasi bawah (`fixed ... z-30` di halaman Translok). Reproduksi di Chromium 360x780 dengan induk bertransform dan nav z-30: tombol Batal tidak bisa diketuk (elemen di titik tombol = bilah nav).

Perbaikan (hanya SusunFoto.tsx, tanpa mengubah perilaku lain):
- Komponen `Lapisan`: lapisan gelap dirender lewat `createPortal` ke `document.body`, `z-[100]`, padding atas/bawah mengikuti area aman HP (`env(safe-area-inset-*)`).
- Jendela konfirmasi kini di tengah layar (sebelumnya menempel di bawah), tinggi maksimum = tinggi lapisan (bisa digulir bila layar pendek).
- Lembar detail foto memakai lapisan yang sama (bawah, bersudut bulat, tidak lagi menempel di tepi bawah).

Uji (Chromium, 360x780, nav z-30 + induk bertransform): sebelum = Batal tidak bisa diketuk; sesudah = "Ya, tukar" (511-559) dan "Batal" (567-615) di dalam layar 780 dan bisa diketuk; nav meredup di bawah lapisan; lembar detail: semua tombol bisa diketuk; layar 360x520: jendela muat tanpa terpotong. tsc bersih. Uji regresi alur lama (tukar, urutkan, pasang cadangan, offline, klik di luar tidak menutup) tidak berubah.

Status: perbaikan sudah jadi di sesi, tetapi laptop tidak terjangkau saat penulisan; berkas SusunFoto.tsx hasil perbaikan diserahkan sebagai berkas untuk menimpa `app/sigap/foto/SusunFoto.tsx`. Belum diuji di HP sungguhan.
