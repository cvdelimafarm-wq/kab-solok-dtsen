# Catatan SQL Fase E (berkas i): Administrasi per item POK
Tanggal 24 Okt 2026. Berkas: `20261024i_keu_administrasi.sql` (migrasi), `20261024z4_cek_kesehatan_keu_i.sql` (cek baca-saja), uji `41_uji_administrasi.sql`, pelari `jalan_i.sh`. Belum dijalankan di produksi.

## Cara menjalankan di produksi
1. Pastikan berkas h sudah terpasang (`list_tables` menunjukkan 45 tabel keu_), jalankan `20261024i_keu_administrasi.sql` di editor SQL (aman diulang).
2. Jalankan `20261024z4_cek_kesehatan_keu_i.sql`: baris 1 sampai 8 harus 0, baris 13 harus 48.
3. Jalankan `20261024z_cek_kesehatan_keu.sql` yang baru: baris 4 harus "48 dari 48".

## Isi
- Tiga tabel: `keu_adm_peta` (lembar khusus satu item), `keu_adm_dok` (status tiap dokumen tiap item), `keu_adm_riwayat` (hanya bertambah).
- Daftar dokumen satu item berasal dari Master dokumen: lembar skema (akun dan uraian, aturan dari mockup `jenisKel`) atau pola umum akun. `keu_adm_peta` menimpa aturan otomatis bila keliru.
- Status: belum, draf (dibuat SIGAP, hanya dokumen bertanda gen), terunggah, terverifikasi. Mengembalikan (alasan minimal 5 huruf) menjadikan dokumen belum dan membersihkan berkas; riwayat tetap menyimpan nama dan hash berkas.
- Catatan terikat pada kunci_stabil POK, sehingga tetap terlihat setelah revisi POK lewat alias kunci; aksi berikutnya mengikat ulang kunci tanpa catatan ganda.
- Fungsi: `keu_adm_aksi(detail, dok, aksi, berkas, catatan, akun)`, `keu_adm_peta_atur`, `keu_adm_peta_lepas`, `keu_adm_buka`, `keu_adm_ro_terbuka`, `keu_adm_boleh_unggah`, `keu_adm_boleh_verif`, `keu_adm_tentukan`, `keu_adm_lembar`.
- View: `keu_v_adm_lembar`, `keu_v_adm_dokumen`, `keu_v_adm_item` (lengkap, diperiksa, berjalan, belum, tanpa_dokumen), `keu_v_adm_ringkas` (per RO).
- Berkas fisik tidak disimpan di basis data: aplikasi mengunggah ke penyimpanan lalu memanggil `keu_adm_aksi` dengan `{"nama","hash","ukuran","path"}` (hash SHA-256 64 heksadesimal).

## Hak akses (sesuai papan 15)
- Membuka tab RO: ketua tim atau admin RO RO itu, PPK, bendahara, atau pemegang `keu_akses_adm` (per RO atau semua RO). Admin Aplikasi dan KPA tidak otomatis.
- Mengunggah atau membuat draf: sebagai pihak dokumen. Tim Kerja = ketua atau admin RO, atau pemegang akses Administrasi khusus RO itu; PBJ, Bendahara, Perencanaan, Tata Usaha menurut peran; PPK semua dokumen.
- Memverifikasi: PPK semua; bendahara hanya dokumen yang melibatkan Bendahara; pemegang kewenangan `verifikasi` (pemberian PPK, mis. Tata Usaha) menurut lingkup pemberian. Pengunggah tidak boleh memverifikasi unggahannya sendiri, kecuali PPK.
- Mengembalikan: dokumen terunggah oleh yang berhak memverifikasi; dokumen terverifikasi hanya oleh PPK.
- Mengatur lembar khusus: PPK, ketua tim, atau admin RO RO itu; ditolak bila item sudah punya dokumen terunggah atau terverifikasi (kembalikan dulu).
- Dari aplikasi tidak ada DML langsung ke tabel; semua lewat fungsi. Dari editor SQL (tanpa akun sesi) batasan data dan urutan status tetap berlaku.

## Keputusan saya yang perlu Anda tinjau
1. Aturan lembar mengikuti mockup apa adanya, termasuk kata pemicu yang longgar (mis. "inda" pada honor akan cocok juga dengan nama yang memuatnya, "materai" jatuh ke seksi A konsumsi). Koreksi cukup lewat Master atau pengaturan khusus per item.
2. Perencana, Tata Usaha, dan PBJ perlu akses Administrasi (`keu_akses_adm`) untuk membuka tab, sama seperti mockup ("dibuka untuknya"). Pemberian kewenangan verifikasi saja tidak membuka tab.
3. Mengembalikan dokumen terverifikasi saya batasi untuk PPK saja (spesifikasi hanya menyebut "kembalikan"); mudah dilonggarkan.
4. Bila dokumen master dinonaktifkan, catatan lama tetap tersimpan tetapi tidak muncul di view.

## Hasil uji (basis data uji, bukan produksi)
Rangkaian a-f, h, uji 40, berkas i dua kali, uji 41, dan z4 lulus. Uji 41 memeriksa: 22 kasus aturan lembar, hak membuka (16 pemeriksaan), alur lengkap (draf, unggah, ganti berkas, verifikasi oleh PPK/TU/bendahara, larangan verifikasi sendiri, pengecualian PPK, mitra sebagai admin RO dan PBJ, kembalikan dengan alasan), riwayat, larangan DML langsung, transisi status dari editor, lembar khusus (ganti, batalkan, tolak setelah unggah), alias kunci, kelengkapan item dan ringkasan RO, RLS dan hak, audit.
