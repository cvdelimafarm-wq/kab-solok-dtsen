# Status tahap 24: alasan versi RAB, jalur penutup, ekspor (25 Okt 2026)

## Sudah di-deploy dan diuji (tahap 23)
Buku selisih Satker, LIBUR 2027, akun 512212: lihat status-tahap23. Uji produksi Buku selisih: tampilan kosong benar; dengan satu catatan fiktif (dicatat lewat tab Kekurangan RO 2906.BMA.005, lalu ditarik kembali): KPI, penyaring kelompok 524/52L/Inti, dan tautan ke tab RO benar.

## Dikerjakan
1. Ekspor: Excel, PDF (A4 mendatar, banyak halaman, blok tanda tangan), dan CSV matriks perubahan POK diverifikasi di sandbox dengan 60 baris contoh (Excel dibaca ulang dengan openpyxl, PDF dirender). Buku selisih Satker mendapat Ekspor Excel dan CSV (mengikuti penyaring).
2. Jalur penutup (papan 1): lib/keu/kecukupan.ts jalurPenutup + tampilan di panel Kecukupan KRO, di bawah Buku selisih. Revisi POK: dua jalur; Revisi DIPA: lima jalur dimulai keputusan PPK. Tes 2.
3. Alasan versi RAB:
   - SQL (sudah dijalankan di produksi lewat SQL editor, tanpa DROP): kolom keu_rab.alasan_versi (null atau minimal 10 karakter); fungsi baru keu_rab_baru_alasan(p_ro, p_dari, p_alasan, p_akun) dengan alasan WAJIB bila p_dari diisi; keu_rab_baru lama menjadi pembungkus (p_dari kosong saja); 'keu_rab_baru_alasan' ditambahkan ke daftar izin keu_jalankan. Arsip: skema-sql/fase-b/20261025x_keu_rab_alasan_versi.sql.
   - Aplikasi: tombol "Susun revisi RAB" di tab RAB RO dan di Kertas kerja KRO meminta alasan (min. 10 karakter); alasan tampil di tab RAB (versi 2 ke atas) dan di kartu Versi RAB. Revisi di Kertas kerja KRO kini menyalin RAB sah (sebelumnya membuat RAB kosong).
4. Catatan: apply_migration Supabase minta konfirmasi untuk DROP dan tidak terjawab; diganti rancangan tanpa DROP.

## Hasil uji produksi (25 Okt 2026, data fiktif, setelah deploy)
- Alasan versi RAB (RO 2907.BMA.006): RAB nomor 1 dibuat dan disahkan; alasan 7 karakter ditolak (pesan "minimal 10 karakter (sekarang 7)", tombol nonaktif); alasan sah membuat RAB nomor 2 dan alasannya tersimpan di basis data. Alasan tampil di tab RAB ("Alasan versi 2") dan di kartu Versi RAB Kertas kerja KRO ("Alasan v2").
- Jalur penutup: tampil di bawah Buku selisih Kertas kerja KRO 2907.BMA setelah RAB draf v2 diubah menjadi Rp 640.000 (di atas POK Rp 465.000): dua jalur Revisi POK, selisih Rp 175.000 pada kelompok 52 selain 524. Panel hanya muncul bila ada RAB melebihi POK.
- Buku selisih Satker: tombol Ekspor Excel (17 KB, buku-selisih-satker.xlsx) dan Ekspor CSV (buku-selisih-satker.csv) menghasilkan berkas; unduhan ditahan agar tidak tersimpan di komputer.
- Perbaikan teks: kalimat lama "Alasan versi ... belum disimpan oleh basis data" di RabInline.tsx diganti (t24d, sudah di repo, perlu commit dan deploy).
- Sisa data uji: RO 2907.BMA.006 punya RAB v1 sah dan v2 draf (item ATK Rp 300.000); baris POK jadwal 7 ("UJI Kertas kerja fiktif") sudah dimuat. Catatan kekurangan uji sudah ditarik.

## Masih terbuka
Padanan baris POK baru/hilang saat impor, persetujuan KPA saat pagu di bawah realisasi (R-06), uji tulis alur revisi (geseran, keputusan PPK, Kembalikan, tombol status), serta yang bergantung data luar (Booked, pengurangan realisasi SPAN, pencabutan kewenangan).
