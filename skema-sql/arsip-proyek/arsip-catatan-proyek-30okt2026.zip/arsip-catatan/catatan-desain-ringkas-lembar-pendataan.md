# Desain ringkas Lembar Pendataan (HP) — 14 Okt 2026

Permintaan user: terapkan mockup kanvas "Lembar Pendataan" (artifact 2ShXk3TgW5NeeZ5QPLtuAt, komponen HpPendataan.dc.html; tiga HP: Peta, Daftar KK, Monitoring). TAMPILAN saja; API, skema, logika catat/log/antrean, dan aturan akses tidak diubah.

## Berkas yang berubah (ditulis ke repo laptop, belum di-commit user)
- `app/sigap/pendataan/page.tsx` — ditulis ulang tampilannya (logika, state, dialog KK, toast, TambahKk, PlottingTim tetap).
- `app/sigap/pendataan/PetaKk.tsx` — kanvas h-full w-full (dulu rasio tetap 360:440, maks 64vh); skala geser memakai ukuran nyata.
- `app/components/BannerLihatSebagai.tsx` — pita 30 px (dulu 36), ikon mata SVG, "Melihat sebagai <nama>", Ganti, Kembali; memasang variabel CSS `--tinggi-banner`.

## Isi desain
- Header navy 3 baris: judul + angka didata/total; tombol pemilih Sub SLS 46 px (lembar bawah, teratas "Semua Sub SLS tim" menggantikan tombol "← Plotting tim"); tab bersegmen 34 px.
- Kartu filter tunggal (bilah bertumpuk + pemilih PPL lembar bawah + 4 angka saring; ketuk = saring, ketuk lagi = semua). Titik tak lolos diredupkan (opacity .2, perilaku lama).
- Peta mengisi sisa layar; pil +/−/semua kanan atas; lokasi saya kanan bawah (di atas tombol "Keluarga baru"); legenda kiri bawah.
- Daftar KK: kolom cari + tombol urut (Belum dulu → Nama → Terdekat), baris ±49 px satu kartu, padding bawah 70 px.
- Monitoring: header "Semua Sub SLS tim"; Progres tim; Menurut PPL = baris per PPL (menggantikan tabel); Per Sub SLS per nagari.

## Hasil uji (render 390×844, Chromium, mock data)
- Kontrol di atas peta 257 px; Daftar KK menampilkan 10 baris; tanpa gulir horizontal; Monitoring tidak ada elemen melebihi lebar.
- tsc bersih pada berkas yang diubah; 61 uji (pendataan, permintaanDaftar, siaranPetugas) lulus.

## Catatan
- Belum diuji di HP asli dan dengan font Plus Jakarta Sans (uji memakai font sistem).
- Area peta tetap dibentuk dari kanvas 360×440 sehingga titik terpusat; ruang kosong atas/bawah di layar tinggi.
- Tombol lokasi di peta tetap perilaku lama: mengurutkan terdekat dan pindah ke tab Daftar KK.
