# Catatan mockup Kertas Kerja Revisi POK, tahap 5 (24 Okt 2026)

Status: MOCKUP saja (artifact Design, Versi 34). Belum ada SQL, migrasi, atau kode aplikasi sampai Pak Iqbal menyatakan "setuju".

## Permintaan
1. Warna kontras antar level RO, Komponen, Akun, Item, RAB (paling penting membedakan Akun, Item, RAB).
2. Tombol "ganti akun" per baris dihapus. Aksi untuk baris item dan akun diganti alur centang, lalu tombol aksi yang sesuai muncul di pojok kiri atas tabel (salah satunya Ganti akun).
3. Warna jelas antara POK Jumlah dan RAB Jumlah; di bawah POK Jumlah ditambah "(revisi ke-2)" karena POK bergerak setelah revisi, sehingga selisih POK vs RAB ikut berubah.

## Usulan warna per level
- RO: biru tua (navy), teks putih.
- Komponen: biru muda dengan garis penanda biru di kiri.
- Akun: kuning/amber dengan garis penanda amber di kiri.
- Item: putih polos (baris utama yang dibaca).
- Rincian RAB: hijau muda dengan garis penanda hijau di kiri.
- Kolom: POK Jumlah bernuansa biru, RAB Jumlah bernuansa hijau, dengan sub-label di header ("revisi ke-2" di bawah POK Jumlah, "dari rincian" di bawah RAB Jumlah). Ada baris legenda warna di atas tabel.

## Alur aksi lewat centang
- Per baris hanya tersisa: kotak centang, dan satu tombol "Rincian" (buka/tutup) pada item RAB.
- Setelah centang item, akun, atau RO, bilah aksi muncul di pojok kiri atas tabel. Isi bilah menyesuaikan tab:
  - Tab Kertas Kerja: kolom "akun baru (6 digit)" + Ganti akun, Batalkan pindah akun (hanya bila ada yang sudah dipindah), Tambah item di akun (hanya bila pilihan berada dalam satu akun), Tandai selesai, Buka kembali, Tampilkan RAB, Hanya yang dipilih, Bersihkan pilihan.
  - Tab RAB: Ganti akun, Batalkan pindah akun, Tandai selesai, Buka kembali, Tampilkan RAB, Tutup rincian, RAB = Item, Salin rincian, Tempel (bila ada salinan), Hapus RAB.
- Bila belum ada yang dicentang, bilah menampilkan petunjuk.
- Ganti akun lewat bilah memakai logika yang sama dengan sebelumnya (duplikasi ke akun baru, akun lama dikosongkan sebesar sisa di luar Booked + Realisasi). Item yang sudah habis terpakai atau sudah dikosongkan dilewati dan dihitung di pesan.

## Asumsi
- "revisi ke-2" bersifat tetap (POK semula = revisi ke-2) pada mockup ini; di aplikasi nyata nilainya mengikuti nomor revisi POK terakhir yang sudah disahkan.

## Pengujian
- Keseimbangan tag, kunci template lengkap, dan skrip uji alur bilah (ganti akun KK dan RAB, batalkan, tambah item, tempel, pilih lewat akun/RO) lulus. Tampilan di peramban belum diverifikasi.
