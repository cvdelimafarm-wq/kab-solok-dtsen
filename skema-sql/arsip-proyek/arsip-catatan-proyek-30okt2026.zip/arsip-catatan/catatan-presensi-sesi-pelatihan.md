# Catatan: Presensi per sesi (8 Okt 2026)

Permintaan: peringatan lokasi ("di luar radius") padam jika peserta sudah memenuhi ketentuan presensi; ketentuan (1x/2x per hari, jam buka-tutup) diatur di Kelola Pelatihan dan terisi bawaan.

## Keputusan (dipilih user)
- Model: jumlah sesi per hari (1-3) + nama & jam buka-tutup tiap sesi; berlaku di semua hari kegiatan (tanggal_mulai s.d. tanggal_selesai).
- Bawaan: 1x per hari, 06.00-18.00 WIB (tanpa isi dari nol). Pilih 2x -> otomatis Pagi 06-12 / Sore 12-18; 3x -> Pagi/Siang/Sore.
- Peringatan lokasi padam per sesi: hanya tampil untuk sesi yang sedang dibuka & belum tercatat; semua sesi hari itu tercatat -> kartu hijau "Presensi hari ini lengkap (n dari n)", GPS tidak dibaca lagi.

## Teknis
- DB: `sigap_pelatihan_pengaturan.presensi_sesi` (jsonb, NULL = turunan dari jam buka/tutup lama = 1 sesi); `sigap_pelatihan_presensi.tanggal` + `sesi_no` (data lama = sesi 1 di tanggalnya). Migrasi 20261008h.
- PENTING: indeks unik lama `sigap_pelatihan_presensi_unik (kegiatan_id, akun_id) where diterima` masih menahan presensi sesi ke-2. Indeks baru `..._unik2 (kegiatan_id, akun_id, tanggal, sesi_no)` sudah dibuat. Perintah DROP macet lewat alat MCP Supabase -> jalankan di SQL Editor:
  `drop index if exists public.sigap_pelatihan_presensi_unik; alter index public.sigap_pelatihan_presensi_unik2 rename to sigap_pelatihan_presensi_unik;`
  Juga hapus tabel uji kosong `drop table if exists public.tmp_uji_drop_zz;`
- Logika murni: lib/sigapPresensi.ts (validasiSesi, hariKegiatan, jadwalSesi, susunHari, keadaanHari) - 28 kasus uji lulus.
- API: peserta POST /presensi menerima `sesi` ("YYYY-MM-DD#no"); hub mengirim `presensi.hari`; admin kehadiran: atur_presensi (sesi), bagian=presensi per sesi (hadir/sebagian/ditolak/belum), presensi_manual (sesi).
- UI: halaman Langkah (IsiPresensi, pemandu), Kelola > Soal & Jadwal (kartu presensi), Monitoring > Presensi (chip per sesi, ekspor kolom per sesi).
- Daftar hadir/PDF: hadir bila minimal satu sesi tercatat; jam = presensi pertama.

## Status
Kode siap di ruang kerja (belum ditulis ke folder laptop karena koneksi laptop putus); belum diuji di browser dengan data asli. Cadangan: presensi-sesi.zip.
