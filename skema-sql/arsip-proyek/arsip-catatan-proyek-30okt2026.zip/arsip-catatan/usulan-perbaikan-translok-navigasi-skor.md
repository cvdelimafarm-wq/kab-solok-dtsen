# Usulan Perbaikan SIGAP: Alur Translok, Navigasi, Pengingat Kekurangan, dan Skor Kinerja Harian

Disusun 14 Okt 2026 dari audit kode (repo laptop) dan cek langsung di Chrome ("Masuk sebagai" mode simulasi, 1 PPL + 1 PML tim yang sama, 20.25 WIB).
Status: USULAN. Belum ada kode yang diubah. Setiap butir perlu dicek ulang terhadap kode terbaru sebelum dikerjakan.
Dokumen audit lengkap (tabel + diagram): Claude Docs "Audit Translok-154 dan Skor Kinerja Harian".
Ringkasan audit: `claude/catatan-audit-translok-skor-kinerja.md`.

Kode butir: U = perbaikan alur/data, N = navigasi, P = pengingat, S = skor kinerja. Prioritas: T = tinggi, S = sedang, R = rendah.

---

## Fase 1 — Perbaikan alur, konsistensi, dan validasi (risiko rendah–sedang)

| Kode | Prio | Masalah (bukti) | Usulan perubahan | Berkas utama | Wajib dicek sebelum mengubah |
|---|---|---|---|---|---|
| U-01 | T | Langkah 2 "Pilih hari kerja" dan 5 "Unduh SPJ" di Layer 2 Translok membuka tab Hari Ini. `susunTranslok` memberi `hrefKerja` yang sama ke langkah 2, 3, 5; halaman translok hanya membaca `?p=`. | Tambah `&tab=hari_kerja` / `&tab=arsip`; halaman translok membaca `tab` dari alamat (sekali saat muat). | `lib/portal/kegiatan.ts`, `app/sigap/translok/[token]/page.tsx` | Tautan lain ke halaman translok (Beranda tugas utama `tugasDariKegiatan`, `siapkan.ts`, push). Panduan login pertama (`langkah`) tetap tampil bila onboarding belum selesai. |
| U-02 | T | "Hari lengkap" beda: API translok memakai `laporanDianggap` (hasil identifikasi/pendataan), adapter Layer 2 hanya `sigap_realisasi`. Layer 2 bisa menyuruh "minta izin susulan" padahal Layer 3 Lengkap. | Satu fungsi server penilai hari lengkap, dipakai Layer 1, 2, 3, Arsip, dan kwitansi. | `lib/portal/kegiatan.ts`, `app/api/sigap/translok/[token]/route.ts`, `lib/realisasiOtomatis.ts` | Perubahan nada/peringatan di Beranda; skor tugas utama; tes `lib/__tests__`; beban query tambahan di `/api/portal/kegiatan` (dipanggil polling 45 dtk). |
| U-03 | T | Halaman translok: galat muat apa pun -> tombol "Masuk kembali" yang menghapus sesi. Sinyal lemah = keluar akun. | Bedakan sesi tidak sah (404 "Sesi tidak valid") dan gangguan jaringan/500; untuk jaringan tampilkan "Koneksi terputus" + Coba lagi, sesi tetap. | `app/sigap/translok/[token]/page.tsx` | Mode "masuk sebagai" (401 kembali ke akun super); antrean offline. |
| U-04 | T | Layer 2 Translok: bila `kegiatan[0]` kosong -> kerangka abu tanpa henti. | Pesan "Kegiatan tidak ditemukan" + tombol Beranda. | `app/sigap/kegiatan/[id]/page.tsx` | Kegiatan berstatus arsip apakah memang dikeluarkan dari API. |
| U-05 | T | Membuka tautan dalam tanpa sesi -> ke `/` tanpa alamat kembali; setelah masuk petugas di Beranda. | Alihkan ke `/?lanjut=<path>` (hanya jalur internal), kembali ke sana setelah masuk. | `useInduk.ts`, `[id]/page.tsx`, `app/portal/Masuk.tsx`, pembantu sesi | Pola `?next=` aman yang sudah ada di `/login`; cegah open redirect; tautan push. |
| U-06 | T | Laporan bisa jauh dari kenyataan. Bukti langsung: PPL lapor 10 keluarga, hari Lengkap; Lembar Pendataan 0 KK atas namanya, jorong 0/39. Juga: HP terima 3 digit (999), server maks 500; angka 0 boleh. | (a) Samakan batas HP dan server. (b) Bila sumber otomatis ada dan angka manual berbeda, kendala/alasan wajib. (c) Usul keputusan user: untuk PPL Pendataan, jumlah terkunci dari Lembar Pendataan. | `page.tsx` (FormRealisasi), `route.ts` aksi `realisasi`, `lib/realisasiOtomatis.ts` | Hari yang sudah tersimpan & sudah dikunci admin tidak berubah statusnya; PPL yang mendata tanpa sinyal (antrean offline belum terkirim) jangan langsung dianggap salah. |
| U-07 | S | Kalender Hari Kerja: "dasar Kwitansi" 11 Okt–10 Nov, 31 hari, Rp5.270.000 (dari pilihan klien, termasuk hari terlewat). Arsip: 14 Okt–10 Nov, 28 hari, Rp4.760.000 (dari server, termasuk 27 hari belum dikerjakan). | Kalender memakai `kelompok` dari server; pisahkan "sudah pasti" (hari lengkap) dan "rencana". | `page.tsx` (KalenderHariKerja, ArsipDokumen) | Catatan 10 Okt: estimasi nominal di Ringkasan dihapus atas permintaan user — konfirmasi apakah nominal di kalender & arsip tetap ingin ditampilkan. Generator PDF kwitansi tidak boleh berubah tanpa izin. |
| U-08 | S | Arsip: jumlah dokumen Laporan hanya `h.realisasi`; daftar hari memberi "Laporan ✓" untuk laporan dianggap. | Pakai aturan U-02. | `page.tsx` (ArsipDokumen) | Isi PDF Laporan untuk hari "dianggap" — apakah ikut tercetak. |
| U-09 | S | Pesan galat basis data (`error.message`) dikirim mentah ke petugas. | Peta galat ke kalimat pendek; teks teknis ke log server. | `app/api/sigap/translok/[token]/route.ts` (+ route lain yang sama polanya) | Admin masih butuh detail saat debug (log). |
| U-10 | S | Hari bukan kerja: kartu "Kerjakan sekarang" hilang tanpa petunjuk. Langkah 4 hanya Menunggu/Selesai, keterangan tetap "Setelah semua hari kerja terisi". Langkah 3 berisi "Minta izin susulan" tetapi tombolnya "Lanjutkan isi hari ini" dan tidak ada tombol minta izin. | Kartu "Berikutnya" (hari kerja berikutnya / menunggu verifikasi). Status "Sedang diperiksa admin". Tombol "Minta izin susulan" bila ada hari terlewat. | `lib/portal/kegiatan.ts`, `[id]/page.tsx` | Alur permintaan izin susulan belum ada (admin memberi lewat `sigap_izin_susulan`): perlu tabel/aksi baru atau cukup tombol WhatsApp ke admin? Keputusan user. |
| U-11 | S | PML diminta 3 tugas "kerjakan satu per satu sesuai nomor" padahal paralel. PPL: kartu Wilayah tim panjang di atas, tugas di bawah. | PML: "Tugas hari ini" tanpa urutan wajib. PPL: tugas di atas, wilayah tim dilipat. | `app/sigap/kegiatan/[id]/[tahap]/page.tsx`, `lib/sigapPrioritas.ts` (`adalahTugas`) | Penomoran "Langkah i dari n" dipakai bersama kartu Beranda — ubah keduanya serentak. |
| U-12 | S | Angka KK satu Sub SLS beda antar layar (mis. 66 vs 39; 159 vs 84): perkiraan vs daftar FASIH, label sama "KK". | Label berbeda: "KK perkiraan" vs "KK di daftar". | `WilayahTim.tsx`, Lembar Identifikasi, Lembar Pendataan | Sumber angka masing-masing (kolom tabel) — pastikan tidak ada yang sebenarnya salah hitung. |
| U-13 | S | PML: Beranda "13 dari 25 Sub SLS", kartu tim di halaman PPL "9 dari 9 selesai". | Sebut cakupan: "9/9 Sub SLS tim · 13/25 semua tugas Anda". | Beranda tugas utama, `WilayahTim.tsx` | Arti 25 (pelaksana + pendamping). |
| U-14 | S | Lembar Pendataan bagi PPL dibuka dengan kartu "Plotting tim hari ini" terbuka penuh (khusus PML). Judul "hari ini" bertentangan dengan "maksimal 5 Sub SLS total". | Bagi PPL dilipat jadi satu baris status; judul "Plotting tim". | `app/sigap/pendataan/PlottingTim.tsx` | Kebutuhan PPL melihat PPL penerima assignment FASIH. |
| U-15 | S | Surat Tugas tujuan tidak memuat seluruh kecamatan wilayah tim. | Peringatan di admin bila wilayah tim di luar tujuan ST. | Admin translok/ST | Data ST lama; ini peringatan saja, bukan pemblokiran. |
| U-16 | R | Label status beda antar layer (Menunggu/Terkunci vs Belum mulai/Belum dibuka); "Langkah x dari n" tampil dua kali di Layer 2; catatan bawah Layer 2 "terbuka otomatis setelah langkah sebelumnya selesai" tidak tepat; peringatan foto huruf kapital semua; pemilih penugasan di header translok bisa pindah kegiatan padahal Kembali tetap ke Layer 2 asal. | Satu kamus label status di lib; hapus duplikat; teks pendek; sembunyikan pemilih bila `?p=`. | `[id]/page.tsx`, `Induk.tsx`, `[tahap]/page.tsx`, `page.tsx` translok | — |

## Fase 2 — Navigasi dan alamat web (keluhan user: sering tersesat, Beranda tidak jelas)

Bukti: tombol kembali bergantung `?dari=`; `/sigap/pendataan` dibuka langsung -> kembali ke Beranda (lompat 2 layer). `keAtas` (`app/portal/navigasi.ts`) memakai `router.replace` bila jejak bukan induk, sehingga tombol kembali HP tidak sama dengan tombol kembali halaman. Tidak ada tombol Beranda tetap; Beranda dan Masuk sama-sama `/`; Transport Lokal punya navigasi bawah sendiri; tombol Keluar di sebelah logo.

| Kode | Prio | Usulan | Wajib dicek |
|---|---|---|---|
| N-01 | T | Header tetap di semua halaman SIGAP: ikon rumah (Beranda) + jejak yang bisa diketuk (di HP dua bagian terakhir). | Komponen header yang ada (`HeaderAdmin`, header Layer 2/3, header Lembar), spanduk "Melihat sebagai". |
| N-02 | T | Alamat bertingkat sesuai menu; tombol kembali = naik satu segmen (tanpa `?dari=`). Contoh: `/beranda`, `/kegiatan/pascabencana`, `/kegiatan/pascabencana/pendataan`, `/…/pendataan/identifikasi`, `/…/pendataan/lembar/peta?sub=…` (juga `/daftar`, `/monitoring`), `/…/pendataan/translok`, `/…/pendataan/translok/hari-ini` (juga `/hari-kerja`, `/arsip`). Alamat lama dialihkan (redirect), tidak dihapus. | Tautan lama yang sudah tersebar (WA, push, bookmark, pintasan PWA), `public/sw.js` cache, `siapkan.ts` (prefetch), `PenjagaKembali`/`lib/sigapNavigasi.ts` (`indukDari`), `middleware.ts` matcher, metadata/OG per segmen, kegiatan lain yang tidak berinduk (penyisiran, DTSEN). Usul: kerjakan bertahap, mulai dari `/beranda` + header. |
| N-03 | S | Satu navigasi bawah: Beranda · Tugas · Pengingat (lonceng + angka) · Akun. Tab Hari Ini/Hari Kerja/Arsip Translok menjadi tab bersegmen di dalam halaman. Tombol "Unduh SPJ" melayang tetap. | Ruang bawah yang dipakai tombol melayang (Keluarga baru, Rekap identifikasi, Unduh SPJ). |
| N-04 | S | Tombol Keluar pindah ke menu Akun. | Keluar juga mematikan push (`matikanPush`). |
| N-05 | S | Tombol kembali HP = tombol kembali halaman (riwayat normal). | Jangan menumpuk riwayat saat pindah tab. |
| N-06 | T (keamanan) | Alamat `/sigap/translok/<token>` memuat kunci akun yang diterima API (`akunDariToken`); tautan yang diteruskan/tertangkap layar bisa membuka dan mengisi akun orang lain. Pakai sesi login biasa; kunci keluar dari alamat. | Apakah token kedaluwarsa/berputar; undangan lama berbasis token; `useDetak`; mode simulasi; unggah foto langsung ke Storage. |

## Fase 3 — Pengingat kekurangan lewat modal dan push (permintaan user)

Prinsip: satu "daftar kekurangan" per akun dihitung di server; modal, lonceng, push, dan kartu Beranda membaca daftar yang sama. Tiap item: judul ≤ 6 kata, dampak (rupiah/status), batas waktu, SATU tombol yang membuka tepat bagian yang harus diisi (tab & Sub SLS terpilih, kolom disorot) + "Nanti".

| Kode | Kekurangan | Pemicu | Contoh kalimat | Tombol | Saluran & waktu |
|---|---|---|---|---|---|
| P-01 | Pelatihan | Pretest/presensi/foto/posttest belum, masih terbuka (`lib/sigapTerlewat.ts`) | "Posttest belum dikerjakan. Tutup 21.00." | Kerjakan posttest | Modal saat buka; push 2 jam sebelum tutup |
| P-02 | Translok hari ini | Hari kerja, foto < wajib atau laporan belum | "Foto hari ini 3/5. Batas 23.59." | Unggah foto | Push 17.00 & 21.00; modal sesudah 15.00 |
| P-03 | Hari terlewat | Hari kerja lampau tidak lengkap | "11–13 Okt tidak dibayar. Minta izin susulan?" | Minta izin susulan | Modal sekali; lonceng |
| P-04 | Laporan ≠ pendataan | Jumlah laporan ≠ hasil Lembar Pendataan tanggal itu | "Laporan 10 KK, Lembar Pendataan 0 KK. Samakan dulu." | Buka Lembar Pendataan | Modal saat simpan laporan; push 20.00 |
| P-05 | Identifikasi belum disimpan | Sub SLS tugas PML tanpa hasil -> laporan PML tidak terisi otomatis | "3 Sub SLS belum diidentifikasi." | Isi identifikasi (filter Belum) | Push 18.00; modal |
| P-06 | Poin di bawah target | 16.00 poin < 6 (setelah Fase 4) | "6/10 poin. Kurang 4 KK terdampak." | Lanjut mendata | Push 16.00 |
| P-07 | Ringkasan tim (PML) | PPL tim belum lengkap | "2 PPL belum unggah foto hari ini." | Lihat tim | Push 20.00 ke PML |

Aturan: modal maks 3 item teratas (batas terdekat, lalu dampak uang); Nanti = tunda 2 jam, setelah 2× tidak muncul lagi hari itu; modal tidak muncul saat petugas mengisi formulir dan tidak bertumpuk dengan modal lain (PengumumanPetugas, modal "Unggah foto pelatihan" — pakai pola komponennya). Push maks 3/orang/hari, jam tetap, hanya kekurangan berbatas hari ini; ketuk push membuka alamat tujuan. Lonceng = daftar lengkap, item hilang sendiri setelah beres.

Wajib dicek: kunci VAPID di Railway (lihat `claude/catatan-notifikasi-push-desain-sigap.md`); penjadwal push (Railway cron / pg_cron) belum ada; iPhone wajib pasang PWA; urutan dengan modal yang sudah ada; beban hitung daftar kekurangan untuk semua akun pada jam kirim.

## Fase 4 — Skor kinerja harian (MENUNGGU KEPUTUSAN USER sebelum dibangun)

Rumus usulan (satuan poin; target 10 poin/hari; 1 poin = 1 KK terdampak):

    P = T + N/2 + min(J/5, J_maks)      Capaian = min(P/10, 1) × 100%

- T = KK terdampak, N = KK tidak terdampak (dari log Lembar Pendataan `bencana_pendataan_log`, hasil terakhir yang berlaku, sekali per KK, untuk PPL pemilik hasil, pada tanggal hasil dicatat). Bukan dari angka laporan.
- J = km rute: rumah (domisili terverifikasi) -> titik GPS tiap penandaan urut waktu -> rumah; garis lurus × 1,3; titik akurasi > 100 m dilewati (`jarakMeter` sudah ada di `lib/pendataan.ts`). Poin jarak hanya bila ≥ 1 KK didata hari itu. J_maks usul 4 poin (20 km).
- Bila sisa KK wilayah tim < 10 poin, target hari itu = poin sisa. Tanpa carry-over.
- Upah: hari dibayar Rp170.000 bila capaian 100% DAN hari lengkap (laporan + foto). Usul toleransi 80–99% dengan persetujuan PML. Tanpa bayar sebagian.

| Kode | Usulan | Wajib dicek |
|---|---|---|
| S-01 | `lib/skorKinerja.ts` murni + tes (contoh: 10/0/2 km = 10,4; 4/8/10 km = 10; 6/2/7 km = 8,4; 2/4/40 km = 8; 0/0/25 km = 0). | Definisi "hasil terakhir berlaku" pada log keroyokan; Urungkan; KK tambahan (Keluarga baru); zona waktu WIB. |
| S-02 | API skor harian per akun & per tim. | Indeks tabel log; performa untuk monitoring tim. |
| S-03 | Tampilan: pil "7,5/10 poin" + notifikasi "+1 poin" di header Lembar Pendataan; kartu capaian di tab Hari Ini Translok (mengganti Ringkasan 2 kolom); keterangan langkah 3 Layer 2; lencana % di kartu tugas Beranda; kolom poin di tab Hari Kerja; kolom poin di Monitoring PML; tabel petugas × tanggal + setujui/tolak di backoffice. MOCKUP DULU. | Kalimat utama dalam satuan KK ("Kurang 2,5: ±3 KK terdampak atau 5 KK tidak terdampak"); status upah Terkunci/Perlu persetujuan PML/Terbuka. |
| S-04 | Integrasi ke hari dibayar & kwitansi. | JANGAN dikerjakan sebelum user & admin anggaran menyetujui; kesesuaian juknis/SBM transport lokal; SPJ yang sudah dikunci tidak berubah; berlaku mulai tanggal tertentu, bukan surut. |

Keputusan user yang dibutuhkan: (1) poin KK "tidak ditemukan" (0 atau 0,25 berbatas); (2) J_maks; (3) toleransi 80–99%; (4) titik awal rute (rumah atau titik kumpul); (5) skor untuk PML; (6) U-06c jumlah laporan PPL dikunci dari Lembar Pendataan; (7) U-10 alur minta izin susulan; (8) U-07 nominal tetap ditampilkan atau tidak.

## Urutan kerja yang disarankan

1. Fase 1 butir T (U-01–U-06), lalu S/R.
2. N-06 (keamanan) dan N-01 header + `/beranda`; sisa Fase 2 bertahap dengan redirect.
3. Fase 3 dimulai dari modal + lonceng (tanpa push), lalu push terjadwal.
4. Fase 4 setelah keputusan user; S-04 terakhir.
