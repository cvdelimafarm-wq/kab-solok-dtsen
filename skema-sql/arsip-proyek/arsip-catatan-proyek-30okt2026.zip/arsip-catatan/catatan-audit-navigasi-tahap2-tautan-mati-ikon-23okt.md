# Catatan Audit Navigasi — Tahap 2 (tautan mati, nama, gaya tombol) — 23 Okt 2026

Lanjutan dari `catatan-audit-navigasi-tahap1-tombol-kembali-23okt.md`. Belum ada perubahan skema/SQL. Perlu: tsc, vitest, build, commit/push/deploy oleh Iqbal.

## Yang SUDAH diubah (12 file, sudah ditulis ke laptop)
1. **Kartu mati "Admin Delego"** — `lib/portal/server.ts`: kartu "Admin <aplikasi>" (dtsen/bencana/penyisiran/seruti/delego) yang `href`-nya kosong di tabel `portal_aplikasi` tidak lagi ditampilkan di Beranda (baris status "Tautan belum diatur" dihapus). Begitu admin mengisi tautan di Kelola Aplikasi, kartu muncul sendiri. Item sidebar "Delego" (admin) tetap ada dan mengarah ke `/sigap/kelola/delego`, yang menampilkan halaman penjelasan + tombol "Buka Kelola Aplikasi" + Kembali (bukan jalan buntu).
2. **Menu admin tampil dua kali di Beranda admin** — `app/portal/Beranda.tsx`: chip peran di header kini label biasa (bukan tautan). Daftar menu admin hanya satu: kisi "Pengelolaan". CATATAN: ini membalik permintaan 10 Okt (label peran bisa ditekan); mudah dikembalikan bila Iqbal lebih suka chip bisa ditekan.
3. **Emoji → ikon garis** (memakai `app/portal/IkonMenu.tsx`, ditambah bentuk `rumah`):
   - `app/sigap/admin/page.tsx`: tab Beranda/Monitoring/Penugasan/Kegiatan/Verifikasi dan tombol "Kelola Peran & Akses" (dulu 🏠📈👥⚙️✅🔐). `ItemTab` di `ui.tsx` mendapat `ikon?: NamaIkon`; `BarisTab` menggambar ikonnya.
   - `app/sigap/admin/Beranda.tsx`: "Atur tarif", "Kelola peran & akses" di Akses cepat.
   - `app/sigap/translok/[token]/page.tsx`: navigasi bawah (Hari Ini/Hari Kerja/Arsip) dan kotak peringatan unggah dokumentasi.
   - `app/sigap/admin/TabVerifikasi.tsx` (peringatan kunci), `TabPenugasan.tsx` (teks "tab Kegiatan & Tarif" tanpa emoji).
   - `app/bencana/page.tsx`: tombol peringatan petugas, tab "Kelola Perkiraan Beban" (teks polos seperti tab saudaranya), teks bantuan.
4. **Tiga varian tombol** — `ui.tsx`: komentar baku UTAMA (`BTN`), SEKUNDER (`BTN_O`), TEKS/TAUTAN (`BTN_T`, baru, min-h 44px). `BTN_G`/`BTN_R` tinggal untuk aksi bermakna warna (simpan/setujui, hapus/tolak). Penyisiran seluruh tombol lama belum dilakukan (lihat "Belum").
5. **Tab terpotong di kanan** — `ui.tsx` komponen baru `PitaGeser` (tepi kanan memudar + panah "›" selama masih ada isi di kanan; hilang di ujung); dipakai `BarisTab` dan strip tab desktop `Bingkai.tsx` (Kelola Pendataan dkk). Tab terpilih otomatis digulir ke terlihat.
6. **Monitoring Korwil** — `app/sigap/korwil/page.tsx`: tinggi baris chip dipesan (32px) saat data dimuat, supaya tab Lapangan/Administrasi tidak bergeser.

## Temuan investigasi (TIDAK diubah, butuh keputusan Iqbal)
- **/dashboard minta Masuk nama+PIN walau sudah login**: bukan bug. `/dashboard` (usulan DTSEN) memakai sesi Supabase Auth terpisah (cookie; layout mengalihkan ke `/login` → "/?lanjut="), sedangkan SIGAP memakai token di localStorage. Kartu "Admin DTSEN" sudah bertuliskan "Masuk dashboard dengan nomor HP akun DTSEN". Pilihan: (a) biarkan; (b) jembatan SSO untuk profil DTSEN yang tertaut; (c) sembunyikan kartu kecuali punya akun DTSEN.
- **"Tahap 1 dari 2" vs "Tahap 3 dari 4"**: `susunTahap` (lib/sigapTahap.ts) memberi `no: hasil.length + 1` pada daftar tahap yang sudah disaring peran, jadi nomor & total relatif terhadap peran. Pilihan: nomor global menurut urutan definisi, atau hapus nomor. Menyentuh: lib/__tests__/sigapTahap.test.ts:58, sigapPrioritas, Induk.tsx, [tahap]/page.tsx, kegiatan/[id]/page.tsx.
- **Istilah**: hitungan kemunculan di kode — "Lembar Pendataan" 102×, "Lembar Identifikasi" 41×, "Monitoring Identifikasi SLS" 3× (judul MonIdentifikasi.tsx + kartu server.ts + sidebar). Perlu Iqbal menetapkan satu nama per hal (usul: "Lembar Pendataan" = formulir KK PPL/PML; "Lembar Identifikasi SLS" = isian PML per SLS; "Monitoring Identifikasi" = pantauan admin). Judul ubin "Translok Pelatihan Petugas PSP…" adalah DATA di DB (bukan kode) — ikonnya sama dengan "Transport Lokal — Pendataan Pascabencana 2026"; pilihan: bedakan ikon atau gabungkan. Judul /bencana harus disamakan dengan nama menu setelah nama ditetapkan.
- Dibiarkan (dekoratif, bukan tab/tombol): emoji di kartu statistik /bencana (📍🏘️🧩✅📋⚠️) dan `IKON_PENGUMUMAN` (lib/sigapPengumuman.ts: ℹ️ ⚠️ ⛔).

## Belum
- Penyeragaman seluruh tombol lama ke 3 varian (hanya konstanta + pedoman; penyisiran per halaman ditunda agar risiko kecil).
- Tahap 3 (konsistensi data, investigasi hanya-baca) dan LAPORAN AKHIR.

## Catatan teknis
- Sandbox pernah menyimpan salinan basi `lib/portal/server.ts` (pakai `@supabase/supabase-js`, laptop pakai `@/lib/supabaseServer`); terdeteksi lewat diff sebelum commit dan diperbaiki dengan menerapkan ulang suntingan ke salinan laptop.
- Cek tipe sandbox tanpa node_modules: hanya error derau (React namespace/children); tidak ada TS2304/TS6133 baru dari perubahan ini.
