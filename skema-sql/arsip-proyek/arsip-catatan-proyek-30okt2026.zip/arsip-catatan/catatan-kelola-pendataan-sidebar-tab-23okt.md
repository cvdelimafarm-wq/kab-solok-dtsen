# Catatan 23 Okt 2026: Kelola Pendataan dibingkai sidebar SIGAP dengan tab runut

Status: kode SUDAH ditulis ke repo laptop; belum tsc/vitest/build/commit oleh Pak Iqbal pada saat catatan ini ditulis. Tanpa SQL, tanpa API baru.

## Keluhan user (setelah deploy 23 Okt)
1. `/sigap/kelola/pendataan` tidak punya sidebar dan tidak ada tab Administrasi; kelengkapan pendataan belum terpadu.
2. Tombol "‹ Beranda" membawa ke `/` (portal), bukan ke beranda/pusat pengelolaan SIGAP.
3. Minta tata letak dan tab seperti Kelola Pelatihan, dipilih yang berhubungan dengan pendataan dan disusun runut.

## Yang dikerjakan
- `app/sigap/kelola/pendataan/page.tsx` ditulis ulang: `Bingkai` (app/sigap/kontrak/Bingkai.tsx = Shell + tab, sama seperti Kelola Pelatihan). Tombol "‹ Beranda" lama dihapus; sidebar "Beranda" = Beranda admin SIGAP (ringkasan dan perlu tindakan).
- Tab (urutan = alur kerja), sumber tunggal `lib/sigapPendataanTab.ts` (11 tes): Ringkasan · 1 Persiapan · 2 Tim & Surat Tugas · 3 Siaran & Notifikasi · 4 Monitoring · 5 Pemeriksaan · 6 Administrasi & SPJ. Pilihan tab ikut di `?tab=`; `?tab=monitoring` (alamat lama) tetap, `?tab=unggah` -> Persiapan, tanpa `?tab` -> Ringkasan.
- Isi lama dipindah apa adanya: unggah daftar KK + riwayat + permintaan FASIH -> `UnggahKk.tsx` (tab 1); Siaran + KirimSatu (tab 3); Monitoring (tab 4).
- Baru: `Ringkasan.tsx` (KK dalam daftar, sudah didata, permintaan menunggu admin, alur 1-6 dengan tombol Buka) dan `PintuMasuk.tsx` (kartu tautan untuk tab 2, 5, 6).
- Pintu masuk: tab 2 -> /bencana (alokasi/papan tim), /sigap/kelola/translok?tab=penugasan, /sigap/kelola/pelatihan. Tab 5 -> /sigap/kelola/identifikasi, /sigap/kelola/lapangan, /sigap/kelola/foto; "Sanggahan dan pengawasan PML" dan "Penutupan wilayah" = segera. Tab 6 -> translok monitoring/verifikasi/kegiatan(tarif), /sigap/kelola/perencanaan, /sigap/kelola/pengadaan; "Kelengkapan SPJ dan paket SPJ", Honor, Perjalanan dinas = segera.
- `Shell.tsx`: kode menu baru `pendataan_kelola`; `lib/sigapMenuV2.ts`: item "Pendataan" kini `aktifKode: "pendataan_kelola"` (sidebar menandai halaman aktif); tes menu 16.
- `kelola/identifikasi/page.tsx` dan `kelola/lapangan/page.tsx`: tautan "‹ Beranda" -> "‹ Kelola Pendataan" (`/sigap/kelola/pendataan?tab=pemeriksaan`).

## Belum (tahap berikutnya, bertahap agar build aman)
- Menyematkan isi halaman berat ke dalam tab (bukan hanya tautan): /bencana (page.tsx 555 KB), identifikasi, lapangan, foto, translok admin. Aturan Next.js 15: berkas page/route tidak boleh mengekspor selain default/GET/POST dst., jadi isi harus dipindah ke berkas komponen dulu (pelajaran insiden build 23 Okt).
- Halaman identifikasi, lapangan, foto belum memakai sidebar (masih bingkai lama).
- Tab 5-6 fitur baru (sanggahan, penutupan wilayah, paket SPJ, honor, dinas) belum ada.
- Pertanyaan: tujuan "Beranda" yang dimaksud user kemungkinan `/sigap/kelola/translok?tab=beranda` (Beranda admin) -- alamat kedua pada pesan user terlihat sama dengan `/`; perlu konfirmasi.

## Uji setelah deploy
Buka /sigap/kelola/pendataan: sidebar tampil dan "Pendataan" menyala; tujuh tab; tab 1 Unggah + permintaan FASIH berfungsi; tab 3 Siaran; tab 4 Monitoring (pilihan variabel ikut `?v=`); tab 2/5/6 tautan terbuka; di HP tab muncul sebagai baris tab. Sebelum push: `npx tsc --noEmit`, `npx vitest run`, `npm run build`.
