# Catatan mockup Kertas Kerja Revisi POK SIGAP, tahap 14 (24 Okt 2026)

Mockup: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap (Versi 45). Belum ada SQL atau kode aplikasi; menunggu kata "setuju".

## Jawaban Bapak pada tahap ini
- Excel seluruh satker: Bapak menyebut sudah ada di "Laporan Fa Detail (16 Segmen)". Saya periksa ulang: berkas xlsx (dua salinan, md5 sama) hanya satu lembar, 94 baris, Program GG, Kegiatan 2906, 52 item, Rp 395.774.000. "16 Segmen" adalah nama laporan, bukan 16 kegiatan. Seluruh satker (Rp 13,4 miliar) belum ada; perlu ekspor ulang tanpa filter kegiatan.
- Koreksi dokumen kelengkapan satu per satu: ya (lewat Master, papan 14).
- SK pendelegasian KPA ke PPK: "iya" (diartikan: ada atau akan dibuat; mockup tetap memakai PPK sebagai pengesah Revisi POK).
- Rumus dan bobot skor: dibuat di Master; isi sementara oleh saya.
- Satuan: U/THN = Unit/Tahun; M2/TH = meter persegi per tahun (sudah masuk Versi 44). Pencatat kekurangan RAB: hanya ketua tim dan admin RO.

## Yang ditambahkan (Versi 45)
- Master (papan 14): bagian "Skor RAB" (bobot penarikan 35, volume 25, cakupan 20, disiplin 20; ambang Baik 85, Cukup 70; pratinjau 3 RO tertinggi dan 3 terendah; hanya PPK yang mengubah; perubahan masuk riwayat) dan bagian "Struktur anggaran" (8 level, jumlah di POK, siapa mengusulkan).
- Kewenangan bertambah dua baris (17 tindakan): mengusulkan Komponen/Subkomponen/Akun/Item (ketua tim, admin RO sebagai draf, PPK) dan mengusulkan KRO/RO/Kegiatan/Program (PPK).
- Papan 16 baru "Tambah level mata anggaran": wizard satu prosedur untuk 8 level (Program, Kegiatan, KRO, RO, Komponen, Subkomponen, Akun, Item).

## Prosedur menambah level (P1 sampai P8)
P1 pilih level dan induk; P2 isi kode, uraian, (RO: volume+satuan; Item: volume, satuan baku, harga); P3 sistem memeriksa (format kode, tidak duplikat, akun ada di Master akun, satuan baku, pengusul berwenang); P4 sistem menunjuk jalur; P5 dana harus ada sumbernya (pagu satker tetap, tanpa baris minus, penggenap tepat pagu; kekurangan tanpa pagu dicatat di papan 15); P6 disimpan sebagai baris usulan berkode sementara T-nnn (ketua tim mengajukan, admin RO menunggu ketua tim, PPK mengesahkan atau meneruskan); P7 POK resmi terbit dan dibandingkan dengan struktur lama; P8 pemadanan kode (sama: aktif; beda: dipadankan manual) dan Item diikat ke nomor item resmi dari Excel realisasi.

## Jalur menurut level (dana digeser di dalam RO)
- Item, Akun: Revisi POK (PPK sah, KPA laporan). Dasar: Pasal 173; Lampiran IV.C angka 5 a-c. Sesuai catatan PMK 23 Okt. Jika dana dari jenis belanja lain atau RO lain: DIPA jalur DJPb (Pasal 124 ayat (2)(b); Lampiran 2.q); bila menurunkan volume RO total: DJA.
- Komponen biasa, Subkomponen: Revisi POK. DUGAAN (komponen ada di POK, bukan Halaman III DIPA); tanyakan Kanwil. Komponen Khusus: DJA (Lampiran IV.C 3.e.2.d).
- RO baru: DIPA jalur DJPb. DUGAAN (RO punya satuan dan volume; Pasal 173 tidak mengizinkan mengubahnya); tanyakan Kanwil.
- KRO baru: DIPA jalur DJPb (antar-KRO dalam 1 Kegiatan di luar Pasal 173).
- Kegiatan baru: Eselon I + Kanwil DJPb (Pasal 172 ayat (1)(a)(2)); ditetapkan pusat.
- Program baru: DJA (Lampiran IV.C 2.b, 2.c, 2.af); ditetapkan pusat.
- Tambahan pagu dari pusat pada level apa pun: DJA.
- Tenggat: DJA 30 Okt 2026, DJPb 30 Nov 2026, Revisi POK 27 Des 2026.

## Pertanyaan terbuka
1. Excel Laporan Ketersediaan Dana Detail seluruh satker (ekspor ulang tanpa filter Kegiatan).
2. Jalur RO baru dan Komponen/Subkomponen baru (dugaan; tanyakan Kanwil).
3. RO dan KRO baru diajukan PPK saja, atau ketua tim yang membutuhkan boleh mengajukan sendiri?
4. Subkomponen dikelola sebagai level sendiri di SIGAP? POK PDF tidak memuatnya terpisah; hanya laporan SAKTI (mis. 052.0A).
5. Koreksi 297 dokumen kelengkapan satu per satu (Master).
