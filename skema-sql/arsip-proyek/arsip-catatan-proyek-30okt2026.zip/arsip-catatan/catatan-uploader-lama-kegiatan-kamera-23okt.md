# Uploader foto lama muncul di kegiatan bermode kamera — perbaikan (23 Okt 2026)

Pemicu: tangkapan layar "Melihat sebagai Wahyuni" menampilkan "Pilih beberapa foto sekaligus (maks 5)" + Ganti/Hapus pada kegiatan Pascabencana (mode kamera).

## Penyebab (tiga kemungkinan, yang paling mungkin: nomor 3)
1. Saklar kegiatan = 'unggah' (bukan kasus ini: kegiatan 1 = kamera).
2. Tanggal izin susulan (sengaja memakai uploader lama untuk hari lampau).
3. Gagal membaca /api/sigap/foto/mode (sinyal lemah) -> FotoKegiatan jatuh ke "unggah". Ditambah: rute unggah/hapus lama tidak memeriksa mode, hanya UI yang menahan.

## Perbaikan (disetujui user: "Setuju")
- `app/sigap/foto/modeTersimpan.ts` (baru): saklar terakhir yang berhasil dibaca disimpan di localStorage HP per kegiatan (kunci `sigap-foto-mode-v1`, umur maks 30 hari). Dipakai HANYA bila pembacaan gagal tanpa status HTTP (tidak ada sambungan). Galat server / belum pernah terbaca -> 'unggah' seperti semula. Tidak pernah memaksa kamera dari galat.
- `app/sigap/foto/FotoKegiatan.tsx`: menyimpan mode saat berhasil, memakai `modeSaatGagal` saat gagal.
- `app/api/sigap/translok/[token]/foto/route.ts` (POST & DELETE, lewat `cekAkses`): tolak 403 "Kegiatan ini memakai Kamera SIGAP…" bila `modeKegiatan` = kamera, KECUALI `akses.susulan` (tanggal izin susulan). Gagal membaca saklar di server = 'unggah' (tidak memblokir).
- Tes baru: `lib/__tests__/modeTersimpan.test.ts` (9), `lib/__tests__/translokFotoModeKamera.test.ts` (5). 14/14 lulus di sandbox; tsc tidak menambah galat.

## Asumsi kebijakan (pertanyaan terbuka, user hanya menjawab "Setuju")
Dipilih pembacaan konservatif: untuk kegiatan bermode kamera, ganti/hapus lewat rute lama DIBLOKIR pada hari biasa; pengubahan foto kamera dilakukan lewat panel nomor foto (SusunFoto) / alur permintaan penghapusan. Jika petugas perlu mengganti foto kamera di hari yang sama lewat uploader lama, longgarkan di `cekAkses`.

## Status
Kode siap di sandbox; penulisan ke laptop menunggu laptop tersambung (cocokkan dengan salinan terbaru dulu, route.ts salinan sandbox berasal dari 20 Okt).
