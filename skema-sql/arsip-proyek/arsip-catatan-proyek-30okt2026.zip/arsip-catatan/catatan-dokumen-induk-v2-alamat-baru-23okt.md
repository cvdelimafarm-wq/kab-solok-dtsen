# Catatan 23 Okt 2026: Dokumen Induk SIGAP v2 diterapkan di kode (alamat baru, menu tanpa Referensi)

Status: ditulis ke repo laptop; BELUM dijalankan tsc/vitest/build oleh user, belum commit/push/deploy. Di sandbox, 3 berkas tes terkait (sigapMenuV2, sigapNavigasi, petaKelola) lulus 35/35 dengan vitest terpasang terpisah.

Dasar: "setuju semua" dibaca sebagai menyetujui seluruh USULAN Claude di Dokumen Induk SIGAP v2 (lihat rekap-audit-navigasi-dan-pekerjaan-tertunda-23okt.md bagian D butir 6).

## Yang berubah
- Alamat baru `/sigap/kelola/monitoring` (isi = halaman lapangan) dan `/sigap/kelola/spj` (isi = halaman admin) lewat PETA_KELOLA di next.config.js (rewrite + pengalihan 307, query dipertahankan). `/sigap/kelola/lapangan`, `/sigap/admin` dialihkan ke alamat baru. `/sigap/kelola/translok` kini hanya pengalihan ke `/sigap/kelola/spj` (daftar ALIAS_LAMA, tanpa rewrite). `/sigap/pelatihan/kelola` -> `/sigap/kelola/pelatihan` sudah ada sebelumnya. `/sigap/translok/<token>` dan `/api/...` tidak disentuh.
- lib/sigapMenuV2.ts: kelompok "Referensi" dihapus (6 kelompok). Monitoring -> `/sigap/kelola/monitoring`. "Audit dan bukti" = Register & arsip bukti (`/sigap/kelola/pedia`) bagi pengelola PEDIA, selain itu "segera". SIGAP PEDIA (`/sigap/pedia`, terlihat semua akun) pindah ke Pengelolaan setelah Tata kelola (KEPUTUSAN CLAUDE: dokumen induk belum menaruhnya; supaya tidak hilang dari sidebar).
- Semua tautan internal ke alamat lama diganti ke alamat baru: Shell (pindah tab/kegiatan), admin/api.ts (cadangan login), akses/page.tsx (3 tempat), kelola/page.tsx (modul pertama admin), api/sigap/pedia/route.ts (tautan kegiatan), lib/portal/server.ts (kartu admin).
- Nama tampil "Admin Transport Lokal" -> "Administrasi & SPJ": judul kecil halaman admin, pesan tanpa izin, tautan di /sigap/akses, kartu portal (kode `admin-translok` tetap), teks di Kelola Aplikasi, label tombol Kembali.
- lib/sigapNavigasi.ts: induk `/sigap/kelola/monitoring` = Kelola Pendataan (sama dengan lapangan); label spj/translok = "Administrasi & SPJ", monitoring = "Monitoring Lapangan".
- Tes: sigapMenuV2.test.ts (diperbarui, 17 tes), sigapNavigasi.test.ts, baru lib/__tests__/petaKelola.test.ts (rewrite/redirect, tanpa pengalihan berantai).

## Sengaja tidak diubah
- `portal_aplikasi.href` di DB (translok `/sigap/admin`, kontrak `/sigap/kontrak`): tetap berfungsi lewat pengalihan; ubah nanti bila mau (UPDATE terpisah).
- Nama modul "Anggaran & SPJ" belum muncul di UI aplikasi (hanya di dokumen/mockup); menu Anggaran masih "segera".
- Petugas -> SDM & Mitra, wilayah -> Pengaturan > Data induk wilayah: halamannya belum ada (SDM & Mitra "segera"); tidak ada kode.
- 11 artboard = Tahap 1: hanya kanvas mockup, tidak ada kode.
- Pertanyaan terbuka lain (satu register regulasi, Beranda per peran, 4 tahap vs GSBPM, data pribadi) tidak menyentuh kode.

## Uji manual setelah deploy
1. Buka `/sigap/admin?tab=verifikasi`, `/sigap/kelola/translok`, `/sigap/kelola/lapangan` -> masing-masing berpindah ke alamat baru dengan parameter utuh. (SUDAH diuji di Chrome user 23 Okt: ketiganya berpindah benar, parameter utuh, sidebar tanpa Referensi.)
2. Sidebar: tidak ada grup Referensi; Monitoring, Administrasi & SPJ (sub-menu), Audit dan bukti (akun pengelola PEDIA), SIGAP PEDIA di Pengelolaan terbuka benar; palet Ctrl+K sama.
3. Tombol Kembali dari Monitoring (-> Kelola Pendataan) dan dari Administrasi & SPJ (-> Beranda).
4. Tautan push/pengingat lama (`?tab=hari_kerja&tgl=`) tetap membuka tab yang benar.

## Tambahan (23 Okt, sore): nama "Monitoring" tidak lagi ganda
- Sub-menu di bawah Administrasi & SPJ yang tadinya "Monitoring" (isi: kelengkapan SPJ transport lokal per petugas + izin susulan) diganti "Kelengkapan SPJ": `MENU_ADMIN` di app/sigap/admin/Shell.tsx (sidebar, palet, tab HP, breadcrumb) dan `SUB_ADMINISTRASI` di lib/sigapPendataanTab.ts (tab "6 · Administrasi & SPJ" di Kelola Pendataan, dulu "Monitoring transport lokal"). Kode (`monitoring`), izin (`translok.monitoring`) dan alamat (`?tab=monitoring`) TIDAK berubah, jadi tautan lama tetap jalan.
- Sekarang "Monitoring" hanya berarti: menu Pengendalian (Monitoring Lapangan) dan tab "4 · Monitoring" Kelola Pendataan (progres pendataan). Tes baru di sigapPendataanTab.test.ts.
