# Draft plotting keroyokan v3 (9 Okt 2026) - Tim Lia sesuai catatan tulisan tangan

File: Draft_Plotting_Keroyokan_88Petugas_v3_TimLia_9Okt2026.xlsx. Menggantikan versi 8 Okt (88Petugas_8Okt2026) sebagai acuan terbaru. STATUS: SUDAH DITERAPKAN ke alokasi petugas (9 Okt, siang) - lihat bagian "Penerapan ke alokasi petugas".

## Arahan baru user (9 Okt)
- Tim Lia angraini (PML 431) = 6 PPL: Rivo Nofri Armon (442), Ira Wahyuni (426), Novi Endria Jhoni (437), Nurul vani fatia (439), Dara muhaima febriana (420), M. Hafizh Dinu Aulia (432).
- 7 Sub SLS terkunci sesuai catatan: Tikalak Pasir 01 -> Rivo; Pasir 02 & 03 -> Ira; Kacang Tembok 01 -> Novi; Tembok 02 -> Nurul; Biteh 01 -> Dara; Biteh 02 -> Hafiz. Jarak 0,2-4,3 km (semua <5 km).
- Ambang 160/PPL tetap. Jika memenuhi ambang mengorbankan jarak, beban dikurangi atau Sub SLS tidak diplot dan dijadikan "Plot Sub SLS Bantuan Keroyokan" (terbuka bagi tim dari luar yang bersedia) + pesan ke petugas di sigap/bencana (draf ada di sheet Draf Pesan Bantuan, belum dikirim/dipasang).
- Keputusan: Febri Handayani masuk tim terdekat (tim Ayu Sepriani bersama Amelia, Bayu pratama, Mega Okra); PML usyenti memimpin tim baru (Rini Nofsiska Sari, Robi Alvian, Yovinda Oktasia Rahmi); Sub SLS >=10 km dari PPL penugasan atau melebihi ambang disisihkan jadi bantuan keroyokan.

## Perbedaan struktur vs draf 8 Okt
Tim Lia 3 PPL (Febri, Ira, Rivo) -> 6 PPL; Tim 04 (usyenti) kehilangan Novi/Nurul/Dara/Hafiz sehingga tim disusun ulang; Febri berpindah tim. Tim lain ikut bergeser karena re-klaster.

## Hasil
- 18 tim, 70 PPL, tim 3-6 PPL (11 tim berukuran 4).
- Terplot 8.673 skor (53%); Bantuan Keroyokan 88 Sub SLS ±7.653 skor (47%): X Koto Singkarak 32, Junjung Sirih 17, Danau Kembar 14, Lembah Gumanti 13, Kubung 12.
- Beban PPL <=160 semua (rata-rata ±134); zona skor plot: 58% <5 km, 42% 5-10 km, tidak ada >=10 km.
- 21 PPL punya sisa kapasitas >=20 poin; 13 di antaranya tak punya Sub SLS bantuan <10 km (calon relawan 10-15 km, terutama Gunung Talang/Kubung).
- Asumsi: jarak jalan = 1,35 x garis lurus (OSRM belum dipakai); batas 10 km dapat diubah (dihitung ulang).

## Pembaruan penetapan PML (9 Okt, siang)
- Arahan: Ardial Jaraf, Ilham, Hariston tetap PML. Ilham = tim selatan. PML mitra memilih tim terdekat lebih dulu (penetapan optimal), baru Ardial Jaraf dan Hariston mengambil tim terdekat dari sisa.
- Hasil: semua PML mitra <=11 km dari wilayah timnya (Dessy Meiyarni 11 km, Yeni siswanti 7,7 km; lainnya <=5 km). Hariston 1,3 km (Tim 12). Ardial Jaraf ±18 km (Tim 01, wilayah Gunung Talang; koordinat perkiraan). Ilham 33 km (tim selatan, berpindah antar lokasi).
- Susunan PPL per tim dan hasil plot Sub SLS tidak berubah; hanya penetapan PML dan nomor tim yang bergeser.

## Kolom Perkiraan Jumlah KK Terdampak (9 Okt, siang)
- Sheet Plot Sub SLS punya kolom "Perkiraan Jumlah KK Terdampak" (setelah Hari kerja porsi) = KK terdampak Sub SLS x porsi. Sheet Bantuan Keroyokan punya kolom serupa untuk porsi yang belum diplot.
- Sumber: fungsi Supabase bencana_kertas_kerja_beban() (kk_terdampak_estimasi; skor draf = skor_beban_pendataan), disalin ke sheet Data KK Terdampak.
- Total ±9.887 KK terdampak (228 Sub SLS): ±4.799 pada porsi terplot, ±5.090 pada bantuan keroyokan. Balai Gadang masih 135,5 KK/Sub SLS (isian lama terjumlah; PDF = 31), keputusan A/B menunggu user.

## Penerapan ke alokasi petugas (9 Okt, siang) - SELESAI
- User mengunggah file v3 (kolom PML ditambah) dan minta plotting diterapkan ke alokasi petugas. Isi file sama persis dengan draf v3 (169 porsi, 70 PPL, 18 PML; 88 ID petugas cocok dengan bencana_petugas).
- bencana_alokasi_subsls dibaca sistem lewat bencana_kertas_kerja_alokasi(): porsi_kk = bagian dari kk_total (porsi_kk/kk_total x skor), NULL = seluruh Sub SLS. pml_id = PML tim; mode_kerja 'keroyok'; terkunci true; jarak_metode 'haversine_fallback' (jarak jalan estimasi 1,35x); jarak_status 'perkiraan_nagari' untuk 3 PPL berkoordinat perkiraan (Amelia 411, Febri 389, Rini 466), selain itu 'riil'.
- Cadangan: bencana_alokasi_subsls_cad_20261009 (214 baris lama), bencana_petugas_atasan_cad_20261009 (atasan_id 473 petugas). Data baru: bencana_alokasi_subsls_baru_20261009 (169 baris), bencana_atasan_baru_20261009 (70 PPL -> PML). Tabel ini boleh dipertahankan sebagai arsip.
- Tool Supabase di sesi Claude TIMEOUT pada DELETE, sehingga user menjalankan sendiri terapkan_plotting_v3_20261009.sql di SQL Editor (hasil: alokasi_baru = 169).
- Verifikasi Claude setelah dijalankan: alokasi 169 baris, 70 PPL, 18 PML, total skor 8.673,2; beban akhir PPL maks 159,93 / rata-rata 138,1 (0 PPL di atas 160); atasan_id 70 PPL sudah sesuai; Tim Lia berisi 6 PPL (Dara, Ira, Hafizh, Novi, Nurul, Rivo).
- 88 Sub SLS yang disisihkan (bantuan keroyokan) kini tidak punya alokasi.
- Rollback: blok komentar di akhir file SQL (kembali ke tabel _cad_).

## Belum diputuskan / tindak lanjut
- Isi kata "tim dari luar ....." pada pesan bantuan (diisi "wilayah" sementara).
- Apakah fitur Plot Sub SLS Bantuan Keroyokan + pesan dibangun di SIGAP (sigap/bencana); saat ini 88 Sub SLS belum terlihat oleh petugas manapun.
- Batas jarak 10 km vs lebih longgar; PML Ilham/Hariston/Ardial koordinat masih perkiraan (Ardial 18 km mungkin berubah bila koordinat asli ada).
