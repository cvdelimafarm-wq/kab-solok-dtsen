# Batch menunggu deploy dan rencana uji produksi (25 Okt 2026)

Menggantikan bagian "Urutan berikutnya" pada claude/status-bangun-kertas-kerja-revisi-24okt.md.

## Menunggu deploy (25 Okt, tahap 26; rincian di claude/status-tahap26-cek-pagu-alur-realisasi-25okt.md)
Cek pagu per akun per RO + alur impor realisasi (batch 1), lalu Sahkan dengan lampiran PDF POK resmi, tab Cek pagu di Versi POK, formulir impor POK dilipat, bagian D di Alur, dan kertas kerja tetap dapat diubah sampai Sah (batch 2). Perubahan SQL `20261025y_keu_kk_ubah_sampai_sah` SUDAH diterapkan ke produksi lebih dulu (fungsi keu_kk_izin, keu_kk_keputusan_cek, keu_kk_tolak); aplikasi lama tidak terpengaruh karena hanya melonggarkan kondisi untuk jadwal pok/administrasi berstatus diterapkan.

## Sudah di-deploy dan diuji produksi (25 Okt)
Batas lebar kartu laptop, papan 2 Alur, papan 3 Pemicu, papan 4 Lampiran, papan 5 Status, papan 13 Administrasi (tata letak), papan 15 Kekurangan, papan 12 bagian 3 skor RAB, akun 512212 di master, alasan versi RAB (min. 10 karakter), panel jalur penutup di Kecukupan KRO, ekspor Excel/CSV Buku selisih.

Kamera SIGAP, tab Arsip (25 Okt, diuji di lebar HP 390px):
- Nomor foto boleh diatur sampai umur tanggal 5 hari (lihat claude/status-susun-foto-5hari-25okt.md).
- Petunjuk foto cadangan disorot dua langkah: "1. Ketuk satu foto" lalu "2. ketuk nomor tujuannya"; foto cadangan terpilih berlatar kuning. Terverifikasi.
- Panel foto Arsip dilebarkan mentok kiri-kanan di HP (mode `penuh` pada FotoKegiatan, `rapat` pada SusunFoto; margin negatif panel di translok/[token]/page.tsx). Ubin 3 kolom kini 120px pada layar 390px. Terverifikasi. Di layar >=640px tampilan lama (bergaris kartu) tetap.

Audit tertimpa/tertutup (25 Okt, 390px dan 1280px): tidak ada halaman yang meluap ke samping; bar bawah Translok tidak menutup isi (jarak >=53px di kelima tab); halaman /sigap/revisi, kertas, buku, alur, pemicu, status, lampiran, versi, struktur, /sigap/kelola/translok tanpa kartu yang saling menindih (temuan di matriks Kertas Kerja hanya baris di dalam kotak gulir dan header lengket, wajar).

## Belum teruji tulis di produksi
Tombol perpindahan status, geseran, keputusan PPK, Kembalikan, tulis Administrasi (Tandai draf siap/unggah/verifikasi), penerapan keputusan kesempatan (perlu tambahan pagu fiktif terbuka), dan (baru) ubah kertas kerja saat jadwal pok/administrasi berstatus diterapkan.

## Celah yang masih terbuka
- (Selesai, diganti model baru 25 Okt) Padanan baris POK baru/hilang tidak diperlukan; diganti cek pagu per akun per RO.
- Persetujuan KPA saat pagu di bawah realisasi (R-06; butuh aturan siapa menyetujui dan kapan).
- Ditunda sampai 2027: sumber Booked, pengurangan realisasi SPAN, pencabutan kewenangan.
- Hari libur (LIBUR hanya akhir 2026).
