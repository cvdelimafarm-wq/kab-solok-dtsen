# Tahap 26: cek pagu per akun per RO dan alur impor realisasi (25 Okt 2026)

## Keputusan Bapak (25 Okt 2026)
- Impor POK hanya di awal tahun anggaran. Sepanjang tahun yang diimpor hanya realisasi (GLP039).
- Revisi POK: proses sah yang sebenarnya ada di SPAN dengan acuan hasil kertas kerja. Di SIGAP, agar kertas kerja tidak berubah, PPK menekan Sahkan dan melampirkan PDF POK resmi dari SPAN.
- Fitur yang dibutuhkan sepanjang tahun hanya CEK: pagu tiap akun pada tiap RO sama dengan POK. Tidak sampai level item/uraian.
- Bila beda: PERINGATAN (bukan penghalang) dan langsung diarahkan ke kertas kerja untuk mengubahnya, karena yang dipakai seharusnya POK resmi.
- Tempat cek: saat unggah realisasi, saat Sahkan (menerapkan revisi), dan di halaman Versi POK.
- Akibatnya padanan baris POK baru/hilang (tugas 144) tidak diperlukan; diganti cek per akun.
- Rencana batch 2 disetujui Bapak ("sesuai"), termasuk perubahan SQL.

## Batch 1 (di repo, menunggu deploy; tanpa SQL)
- lib/keu/cekPagu.ts: pembanding per (RO, akun): sama / beda / hanya di resmi / hanya di sistem; lingkup `ro_resmi` (bawaan, untuk GLP039 yang bisa memuat satu kegiatan), `irisan` (kertas kerja yang baru memuat sebagian RO), `semua`; toleransi; pembungkus sumber (GLP039, POK berlaku keu_v_adm_lembar, kertas kerja keu_v_kk_baris kolom Menjadi, PDF POK); tautanKertasKerja(ro, jadwal). 10 tes.
- lib/keu/alurRealisasi.ts: lima langkah (1 siapkan/pilih berkas, 2 periksa berkas, 3 cocokkan pagu dengan POK, 4 kirim, 5 pantau dampak) dengan status selesai/sekarang/menunggu/perlu perhatian; pagu beda hanya memberi perhatian, tidak menghalangi kirim. 12 tes.
- app/sigap/revisi/CekPaguAkun.tsx: KartuCekPagu (ringkasan, daftar RO bermasalah, tabel akun, tombol "Buka kertas kerja"), hook useSisiSistem, statusCek.
- app/sigap/realisasi/page.tsx: penunjuk 5 langkah, pilihan pembanding (POK berlaku atau kertas kerja yang sudah diterapkan/sah), kartu cek pagu di dalam kartu unggah, kartu "Langkah 5: dampak".

## Batch 2 (di repo, menunggu deploy; SQL y SUDAH diterapkan ke produksi)
1. SQL `20261025y_keu_kk_ubah_sampai_sah` (berkas di skema-sql/fase-b): kertas kerja jadwal berjenis pok/administrasi tetap dapat diubah sampai Sah (status `diterapkan`), lewat keu_kk_izin, keu_kk_keputusan_cek, keu_kk_tolak. DIPA tetap beku sejak diterapkan. Pada status selain `dibuka`, hanya yang berwenang `sahkan` (PPK) yang lolos. Diverifikasi dengan pg_get_functiondef. BELUM diuji tulis di produksi (uji setelah deploy).
2. Halaman Status (`/sigap/revisi/status`): aksi Sahkan mewajibkan melampirkan PDF POK resmi SPAN. PDF dibaca di perangkat (bacaBerkasPok), pagu per RO+akun (paguDariPdf) dibandingkan dengan kolom Menjadi kertas kerja jadwal itu (lingkup `irisan`). Beda = peringatan + tautan "Buka kertas kerja"; TIDAK memblokir. Catatan riwayat otomatis memuat nama berkas, 12 karakter awal SHA-256, dan hasil cek (maks 300 karakter; catatan pengguna dipotong lebih dulu). PDF yang tidak lolos pemeriksaan jumlah atau tanpa baris menahan Sahkan. Label tombol: "Sahkan revisi POK (lampirkan PDF POK resmi SPAN)". Tautan "Lanjut ke impor hasil penetapan" diganti "Cek ulang pagu di halaman Versi POK". Helper murni di lib/keu/status.ts: perluLampiranPok, periksaLampiranPok, catatanSahDenganPdf (tes ditambah).
3. Halaman Versi POK: tab baru "Cek pagu per akun" (acuan: laporan realisasi terakhir keu_v_realisasi_terbaru; pembanding: POK berlaku atau kertas kerja terpilih). Tab RPD/Dampak tidak lagi memuat kertas kerja kecuali dipilih.
4. Halaman POK resmi (`/sigap/revisi/pok`): formulir impor PDF dilipat bila POK berlaku sudah ada ("khusus awal tahun anggaran", ada tombol buka formulir dan tautan ke Status). Daftar unggahan dan Banding per baris tetap. Teks penjelasan diperbarui.
5. Halaman Alur: C1 menjadi "Lampirkan PDF POK resmi dan cek pagu per akun" (tautan ke Status), B1 dan P4 disesuaikan, bagian baru "D. Impor realisasi sepanjang tahun" (D1-D5, tautan ke /sigap/realisasi dan /sigap/ro). alur.test.ts: tautan boleh diawali /sigap/.
6. Halaman Kertas kerja: jadwal pok/administrasi berstatus diterapkan diurutkan setelah draf (lalu jadwal lain) dan berlabel "Diterapkan, menunggu Sah (masih dapat disesuaikan dengan POK resmi)".

## Pemeriksaan
- tsc di overlay: tidak ada galat pada berkas yang diubah (galat tersisa hanya dari salinan overlay usang: kertas/page.tsx terhadap RabInline/matriks, kecukupan).
- vitest: status, alur, cekPagu, alurRealisasi lulus (47 tes).

## Uji produksi setelah deploy (data fiktif)
- Realisasi: pilih GLP039 fiktif, lihat penunjuk 5 langkah dan kartu cek pagu; ubah satu pagu akun untuk melihat peringatan.
- Status: jadwal pok berstatus diterapkan, lampirkan PDF POK (pagu sama dan beda), pastikan Sahkan tetap jalan dan catatan riwayat memuat nama/sidik jari/hasil cek.
- Kertas kerja: saat jadwal diterapkan (pok/administrasi), PPK dapat mengubah sel; non-PPK ditolak; DIPA tetap terkunci; setelah Sah terkunci.
- Versi POK: tab Cek pagu per akun.
- POK resmi: formulir terlipat, tombol buka formulir bekerja.
- Alur: bagian D dan tautan.
