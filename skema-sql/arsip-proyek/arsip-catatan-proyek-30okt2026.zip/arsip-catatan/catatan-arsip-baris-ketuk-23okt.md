# Catatan: tab Arsip petugas — baris dapat diketuk, tombol melayang dihapus, penyederhanaan (23 Okt 2026)

Berkas: `app/sigap/translok/[token]/page.tsx` (hanya berkas ini).

Permintaan: tiap baris jenis SPJ di kartu "Arsip per tanggal" dapat ditekan dan merujuk ke tempat yang sesuai; tombol melayang "Unduh SPJ" dihapus; cari fungsi/tombol ganda atau mirip dalam satu halaman.

Perilaku baru (kartu per tanggal):
- Laporan -> membuka isian laporan tanggal itu di bawah kartu (KartuHari hanya="laporan"); ketuk lagi menutup.
- Dokumentasi -> membuka nomor foto tanggal itu (KartuHari hanya="foto"; Kamera SIGAP / susun foto seperti biasa). Hari terlewat tetap menampilkan alasan + tombol WhatsApp izin susulan.
- Surat Tugas (bila ada file), Kwitansi, Visum, Surat Pernyataan Kendaraan Dinas -> lembar Unduh terbuka dengan rentang (kelompok tanggal yang memuat hari itu, atau "semua" untuk Surat Tugas) dan jenis dokumen itu sudah terpilih. Baris yang tidak masuk (hari rencana / tidak lengkap) tidak dapat diketuk.
- `LembarUnduh` mendapat prop `jenisAwal` dan `rentangAwal`.

Dihapus / digabung:
- Komponen tombol melayang `TombolUnduhMelayang` (+ posisi di localStorage `sigap_fab_unduh_pos`), padding bawah halaman pb-44 -> pb-28.
- Tab Arsip: daftar 6 jenis ("Ringkasan seluruh periode") dan tombol "Unduh SPJ…" -> diganti satu kartu "Kwitansi, Visum & Surat Pernyataan" per kelompok tanggal (ketuk = unduh kelompok; "Semua tanggal" bila > 1 kelompok); peringatan hari terlewat dilipat ke kartu itu.
- Kartu per tanggal: dua tombol (Unduh tanggal ini + Lihat laporan & foto / Lengkapi) -> satu tombol Unduh; tanggal ganda di dalam isian dihilangkan (`tanpaJudul`); teks ringkasan atas "x lengkap · y perlu dilengkapi" -> "x hari lengkap" (jumlah belum lengkap sudah ada di chip filter).
- Tab Hari Kerja: baris "Jumlah hari kerja" di ringkasan dihapus (sama dengan lencana N / maks M hari); kalimat legenda yang mengulang catatan mode edit dipangkas.
- Panduan login langkah 5 (ArsipDokumen ringkasSaja) tidak berubah, hanya tanpa kartu per tanggal.

Belum diubah (usulan): "Status per hari kerja" di tab Hari Kerja mirip dengan kartu Arsip per tanggal (sama-sama status per hari + isian laporan/foto). Tautan dalam ?tab=hari_kerja&tgl= masih memakainya, jadi dibiarkan menunggu keputusan.

Uji setelah deploy: ketuk tiap baris pada hari ini / hari lampau lengkap / hari terlewat / hari rencana; unduh dari baris Kwitansi, Visum, Surat Pernyataan, Surat Tugas (rentang & centang sudah benar); baris kelompok & "Semua tanggal"; tombol melayang tidak muncul di tiga tab; panduan langkah 5 tetap tampil.

## Tambahan (23 Okt 2026, sore): daftar "Status per hari kerja" digabung ke Arsip per tanggal
- `DaftarHari` dihapus dari tab Hari Kerja translok (tab itu kini hanya kalender pemilihan hari + ringkasan).
- Tautan lama `?tab=hari_kerja&tgl=<tanggal>[&fokus=laporan|foto]` dialihkan di sisi klien: tab Arsip membuka tanggal itu dan, bila `fokus`, langsung membuka isian laporan/foto. `lib/sigapTautanKerja.ts` tidak diubah.
- `Shell.tsx`: label tautan ke `/` "Beranda SIGAP" -> "Portal utama".
