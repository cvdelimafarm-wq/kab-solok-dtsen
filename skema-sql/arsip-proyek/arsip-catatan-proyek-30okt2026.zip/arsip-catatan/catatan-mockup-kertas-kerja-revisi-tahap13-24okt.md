# Catatan mockup Kertas Kerja Revisi POK SIGAP, tahap 13 (24 Okt 2026)

Mockup: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap (Versi 44). Belum ada SQL atau kode aplikasi; menunggu kata "setuju".

## Keputusan Bapak (jawaban atas pertanyaan terbuka tahap 12)
1. Sumber data otomatis: Excel (lihat uji di bawah). 
2. Verifikasi dokumen administrasi: PPK dan/atau bendahara, atau akun lain yang diberi kewenangan (contoh di mockup: Tata Usaha diberi PPK).
3. PPK yang merangkap ketua tim: RAB-nya langsung sah (tidak ke KPA).
4. Sah atau tidaknya revisi cukup di PPK saja; KPA hanya menerima laporan. (Catatan: Pasal 173 PMK menyebut Revisi POK wewenang KPA; perlu SK pendelegasian dari KPA agar dasar tertulisnya ada.)
5. Skor kualitas RAB terlihat oleh semua orang, khususnya PPK, bendahara, ketua tim, tata usaha, KPA.
6. Item tanpa lembar subject matter: dokumen digenerate dari pola umum; ada menu Master (akun, anggaran: satuan/waktu/kewenangan, dan master lain).
7. Seksi "D" ganda di Excel kelengkapan: oke (diganti E).
8. Dana penggenap tidak boleh minus sementara; penggenap wajib sesuai pagu; kekurangan RAB yang belum ada anggaran resminya dicatat, dan saat pusat menambah pagu lewat revisi DJA/DJPb ketua tim memutuskan tiap catatan: penuhi, tunda, atau tolak.

## Keputusan tambahan (Versi 43 dan 44)
- Arti satuan dikonfirmasi: OJP = Orang/Jam/Pelajaran; THN = Tahun; EA = Each (per unit); M2 = Meter persegi; OT = Orang/Tahun; U/THN = Unit/Tahun; M2/TH = meter persegi per tahun. Di Master (papan 14) semuanya berstatus pasti; U/THN dan M2/TH tetap baris tersendiri (tidak digabung ke THN atau M2). Alias SEGMN digabung ke SGMN.
- "Upayakan semua dokumen, buat saja sebisamu dulu, nanti koreksi satu per satu": seluruh 297 dokumen kelengkapan (265 lembar subject matter + 32 pola umum) ditandai dapat dibuat SIGAP sebagai tahap pertama (GEN_SEMUA). Di Master ada daftar "Dokumen kelengkapan: koreksi satu per satu" dengan tombol dapat dibuat dan "Sudah dikoreksi" per dokumen.
- Pencatat kekurangan RAB: cukup ketua tim dan admin RO untuk RO sendiri; anggota tim tidak mencatat (sesuai model yang sudah ada, teks papan 15 dipertegas).

## Uji baca berkas contoh (berkas "Laporan Fa Detail 16 Segmen", Excel dan PDF)
- Laporan Ketersediaan Dana Detail (GLP039), periode September 2026, hanya Kegiatan 2906 (2 RO, Rp 395.774.000, 52 item).
- Excel diunggah ulang pada 24 Okt: md5 identik dengan sebelumnya, tetap hanya Kegiatan 2906. Berkas seluruh satker (Rp 13,4 miliar) belum ada.
- Excel: terbaca benar semua. Pemeriksaan: total = jumlah item (pagu, lock, realisasi, sisa); tiap akun = jumlah item (12/12); s.d. periode = lalu + ini (52/52); sisa = pagu - lock - s.d. (52/52); 52 dari 52 item cocok dengan POK menurut RO+komponen+akun+uraian. Perlu ditangani: baris catatan kaki "*Lock Pagu" di pergantian halaman (dilewati) dan baris sambungan uraian berangka duplikat (teks digabung, angka diabaikan).
- PDF: 2 dari 52 baris salah/hilang (item 000260 tanpa angka; item 000552 mendapat angka baris lain, selisih Rp 2.692.000), persen terpotong. Hanya untuk tampilan/pembanding.
- PDF POK RKKS 30 Sep 2026: 38 RO, 677 baris, jumlah tiap RO dan alokasi Rp 13.431.536.000 cocok persis. Selisih pembulatan harga satuan ada pada 29 baris (jumlah biaya yang dianggap benar, bukan volume x harga).
- Lock Pagu (catatan kaki laporan): pagu yang sedang dalam proses usulan revisi DIPA/POK; hilang setelah usulan selesai. RO 2906.BMA.005: pagu revisi 10.682.000, lock 1.823.000, POK 30 Sep 8.859.000 (selisih = lock).
- Nomor item (mis. 000252) hanya ada di laporan realisasi: kandidat kunci stabil item.
- Parser acuan: `claude/referensi/parser-laporan-fa-detail-xlsx.py`.

## Papan baru dan perubahan di mockup
- Papan 14 Master data: akun (43 akun dari POK + tambah/nonaktifkan, pola dokumen), satuan (20 baris baku, semua pasti), kelompok belanja dan prioritas, waktu, kewenangan (matriks 15 tindakan x 9 peran; hanya Admin yang ubah), pola dokumen (7 pola: PEG, BRG, LGN, JSA, PDN, MLH, MDL), koreksi dokumen kelengkapan (297 dokumen), tim/peran/status, riwayat perubahan. Yang boleh mengubah master: Admin dan PPK.
- Papan 15 Catatan kekurangan RAB: catat (ketua tim/admin RO), PPK mencatat tambahan pagu resmi (DJA/DJPb), ketua tim memutuskan penuhi/tunda/tolak (tolak wajib alasan, total dipenuhi <= tambahan), sisa tambahan menjadi dana penggenap, tunda muncul lagi pada tambahan berikutnya.
- Papan 13: item tanpa lembar memakai pola umum (chip "Pola umum"); semua dokumen kini dapat dibuat SIGAP (tahap pertama); verifikasi lewat kewenangan (Tata Usaha dapat diberi).
- Papan 12: kartu uji baca Excel vs PDF.
- Papan 10: PPK mengesahkan, KPA menerima laporan; PPK merangkap ketua tim langsung sah; baris matriks baru.
- Papan 11, Alur, Status, Main: teks PPK sah, KPA laporan; Main R-17 (tidak ada baris minus; pagu RO yang berubah karena pergeseran antar-RO hanya info).

## Pertanyaan terbuka berikutnya
1. Berkas Excel Laporan Ketersediaan Dana Detail seluruh satker (bukan hanya 2906) untuk uji kedua.
2. Koreksi isi dokumen kelengkapan satu per satu lewat Master (297 dokumen, semuanya tahap pertama).
3. SK pendelegasian KPA ke PPK untuk pengesahan Revisi POK.
4. Rumus dan bobot skor (sekarang ILUSTRASI).
