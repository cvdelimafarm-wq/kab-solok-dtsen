# Tahap 26: hasil uji produksi

## Hasil uji produksi (25 Okt 2026, Chrome, akun IH, data fiktif)
Lulus:
- Halaman Alur: bagian D dan tautan tampil.
- Status: Sahkan ditolak tanpa PDF; dengan PDF fiktif sukses; riwayat memuat nama berkas, sidik jari 12 karakter, hasil cek pagu. Cek pagu "Sama" dan "beda" tampil dengan tautan kertas kerja.
- Kertas kerja: edit saat jadwal Diterapkan tersimpan (SQL y bekerja); label "Diterapkan, menunggu Sah (masih dapat disesuaikan dengan POK resmi)". Jadwal #8 setelah Sah: pesan "dapat diubah saat jadwal dibuka atau diterbitkan" (terkunci).
- Realisasi: berkas GLP039 fiktif (GLP039_FIKTIF_UJI_25Okt2026.xlsx) dibaca; penunjuk 5 langkah berjalan (langkah 1-2 selesai, 3 perlu perhatian, 4 sekarang, 5 menunggu); kartu cek pagu: "1 dari 9 akun berbeda ... (1 RO)", RO 2906.BMA.005 akun 524113: laporan 6.545.000 vs POK berlaku revisi 2 6.495.000, selisih +50.000; 33 RO tidak dibandingkan; tautan /sigap/revisi/kertas?ro=2906.BMA.005. Kirim TIDAK ditekan (tidak ada data realisasi baru).
- Versi POK: tab "Cek pagu per akun" tampil (kosong karena belum ada realisasi diterima).
Catatan teknis uji: berkas uji dimasukkan ke kolom unggah lewat skrip (DataTransfer) karena folder keluaran tidak dibagikan ke unggah Chrome.
Efek samping data fiktif: jadwal #8 (UJI Sahkan PDF fiktif) berstatus Sah, 56 baris POK dimuat; jadwal #7 berstatus terkumpul (Ditutup).
Perbaikan susulan: teks J5 "Sah" di /sigap/revisi (app/sigap/revisi/page.tsx) diganti sesuai model baru (sudah di repo, menunggu deploy).
Belum teruji: Versi POK dengan data realisasi nyata; non-PPK ditolak saat diterapkan; DIPA tetap beku; formulir POK resmi terlipat (halaman /sigap/revisi/pok); edit kertas kerja ditolak setelah Sah (hanya terlihat dari pesan, belum uji tulis).
