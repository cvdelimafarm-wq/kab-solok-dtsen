# Status tahap 20: papan 5 (Siklus status, peran, dan riwayat)

Tanggal: 25 Okt 2026. Papan mockup: "Status dan Riwayat" (Status.dc.html). Alamat halaman: `/sigap/revisi/status?jadwal=<id>`.

## Keputusan rancangan
Mockup memodelkan satu siklus per versi: Draf, Diterapkan, Disetujui, Diajukan, Hasil resmi, dengan peran yang dipilih di layar. Produksi sudah punya siklus jadwal sendiri (terjadwal, dibuka, terkumpul, diterapkan, sah, dilewati) lewat `keu_jadwal_aksi`, dan peran asli dari login. Maka:
1. Tahap pada kartu dipetakan ke siklus produksi: POK dan Administrasi = Pengumpulan usulan, Ditutup, Diterapkan di SAKTI, Disahkan. DIPA = ditambah Diajukan dan Hasil resmi (Dikembalikan, Ditolak, atau Disahkan).
2. Pengajuan, dikembalikan, ditolak, dan perbaikan untuk DIPA belum ada di basis data, sehingga ditambah tabel riwayat. Status jadwal tidak diubah (tetap `diterapkan` sampai sah); posisi diturunkan dari baris riwayat terakhir. Dengan begitu `keu_revisi_jadwal`, pemicu, dan papan 11 tidak tersentuh.
3. "Masuk sebagai" (pilihan peran mockup) diganti kewenangan akun yang sebenarnya (`keu_boleh(jadwal)`); tabel "Siapa boleh apa" dibaca dari master peran dan kewenangan.

## SQL `20261025u_keu_jadwal_riwayat.sql` (terpasang di produksi sebagai migrasi `keu_jadwal_riwayat_u`)
- Tabel `keu_jadwal_riwayat` (append-only: pemicu menolak ubah dan hapus dari aplikasi): jadwal, waktu, aksi, status_ke, nomor, tanggal, catatan, oleh. Diisi awal dengan satu baris `awal` per jadwal (jejak audit umum tidak memuat id jadwal pada pembaruan status, sehingga riwayat lama tidak bisa dipulihkan).
- `keu_jadwal_aksi` tetap, hanya ditambah satu INSERT riwayat (penggantian teks terjaga, aman diulang).
- `keu_jadwal_catat`: ajukan, kembalikan, tolak, perbaiki; hanya DIPA, hanya status diterapkan; urutan dijaga (kembalikan atau tolak hanya setelah ajukan; perbaiki hanya setelah kembalikan atau tolak; ajukan lagi hanya setelah perbaiki); nomor dan tanggal wajib untuk ajukan, kembalikan, tolak.
- `keu_jadwal_langkah`: satu pintu halaman Status: enam aksi lama (lewat `keu_jadwal_aksi`, dengan catatan) dan empat aksi baru; DIPA hanya dapat dinyatakan sah setelah pengajuan dicatat (papan 11 yang memanggil `keu_jadwal_aksi` langsung tidak berubah). Terdaftar di `keu_jalankan`.
- View `keu_v_jadwal_riwayat` (security_invoker) dan whitelist baca di `lib/keu/tampilan.ts` (pengecualian ketiga pada tes daftar putih).

## Kode
`lib/keu/status.ts` (posisi, kartu tahap, tindakan, label dokumen, argumen, riwayat, matriks peran), `lib/keu/__tests__/status.test.ts` (17 tes), `app/sigap/revisi/status/page.tsx`, tautan dari `/sigap/revisi` ("Status, peran, dan riwayat jadwal").

## Penyimpangan dari mockup
- Tidak ada "Tarik kembali ke draf": basis data tidak mengizinkan mundur dari diterapkan.
- Tidak ada pemisahan operator dan PPK untuk "Terapkan": di produksi seluruh aksi jadwal berada di kewenangan `jadwal` (PPK).
- "Setujui (PPK)" pada mockup = "Nyatakan sah" atau "Catat revisi POK berlaku" (POK) di produksi.
- Riwayat sebelum 25 Okt 2026 hanya berupa baris awal.
- Versi usulan (mis. "versi 2") hanya bermakna untuk DIPA: 1 + banyaknya perbaikan.

## Status uji
- Sandbox PostgreSQL: seluruh alur (ajukan, tolak, perbaiki, ajukan lagi, sah, POK sah, non-PPK ditolak, ubah atau hapus riwayat ditolak, aksi tak dikenal, migrasi diulang) lolos; 352 tes `lib/keu` lulus; tsc bersih; render halaman dua skenario lolos.
- Produksi: migrasi terpasang, 5 baris `awal` terisi, `keu_jadwal_aksi` dan `keu_jalankan` memuat penambahan, RLS aktif. UI belum diuji di produksi (menunggu deploy).
