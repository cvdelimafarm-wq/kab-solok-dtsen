# Catatan 22 Okt 2026 (sore): logika Anggaran dan uji pengaman impor Supabase

Status: ditulis ke repo laptop, lulus di salinan sandbox (29 + 5 tes, tsc strict bersih). BELUM dijalankan user di repo, belum di-commit.

## 1. lib/anggaranRab.ts (logika murni, tanpa DB/React/alamat baru)
Menyambung ke model POK yang sudah ada (lib/perencanaanPok.ts: DetailPok, Alokasi, kunciDetail). Isi: salinPokKeRab (RAB v1 = POK), cekSetujuRab (cermin trigger keu_rab_cek_setuju: total <= pagu x (100 - cadangan)/100), bolehMenyetujui (penyusun != penyetuju), rentangBawaan (v1 22%, v2 14%, v3 8%, v4+ 5%), vonisRab (sisa_pasti / kurang_pasti / belum_pasti; batas sama dengan pagu = belum pasti), simpanganPersen (bahan kalibrasi rentang), polaBawaan + sebarKeBulan + rpdDariRab + bandingRpd (RPD per bulan, jumlah 12 bulan selalu sama dengan jumlah awal), ringkasSerapan, pasangkanRevisi (sisa-kurang; dalam RO dulu, lalu antar RO, lalu antar program; tidak bergantung urutan masukan), pergeseranTerjauh, batasAmanGeser (sisa - 5% RAB), alasanRevisiSah (>= 20 karakter), rp.
Angka contoh rancangan terbukti: pagu RO 2907.BMA.009 Rp 937.222.000, RAB v4 Rp 748.164.540 -> sisa Rp 189.057.460, vonis sisa hampir pasti pada +-5%.
Yang USULAN AWAL dan perlu kalibrasi tim: rentang per versi, cadangan 5%, pola bayar per jenis item. Kewenangan persetujuan revisi TIDAK dikodekan (diisi admin dari ketentuan resmi); aplikasi hanya menandai jenis pergeseran.
Uji: lib/__tests__/anggaranRab.test.ts (29 tes).

## 2. Uji pengaman: lib/__tests__/imporSupabaseServer.test.ts
Gagal bila ada berkas di app/ atau lib/ yang mengimpor nilai createClient langsung dari @supabase/supabase-js. Dikecualikan: lib/supabaseServer.ts, berkas "use client", impor `import type`, berkas uji. Pengecualian sah lain ditambahkan ke PENGECUALIAN dengan alasan. Terbukti menangkap pelanggaran (berkas contoh dibuat lalu dihapus di sandbox).

## 3. Belum dikerjakan (menunggu keputusan/prasyarat)
- Halaman Anggaran belum ada: butuh alamat (usul /sigap/kelola/anggaran atau tab di /sigap/kelola/perencanaan) dan penyimpanan RAB berversi (migrasi 20261022a dan b belum diterapkan; sementara RAB bisa memakai tabel yang sudah ada atau menunggu migrasi).
- Menu Anggaran di sidebar v2 masih "segera".
