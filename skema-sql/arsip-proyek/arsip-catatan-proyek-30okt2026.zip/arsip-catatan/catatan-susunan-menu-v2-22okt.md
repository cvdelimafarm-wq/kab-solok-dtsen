# Catatan susunan menu dan ruang lingkup v2 (22 Okt 2026)

Status: MOCKUP. Kanvas "SIGAP · Sistem Integrasi Kegiatan BPS (v2)" diterbitkan sebagai versi 19 (40 artboard, tidak ada yang dihapus). Dokumen Induk SIGAP v2 (termasuk Log Keputusan dan pertanyaan terbuka) dibuat sebagai Claude Doc "Dokumen Induk SIGAP v2". Kode aplikasi dan SQL belum disentuh.

## Keputusan user
- Payung: SIGAP = Sistem Integrasi Kegiatan BPS. SIGAP bukan lagi nama modul anggaran/SPJ.
- Sidebar mengikuti siklus: Beranda; Perencanaan (Alur GSBPM, Anggaran); Pelaksanaan (Pelatihan, Pendataan, Perjalanan dinas, Honor, Pengadaan); Pengendalian (Monitoring, Ruang keputusan); Pertanggungjawaban (Administrasi & SPJ, Audit dan bukti); Pengelolaan (SDM & Mitra, Tata kelola, Kantor, Diseminasi, Pengaturan).
- Alamat /sigap/... tetap hidup; yang pindah dialihkan (307).
- Tidak ada fitur baru, tidak ada artboard dihapus, perubahan ditandai "v2".

## Usulan Claude (belum diputuskan user)
- Nama modul anggaran/SPJ: "Anggaran & SPJ" (alternatif: Keuangan Kegiatan, Gerak Anggaran).
- Satu rumah: Monitoring -> menu Pengendalian; Transport lokal -> Administrasi & SPJ; Referensi dihapus (petugas ke SDM & Mitra, wilayah ke Pengaturan).
- Alamat baru: /sigap/kelola/monitoring, /sigap/kelola/spj (belum ada di aplikasi). /sigap/kelola/lapangan -> monitoring; /sigap/kelola/translok dan /sigap/admin -> spj; /sigap/pelatihan/kelola -> /sigap/kelola/pelatihan; /sigap/translok/<token> tidak berubah.
- Tahap: 11 artboard TAHAP 1 (Main, Peta-Ekosistem, Peta, Fase1-Ringkasan, Fase1-Lapangan, Fase2-Persiapan, Fase2-Pemeriksaan, Fase3-TimST, Fase4-Admin, Fase5-GSBPM, Hub-Pendataan); 29 TAHAP BERIKUTNYA.
- Peta Ekosistem: 20 modul (6 jalan, 6 setengah jadi, 8 rencana; 9 modul Tahap 1), 4 sambungan aliran, 10 modul belum memenuhi syarat data induk + satu login.

## Pertanyaan terbuka (butir 1-11 di dokumen induk)
Nama modul; tempat SIGAP PEDIA; satu register regulasi; Beranda per peran; pemetaan 4 tahap vs GSBPM; kelayakan 11 artboard Tahap 1; persetujuan alamat baru; kepanjangan lama SIGAP di kaki sidebar aplikasi nyata; pengamanan data pribadi minimal Tahap 1; tinggi artboard belum dirender; akses kanvas "siapa pun dengan tautan".

## Audit kata SIGAP
11 titik di mockup: 8 payung, 2 modul anggaran (Kantor, Skema-Data; sudah diganti), 1 kelompok nama fitur (Kamera SIGAP, SIGAP PEDIA).
