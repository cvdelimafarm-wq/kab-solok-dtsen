# Status uji produksi tahap 29–32 (25 Okt 2026)

Penguji: Claude in Chrome (Browser 2), akun IH, https://bps-solokkab.up.railway.app. Hanya data fiktif. Tanpa screenshot rutin, tanpa GIF, tanpa sub-agen. Tab ditutup di akhir.

## Hasil ringkas

| # | Tahap | Langkah | Hasil | Catatan |
|---|---|---|---|---|
| 1 | 29–30 | Lencana notifikasi pada halaman Identifikasi, Lanjutan, Pelaksanaan | LULUS | Awal 0 (tanpa angka); naik ke 1, 2, 4 seiring kejadian |
| 2 | 29 | Buka Identifikasi lanjutan "UJI Fiktif Survei Harga 27a" (id 1, RO 2903.BMA.009, Terupdate v2) | LULUS | Peringatan "Sudah lewat H-15 (14/02/2026)" tampil |
| 3 | 29 | Isi lanjutan: wilayah tugas, 1 kelas briefing (Fix), PML organik 1 (Fix), 1 petugas = akun IH | LULUS | Status berubah ke Final di layar sebelum disimpan |
| 4 | 29 | Simpan versi pertama | LULUS | Versi 1, Final, ditandai "Sesudah H-15"; riwayat versi tampil |
| 5 | 29 | Peringatan terhadap awal dan lembar kebijakan terbaca | LULUS | Peringatan "wilayah tugas" hilang setelah diisi; tersisa "Belum ada lembar kebijakan yang berlaku" (tidak memblokir) |
| 6 | 29 | Dokumen undangan tampil berstempel KONSEP | LULUS | Satu penanda KONSEP; tombol Terbitkan tidak ditekan |
| 7 | 30 | Notifikasi "Sesudah H-15" masuk; keputusan KPA "1 menunggu" | LULUS | Keputusan KPA dibiarkan menunggu |
| 8 | 31 | Buat kegiatan fiktif "UJI Fiktif Pelaksanaan" (id 4; kode anggaran memuat 2903.BMA.009; 1–31 Mar 2026; peran PML Rp100.000, maks 5 hari) | LULUS | Id 1–3 tidak disentuh |
| 9 | 31 | Halaman Pelaksanaan: tautkan kegiatan | LULUS | Ditandai "★ disarankan" dan "Kode RO sama" |
| 10 | 31 | Usulan penugasan dan terapkan satu penugasan untuk IH | LULUS | Status "Siap diterapkan", lalu "Sudah ditugaskan"; hanya akun IH |
| 11 | 31 | Notifikasi "Penugasan diterapkan" | LULUS | Pesan menyebut PPK sudah diberi tahu |
| 12 | 31 | Kartu laporan harian, evaluasi, Bendahara tanpa galat | LULUS | Konsol bersih; kartu Bendahara memuat 3 butir Siap, 2 Belum, 1 Belum dapat dinilai |
| 13 | 32 | Halaman Gap: temuan | LULUS | 1 keras (kegiatan berakhir tanpa laporan harian), 2 perlu perhatian, 1 informasi |
| 14 | 32 | Simpan peringatan pelaksanaan | LULUS | v1 Berjalan |
| 15 | 32 | Notifikasi temuan keras | LULUS | "1 temuan keras baru pada pelaksanaan" |
| 16 | 32 | Satu tanggapan (Dijelaskan, penjelasan ≥ 10 huruf) | LULUS | Tersimpan dengan nama dan waktu; tombol Ubah tanggapan muncul |
| 17 | 32 | Simpan laporan Gap akhir | LULUS | v2 Akhir; pesan "Temuan saat ini sama dengan laporan akhir versi 2" |
| 18 | 32 | Notifikasi "Laporan Gap akhir tersedia" | LULUS | Notifikasi masuk (4 belum dibaca) |
| 19 | 32 | Lencana pada daftar identifikasi | LULUS | "1 temuan keras pelaksanaan" |
| 20 | Bersih | Lepas tautan kegiatan | LULUS | "Belum ada kegiatan tertaut" |
| 21 | Bersih | Nonaktifkan kegiatan fiktif (status Selesai) | LULUS | "Data kegiatan disimpan" |
| 22 | Bersih | Nonaktifkan penugasan IH | LULUS | Awalnya saya kira tidak bisa. Ternyata tombol "Isi ST"/"Ubah" membuka panel dengan pilihan Aktif/Nonaktif. Setelah diatur Nonaktif: "0 aktif" |

Galat konsol: tidak ada pada halaman Pelaksanaan (satu-satunya halaman yang konsolnya saya baca). Tidak ada langkah yang gagal berulang.

## Daftar temuan untuk sesi pengembangan

Diperbarui 25 Okt 2026, 22.1x, setelah memeriksa repo laptop (hanya baca): kode tahap 31–32 (`identifikasi/[id]/pelaksanaan`, `identifikasi/[id]/gap`) ada di repo; temuan 1, 3, dan 4 di bawah ternyata bukan masalah.

Tidak ada galat fungsional. Hanya catatan dan batas uji:

1. **(Dicabut)** Dugaan awal "penugasan tidak bisa dinonaktifkan" keliru. Kode `app/sigap/admin/TabPenugasan.tsx` (repo laptop) memang menyediakan panel Ubah dengan Aktif/Nonaktif; tombolnya berlabel "Isi ST" bila baris belum punya ST, jadi mudah terlewat. Saran ringan: label tombol bisa dibuat "Ubah / Isi ST".
2. **Rincian kebutuhan di lanjutan tidak memakai tarif peran kegiatan tertaut.** Setelah tarif PML Rp100.000 dan penugasan ada, kartu rincian (lanjutan) dan kartu Bendahara tetap "belum dapat dihitung" (menunggu tarif atau jumlah hari). Penyebabnya: kartu lanjutan membaca tarif dari lembar kebijakan (belum ada yang berlaku) dan hari kerja belum dipilih. Bila tarif peran kegiatan dimaksudkan menjadi sumber, perlu keputusan.
3. **Tombol "＋ Kegiatan baru" ganda di Kegiatan & Tarif.** Dua tombol dengan teks sama; klik pada tombol pertama yang ditemukan tidak membuka form, tombol kedua (kanan atas) berfungsi. Hasil cek repo: `app/sigap/admin/page.tsx` memang punya beberapa tombol "＋ Kegiatan baru" (layar daftar dan header, baris 243, 309, 327), jadi dua tombol di DOM adalah tampilan responsif, bukan galat. Prioritas sangat rendah.
4. **Satuan realisasi kegiatan baru:** isian ini tampil terisi "ruta" sebagai nilai bawaan pada form Kegiatan baru. Hasil cek repo: "ruta" adalah nilai bawaan yang disengaja (`TabKegiatan.tsx` baris 100). Tidak perlu diubah kecuali ingin bawaan per jenis kegiatan.
5. **Bendahara: "Lembar kebijakan berlaku" berstatus Belum** karena belum ada lembar yang berlaku di produksi. Itu keadaan data, bukan galat; uji peringatan kebijakan (minimal per jabatan, rangkap, persen petugas baru, maks. peserta kelas, hotel luar kota) tidak dapat dilakukan sebelum ada lembar yang berlaku.

## Tidak teruji (alasan)

- Notifikasi Draf ke Final sebelum H-15 (PPK, TU, Bendahara, KPA, PBJ): H-15 identifikasi ini sudah lewat (14/02/2026). Perlu identifikasi fiktif baru dengan H-15 di masa depan.
- Perubahan pada lanjutan Final sesudah H-15 wajib beralasan (minimal 10 huruf); notifikasi nama petugas menyusul yang terisi; pengecualian kebijakan dan keputusan KPA (setuju/tolak).
- Terbit dan cabut dokumen: dilarang pada tugas ini. Dokumen surat pengantar dan surat tugas/SPK hanya dilihat di daftar ("Belum dibuat"), tidak dibuka.
- Temuan Gap lain: jumlah petugas ditugaskan di bawah 80% rencana, jadwal tidak selaras, biaya melebihi pagu, perubahan berulang; hanya empat temuan pada keadaan ini yang muncul.
- Penyimpanan Gap yang sama persis (tidak membuat versi baru) tidak diuji.
- Padanan nama kembar atau akun tidak ditemukan pada usulan penugasan; hanya padanan tunggal ("siap") yang diuji.

## Sisa data uji di produksi

| Data | Keadaan |
|---|---|
| Identifikasi "UJI Fiktif Survei Harga 27a" (id 1) | Sudah ada sebelum uji (Terupdate v2, disahkan). Tidak dibatalkan karena bukan saya yang membuat |
| Lanjutan id 1 | Versi 1, Final, sesudah H-15; wilayah tugas "Nagari Uji Fiktif"; 1 petugas PML = akun IH |
| Keputusan KPA untuk lanjutan v1 | Menunggu (tidak diputuskan) |
| Kegiatan "UJI Fiktif Pelaksanaan" (id 4, kode uji_fiktif_pelaksanaan) | Status Selesai; tautan ke identifikasi sudah dilepas; peran PML (Rp100.000, maks 5 hari) tersisa |
| Penugasan akun IH pada kegiatan id 4 | Nonaktif (0 aktif) |
| Gap versi 1 (berjalan) dan versi 2 (akhir) untuk id 1 | Tidak dapat diubah; satu tanggapan "Dijelaskan" pada v1 |
| Notifikasi IH | 4 belum dibaca |

Tidak ada dokumen surat yang diterbitkan. Tidak ada data berstatus "berlaku" milik akun selain IH. Tidak ada penugasan atau tautan untuk akun lain. Kegiatan nyata (id 1–3) tidak ditulis; yang saya buka hanya halaman pilihannya, tanpa mengubah isi.
