# Tahap 39 — Delego untuk pekerjaan teknis kantor (26 Okt 2026)

## Tujuan
Delego melayani pekerjaan teknis pegawai organik BPS Kab. Solok (periksa dokumen, periksa peta, evaluasi pelaksanaan, pembekalan, menyusun KAK, merevisi anggaran), tidak hanya pengumpulan data lapangan.

## Keputusan Ketua Tim (AskUserQuestion)
1. Ukuran beban: **katalog jenis pekerjaan, ukuran tetap poin** (kapasitas 70 poin/hari = 7,5 jam = 450 menit, ±6,4 menit/poin).
2. Asal tanpa RO: **kelompok "Pekerjaan tim" non-RO** (pseudo-RO `TIM-XXXX`, seed `TIM-KESRA`).
3. Fitur fase 1 (keempatnya): hasil kerja + tinjau ulang; templat pekerjaan berulang; daftar langkah (checklist); pekerjaan insidental dengan tenggat jam.

## Rancangan
- Tabel baru: `keu_dlg_jenis`, `keu_dlg_kelompok`, `keu_dlg_hasil`, `keu_dlg_langkah`, `keu_dlg_rutin`; kolom baru di `keu_dlg_delegasi` (jenis_id, poin_per_satuan salinan, perlu_hasil, perlu_tinjau, insidental, tenggat_waktu, rutin_id, kelompok).
- Delegasi berjenis: `target_total`/`target_harian`/`laporan.poin` bernilai POIN; input laporan berupa jumlah (`keu_dlg_lapor_jumlah`, poin = jumlah × poin_per_satuan). Mengubah poin katalog hanya berlaku untuk delegasi baru.
- Hasil kerja: 1–5 butir (teks/tautan http(s)/foto `delego/<id>/<hash>.(jpg|png|webp)`), status diserahkan/diterima/revisi; ditinjau pemberi (`keu_dlg_hasil_tinjau`); diterima → delegasi selesai; `keu_dlg_ubah` menolak "selesai" tanpa hasil diterima/diserahkan bila perlu hasil. Insidental tanpa tinjau: serah hasil = otomatis lapor + selesai.
- Langkah: `keu_dlg_langkah_atur` (hapus lunak) dan `keu_dlg_langkah_centang`.
- Berulang: `keu_dlg_rutin` mingguan (1–7) / bulanan (1–28), `keu_dlg_rutin_jalan` idempoten. Pengingat tenggat jam `keu_dlg_pengingat_tenggat` (2 jam sebelum → penerima; lewat → pemberi, sekali). Kedua fungsi penjadwal TIDAK ada di gateway.
- Notifikasi baru: delegasi_hasil, delegasi_tinjau, delegasi_tenggat (tautan tetap `/sigap/delego/saya`; lonceng mengalihkan delegasi_hasil ke `/sigap/delego/papan`).
- Rute foto: GET kini juga mengizinkan path pada `hasil`; POST tidak berubah.
- Hak donor untuk `TIM-*` hanya untuk peran global (hak.semua / beri_kelompok).

## Katalog awal (USULAN — Ketua Tim yang menyesuaikan poinnya lewat menu "Katalog pekerjaan")
8 jenis seed pada `20261026i`; poin per satuan hanya saran dan dapat diubah.

## Berkas
SQL: `skema-sql/fase-b/20261026i_keu_delego_teknis.sql` (utama, ±900 baris), `20261026j_keu_delego_teknis_jadwal.sql` (pg_cron), `60_uji_delego_teknis.sql` (uji dry-run).
Kode: `lib/delego/{tipe,bukti,teknis}.ts`, `lib/notifikasi.ts`, rute bukti, `BuktiFoto`, `KerjaTeknis` (baru), `PemilihPenerima` (baru), halaman buat/lapor/saya/papan/riwayat/Detail/DelegoShell/Lonceng, halaman baru `jenis` (Katalog pekerjaan) dan `rutin` (Pekerjaan berulang). Uji: `delego-teknis.test.ts` (27), `delego-bukti.test.ts` (15).

## Hasil uji
- SQL i + 60 lolos dry-run di produksi (rollback otomatis) pada percobaan pertama.
- vitest unit dan smoke hijau di harness; tsc bersih selain galat stub harness yang sudah dikenal. Uji smoke hanya ada di harness, tidak di repo laptop.

## Urutan pemasangan (dilakukan Ketua Tim)
1. Jalankan `20261026i_keu_delego_teknis.sql` di Supabase produksi.
2. Jalankan `20261026j_keu_delego_teknis_jadwal.sql` (cron; dijalankan Ketua Tim).
3. Di repo laptop: `npx tsc` dan `npx vitest run`.
4. Commit, push, deploy.
5. Uji di ponsel: buat delegasi "Pekerjaan tim", serah dan tinjau hasil, centang langkah, insidental dengan jam tenggat, pekerjaan berulang.

## Sisa
- Batalkan (jangan hapus) delegasi fiktif id 2–13 setelah uji.
- `20261026f` dan `58_uji_delego_pindah.sql` belum ada di laptop (hanya di Project).
- Penggantian nama menu "Alur GSBPM" → "Perencanaan" belum disetujui.
