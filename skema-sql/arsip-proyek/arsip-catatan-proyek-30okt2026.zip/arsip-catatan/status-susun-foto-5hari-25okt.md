# Susun nomor foto: boleh sampai 5 hari (25 Okt 2026)

Keluhan petugas: di tab Arsip, kisi nomor foto dan "Foto cadangan" tidak bisa diketuk untuk hari yang sudah lewat.

Penyebab: rute /api/sigap/foto/susun memakai cekAksesIsian (batas isian 23.59 WIB), sehingga hari lampau mengembalikan boleh=false dan semua tombol nonaktif. Fungsi basis data sigap_foto_pindah_nomor dan sigap_foto_tempatkan tidak punya batas waktu sendiri, jadi tidak ada perubahan SQL.

Perubahan:
- lib/sigapFotoSusun.ts: BATAS_HARI_SUSUN = 5, umurHari, jendelaSusunFoto (ok / akan_datang / terkunci).
- lib/sigap.ts: cekAksesSusunFoto (tanpa batas 23.59; umur tanggal <= 5 hari boleh, lebih dari 5 hari terkunci; tetap menolak SPJ yang sudah dikunci admin, bukan hari kerja, dan tanggal mendatang).
- app/api/sigap/foto/susun/route.ts: GET dan POST memakai akses baru; respons GET menambah lampau dan sisa_hari; foto yang dipasang pada hari lampau ditandai susulan.
- app/sigap/foto/SusunFoto.tsx: catatan "masih bisa diatur N hari lagi" pada hari lampau.
- Pengambilan foto baru dan unggah tetap memakai batas 23.59 WIB / izin susulan (tidak diubah).
- Tes: 12 tes baru (jendela umur, GET lampau, POST lampau, tanggal terkunci); 91 tes foto lolos.
