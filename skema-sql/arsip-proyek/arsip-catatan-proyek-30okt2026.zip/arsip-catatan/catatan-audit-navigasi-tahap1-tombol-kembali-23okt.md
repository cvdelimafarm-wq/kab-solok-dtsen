# Catatan: Audit navigasi Tahap 1 — tombol Kembali seragam (23 Okt 2026)

Sumber: prompt audit 23 Okt (Tahap 1: komponen kembali dan beranda yang seragam). Belum di-build/deploy; tsc, vitest, build dijalankan user.

## Yang dibuat
- `lib/sigapNavigasi.ts` (tambahan, fungsi murni):
  - `dariAman(raw)`: ?dari= hanya jalur internal diawali "/"; ditolak "//", "\\", skema (https:, javascript:), karakter kendali, segmen "..", panjang > 300. Query sah dipertahankan.
  - `labelTujuan(path)`: nama tujuan untuk label tombol (Beranda, Kelola Pendataan, Admin Transport Lokal, Tahapan, Tahap kegiatan, dst.; tak dikenal = "Halaman sebelumnya").
  - `tujuanKembali(dari, path)`: ?dari= aman (bukan halaman sendiri) > induk logis (`indukDari`) > Beranda.
  - `denganDari(href, asal)`: menambah ?dari= ke tautan.
  - `indukDari`: /sigap/kelola/foto, /identifikasi, /lapangan kini naik ke /sigap/kelola/pendataan.
- `app/components/TombolKembali.tsx`: satu tombol (ikon ‹ + nama tujuan, min 44 px). Prop: `tema` gelap/terang, `induk` (tujuan bawaan halaman), `label`+`onKlik` (perilaku sendiri, mis. tutup layar bagian dalam). Riwayat lewat `keAtas` (router.back bila halaman sebelumnya memang tujuan, kalau tidak replace).
- `lib/__tests__/sigapNavigasi.test.ts`: 12 tes (validasi dariAman, indukDari Kelola Pendataan, tujuanKembali, labelTujuan, denganDari). Dicek lulus dengan harness sederhana di sandbox; vitest asli belum.

## Halaman yang diubah (33 berkas)
- Bingkai halaman Kelola (`app/sigap/kontrak/Bingkai.tsx`) + `HeaderAdmin` (`admin/ui.tsx`, prop `kembali`): otomatis berlaku untuk Kelola Pendataan, Perencanaan, Pengadaan (halaman penuh), Kelola Pelatihan. Kelola Pelatihan: "← Daftar pelatihan" -> `kembali` berlabel "Daftar pelatihan".
- Admin Transport Lokal (`admin/page.tsx`): tiga "← Daftar kegiatan" -> TombolKembali (label "Daftar kegiatan"); tingkat daftar kegiatan mendapat Kembali (?dari= atau Beranda). "Kegiatan baru" dobel dikurangi: satu tombol per layar (daftar = aksiKanan; Beranda = baris cepat; tab lain = header). Aksi palet Ctrl+K dibiarkan.
- Peran & Akses (`akses/page.tsx`), Lembar Pendataan, Korwil, SPDT, Perbaikan administrasi, Lembar Identifikasi (daftar dan [id], [id] berlabel "Daftar Sub SLS"), Kegiatan induk/tahap/translok-id (`kegiatan/[id]/*`), translok token (Kembali menghormati ?dari=, logo = tautan ke Beranda, "← Kembali" pada langkah isian diganti "‹ Sebelumnya"), Kamera SIGAP (`foto/page.tsx`, sebelumnya tanpa kembali), Monitoring Identifikasi / Lapangan / Kelola Foto (halaman penuh), Delego, Perencanaan, Pelatihan (Kerangka `komponen.tsx`: pil "Tahapan"/"Langkah" diganti; kuis; tes), Kelola Aplikasi (`portal/admin`, `tahap`), `/bencana` (tombol Kembali, logo BPS jadi tautan ke Beranda, layar "Memuat data pendataan bencana…" dengan indikator putar + Kembali, juga di layar galat).
- Tautan dari tab Kelola Pendataan (`PintuMasuk.tsx`) kini membawa ?dari=/sigap/kelola/pendataan?tab=<tab>.
- `BannerLihatSebagai.tsx`: tombol oranye "Kembali" -> "Keluar simulasi".
- Duplikat "Ke Beranda"/"← Kembali ke Pelatihan" yang mengulang tombol header dihapus (Perencanaan akses ditolak, kegiatan 404, tiga tautan di halaman tes). "Kembali ke Pelatihan" di akhir kuis dipertahankan tanpa panah.

## Catatan teknis / keputusan
- Satu salinan `pendataan/page.tsx` di sandbox ternyata usang (belum memuat fitur Batalkan keluarga baru 21 Okt); sudah diambil ulang dari laptop dan perubahan diterapkan ulang. Semua berkas lain dibandingkan dengan versi laptop sebelum ditulis.
- Tidak diubah: tombol Kembali dalam dialog (batal konfirmasi), panah tanggal "‹" pada Arsip translok, "← Tutup layar penuh" peta, stepper "← 1. nama" di Perencanaan, "Ke Beranda" di layar galat translok tanpa header.
- /bencana tetap berbingkai sendiri (belum dibingkai Shell); itu butuh pekerjaan terpisah karena berkas 555 KB.
- Pengadaan (halaman penuh) dan Perencanaan tanpa ?dari= kembali ke "Beranda", bukan Kelola Pendataan (modul Pengadaan juga dipakai akun tanpa akses Pendataan).

## Belum selesai / perlu uji user
- `npx tsc --noEmit`, `npx vitest run`, `npm run build`.
- Uji manual PML, PPL, Korwil, Admin di HP: Beranda -> kegiatan -> tahap -> lembar/translok lalu tekan Kembali berulang (harus mundur selangkah demi selangkah); header Lembar (judul menyempit karena label kembali, maks 40% lebar); Kamera (tambahan baris Kembali di atas tab).
- Tahap 2 dan 3 belum dimulai.
