# Editor isi Siaran bergaya Word (21 Okt 2026)

Kelola > Pendataan > Siaran: isi modal kini diketik langsung dengan toolbar, tanpa mengetik kode `**` / `==` / `- `.

## Format tersimpan (tidak berubah untuk data lama)
Isi tetap TEKS BERPENANDA, sehingga modal di HP, templat, dan data lama tetap jalan:
- `**tebal**`, `==sorot==`, `[teks](https://...)` (sudah ada)
- BARU: `__miring__`, baris `## ` = subjudul, baris `1. ` = daftar bernomor (`- ` = poin, sudah ada)
- Penanda tidak bersarang. Bila satu teks bergaya ganda yang dipakai: sorot > tebal > miring. Tombol toolbar otomatis melepas gaya lain.
- Teks biasa yang memuat penanda ("**", "==", "__", awal baris "- ", "1. ", "## ") dinetralkan dengan karakter lebar-nol.

## Berkas
- `lib/teksKaya.ts` (+ `lib/__tests__/teksKaya.test.ts`, 27 uji): terjemah dua arah markup <-> pohon/HTML editor.
- `app/components/EditorTeksKaya.tsx`: komponen contentEditable (tombol B, I, Sorot, Subjudul, Poin, Nomor, Tautan, Batalkan, Ulangi, Hapus format).
- `lib/sigapPengumuman.ts`: pengurai menambah `miring`, blok `judul`, `daftar.bernomor`. Kompatibel mundur.
- `app/sigap/pelatihan/pengumumanUi.tsx`: render `<i>`, `<h3>`, `<ol>`.
- `app/sigap/kelola/pendataan/Siaran.tsx`: memakai editor.

## Perilaku penting / jebakan Chromium
- Enter = paragraf baru (separator `div`), Shift+Enter = baris baru. Tempel selalu teks polos; teks berpenanda ditempel sebagai isi bergaya.
- Setelah perintah daftar/subjudul Chromium memindahkan kursor ke awal baris: dipulihkan lewat catatan (urutan baris, jumlah huruf).
- formatBlock h3 membungkus isi dengan span `font-weight:700`: dibersihkan dengan removeFormat agar baris sesudahnya tidak ikut tebal.
- Tempel banyak baris di dalam butir daftar/subjudul digabung jadi satu baris; seleksi yang dihapus dulu sebelum menempel.
- Gaya (miring/tebal) terbawa ke baris berikutnya seperti di Word.
- Subjudul tidak bisa di dalam daftar (dan sebaliknya); daftar bersarang tidak didukung.
- `__init__` pada teks tempelan dibaca sebagai miring (sama seperti `**`).

## Pengujian
Vitest 27 lulus; build Next strict lulus; uji Playwright Chromium (ketik, tombol, undo/redo, tempel, pratinjau). BELUM diuji di HP / Safari / Firefox.
