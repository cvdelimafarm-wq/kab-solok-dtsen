# Tahap 38: Delego lanjutan (26 Okt 2026)

Status: kode dan SQL SELESAI, diperiksa di sandbox, dan SUDAH ditulis ke repo laptop (26 Okt 2026 sore, 30 berkas, mtime dicocokkan dulu). BELUM di-tsc/vitest di laptop, BELUM di-commit/push/deploy, BELUM dijalankan di produksi.
Tambahan sesudah catatan ini ditulis: perbaikan lebar HP (grid-cols-1 pada 12 halaman) dan skala warna sel beban (`lib/delego/warna.ts`).
Catatan: `20261026f_keu_delego_pindah.sql` dan `58_uji_delego_pindah.sql` belum ada di skema-sql/fase-b laptop (hanya di Project); SQL g bergantung pada f sudah dijalankan di produksi.
Permintaan user 26 Okt 12:29: ikon Delego di Kegiatan saya untuk tiga pegawai uji (Mailani 357, Nurafiza 464, Dina 160) dan "lanjutkan pembangunan web". Empat pilihan user: bukti foto, kalender libur + pengingat 18:00, tautan ke identifikasi/Gap/Lembar Pendataan, target per tanggal + bobot skor.

## Yang dibangun
1. **Kalender libur** (`keu_dlg_libur`, 51 isian bawaan 2026–2027 dari SKB 3 Menteri, cek aturan; cuti bersama aktif bawaan). Libur aktif = bukan hari kerja: tanpa target, hutang, beban, kewajiban lapor, pengingat. Layar: Delego > Kalender libur (`/sigap/delego/libur`); hanya pemberi tingkat tim yang mengubah; tidak ada hapus (dinonaktifkan).
2. **Target harian berlaku per tanggal** (`keu_dlg_target`; baris pertama = target awal). Perubahan target pada delegasi yang sudah mulai masuk riwayat, berlaku mulai hari ini, tidak surut. `keu_dlg_saya`/`keu_dlg_bahan` mengirim target efektif hari ini + `riwayat_target`. Layar: Detail > "Target harian per tanggal".
3. **Bobot skor** (`keu_dlg_bobot`, satu baris, jumlah 100): ketepatan, capaian, kualitas, kepatuhan. Diatur di Pembinaan > Skor (kartu bobot).
4. **Pengingat 18:00 WIB** (`keu_dlg_pengingat`, pg_cron `delego-pengingat-1800` pada `0 11 * * *` UTC): satu notifikasi 'delegasi_pengingat' per akun per hari kerja bagi penerima yang belum lapor; idempoten. Label ditambahkan ke `lib/keu/notifikasi.ts`.
5. **Tautan ke identifikasi**: kolom `ident_ver`; peringatan "identifikasi berubah sejak delegasi dibuat" + tombol Tinjau (`keu_dlg_tinjau_ident`) di Detail; tautan Identifikasi/Gap/Lanjutan; kartu C "Delegasi pada survei ini" di halaman Gap (`gap/KartuDelego.tsx`, hanya tampilan).
6. **Bukti foto di Lapor harian** (tanpa SQL baru): rute `/api/sigap/delego/bukti` (POST unggah, GET lihat), foto dikecilkan di HP (1600 px, JPEG), disimpan di sigap-files `delego/<delegasi>/<hash>.<ext>`, dicatat di `keu_dlg_laporan.bukti` sebagai `{ket, path}`. Teks lama tetap terbaca. Ditampilkan di Detail, Delegasi saya, Riwayat, dan Laporan tim.

## Berkas SQL (urutan jalan; keduanya sudah lulus dry-run produksi yang auto-rollback)
- `20261026g_keu_delego_lanjutan.sql` (WAJIB sebelum deploy kode: `hak.libur`, `hak.bobot`, kolom baru) + uji `59_uji_delego_lanjutan.sql`.
- `20261026h_keu_delego_pengingat.sql` (fungsi + `cron.schedule`; cron.schedule adalah DDL produksi, dijalankan user).

## Berkas kode
lib/delego: `hitung.ts`, `tipe.ts`, `bukti.ts` + tes `delego-hitung.test.ts` (32), `delego-bukti.test.ts` (13). `lib/keu/notifikasi.ts` (+1 jenis).
app/sigap/delego: `DelegoShell.tsx`, `Detail.tsx`, `BuktiFoto.tsx` (baru), `libur/page.tsx` (baru), `lapor/page.tsx`, `saya/page.tsx`, `riwayat/page.tsx`, `laporan/page.tsx`, `papan/page.tsx`, `pembinaan/page.tsx`.
app/api/sigap/delego/bukti/route.ts (baru). Halaman Gap: `gap/page.tsx` (+1 impor, +1 kartu), `gap/KartuDelego.tsx` (baru).
Beranda: `app/portal/Beranda.tsx` (ikon Delego untuk akun super + 3 pegawai uji) dikirim terpisah.
tsc harness: hanya galat bawaan stub; vitest harness 183 lulus.

## Belum / keputusan
- **Lembar Pendataan** (sumber poin per KK): BELUM dibangun. Sumbernya sistem pendataan pascabencana (`bencana_pendataan_kk`/log, `lib/skorKinerja.ts`, target 60 poin O-K sejak 20 Okt) berbeda dari kapasitas Delego (70). Perlu rancangan: pemetaan poin otomatis ke laporan Delego atau hanya tautan. Tunggu keputusan user.
- Foto bukti: tidak ada hapus berkas (sesuai aturan); berkas yang batal dilampirkan tertinggal di penyimpanan. Foto hanya terlihat oleh akun yang berhak melihat laporannya (pemeriksaan di rute).
- Tampilan "Melihat sebagai" tidak boleh mengunggah (diblok rute dan lapisan simulasi).

## Langkah user (urutan)
1. Jalankan `20261026g` lalu `20261026h` di SQL editor produksi (atau minta saya menjalankan g bila didelegasikan; h memuat cron.schedule).
2. Salin berkas ke repo (atau tunggu laptop tersambung), `npx tsc --noEmit`, `npx vitest run`.
3. Commit/push/deploy (bersama perubahan Kamera, H+1, Terapkan usulan yang masih tertunda).
4. Uji produksi: Lapor dengan foto dari HP, Kalender libur, ubah target per tanggal, Pembinaan > bobot, kartu di Gap, pengingat (`select keu_dlg_pengingat(current_date)` uji kering).
5. Setelah uji, batalkan delegasi fiktif id 2–13 lewat Papan > Detail > Status dengan alasan (jangan dihapus).
