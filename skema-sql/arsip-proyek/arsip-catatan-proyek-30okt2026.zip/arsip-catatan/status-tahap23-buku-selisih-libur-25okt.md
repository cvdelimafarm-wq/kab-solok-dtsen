# Status tahap 23: akun 512212, Buku selisih Satker, hari libur 2027 (25 Okt 2026)

## Hasil uji produksi tahap 22 (sesudah deploy)
- /sigap/revisi/alur: seluruh bagian A, A+, B, C tampil; tautan "Buka: ..." sesuai TAUTAN_LANGKAH.
- /sigap/revisi/pemicu: sembilan skenario diklik satu per satu; jenis, tingkat, alasan, kolom jalur, dan tenggat pengingat (27 Des / 30 Nov / 30 Okt) sesuai papan 3. Tanpa galat konsol.
- /sigap/revisi: dua tombol baru (Alur, Pemicu) ada. Tab ditutup.

## Dikerjakan
1. Akun 512212 ditambahkan ke keu_master_akun atas persetujuan PPK di chat: nama "Belanja Uang Lembur PPPK" (mengikuti POK unggahan, 2 baris sudah memakai akun ini), pola PEG, kelompok 51 (kolom turunan). Arsip: skema-sql/fase-b/20261025w_keu_master_akun_512212.sql. Nama dapat diubah lewat menu Master bila Bapak ingin redaksi lain.
2. /sigap/revisi/buku (Buku selisih seluruh Satker): KPI, ringkasan per kelompok belanja (51, 524, 52L, 53) dan prioritas sebagai penyaring, daftar catatan terbuka per RO dengan tautan ke tab Kekurangan RAB. Hanya baca; membaca keu_v_kekurangan (sudah di whitelist). lib/keu/bukuselisih.ts + 4 tes. Tombol tautan di /sigap/revisi.
3. LIBUR diperluas ke seluruh 2027 (lib/keu/lampiran.ts): libur dan cuti bersama pada hari kerja menurut SKB 3 Menteri 2027 (dua sumber berita cocok). Idulfitri dan Iduladha dapat bergeser bila pemerintah menetapkan lain. Tes hariKerja dan efektif ditambah.

## Pengujian
tsc bersih; lib/keu seluruhnya lulus; render uji Buku selisih lulus.

## Masih terbuka (perlu keputusan atau bahan dari Bapak)
Alasan versi RAB, jalur penutup Revisi POK/DIPA, pengurangan realisasi SPAN, padanan baris POK baru/hilang saat impor, jadwal 7 masih memakai POK lama, uji tulis geseran/keputusan PPK/Kembalikan, pencabutan kewenangan, unduhan ekspor, persetujuan KPA saat pagu di bawah realisasi, sumber data Booked.
