# Nomor foto otomatis, susun foto Kamera SIGAP, dan pengaman "lupa Kirim" (21 Okt 2026)

Permintaan M. Iqbal Hadi (21 Okt 2026, setelah pemeriksaan foto PML Hariston 20 Okt): (1) bila foto lebih dari 5, susun saja; (2) pada kesempatan melengkapi foto berikutnya, foto Kamera SIGAP langsung terisi; (3) di kamera, foto pertama hari itu otomatis nomor 1 (saat berangkat), kedua nomor 2, dst, dan petugas boleh mengetuk nomor lain; (4) bagaimana mencegah petugas lupa menekan Kirim.

## Temuan penyebab (penugasan 49, 20 Okt)
Foto 279 dan 282 dikirim TANPA nomor (hanya di-tag ke rekan, akun 91), foto 364 sempat masuk nomor 5 lalu tergeser foto 369 (tag "dilepas"). Nomor 1-2 terisi unggahan manual susulan. Nomor 4 kosong. Panel susulan lama hanya unggah galeri sehingga foto Kamera SIGAP yang menganggur tidak terlihat.

## Yang dibuat (paket-21okt-d; sudah dikirim ke laptop, BELUM commit/push/deploy)
- `lib/sigapFotoSusun.ts` (murni): `nomorBerikutnya`, `nomorKosong`, `susunFoto`. Foto <= nomor kosong: urut waktu ke nomor kosong terkecil. Foto > nomor kosong: foto kuning disisihkan dulu; sisanya dipilih sepadan posisi waktunya dengan nomor (1 = paling awal, 5 = paling akhir, 3 = tengah); yang tak terpilih jadi cadangan. Foto jauh dari wilayah (> 10 km dari KK dan rumah) tidak ditempatkan di nomor 2-4. ASUMSI tafsir "foto > 5 susun saja"; mudah diubah.
- `app/api/sigap/foto/susun/route.ts`: GET keadaan nomor + cadangan + saran; POST `isi` (susun otomatis ke nomor kosong, tidak menimpa), `pasang` (cadangan ke nomor pilihan), `pindah` (pindah/tukar). Memakai `cekAksesIsian` (hari kerja, 23.59, izin susulan, SPJ belum dikunci). Foto merah belum diperiksa dan "dipertanyakan" tidak ikut. Pindah ke nomor 2-4 juga memeriksa lokasi.
- Migrasi sudah dijalankan: `sigap_foto_pindah_nomor(p_akun, p_penugasan, p_tanggal, p_dari, p_ke)` (arsip `supabase/migrations/20261021d_foto_pindah_nomor.sql`). Pertukaran menukar ISI baris (ada indeks unik `sigap_dokumentasi_penugasan_tgl_slot_uq` dan CHECK slot 1-5, jadi nomor tidak bisa ditukar langsung). Diuji dalam transaksi yang dibatalkan pada penugasan 49: tukar, pindah ke kosong, asal kosong, bukan pemilik. Tidak ada data dihapus.
- `app/sigap/foto/SusunFoto.tsx`: panel Nomor foto (thumbnail, lencana kepercayaan, chip pindah, cadangan). Dipasang di `FotoKegiatan` (prop baru tanggal, jenis, onBerubah) dan diteruskan dari kartu hari di `translok/[token]/page.tsx`. Pada tanggal izin susulan panel langsung menyusun otomatis satu kali; uploader lama tetap di bawahnya untuk nomor yang masih kosong.
- `KameraSigap.tsx`: nomor otomatis (nomor kosong terkecil dari server + antrean HP), baris penanda 1-5 di layar kamera, tombol "Kirim sebagai Foto n", hitung mundur kirim otomatis 10 detik (berhenti bila petugas mengetuk nomor lain, Bagikan, atau "Ubah dulu"), semua nomor terisi -> kirim sebagai cadangan.
- Pengaman lupa Kirim: begitu dipotret foto disimpan sebagai DRAF di IndexedDB dengan detak 20 detik. Tombol Back, pindah aplikasi, layar mati, atau tab ditutup mengubah draf menjadi antrean yang terkirim otomatis (`kirimAntrean.ts`, dipanggil juga dari kartu hari dan saat sinyal kembali). Hanya tombol "Buang & ulangi" yang membuang. Draf yang tertinggal (detak > 90 detik) ikut terkirim. Item ditolak permanen server tidak diulang otomatis kecuali tombol "Kirim sekarang".
- Tes: `lib/__tests__/sigapFotoSusun.test.ts` (14) dan `fotoSusunRoute.test.ts` (18) lulus di sandbox; tsc bersih untuk berkas baru (selain modul sharp/qrcode yang tidak ada di sandbox).

## Perubahan perilaku yang perlu diketahui
- Nomor yang sudah diterima kini BISA dipindah/ditukar lewat panel (sebelumnya sengaja tidak bisa). Tidak ada baris yang dihapus; tercatat di `sigap_audit` (`foto.nomor_dipindah`, `foto.isi_otomatis`).
- Back saat pratinjau tidak lagi membuang foto.
- Foto antre yang baru terkirim pada hari berikutnya dicatat dengan waktu terima server (kuning) bila token potret sudah kedaluwarsa (perilaku antrean lama, tidak diubah).

## Belum
Uji di HP sungguhan (Android/iPhone), deploy, dan commit/push. Foto 279/364 milik Hariston baru tersusun otomatis bila tanggal 20 Okt dibuka lagi lewat izin susulan. Opsional: Background Sync di service worker agar antrean terkirim walau aplikasi tertutup; tag masuk dari rekan belum ikut tersusun otomatis (tetap lewat persetujuan di Foto saya).
