# Kartu plotting tim + permintaan daftar KK ke FASIH (13 Okt 2026)

Permintaan user: pada kartu "1. Lembar Pendataan KK" (tahap Pendataan), sebelum peta/daftar KK tampil kartu **Plotting tim hari ini**. PML menandai maksimal 2 Sub SLS untuk didata hari ini, memilih PPL dari dropdown untuk tiap Sub SLS, lalu menekan **Kirim** untuk meminta daftar KK "keluar" di FASIH. **Tampilan sama untuk PML dan PPL; bedanya hanya bisa Kirim atau tidak** (PPL hanya melihat; keterangan jelas di bawah tombol: hanya PML yang dapat mengisi).

## Alur
1. PML pilih Sub SLS (maks. 2/hari) + PPL tiap Sub SLS -> Kirim. Admin dapat push, permintaan masuk ke Kelola > Pendataan > "Permintaan daftar KK ke FASIH".
2. Admin pilih permintaan -> **Ekspor templat FASIH** (format Pengawas-Pencacah, 7 kolom: PROVINSI, KABUPATEN/KOTA, KECAMATAN, DESA/KELURAHAN, SLS/SUBSLS, Email Pengawas, Email Pencacah; semua teks; SLS/SUBSLS = 6 digit terakhir idsubsls) -> unggah dan assign di FASIH.
3. Admin tekan **Sudah keluar di FASIH** (dua langkah). PML dan PPL dapat push; status di kartu berubah Menunggu admin -> Sudah keluar di FASIH.
4. PML bisa **Batalkan** permintaan yang masih menunggu (lunak: status dibatalkan, kuota kembali).

## Aturan
- Batas "maks. 2 Sub SLS" ditafsirkan **per PML per hari menurut tanggal WIB** (jawaban user: "per pml untuk sesi ini"). Dijaga atomik di fungsi DB `bencana_pendataan_minta` (kunci penasihat per PML). Satu Sub SLS hanya punya satu permintaan berlaku (indeks unik parsial).
- Server memeriksa: pengirim PML tim, Sub SLS milik tim, PPL anggota tim, Sub SLS punya daftar KK aktif. Sesi "masuk sebagai" ditolak untuk semua POST.
- Email templat: `bencana_petugas.email_fasih` diutamakan, lalu `sigap_akun.mitra_id -> bencana_mitra.email`. Baris tanpa email ditandai di layar admin (bisa diisi langsung, aksi `email`) dan kolomnya dikosongkan di Excel.
- Izin: lihat/ekspor = bencana.admin lihat; tandai sudah keluar = bencana.admin kelola.

## Berkas
Migrasi `20261013c_pendataan_permintaan_daftar.sql` dan `20261013d_petugas_email_fasih.sql` (sudah diterapkan ke Supabase; tabel `bencana_pendataan_permintaan`), `lib/permintaanDaftar.ts` (murni), `lib/portal/permintaanDaftar.ts` (server), `app/api/portal/pendataan/permintaan/route.ts`, `app/sigap/pendataan/PlottingTim.tsx` (+ dipasang di `page.tsx`), `app/sigap/kelola/pendataan/PermintaanDaftar.tsx` (+ dipasang di `page.tsx`), `lib/__tests__/permintaanDaftar.test.ts` (15 uji), `lib/__tests__/siaranPetugas.test.ts` (9 uji).

## Siaran INFO diganti
Teks siaran bawaan di Kelola > Pendataan diganti menjadi "Data keluarga sudah tersedia": PML pilih 2 Sub SLS untuk didata hari ini, nanti di-assign ke FASIH; sorotan: upayakan pendataan awal dengan keroyokan, daftar keluarga di-assign ke salah satu akun PPL. Tautan push membuka /sigap/pendataan. **Belum terkirim**: harus diklik admin di Kelola > Pendataan > Siaran ("Kirim siaran..." -> "Ya, kirim"); uji dulu dengan tombol "Uji". Push tidak bisa dikirim dari cloud (kunci VAPID hanya di Railway). Penerima ±85 petugas.

## Tambahan (13 Okt 2026, sesudah uji user)
- **Email FASIH**: kolom `bencana_petugas.email_fasih` (migrasi 20261013d). Rini Nofsiska Sari (PPL, petugas 466, akun 778; tidak punya mitra) = rininofsiska4@gmail.com. **PML Ardial Jaraf (460, ardialjaraf-pppk@bps.go.id), Hariston (459, hariston-pppk@bps.go.id), Ilham (458, ilham-pppk@bps.go.id) sudah terisi** (sumber: alokasi_pengawas_pencacah_subsls_13.xlsx). Semua PML/PPL aktif kini punya email.
- Tulisan **"maksimal 2 Sub SLS"** disorot kuning di kartu plotting dan di modal siaran (==...==).
- Modal siaran punya **tombol navigasi** (bawaan "Buka Lembar Pendataan" -> /sigap/pendataan, tab yang sama, sekaligus mengonfirmasi modal) dan juga muncul di **Beranda**.
- **Uji notifikasi**: tombol "Uji: kirim notifikasi ke akun saya saja" di Siaran. Modal/push tidak muncul saat "masuk sebagai" Ayu Sepriani karena siaran belum pernah dikirim dan kode belum di-deploy; push selalu ke HP petugas yang dilihat, tidak pernah ke akun super.
- **Notifikasi "Sudah keluar di FASIH" diperkaya**: rincian jorong + nama PPL penerima, pengingat cek apakah identifikasi jorong sudah tersubmit di FASIH jika belum muncul di akun PPL, dan catatan sorot kuning: jika keroyokan, seluruh petugas login memakai akun PPL penerima. Teks di `lib/permintaanDaftar.ts` (`CATATAN_CEK_SUBMIT`, `CATATAN_KEROYOKAN`, `susunPushKeluar`); tampil juga di kartu PPL/PML dan layar admin.
- **Perbaikan tampilan**: baris Sub SLS tidak lagi terpotong (teks dibungkus, chip "Sub xx" selalu tampak, nagari/kecamatan/KK di baris kecil) di `PlottingTim.tsx` dan `PermintaanDaftar.tsx`.

## Data nyata & status
PML usyenti sudah mengirim 2 permintaan (id 4, 5): Jorong Tanjung (1303140001000500) -> Yovinda Oktasia Rahmi (102 KK) dan Jorong Gando 04 (1303140002000104) -> Rini Nofsiska Sari (104 KK), status menunggu admin. Semua berkas sudah ditulis ke laptop; tinggal git commit/push/deploy (perbaikan Sub SLS terakhir menunggu commit).
