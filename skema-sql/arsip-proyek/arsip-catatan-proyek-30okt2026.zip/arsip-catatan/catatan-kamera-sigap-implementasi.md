# Kamera SIGAP: hasil implementasi kode dan SQL (19 Okt 2026; diperbarui 20 Okt 2026)

Status: kode dan SQL SELESAI ditulis, BELUM dipasang. Tidak ada migrasi yang dijalankan, tidak ada yang di-push; Iqbal yang menyalin, menjalankan SQL, commit, dan push. Berkas keluaran ada di folder `kamera-sigap/` (sesi 19 Okt 2026) beserta `PANDUAN_PASANG.md`. Rancangan: `claude/rancangan-kamera-sigap-berbagi-foto.md`. Saklar: `claude/catatan-saklar-kamera-sigap.md`. Perubahan 20 Okt: lihat bagian "Pembaruan 20 Okt 2026" di bawah dan `claude/catatan-perubahan-20okt-2026.md`.

## Keputusan yang berlaku
- Masa simpan foto 3 tahun (keputusan user). Dihitung dari tanggal selesai kegiatan (atau tanggal foto bila lebih akhir). ASUMSI acuan; belum diverifikasi ke jadwal retensi arsip. Hanya penanda: tidak ada hapus otomatis.
- Foto dihapus hanya setelah persetujuan user. Admin mengusulkan, akun super menyetujui, user menghapus berkas fisik manual lalu mengisi `file_dihapus_at`. Trigger melarang DELETE pada `sigap_foto` dan `sigap_foto_tag`.
- Saklar kamera/unggah: bawaan global + per kegiatan; bawaan awal `unggah` supaya migrasi tidak mengubah perilaku. Dimatikan = kembali ke unggah foto lama. Perubahan dicatat di `sigap_audit` (aksi `foto.saklar`).
- Tag di luar tim boleh jadi bukti kegiatan penerima (kegiatan tujuan harus bermode kamera). Maks 8 orang per foto.

## Berkas
- SQL: `supabase/migrations/20261019d_kamera_sigap.sql` (tabel `sigap_foto_pengaturan`, `sigap_foto_pengaturan_kegiatan`, `sigap_foto`, `sigap_foto_tag`, `sigap_foto_cek`; kolom `foto_id` dan `sumber` di `sigap_dokumentasi`; fungsi `sigap_foto_tempatkan` dan `sigap_foto_lepas_tahan`, SECURITY DEFINER, revoke dari public/anon/authenticated; RLS tanpa policy; trigger pengaman).
- Lib: `lib/sigapFoto.ts` (murni), `sigapFotoCap.ts` (sharp + qrcode), `sigapFotoServer.ts`, `sigapFotoRoute.ts`.
- API: `/api/sigap/foto` (POST ambil, GET foto saya), `/mode`, `/token`, `/rekan`, `/tag`, `/tag/keputusan`, `/berkas`, `/periksa`, `/pengaturan`, `/usulan-hapus`; publik `/api/verifikasi-foto`.
- UI: `/sigap/foto` (Kamera, Foto saya, Periksa), gerbang `FotoKegiatan` (prop fallback = uploader lama), `/sigap/kelola/foto`, publik `/verifikasi`.
- Aset: `public/fonts/PlusJakartaSans-{Bold,Regular}.ttf`, `public/sigap-logo-cap.png`.
- Dependensi baru: `qrcode` dan `@types/qrcode`.

## Cara kerja inti
- Token potret (HMAC, 30 menit, nonce sekali pakai) -> waktu foto = waktu server token + jam monotonik HP. Tanpa token: waktu terima server, kuning.
- Kepercayaan (aturan terkini, lihat pembaruan 20 Okt): merah (kecepatan > 120 km/jam, jam HP beda > 1 jam, > 10 km dari wilayah DAN rumah pada nomor 2-4, waktu token tidak wajar), kuning (waktu belum terverifikasi, jam beda > 2 menit, jam melompat/HP tidur, akurasi > 300 m, 5-10 km dari wilayah dan rumah, koordinat identik hari lain, gambar mirip foto lain, posisi basi). Merah = tag ditahan sampai PML/admin menandai Diperiksa.
- Kunci akses: `cekAksesIsian` (hari kerja, 23.59, kunci, periode) terhadap tanggal foto. Foto diterima menulis ke `sigap_dokumentasi` (`sumber='kamera'`), jadi alur SPJ lama jalan.
- Rekan tim: kelompok kortim/PML (`bencana_kelompok_tim`) + alokasi PML-PPL (`bencana_alokasi_subsls`), difilter penugasan aktif di kegiatan sama. Di luar tim: pencarian nama (maks 10).
- Hak admin foto: akun super atau izin `translok.verifikasi` level kelola (konstanta `MENU_ADMIN_FOTO`). PML memeriksa foto timnya (daftar Periksa dan `bolehPeriksa` memakai sumber yang sama sejak 20 Okt).

## Pembaruan 20 Okt 2026
- Akurasi GPS: sampai 300 m hijau (tanpa penanda, tanpa menunggu); 300-5000 m dispensasi berpenanda kuning `akurasi_kasar` (kamera menunggu 30 detik + panduan); > 5000 m ditolak. Konstanta: `MAKS_AKURASI_M` = 300, `MAKS_AKURASI_DISPENSASI_M` = 5000, `TUNGGU_AKURASI_KASAR_DTK` = 30. Penanda `akurasi_sedang` (30-100 m) dihapus. (Sebelumnya: > 100 m ditolak, lalu dispensasi 100-5000 m pada 21 Okt versi kode.)
- Jarak wilayah: `WILAYAH_KUNING_M` 5000, `WILAYAH_MERAH_M` 10.000. Jarak yang dinilai = terdekat antara KK wilayah tugas dan RUMAH petugas (`jarakEfektifM`; `jarakKeRumah` di server memakai `sigap_akun.domisili_lat/lng`). `jarak_wilayah_m` di tabel tetap jarak ke KK; jarak rumah dihitung langsung (tidak disimpan). Tab Periksa menampilkan kedua jarak.
- Revalidasi data lama: 21 foto diperbarui (20 menjadi hijau); rincian di `claude/catatan-perubahan-20okt-2026.md`.
- QR di cap: alamat dasar = `NEXT_PUBLIC_SITE_URL` -> header proxy -> `https://bps-solokkab.up.railway.app`. Bug awal: QR berisi `https://localhost:8080/verifikasi?k=...`. Foto lama tetap berQR salah; kodenya bisa dicari di `/verifikasi?k=<kode>`.
- Cap landscape (lebar >= 1,15x tinggi) dirancang ulang (`bubuhiLandscape`); Foto saya menampilkan alasan "Kenapa perlu perhatian / ditahan".
- Daftar Periksa PML mencakup kelompok-tim (selaras `bolehPeriksa`).
- Tes `lib/__tests__/sigapFoto.test.ts`: 31 lulus.

## Penyimpangan dari mockup
Tanpa peta mini; nagari/kecamatan hanya bila titik dalam 1,5 km dari KK pada Sub SLS alokasi; kode 12 heksa; halaman verifikasi publik tanpa foto arsip dan tanpa koordinat; nomor foto tidak bisa diubah penerima setelah Terima (mengubah = hapus); "Dipertanyakan" hanya menandai, tidak mencabut baris nomor foto yang sudah terisi.

## Pengujian (sandbox; bukan DB produksi, bukan HP)
48 uji lulus pada 19 Okt: 25 logika murni, 4 cap dan sidik gambar (dilihat visual), 7 SQL di PGlite (idempoten, penempatan, ganti nomor tanpa hapus, tahan-lepas, larangan DELETE, unik, hak fungsi), 1 token, 11 route POST dengan DB tiruan. `tsc --noEmit` bersih untuk berkas baru. Skema produksi dibaca (hanya baca) untuk mencocokkan kolom dan batasan; tidak ada trigger lain pada `sigap_dokumentasi`; bucket `sigap-files` privat.

## Belum
Uji di HP Android dan iPhone, di Railway (memori sharp), dan di DB produksi. Uji otomatis untuk `tag/keputusan`, `periksa`, `usulan-hapus`, `pengaturan`. Dua titik pasang: halaman foto kegiatan (bungkus uploader lama dengan `FotoKegiatan`) dan kartu Kelola Foto di beranda portal (`susunBeranda`); berkasnya tidak ada di salinan repo yang saya pegang. Halaman `/verifikasi`: belum diperiksa apakah ada kolom ketik kode.

## Menunggu
User menyalin berkas, menjalankan SQL, menguji satu kegiatan, lalu commit dan push. Opsional: lencana hijau/kuning/merah dan layar PML di mockup.
