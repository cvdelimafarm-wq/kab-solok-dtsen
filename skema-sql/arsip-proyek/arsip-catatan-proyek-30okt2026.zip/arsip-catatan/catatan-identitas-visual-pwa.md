# Identitas visual SIGAP dan PWA (8 Okt 2026)

## Keputusan user
- Nama: SIGAP, kepanjangan "Sistem Integrasi Kegiatan BPS" (cakupan: anggaran/SPJ, pelatihan, delegasi, arsip, pembinaan sistem).
- Logo: ikon S pita biru-emas + kotak kecil (dibuat user di ChatGPT; versi terakhir 5 kotak + garis putih pemisah). Logo selalu di atas latar putih (ubin putih bila di atas latar biru).
- Sidebar backoffice: biru elegan, gradasi #1A4590 -> #0F2A52; menu aktif sorotan transparan + garis emas.
- Warna: biru aksi #1F5FD1 (menggantikan #0B5ED7), navy #0F2A52, emas #F4B400 (teks navy di atas emas), latar #F5F8FE.
- Status: Selesai hijau, Berjalan biru, Perlu perhatian kuning, Terlambat merah, Menunggu abu-abu.
- Backoffice laptop dibuat padat (baris tabel 34 px, chip ringkasan di baris judul, panel detail kanan 340 px).

## Mockup
Kanvas desain "Konsep Ikon SIGAP" (https://claude.ai/artifact/2ShXk3TgW5NeeZ5QPLtuAt), halaman "UI kit dan backoffice": SIGAP UI kit, Backoffice padat (interaktif), PWA (ikon, splash, masuk nama + PIN). Halaman "Konsep ikon": konsep logo lama.

## PWA (disetujui)
- Paket sigap-pwa-ikon.zip: public/manifest.webmanifest, public/icons/icon-{192,512}.png, icon-maskable-{192,512}.png (logo di lingkaran aman 80%), app/favicon.ico, app/icon.png, app/apple-icon.png, sumber/sigap-logo.png (1232 x 1191 transparan), PANDUAN-PWA.md.
- Manifest: short_name SIGAP, theme_color #0F2A52, background_color #FFFFFF, display standalone, start_url /.
- app/layout.tsx: tambah manifest, applicationName, appleWebApp, viewport.themeColor.
- Belum: service worker (offline + prompt pasang), versi vektor logo, layar masuk PWA belum dibangun di kode.
