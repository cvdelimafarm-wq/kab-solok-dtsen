# Status Tahap 31–32: Pelaksanaan dan Gap (25 Okt 2026)

Belum di-deploy. Semua angka dan data uji bersifat fiktif. Tidak ada yang "terbit" sebelum pengguna menyatakan "sudah deploy".

## Keputusan yang dipakai
- Tautan identifikasi ke kegiatan SIGAP dipilih manual oleh penyusun; sistem hanya menyarankan kegiatan yang kode anggarannya memuat kode RO.
- Peringatan dan Gap tampil di halaman baru dalam Perencanaan, ditambah lencana "temuan keras" pada daftar identifikasi. Temuan keras diberitahukan ke PPK lewat notifikasi. Tidak ada yang memblokir.
- Delego satu kesatuan dengan web SIGAP, jadi tidak ada ekspor. Lanjutan Final menghasilkan usulan penugasan yang diterapkan langsung ke `sigap_penugasan`. Bagian penghargaan dan sanksi Delego tidak disentuh.
- Saran arsitektur (sudah disampaikan): satu proyek, satu repo, satu Supabase, satu akun.

## Tahap 31: Pelaksanaan (halaman `/sigap/kelola/perencanaan/identifikasi/[id]/pelaksanaan`)
- A. Kegiatan tertaut (tautkan, lepas; jejak tetap ada; satu kegiatan boleh ditautkan ke beberapa identifikasi).
- B. Usulan penugasan: nama petugas pada lanjutan dipadankan dengan akun aktif. Status: siap, sudah ditugaskan, tarif peran belum ada, nama kembar, akun tidak ditemukan, peran kosong, nama menyusul. Menerapkan hanya menambah penugasan berstatus "siap"; tidak pernah mengubah atau menghapus penugasan yang ada. Kortim menjadi korwil di SIGAP. PPK diberi tahu.
- C. Laporan harian dan keselarasan jadwal dengan jendela pendataan.
- D. Evaluasi (rapat evaluasi tercatat, bahan dari identifikasi awal).
- E. Bendahara: kebutuhan biaya dibanding sisa pagu per akun, dan daftar kesiapan pencairan.
- SQL: `Tahap31/1_20261025zj`, `2_20261025zk` (cek kesehatan).

## Tahap 32: Gap (halaman `.../[id]/gap`)
- Temuan dihitung di aplikasi (`lib/keu/gap.ts`) dari rencana lanjutan dibanding kenyataan: tautan, jumlah petugas (rencana vs ditugaskan, ambang keras: kurang dari 80% rencana setelah pelaksanaan dimulai), jadwal, laporan harian, biaya vs pagu, evaluasi, dan perubahan sesudah H-15.
- Disimpan sebagai versi berurutan yang tidak dapat diubah (`keu_gap`). Jenis "berjalan" (peringatan) dan "akhir" (laporan Gap akhir, hanya sesudah semua kegiatan tertaut berakhir). Penyimpanan yang sama persis dengan versi terakhir tidak membuat versi baru.
- Notifikasi: `gap_keras` ke PPK hanya untuk temuan keras yang BARU; `gap_akhir` ke PPK dan KPA.
- Tanggapan per temuan (diterima / dijelaskan / ditindaklanjuti; dua yang terakhir wajib penjelasan minimal 10 huruf).
- SQL: `Tahap32/1_20261025zl`, `2_20261025zm` (cek kesehatan).

## Pengujian lokal (Postgres 16 dengan stub)
- Uji SQL 50, 51, 52, 53, 54: LULUS. Uji mutasi (merusak aturan sengaja) pada 53 dan 54 gagal sebagaimana mestinya.
- Cek kesehatan zk dan zm: semua baris p0 = 0.
- Vitest lib/keu: 325 tes lulus (termasuk 24 baru pelaksanaan dan 23 baru gap). Lima berkas uji lain gagal dimuat di salinan kerja saya karena modul lain tidak ada di salinan itu (bukan berkas yang saya ubah); dijalankan lengkap di repo laptop saat build.
- tsc (berkas yang tersentuh): bersih, kecuali galat lama di `lib/sigap.ts` dan `lib/keu/rab.ts`.
- Render server (smoke) seluruh kartu baru: lulus.

## Urutan deploy
1. SQL di Supabase SQL Editor, urut: Tahap29 (zf, zg), Tahap30 (zh, zi), Tahap31 (zj, zk), Tahap32 (zl, zm). Setiap berkas `zk`, `zm`, `zi`, `zg` hanya membaca; semua baris `p0` harus 0.
2. Commit dan push repo (berkas sudah ada di laptop), tunggu Railway.
3. Ketik "sudah deploy"; baru saya uji di produksi dengan akun IH dan data fiktif.

## Catatan dan asumsi yang perlu dikonfirmasi
- Laporan Gap akhir sengaja ditolak server bila ada kegiatan tertaut yang belum berakhir (atau tanpa tanggal selesai). Ini bukan memblokir kegiatan, hanya prasyarat laporan akhir. Bila ingin dilonggarkan, bilang saja.
- Temuan dihitung di aplikasi lalu disimpan; basis data memeriksa bentuk dan hak penyimpan serta menyimpan jejaknya, tetapi tidak menghitung ulang temuan.
- Peran "entri" tidak dibandingkan (tidak ada penugasan lapangan untuknya di SIGAP).
- Padanan nama petugas memakai nama persis (huruf besar-kecil dan spasi ganda diabaikan). Nama kembar tidak pernah dipilihkan otomatis.
- Menanamkan peringatan ke halaman Kelola translok yang ada ditunda sampai berkas-berkas itu dibaca dari laptop.
- Tetap terbuka: Arosuka sebagai kota pada kop surat (asumsi), format surat, arti SPKL, dasar hukum uang harian/translok, honor instruktur 522151 vs 521213-C, berkas SBM/paket/SK transport, `keu_kebijakan_rujukan` (ditunda), metode pelatihan pada Gap (data terbatas), serta catatan lama: mockup Version 7, Balai Panjang Sub 03 menunggu `1303.csv`, tugas #141 dan #145, dan baris fiktif identifikasi id 1 ("UJI Fiktif Survei Harga 27a").
