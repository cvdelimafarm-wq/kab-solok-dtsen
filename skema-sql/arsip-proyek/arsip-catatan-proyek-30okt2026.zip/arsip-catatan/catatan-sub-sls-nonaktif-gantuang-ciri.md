# Pembekuan (non aktif) Sub SLS Nagari Gantuang Ciri — 18 Okt 2026

Permintaan user: seluruh Sub SLS di Nagari Gantuang Ciri dibuat NON AKTIF (freeze) agar PML tidak dapat mengajukannya untuk pendataan/FASIH.

## Temuan data
- Nagari ditulis "GANTUANG CIRI" (Kec. Kubung, desa 1303110005): 14 Sub SLS (Jorong Baringin 01-03, Markiyo 01-03, Kapalo Koto 01-03, Pinang Sinawa 01-02, Kampung Baru 01-03), semuanya bukan daftar awal, sudah teralokasi ke PML (96 Irawita, 200 Lucky, 241 Yurneti, 459 Hariston) dan punya daftar KK aktif.
- Belum ada kolom status di bencana_wilayah.
- 5 permintaan masih berlaku (menunggu admin, 17 Okt): 1303110005000101 dan ...0402 (Irawita), ...0501 dan ...0503 (Yurneti), ...0502 (Hariston). Tidak diubah; menunggu keputusan user (batalkan atau biarkan).

## Rancangan (ditulis ke laptop 18 Okt; user menerapkan migrasi dan commit/push)
- Migrasi `supabase/migrations/20261018a_wilayah_nonaktif.sql` (BELUM diterapkan): kolom bencana_wilayah.nonaktif/nonaktif_alasan/nonaktif_at; pemicu BEFORE INSERT di bencana_pendataan_permintaan menolak Sub SLS non aktif (SUB_NONAKTIF) untuk semua jalur; membekukan 14 Sub SLS; catatan audit; **bencana_kolam_progres ditulis ulang agar Sub SLS non aktif tidak masuk target "wilayah awal" (syarat 70% Kolam wilayah)**. Cara mengaktifkan kembali ada di komentar akhir berkas.
- Kode: `SubTim.nonaktif`, `pilihanNonaktif` (lib/pendataan.ts); `ambilTim` memilih kolom baru dengan cadangan ke kolom lama; `buatPermintaan` menolak (409); kartu Plotting tim: lencana "Non aktif", kotak pilih mati, urutan paling bawah; page.tsx: Sub SLS non aktif dikeluarkan dari angka target tim (Progres tim, header Monitoring) dan dari pilihan Sub SLS prioritas; tautan dalam `?kolam=1` membuka mode Kolam wilayah langsung.
- Siaran (Kelola > Pendataan > Siaran): pemilih templat; bawaan "Gantuang Ciri dinonaktifkan + Kolam wilayah" (push + modal jenis Perhatian, tombol "Buka Kolam Wilayah" -> /sigap/pendataan?kolam=1); templat kedua = siaran Peta Batas. **Belum terkirim** (perlu klik admin: "Kirim siaran…" -> "Ya, kirim").
- Uji: lib/__tests__/subNonaktif.test.ts (4 lulus).

## Belum diputuskan
- Nasib 5 permintaan yang sudah diajukan (kini tidak dihitung di target tim).
- Pengingat/kekurangan harian (sigapPengingat/sigapKekurangan) belum diperiksa apakah masih menghitung Sub SLS Gantuang Ciri.
