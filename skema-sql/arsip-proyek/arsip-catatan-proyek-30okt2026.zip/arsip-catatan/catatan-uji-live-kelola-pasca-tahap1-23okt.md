# Catatan: uji langsung SIGAP Kelola setelah deploy Tahap 1 (23 Okt 2026, ±15.50 WIB)

Penguji: Claude lewat Chrome (akun Admin M. Iqbal Hadi; PML Irawita dan PPL Yola lewat "Lihat sebagai"). Baca-saja: tidak ada data diubah. Folder proyek belum terhubung ke sesi, jadi kode tidak diperiksa.

## Lulus
- Tombol Kembali seragam (ikon ‹ + nama tujuan) di Beranda, Kegiatan, Tahap, Lembar Pendataan, Korwil, translok, Perencanaan, Pengadaan, Kelola Aplikasi, /bencana. Kelola Pendataan kini berbingkai sidebar dan punya "‹ Beranda".
- Rantai kembali Korwil -> Tahap -> Kegiatan -> Beranda mundur selangkah demi selangkah (label Korwil: "Tahap kegiatan").
- ?dari= berbahaya aman: `//example.com/x` dan `https://example.com/x` kembali ke Beranda portal, tidak keluar domain.
- Tombol oranye di mode simulasi sudah "Keluar simulasi".
- Lebar HP 390 px (iframe): tidak meluap ke samping di Beranda, Kegiatan, Tahap, Korwil, 4 tab Kelola Pendataan, translok, Perencanaan, Aplikasi. Tab Kelola punya panah geser.
- Tab 5 (Identifikasi SLS, Lapangan per petugas, Foto & dokumentasi) dan tab 6 (Kelengkapan SPJ, Verifikasi & Kunci, Kegiatan & Tarif, Pengadaan & kontrak, Anggaran & lainnya) tersemat.
- Teks PML/PPL "sudah punya hasil" menggantikan "sudah didata".

## Gagal / belum diperbaiki
1. /bencana meluap ke samping di 390 px (scrollWidth 567 > 375); tombol "Muat ulang" 24 px, baris kecamatan 20 px.
2. Ukuran sentuh kecil di HP: "Keluar" 25 px di semua halaman; Admin Aplikasi (+ Tambah 27, × 19, Ubah 27); Perencanaan (Kembalikan contoh awal 19, Tambah RO 31); tabel Kelengkapan SPJ (±200 kontrol 18-33 px); "buka di Maps" 15 px.
3. Admin Delego masih tampil di Beranda admin (chip dan Menu umum) dan sidebar "Delego"; halaman berujung "Tautan Delego belum diatur".
4. /dashboard (Admin Usulan DTSEN) masih memunculkan form Masuk nama + PIN walau sudah login (alamat jadi /?lanjut=%2Fdashboard).
5. Penomoran tahap: admin "Tahap 1 dari 2" (0/2), PML/PPL "Tahap 3 dari 4" (2/4).
6. Daftar tautan admin tampil dua kali di Beranda admin (chip di atas + Menu umum).
7. Perencanaan masih berlabel uji coba (data RO contoh, tersimpan di peramban).
8. Bagian "Nomor foto 5/5" PPL masih desain lama (Pindah ke nomor, Ganti foto N, "Perlu perhatian" tanpa alasan); desain kisi + modal konfirmasi belum dikerjakan.
9. /bencana punya dua tombol Beranda (tombol "Beranda" dan tautan "Ke Beranda SIGAP").

## Data (sama seperti audit pagi, belum disentuh)
- Ringkasan Kelola: "Sudah didata 9.7xx (9% dari 105.570)" vs tab Monitoring (capaian vs target tim). Dua penyebut berbeda tanpa label.
- Penyebut petugas: Kelengkapan SPJ 100 petugas aktif, "Hari ini lengkap 15 / 90"; Siaran 97 penerima.
- Kolom "Hari kerja" tabel SPJ memakai "N / tanpa batas".

## Di luar cakupan uji
Akses Kelola oleh akun non-admin sungguhan (tidak bisa diuji lewat Lihat sebagai), tombol yang mengubah data, unduh SPJ, kamera.
