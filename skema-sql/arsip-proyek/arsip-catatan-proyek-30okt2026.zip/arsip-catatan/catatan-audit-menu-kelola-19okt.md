# Audit menu & alamat /sigap/kelola/translok (19 Okt 2026, sore)

Sumber: halaman hidup lewat Claude in Chrome (akun super Iqbal), tabel `sigap_kegiatan` & `sigap_kegiatan_tarif` (baca-saja), catatan Project. Kode halaman admin translok TIDAK ada di salinan cloud (hanya subset berkas), jadi tidak diaudit dari kode. Tidak ada tombol aksi yang ditekan (tanpa kunci/tambah/simpan); hanya pindah tab & pilih kegiatan.

STATUS: review disimpan; belum ada kode/mockup yang dikerjakan. Menunggu "setuju" Iqbal untuk mulai (mockup beranda admin + alur persetujuan keuangan).

## Peta menu sidebar admin -> alamat
- Beranda: tombol, TANPA alamat (tab di /sigap/kelola/translok). Logo SIGAP -> "/" (Beranda lain).
- Perencanaan: Perencanaan kegiatan -> /sigap/kelola/perencanaan (UJI COBA, data di browser); RAB/POK, Revisi anggaran = "segera".
- Pelaksanaan: Transport lokal (nonaktif: akun tak punya penugasan); Pelatihan -> /sigap/pelatihan (admin dialihkan ke /sigap/kelola/pelatihan); Kelola pelatihan -> /sigap/kelola/pelatihan; Perjalanan dinas, Honor = "segera"; Pengadaan -> /sigap/kelola/pengadaan.
- Referensi: SIGAP PEDIA -> /sigap/pedia; Register & arsip bukti -> /sigap/kelola/pedia.
- Monitoring: Realisasi dan serapan, Sinkronisasi Delego = "segera"; Monitoring lapangan -> /sigap/kelola/lapangan.
- Administrasi: Admin transport lokal (+ sub: Monitoring, Penugasan & ST, Kegiatan & Tarif, Verifikasi & Kunci = tombol, alamat tetap /sigap/kelola/translok); Peran dan akses -> /sigap/kelola/akses; Aplikasi & periode -> /sigap/kelola/aplikasi; Delego -> /sigap/kelola/delego ("Tautan Delego belum diatur"); Unggah daftar KK -> /sigap/kelola/pendataan (isi: tab "Unggah & Siaran" dan "Monitoring").
- Alamat lama dialihkan benar: /sigap/admin, /sigap/pelatihan/kelola, /sigap/kontrak, /sigap/akses, /portal/admin. Semua 11 alamat sidebar terbuka (200).

## Temuan konsistensi (urut prioritas)
1. Dua "Beranda": logo -> "/" menampilkan Tugas aktif "Penyisiran & Identifikasi SE2026" (tidak relevan bagi admin); "Beranda" sidebar = ringkasan admin (Perlu tindakan 8) di alamat translok. Beranda admin sebaiknya punya alamat sendiri.
2. Alamat tidak mengikuti menu: 6 tampilan (Beranda, Daftar kegiatan, Monitoring, Penugasan & ST, Kegiatan & Tarif, Verifikasi & Kunci) satu alamat; kegiatan terpilih lewat pilihan di header. Breadcrumb "Admin transport" (menu: "Admin transport lokal").
3. Penamaan/penempatan: "Transport lokal" (Pelaksanaan, versi petugas) vs "Admin transport lokal" (Administrasi); Pelatihan dan Kelola pelatihan berujung halaman sama bagi admin; Pengadaan di Pelaksanaan (rancangan: persiapan); "Monitoring" muncul 4 kali (grup, tab translok, tab Kelola Pendataan, Monitoring lapangan); "Unggah daftar KK" ternyata halaman "Kelola Pendataan" (unggah, siaran, monitoring).
4. Tata letak tidak seragam: Monitoring lapangan & Kelola Pendataan tanpa sidebar ("← Beranda" ke "/"); Aplikasi & periode berheader navy "← Beranda portal", judul "Periode kegiatan" (menu "Aplikasi & periode").
5. Menu mati: 6 "segera" + Delego buntu (tampak aktif). Dua kepanjangan SIGAP: "Sistem Integrasi Kegiatan BPS" (header) vs "Gerak Anggaran & Pertanggungjawaban" (kaki sidebar).
6. Modal "Unggah foto pelatihan" masih muncul di Kelola Pelatihan (kode pematian sudah ditulis ke laptop, menunggu commit/push/deploy).
7. Beranda admin: "Kegiatan aktif 3 / 3 sudah berjalan" padahal Pelatihan tanggal selesai 8 Okt (daftar menandai "Selesai") dan masih menghasilkan 3 butir mendesak; "Petugas aktif 249" = 96+59+94 (penjumlahan penugasan; orang ikut >1 kegiatan kemungkinan terhitung berulang, perlu dicek).

## Pencocokan dengan aturan keuangan / RAB / lapangan
- Verifikasi & Kunci Pascabencana: "Total nominal Rp410.890.000" memuat hari rencana sampai 10 Nov (mis. Hariston PML 24 hari = Rp4.080.000) -> proyeksi, bukan realisasi; label perlu "Rencana".
- Nominal = hari x Rp170.000. Aturan 15 Okt (5/1 poin, jarak, target 45, hutang kumulatif, 1 O-K/hari, bulat ke bawah) belum terpasang di Verifikasi/SPJ (S-04 belum dibangun); jangan dikunci SPJ untuk Pascabencana sebelum ada keputusan PPK/SPK.
- Kuota O-K (Pascabencana PPL 3.458, PML 980; SPDT 500 & 500) ada di DB, tetapi tidak tampil di Admin Translok; Beranda: "Pagu & realisasi - Menunggu modul RAB/POK". RAB/POK & Revisi "segera"; Perencanaan kegiatan masih uji coba (localStorage) -> rantai RO -> Sub Komponen -> detail -> kuota belum tersambung.
- SPDT NTP: PML tarif Rp170.000 (catatan lama "sementara 58.472"); "Maks hari: tanpa batas" di tingkat peran sedangkan kuota 500 O-K dan per orang 3 hari. Cocokkan ke RKKS/SBM.
- Pelatihan PSP: kode anggaran ...524114 (paket meeting) sedangkan uraian tarif "Perjalanan peserta pelatihan di kab/kota" Rp170.000; aturan skema: kantor dalam kota = 524113-A, hotel dalam kota = 524114. Cocokkan akun dengan penyelenggaraan sebenarnya.
- SPDT: baris "1 hari tidak dibayar" tetap menampilkan nominal Rp170.000 (mis. BUKHTIAR, NOVAL) -> perjelas apakah nominal sudah dipotong.
- Pascabencana: seluruh Korwil 0 hari & ST belum ada (Beranda: 13 petugas ST belum bernomor).

## Usulan (belum dikerjakan; UI besar = mockup dulu, menunggu "setuju")
Tahap awal (tidak mengganggu target 30 Okt):
- Beranda admin beralamat sendiri (mis. /sigap/kelola), jadi tujuan logo bagi akun admin; ringkasan keuangan (kuota, rencana vs realisasi) di sana.
- Alamat per tab: /sigap/kelola/translok/{monitoring|penugasan|tarif|verifikasi}?kegiatan=<id>.
- Kelompokkan menu mengikuti alur: Perencanaan (RAB/POK, Revisi, Perencanaan kegiatan) -> Pelaksanaan lapangan (Pelatihan, Pendataan, Translok) -> Keuangan (Verifikasi & Kunci, Honor, Perjadin, Pengadaan) -> Monitoring -> Administrasi. Satu kamus nama; sembunyikan menu "segera" untuk non-admin; seragamkan kerangka halaman.
- Alur persetujuan keuangan: petugas isi -> PML periksa -> admin verifikasi -> PPK setujui -> bendahara bayar; tiap langkah tercatat (siapa/kapan), buka kunci wajib alasan; pejabat (KPA/PPK/bendahara) dengan masa berlaku (menggantikan lib/spjPejabat.ts).
- Aturan kegiatan sebagai paket berlaku-mulai-tanggal (tarif, kuota, maks hari, bobot poin, akun anggaran); SPJ lama tetap pakai aturan lamanya.
Tahap berikutnya:
- Beranda per peran (admin/PJ, PPK, bendahara, pimpinan); "Kegiatan yang saya kelola" (admin kini tak bisa buka Layer 2).
- Rantai anggaran RKKS/POK -> kegiatan -> kuota -> realisasi -> sisa pagu; perbandingan versi POK; peringatan dini kuota; katalog skema belanja (22 skema, 265 dokumen) + status per dokumen.
- Perencanaan GSBPM tersimpan di database (kini localStorage), duplikasi kegiatan, jadwal & risiko ringan.
- SDM lintas kegiatan: satu profil (riwayat, beban, penilaian mitra), kalender petugas, cadangan peran.
- Satu daftar pengingat server (modal, lonceng, push, Beranda).
- Kerapian: alamat/tombol kembali konsisten, kamus istilah, kepanjangan SIGAP tunggal, panduan per peran ke SIGAP PEDIA.
- Tata kelola: pisahkan akun harian dari akun super (9 peran; pakai "Masuk sebagai" untuk uji), jejak audit tunggal, tutup utang skema S1/S2 (RLS/definer; cek kondisi terbaru), perbaiki kebocoran memori klien Supabase (menunggu "setuju").
