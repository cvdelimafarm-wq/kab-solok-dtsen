# Hasil perbaikan uji HP Android per peran: 26 Okt 2026

Sumber temuan: `claude/catatan-uji-android-per-peran-26okt.md`. Semua kode sudah ditulis ke repo laptop (27 file). Belum di-commit, belum di-deploy. Tidak ada SQL baru.

## Bagian A (data)
- A1 satu fungsi hari kerja: `lib/ringkasHariKerja.ts` (+tes). Hari ini tidak dihitung lengkap/terlewat. Dipakai Korwil Administrasi, Transport Lokal, `korwilMonitor`.
- A2 "Sub SLS identifikasi" dan "Sub SLS pendataan" dibedakan di teks tahap (`lib/sigapTahap.ts`).
- A3 teks "dibagi" dijelaskan di Korwil (jumlah Sub SLS unik vs jumlah per tim).
- A4 satu fungsi nama: `lib/namaTampil.ts` (+tes). Data di database tidak diubah.

## Bagian B (bahasa)
- B1 kartu ketiga Korwil: "Capaian".
- B2 dua istilah: "Sudah punya hasil" (semua hasil termasuk tidak ditemukan) dan "Berhasil didata" (terdampak + tidak terdampak). Angka tidak bergeser. "Tdk" menjadi "Tidak".
- B3 daftar kata sulit TIDAK disetujui, tidak diubah.
- B4 kalimat batas bertahap dihapus; "Plotting tim hari ini" diperbaiki.
- B5 kalimat izin susulan: "Isian tanggal ini sudah tutup. Minta izin susulan ke admin bila perlu." (memakai "tanggal ini", bukan "hari ini", karena merujuk tanggal yang sudah lewat).
- B6 Beranda PML/PPL menampilkan "PML · Tim <nama>" / "PPL · Tim <nama>". Butuh deploy `lib/portal/induk.ts` (hanya field opsional).
- B7 duplikat "Tinggal 1 foto lagi" / "Foto kurang 1" dihapus.
- B8 kalimat daftar ganda di halaman tahap dihapus.

## Bagian C (tampilan)
- C1 Lembar Pendataan (Plotting tim) lebih pendek: panduan tertutup bawaan (diingat di localStorage), daftar "Sudah di-assign ke FASIH" ganda dihapus, PPL melihat Sub SLS miliknya dulu.
- C2 Monitoring Korwil Lapangan: kartu ringkas, rincian wilayah dan petugas tertutup bawaan, badge "Capaian terendah".
- C3 Rekap identifikasi dipindah setelah semua tugas bernomor.
- C4 dilewati sesuai keputusan. C9 dibiarkan.
- C5 legenda peta tumpang tindih: penyebabnya salah ketik kelas `left-2.5flex`. Penjelasan angka "N/M KK" di pemilih Sub SLS ditambahkan.
- C6 ruang bawah halaman Pendataan `pb-28` menjadi `pb-40` agar tombol melayang tidak menutup kartu.
- C7 target sentuh minimal 44 px (chip, tab, tombol Keluar, avatar, baris pemilih).
- C8 sebagian: target sentuh sudah; label ikon dan chip peran kembar belum (butuh tangkapan layar atau nama label tepatnya).

## Belum selesai / perlu keputusan
- Kata "didata" di Kolam Wilayah: artinya "punya hasil" atau "berhasil didata"? Belum diubah.
- `PlottingTim.tsx` memakai cast `ppl_akun_id`; belum diperiksa tsc.
- `sigapPrioritas.test.ts` (ekspektasi "Foto kurang 2 dan 1 hal lain") belum dijalankan.

## Langkah user
`npx tsc --noEmit`, `npx vitest run`, `npm run build`, commit, push, deploy. Lalu uji HP lebar 360 dan 412 px untuk Korwil, PML, PPL.
