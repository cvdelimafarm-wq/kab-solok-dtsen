# Catatan SQL berkas l: gerbang tulis `keu_tulis` dan gerbang panggil `keu_jalankan`
Tanggal 24 Okt 2026. Berkas: `20261024l_keu_tulis.sql`, `20261024z7_cek_kesehatan_keu_l.sql`, uji `44_uji_tulis.sql`, pelari `jalan_l.sh`. Tidak menambah tabel (tetap 53). Belum dijalankan di produksi.

## Mengapa ada
Aplikasi memakai supabase-js (PostgREST): tiap panggilan satu transaksi dan tidak bisa menjalankan `set_config('app.akun_id', ...)` lebih dulu. Tanpa akun pelaku, penjaga tabel (kewenangan, pembekuan, audit) tidak memeriksa apa pun. Fungsi `keu_tulis(p_akun, p_tabel, p_op, p_data, p_kunci)` menyetel akun pelaku di dalam transaksi yang sama, lalu insert atau update satu baris tabel `keu_`. Semua trigger penjaga tetap berlaku. Fungsi `keu_...` lain sudah menerima `p_akun` sendiri.

## Dua gerbang
- `keu_tulis(p_akun, p_tabel, p_op, p_data, p_kunci)`: insert atau update satu baris tabel keu_.
- `keu_jalankan(p_akun, p_fungsi, p_args jsonb)`: memanggil fungsi keu_ dari daftar izin (di dalam fungsinya; bantu dan pemicu tidak termasuk) dengan argumen bernama. Penting karena banyak fungsi alur (mis. `keu_pok_berlakukan`, `keu_rab_hapus_baris`, `keu_kk_*`) membaca akun dari sesi; dipanggil langsung lewat supabase-js sesinya kosong sehingga pemeriksaan hak dilewati. Gerbang ini selalu menyetel akun dan mengisi `p_akun` sendiri (klien tidak boleh mengirim `p_akun`). Fungsi yang mengembalikan himpunan menghasilkan larik JSON.

## Aturan
- Hanya `service_role` (server aplikasi) yang boleh memanggil; akun pelaku harus ada dan aktif (aplikasi mengambilnya dari sesi bertanda tangan, bukan dari masukan pengguna).
- Hanya insert dan update; tidak ada hapus. Tabel `*_riwayat` dan tabel non-`keu_` ditolak. Kolom yang tidak ada ditolak; kolom identitas tidak bisa diisi; kunci utama tidak bisa diubah; update wajib menyebut tepat kolom kunci utama.
- Status berkas yang hanya boleh berubah lewat fungsi alur tetap ditolak penjaga (diuji: status usulan struktur lewat gerbang ditolak).

## Cek dan uji
`z7` baris 1 sampai 5 harus 0. Uji 44 memeriksa hak (termasuk fungsi tanpa p_akun lewat keu_jalankan), validasi gerbang, CHECK tabel, audit dengan akun pelaku, dan hak eksekusi. Seluruh rangkaian a-f, h, i, j, k, l lulus.
