# Status tahap 22: papan 2 (Alur) dan papan 3 (Pemicu), 25 Okt 2026

Dengan tahap ini, 16 papan mockup Kertas Kerja Revisi POK sudah terbangun. Data contoh pada halaman Pemicu adalah ILUSTRASI (angka rekaan), tidak membaca data nyata.

## Yang dibangun
- `/sigap/revisi/pemicu` (papan 3): tabel pemicu P-01 sampai P-08 (kode, nama, kapan ditandai, contoh baris), kartu tingkat pergeseran 1 sampai 5 beserta jalurnya, pilihan skenario (T00, T01, T02, T03, T05b, T04, T06, T07, T15), tabel baris skenario berikut pemicu dan jalur, dan kotak Hasil: jenis revisi disarankan (Revisi POK / Administrasi / DIPA DJPb / DIPA DJA), tingkat, alasan, catatan campuran, lampiran, dan tenggat pengingat dari `keu_v_tenggat`.
- `/sigap/revisi/alur` (papan 2): A. Sebelum revisi (A1 sampai A6, status Draf); A+ Bila anggaran kurang (K1 K2, cabang Revisi POK K3 sampai K5, cabang Revisi DIPA P1 sampai P4); B. Saat revisi (B1 sampai B4, hasil Dikembalikan/Ditolak/Disahkan, catatan tenggat Pasal 175); C. Sesudah revisi (C1 sampai C4); penutup. Tiap langkah ditautkan ke halaman SIGAP yang mengerjakannya.
- `/sigap/revisi` (Jadwal revisi): dua tombol tautan baru ke Alur dan Pemicu.

## Logika murni (tanpa DB)
- `lib/keu/pemicu.ts`: `pemicuBaris`, `tabelPemicu`, `tingkatDari`, `lintasJenis`, `saranDari`, `SKENARIO`, `META_CONTOH`. Tingkat dan saran diporting dari `kk-logic.js` mockup; menghitung netto per kelompok (KRO, Kegiatan, Program) dan per jenis.
- `lib/keu/alur.ts`: teks langkah dan `TAUTAN_LANGKAH`.
- Pengujian: pemicu 11 tes, alur 3 tes; seluruh `lib/keu` 389 tes lulus; tsc bersih; render uji (smoke) kedua halaman lulus.

## Catatan
- Tidak ada migrasi SQL baru pada tahap ini. Halaman Pemicu hanya membaca `keu_v_tenggat`.
- Pemicu nyata pada kertas kerja tetap dihitung oleh fungsi pemicu di basis data (`20261024f_keu_kertas_kerja.sql`); halaman ini hanya penjelasan dan simulator.
- Kekurangan yang masih terbuka (tidak diubah): akun 512212 belum ada di master, alasan versi RAB, jalur penutup, pengurangan realisasi SPAN, halaman kekurangan seluruh satker, padanan baris POK baru/hilang, jadwal 7 masih pada POK lama, uji tulis geseran/keputusan PPK/Kembalikan, pencabutan kewenangan, unduhan ekspor, persetujuan KPA bila pagu di bawah realisasi, sumber data Booked, konstanta LIBUR terbatas akhir 2026.

## Berkas
lib/keu/pemicu.ts, lib/keu/alur.ts, lib/keu/__tests__/pemicu.test.ts, lib/keu/__tests__/alur.test.ts, app/sigap/revisi/pemicu/page.tsx, app/sigap/revisi/alur/page.tsx, app/sigap/revisi/page.tsx.

## Uji produksi (setelah deploy)
Buka /sigap/revisi, tekan tombol Alur dan Pemicu; pada Pemicu pindah-pindah skenario dan cocokkan Hasil (T01 sama dengan Revisi POK tingkat 1, T05b sampai T07 menurut papan 3); pada Alur klik tautan tiap langkah. Data fiktif saja.
