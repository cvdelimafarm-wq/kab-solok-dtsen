# Catatan 23 Okt 2026: cek PMK revisi anggaran terhadap Skema Pengelolaan 1 Kegiatan Statistik (Draf 3)

Status: hasil pemeriksaan. Tidak ada dokumen lain yang diubah. Menjawab Q-16 dan G-15 pada skema (kecuali Perdirjen, lihat bagian "Belum pasti").

## Dasar yang dibaca (teks penuh)
- PMK 62/2023 (ditetapkan 20 Jun 2023): Perencanaan Anggaran, Pelaksanaan Anggaran, serta Akuntansi dan Pelaporan Keuangan. Induk.
- PMK 107/2024 (13 Des 2024): Perubahan pertama. Mengubah antara lain Pasal 124, 144, 146, 171, 174, 175.
- PMK 41/2026 (12 Jun 2026): Perubahan kedua. Mengubah antara lain Pasal 144, 157, 158A (baru), 165, 175 ayat (6), 182-184, dan mengganti Lampiran IV (termasuk tabel kewenangan huruf C). TIDAK mengubah Pasal 120, 124, 172, 173, 174.
- Ketiganya bukan naskah terkonsolidasi; perubahan saya terapkan sendiri. Tabel kewenangan yang dipakai = Lampiran IV huruf C versi PMK 41/2026.
- Pasal inti revisi: 120 (tiga jenis revisi), 123 (Menkeu dapat membatasi revisi), 124 (siapa menetapkan; ayat 3: usul pengesahan DIPA diajukan SEBELUM pelaksanaan kegiatan terdampak), 172 (mekanisme di Kanwil DJPb), 173 (wewenang KPA), 174 (revisi K/L yang mengubah DIPA), 175 (batas akhir), 179 (lewat batas).

## Hasil cek butir skema
1. Pergeseran dalam 1 KRO oleh KPA (Mode Revisi POK): SESUAI, kurang lengkap. Pasal 173 ayat (1)-(3); Lampiran IV.C angka 5 a-c (antar-RO dalam 1 KRO dan 1 Satker; dalam 1 RO; tambah/ubah akun dalam 1 RO). Syarat PMK: tidak mengubah sumber dana, PAGU SATKER, SATUAN dan volume RO, jenis belanja, dan dilakukan dengan memperhatikan hasil reviu APIP K/L atas RKA-K/L. Skema belum memuat pagu satker, satuan RO, dan APIP. Penguncian di tingkat KRO = batas PMK (jawaban Q-19).
2. "Bukan RO PN": lebih ketat dari PMK. Lampiran IV.C angka 5e membolehkan KPA dalam 1 RO PN, 1 Satker, 1 jenis belanja, tanpa ubah output dan lokasi. Boleh dipertahankan sebagai aturan internal, beri label internal.
3. Antar-jenis belanja tanpa turun volume RO ke Kanwil DJPb: SESUAI. Pasal 124 ayat (2)(b); Lampiran IV.C angka 2.q. Tambah: bila menurunkan volume RO total, ke DJA (2.q, 2.u); antar-Kanwil ke Direktorat Pelaksanaan Anggaran DJPb. PER-9/PB/2023 Pasal 7 huruf f dan Pasal 12 huruf g terverifikasi di naskah JDIH. "Jenis belanja = dua digit pertama akun" TERVERIFIKASI (Lampiran II PMK 62/2023 hlm. 440, kalimat sama di lampiran PMK 107 dan 41); hapus tanda (cek). Dari kalimat itu juga: perubahan pada empat digit terakhir akun adalah kelonggaran KPA, jadi pelonggaran P dan B (sama-sama 52) sah.
4. "Antar-KRO, antar-kegiatan, antar-satker: persetujuan Eselon I dan pengesahan Kanwil": PERLU DIPECAH.
   - Antar-Kegiatan, antar-Satker, penambahan Kegiatan baru: surat persetujuan pejabat Eselon I (daftar "antara lain") + pengesahan Kanwil (Pasal 172 ayat (1)(a)(2), (4)-(6); proses 1 hari kerja sejak lengkap).
   - Antar-Program atau antar-Eselon I dalam K/L: DJA (Lampiran IV.C 2.b, 2.c, 2.af).
   - Antar-Satker antar-Kanwil: Direktorat Pelaksanaan Anggaran (Pasal 171, 124 ayat (2)(b)(1)).
   - Antar-KRO dalam 1 Kegiatan: di luar Pasal 173; jalur Kanwil. CATATAN KERANCUAN: Lampiran 2.af menulis KPA berwenang "dalam 1 Satker sepanjang tidak mengubah volume RO, jenis belanja, sumber dana", sedangkan Pasal 173 membatasi pada 1 KRO dalam 1 Kegiatan. Ikuti yang ketat sampai ditanyakan ke Kanwil.
5. Penambahan pagu bukan wewenang KPA: SESUAI. Pasal 120 ayat (2); Lampiran IV.C angka 1 (hampir seluruhnya DJA); jalur lewat Eselon I (Pasal 165 ayat (1)(a)).
6. Belanja pegawai tidak jadi sumber penutup: SESUAI ARAH, dasar kini jelas. Pasal 146 ayat (2) (versi PMK 107): hanya dari belanja pegawai operasional ke belanja barang operasional, tidak boleh membuat pegawai operasional satker minus akhir tahun, usul ke Kemenkeu dilampiri surat persetujuan Sekjen/Sestama (bukan sekadar pernyataan pejabat satker). Pasal 144 ayat (1) (versi PMK 41): revisi terkait Belanja Operasional hanya untuk kekurangan Belanja Operasional dan kebutuhan non-operasional pada RO Khusus. Kesimpulan saya (inferensi, bukan kalimat eksplisit): memakai belanja operasional untuk menutup kegiatan non-operasional praktis tertutup kecuali RO Khusus. Pagu minus: Pasal 147. Gaji boleh melampaui DIPA: Pasal 180 ayat (4)-(5).
7. Pagu baris tidak boleh di bawah Booked + Realisasi: dasar PRINSIP, bukan pasal eksplisit. Pasal 180 ayat (2)-(3): DIPA batas tertinggi; tindakan yang berakibat pengeluaran tidak dapat dilakukan bila anggaran tidak cukup. Istilah Booked tidak ada di PMK. "Self blocking" di PMK = sanksi disinsentif anggaran ke K/L, bukan kolom POK.
8. RO Khusus / Komponen Khusus: SESUAI. Definisi PMK 41 Pasal 1 angka 139-141 benar. Isi: Pasal 157 ayat (6)(c) dan 158A: Komponen Khusus + catatan Halaman IV.B "Pemanfaatan alokasi didasarkan pada Keputusan Menteri/Pimpinan Lembaga"; pemanfaatan lewat Komponen baru dengan Keputusan Menteri/Pimpinan Lembaga; pembayaran melampirkan salinan keputusan + SPTJM KPA; sisa sampai akhir TW III dapat dialihkan lewat revisi. Pembentukan Komponen Khusus = DJA (Lampiran IV.C 3.e.2.d). Koreksi: "Izin Presiden" (angka 141) dipakai di Pasal 159 ayat (2)(b), bukan syarat RO Khusus; jangan disatukan di Q-20.
9. Baris penggenap lump sum (PAKET, volume 1): TIDAK ADA rujukan di tiga PMK, tidak didukung dan tidak dilarang eksplisit. Pasal 124 ayat (4) menelaah relevansi akun/detail dengan RO, jadi baris penutup rawan dipertanyakan. Tetap (cek aturan); tanyakan ke Kanwil/APIP sebelum dikodekan.
10. Alur status Mode Revisi DIPA: PERLU TAMBAH. Pasal 172 ayat (3) dikembalikan bila dokumen belum lengkap, ayat (5) ditolak, ayat (6) 1 hari kerja; Pasal 174 ayat (1)(d) dokumen asli disimpan KPA; Pasal 124 ayat (3) pengajuan sebelum kegiatan terdampak dilaksanakan. Usul status: Diterapkan ke kertas kerja, Disetujui KPA, (Persetujuan Eselon I bila perlu), Diajukan, Dikembalikan / Ditolak / Disahkan. Belanja yang terdampak jangan dikomitmenkan sebelum Disahkan.
11. G-10 pengganti KPA: Pasal 183 ayat (1) (versi PMK 41): Plt/Plh Kepala Satker otomatis menjadi KPA, penunjukan disampaikan ke KPPN (ayat 1a); KPA ex officio (Pasal 182 ayat 1a). PPK tidak boleh dirangkap KPA/PPSPM (Pasal 187 ayat 5).

## Tenggat (TIDAK ada di skema)
- 31 Okt: usulan ke DJA (antar-Program, antar-Eselon I, perubahan pagu, dll.). Pasal 175 ayat (1)(a). Item tertentu 15 Des (ayat 9: mis. pergeseran belanja pegawai, PNBP, revisi Rumusan Informasi Kinerja) dan 27 Des (ayat 10).
- 30 Nov: usulan ke DJPb (Kanwil/Dit PA) dan revisi kewenangan K/L yang mengubah DIPA (Pasal 174 ayat 1 huruf a), kecuali pagu minus belanja pegawai operasional. Pasal 175 ayat (1)(b)-(c).
- 27 Des: pemutakhiran POK oleh KPA (Lampiran IV.C 5d) dan yang mengubah Halaman III DIPA serta revisi administrasi ke DJPb. Pasal 175 ayat (14).
- 31 Des: pagu minus belanja pegawai. Pasal 175 ayat (15).
- Ayat (17): dokumen lengkap dan benar saat diterima. Ayat (18): jatuh pada hari libur/cuti bersama dimajukan ke hari kerja terakhir sebelumnya. 31 Okt 2026 = Sabtu (praktis Jumat 30 Okt); 27 Des 2026 = Minggu (cek cuti bersama). Lewat batas hanya untuk direktif Presiden/prioritas penting dan mendesak dengan persetujuan Menkeu (Pasal 179).

## Dampak ke yang sudah dibangun
- Artboard Revisi-Anggaran: u1 (2907 ke 2906), u2 (ke 2903), u4 (ke 2902) berlabel "Antar RO, satu program" dan baris 133 menulis "Antar RO: persetujuan KPA". Kode menunjukkan Kegiatan berbeda, jadi antar-Kegiatan: bukan wewenang KPA (Pasal 173 ayat (1)(a)); perlu surat Eselon I + pengesahan Kanwil. u3 (ke 2886.EBA.994, antar Program): DJA, kecuali dipenuhi sebagai kekurangan Belanja Operasional (Pasal 174 ayat (1)(a)(1), pengesahan Kanwil, tenggat 30 Nov).
- Penanda jenis pergeseran (lib/anggaranRab.ts: dalam RO, antar RO, antar program) perlu lima tingkat: dalam RO, antar-RO dalam KRO, antar-KRO dalam Kegiatan, antar-Kegiatan, antar-Program. Tetap sebagai penanda, bukan keputusan.
- keu_revisi.jenjang_berwenang (satker/kanwil/pusat) terlalu kasar. PMK punya enam pemutus: KPA, Eselon I K/L, Sekjen/Sestama K/L, Kanwil DJPb, Dit. Pelaksanaan Anggaran DJPb, DJA. Status keu_revisi belum punya "dikembalikan". Kolom jenis (pagu/rincian/administratif) cocok dengan Pasal 120 ayat (1) a/b/c.

## Belum pasti
- PER-9/PB/2023 (13 Sep 2023, Petunjuk Teknis Revisi Anggaran kewenangan DJPb) ada di JDIH dan pasal yang dikutip skema (7 f, 12 g, 14 ayat 1, 33) cocok; belum terkonfirmasi masih berlaku utuh setelah PMK 107/2024 dan 41/2026. Pasal 32 ayat (6)(d) PER-9 memuat tenggat 27 Des. "Sepuluh syarat" dari halaman Kanwil Sultra tidak ada di PER-9; yang setara ada di PMK 62 Pasal 173 ayat (3), rujuk itu.
- Kolom wewenang pada beberapa baris Lampiran IV.C sulit dibaca dari teks hasil ekstraksi (mis. baris 2.i); tidak dipakai sebagai dasar.
- Apakah POK BPS Kab. Solok punya RO Khusus (Q-20) hanya bisa dijawab dari POK.
- Perdirjen Perbendaharaan terbaru dan SK cuti bersama 2026 tidak diperiksa.
