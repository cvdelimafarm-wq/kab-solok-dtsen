# Tombol menuju tempat perbaikan nomor foto (21 Okt 2026)

Lanjutan dari catatan-nomor-foto-otomatis-pengaman-kirim-21okt.md.

Pertanyaan M. Iqbal Hadi (kasus Marvi Gusneriza, 7 foto tetapi tercatat 4/5): di mana tempat memperbaikinya dan adakah tombol yang mengarahkan petugas ke sana?

- TEMPAT PERBAIKAN = kartu hari (halaman kerja Transport Lokal, tab Hari Ini / Hari Kerja) -> bagian Foto -> panel "Nomor foto n/5" (SusunFoto). Di situ ada "Pindah ke nomor", "Foto cadangan" dengan "Pasang di nomor", dan tombol "Isi nomor kosong otomatis".
- Alamat dalam (sudah ada, `lib/sigapTautanKerja.ts`): `/sigap/translok/<token>?p=<penugasan>&tab=hari_ini|hari_kerja&tgl=YYYY-MM-DD&fokus=foto` (halaman menggulir dan menyorot `bag-foto-<tgl>`).
- Tombol baru 1, layar Kamera SIGAP: GET `/api/sigap/foto/susun` kini mengembalikan `href_kerja`; `KameraSigap.tsx` menampilkan banner kuning "Ada n foto belum bernomor" + tombol "Rapikan nomor foto" (Link) bila `cadangan > 0` dan masih ada nomor kosong, disembunyikan saat pratinjau foto sedang terbuka.
- Tombol baru 2, kartu "Foto kurang" di Beranda: `IsianHari.cadangan` dan `IsianTranslok.cadangan` diisi `hitungCadanganFoto` (lib/portal/kegiatan.ts: tag pemotret berstatus diajukan/dilepas yang fotonya tidak dipakai di `sigap_dokumentasi`, tidak termasuk merah-belum-diperiksa dan dipertanyakan). Bila cadangan > 0 judul menjadi "Nomor X masih kosong, ada n foto belum terpakai", ringkas "n foto belum bernomor", tombol "Rapikan nomor foto" (href tetap `tab=hari_ini&fokus=foto`). Kode kartu bertambah `:c<n>` sehingga modal pengingat muncul lagi.
- Tes: `lib/__tests__/kekuranganRapikan.test.ts` (5); seluruh sandbox 260 uji + 35 uji lama (sigapKekurangan, kegiatanTranslok) lulus; tsc bersih. Paket sudah dikirim ke laptop (belum commit/deploy).
- Berkas berubah: lib/sigapKekurangan.ts, lib/portal/kegiatan.ts, app/api/sigap/foto/susun/route.ts, app/sigap/foto/KameraSigap.tsx, lib/__tests__/fotoSusunRoute.test.ts, lib/__tests__/kekuranganRapikan.test.ts (baru).
- Keputusan data tertunda: menempatkan foto 556 milik Marvi ke nomor 3 (penugasan 185, 2026-10-21) menunggu konfirmasi; petugas juga bisa melakukannya sendiri lewat tombol di atas setelah deploy.
