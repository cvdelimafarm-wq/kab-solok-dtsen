# Catatan impor POK 2026 (posisi 30 Sep 2026) ke produksi — 24 Okt 2026

Status: SELESAI dan terverifikasi di produksi (project nlwkpakyfprugqwklxiu).

## Hasil
- `keu_pok_versi` id 2: tahun 2026, nomor_revisi 1 (SEMENTARA), jenis revisi, tanggal efektif 2026-09-30, status **berlaku**.
- 524 node, 677 baris detail, total **Rp13.431.536.000**.
- `keu_v_pok_selisih` tidak ada selisih; md5 isi detail = 342fc53740221235cd2696ee9e1613bc (sama dengan hasil sandbox).
- z_cek: 39 dari 39 tabel, semua P0 = 0, versi berlaku = 1, node tidak konsisten = 0, kolom Semula kertas kerja sama dengan POK.

## Berkas
`g1_versi_node.sql` (versi + 524 node), `g2_detail_1.sql` (detail 1-338), `g3_detail_2_berlakukan.sql` (detail 339-677 + berlakukan), `gen_impor.py` (pembuat), `g_impor_pok.sql` (satu berkas, hanya diuji di sandbox). Semua memakai penjaga md5 agar salinan yang rusak ditolak, aman diulang (versi bukan draf dilewati). Tanpa DELETE/DROP.

## Yang masih sementara (perlu keputusan/pembaruan)
1. nomor_revisi 1 hanya penanda; nomor revisi resmi menyusul. Bila resmi berbeda, buat versi baru lewat unggahan POK resmi (fase berikutnya), jangan ubah versi ini (beku).
2. hash_berkas = sha256 dari pok_tree.json hasil penguraian (bukan PDF/RKKS asli).
3. Volume RO (R-02) kosong; nomor_item resmi belum ada; sumber_dana bawaan RM; tanda_blokir bawaan false (catatan "* = Blokir" di baris 524 menempel pada uraian, tidak dipakai).
4. Beberapa uraian sumber memuat sisa teks (mis. baris honor triwulanan penggalian "- 66,00066,0001.0 DOK honor petugas", dan catatan U/P/* pada Perjalanan ke DJPB) — disalin apa adanya dari sumber; perbaiki lewat kertas kerja atau POK resmi.
