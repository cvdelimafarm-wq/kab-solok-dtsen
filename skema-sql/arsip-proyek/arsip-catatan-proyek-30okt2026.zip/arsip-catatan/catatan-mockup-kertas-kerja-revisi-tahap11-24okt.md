# Catatan mockup Kertas Kerja Revisi POK, tahap 11 (24 Okt 2026)

Artifact: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap (Versi 40). Mockup saja; belum ada SQL atau kode aplikasi sampai Iqbal bilang "setuju".

## Permintaan Iqbal
1. Jenis belanja harus sama. Penggenap akun 52 hanya menutup kekurangan akun 52, tidak untuk 51 atau 53. Di dalam 52: 524xxx hanya dengan 524xxx, dan 52xxxx selain 524 hanya dengan 52xxxx selain 524.
2. Revisi POK: pilihan hanya menurunkan volume item yang boleh ditunda, selisih (kekurangan) tetap dicatat agar tidak perlu RAB baru. Skema harus matang agar tidak bertabrakan.
3. Revisi DIPA (DJA atau DJPb): di tampilan PPK ada daftar anggaran yang kurang (secara pagu KRO), lalu PPK memutuskan terima semua usulan, sebagian, atau tunda. Skema ini belum matang di sisi Iqbal.

## Yang dipasang di mockup
- Kelompok belanja: 51, 524 (perjalanan dinas), 52L (52xxxx selain 524), 53. Donor, penerima, dan penggenap harus satu kelompok. Pemeriksaan baru R-16 (merah pada mode pagu tetap, info pada Revisi DIPA). Dasar pasalnya belum dicek, tanyakan ke Kanwil.
- Jendela geseran: kolom Kel., kotak centang "Turunkan volume item yang boleh ditunda" (muncul hanya pada Revisi POK bila masih ada kekurangan setelah fase 1), tanda per baris dan chip "Selisih tercatat". Tombol baru "Turunkan item yang boleh ditunda".
- Buku selisih: kolom kelompok, ringkasan per kelompok, penjelasan menurut jenis revisi, kotak "Diteruskan ke PPK" pada Revisi DIPA. Jalur penutup mengikuti mode: Revisi POK hanya satu jalur, Revisi DIPA lima jalur dimulai dari keputusan PPK.
- Papan Peta KRO Satker: bagian "Tampilan PPK" dengan keputusan per KRO (Menunggu, Terima semua, Terima sebagian + jumlah, Tunda) dan penelusuran sumber bagian yang diterima (DJPb tingkat 3, Eselon I tingkat 4, DJA tingkat 5).
- Papan Alur: bagian baru A+ (K1 sampai K5 untuk Revisi POK, P1 sampai P4 untuk Revisi DIPA).

## Aturan agar tidak bertabrakan (invarian)
1. RAB tidak pernah ditulis ke POK dan tidak dibuat ulang.
2. Kekurangan adalah angka turunan: max(0, RAB − POK) per item, jadi satu sumber kebenaran. Tidak ada tabel kekurangan yang harus disinkronkan.
3. Revisi POK: pagu KRO tetap, geseran hanya dalam kelompok, penggenap menyapu sisa di atas RAB, penurunan item tunda boleh di bawah RAB tetapi tidak di bawah Booked + Realisasi, hanya ke item berprioritas lebih tinggi.
4. Revisi DIPA: kekurangan per KRO = RAB − POK pada tingkat KRO; PPK memutuskan; yang diterima menjadi bahan usulan perubahan pagu (R-01); ditunda atau menunggu tetap di Buku selisih.
5. Setelah DIPA disahkan dan POK baru diimpor, kekurangan dihitung ulang terhadap POK baru.

## Konsekuensi skema (belum dibuat, menunggu "setuju")
- Fungsi atau view kelompok belanja dari kode akun.
- Tabel kategori prioritas per satker (nama, urutan, boleh ditunda).
- Tabel keputusan PPK per KRO per revisi: enum semua, sebagian, tunda, jumlah diterima, ppk, waktu, catatan.
- View kekurangan = RAB − POK per item dan per KRO.

## Pertanyaan terbuka
- Kebiasaan kantor saat dana kurang: apakah penggenap boleh minus sementara menunggu revisi?
- Satu akun penggenap per RO atau per komponen (sekarang per akun dan komponen).
- Redaksi baru: P-02 atau P-06 + P-07 (cek ke Kanwil).
- Nilai faktor 0,9, Q-26, dasar hukum R-09 dan R-16.
- Di mana keputusan PPK masuk paket usulan DIPA.
