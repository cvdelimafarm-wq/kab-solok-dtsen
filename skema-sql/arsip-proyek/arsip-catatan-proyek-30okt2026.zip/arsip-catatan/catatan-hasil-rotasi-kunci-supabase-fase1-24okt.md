# Catatan 24 Okt 2026: hasil rotasi kunci Supabase fase 1

Waktu (UTC): deploy Railway dengan secret key baru selesai sekitar 24 Okt 00.00-00.06.

## Verifikasi log API Supabase (edge_logs, proyek nlwkpakyfprugqwklxiu)
- Sampai 00.06 UTC instance Railway lama masih melayani sisa permintaan dengan kunci legacy (peralihan bertahap). Mulai 00.07 UTC semua permintaan dari aplikasi memakai secret key baru (awalan sb_secret_GDPYm; egress "Google LLC"). Tidak ada respons status 400 ke atas sama sekali pada jendela peralihan.
- 24 jam terakhir (23 Okt 01.00 sampai 24 Okt 00.05 UTC): tidak ada klien non-Railway yang memakai kunci legacy pada rest/auth; satu-satunya permintaan tanpa kunci adalah unduhan publik berkas peta dari peramban/ponsel (storage publik, tidak butuh kunci) dan panggilan manajemen Supabase sendiri. Tidak ada panggilan ke /functions/v1 (Edge Functions tidak dipakai). Tidak ada pemakaian dari laptop pada jendela itu (IP Telkomsel yang terlihat 19-22 Okt adalah laptop user).
- NEXT_PUBLIC_SUPABASE_ANON_KEY di Railway sudah berawalan sb_publishable_ (konfirmasi user).

## Sisa pekerjaan
1. Ganti kunci di .env.local laptop (user menyatakan sudah dikerjakan pada langkah 4).
2. Hapus Edge Function bulk-create-operators di dashboard Supabase.
3. Fase 2: nonaktifkan kunci legacy (API Keys, tab Legacy) setelah beberapa jam lalu cek ulang log; bila ada yang rusak, kunci legacy dapat diaktifkan lagi dari dashboard (pastikan dulu di dashboard bahwa opsi itu tersedia).
4. Variabel Railway lain (PENYISIRAN_PIN, PENYISIRAN_IDENTIFIKASI_PIN, SIGAP_KODE_BROWSER, VAPID): status penggantian menunggu konfirmasi user; bila PIN diganti, bagikan ke pengguna.
5. Commit perubahan scripts/upload-peta.mjs dan scripts/hitung-jarak-rute.mjs.
6. Saran jangka menengah: pisahkan rahasia sesi SIGAP dari kunci database.
