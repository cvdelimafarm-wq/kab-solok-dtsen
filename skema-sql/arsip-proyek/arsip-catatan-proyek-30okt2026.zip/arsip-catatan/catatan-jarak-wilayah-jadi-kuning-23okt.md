# Catatan: foto "jauh dari wilayah" (> 10 km) diturunkan dari merah ke kuning (23 Okt 2026)

Alasan: petugas mengeluh foto nomor 2-4 ditahan ("Ditahan, perlu diperiksa") bila titiknya > 10 km dari KK wilayah tugas DAN rumah petugas.

Perubahan:
- `lib/sigapFoto.ts` `nilaiKepercayaan`: `jarakWilayahM > WILAYAH_MERAH_M` kini `kuning.push("jauh_dari_wilayah")` (sebelumnya merah). 5-10 km tetap kuning `luar_wilayah_dekat`. Foto kuning tidak ditahan: langsung mengisi nomor, hanya muncul di tab Periksa (PML/admin). Kode alasan dan label tidak berubah.
- Konstanta `WILAYAH_MERAH_M` dipertahankan sebagai pembeda dua alasan kuning itu.
- Tes `lib/__tests__/sigapFoto.test.ts` disesuaikan (12 km = kuning; kasus "merah menang" memakai kecepatan_tak_wajar).
- SQL `supabase/migrations/20261023a_foto_jauh_wilayah_jadi_kuning.sql` (idempoten): foto lama yang satu-satunya alasan merahnya jauh_dari_wilayah -> kuning (data 23 Okt: 50 foto); tag ditahan dilepas hanya bila nomor fotonya masih kosong (5 foto); 14 tag yang nomornya sudah terisi dibiarkan ditahan supaya foto terpasang tidak tertimpa, PML memutuskan lewat tab Periksa -> Diperiksa.
- Alasan merah yang tersisa: waktu_tidak_wajar, jam_hp_beda_besar, kecepatan_tak_wajar.
