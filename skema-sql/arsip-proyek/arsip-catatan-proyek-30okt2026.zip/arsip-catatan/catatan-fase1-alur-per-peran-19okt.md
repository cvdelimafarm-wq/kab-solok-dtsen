# Fase 1 perbaikan alur per peran (19 Okt 2026)

Disetujui user ("setuju", lalu "Lanjutkan"). Kode ditulis ke laptop, user yang commit/push. Tanpa migrasi yang dijalankan.

## Putaran 1 (12 berkas) -- sudah di laptop
- `lib/sigapPrioritas.ts`: monitoring_korwil (berjalan) jadi kandidat tingkat PERLU -> kartu utama korwil = Monitoring Korwil (kecuali Transport Lokal mendesak). "Langkah i dari n" -> "Tugas i dari n".
- `lib/sigapTahap.ts`: `ketTranslok()` -- baris Transport Lokal di halaman tahap menampilkan kekurangan nyata ("Foto kurang 2 · +1 lagi").
- `Induk.tsx`: "Tahap x dari n" = tahap aktif; kartu aktif menghitung "x dari y tugas" dan chip hanya tugas.
- `[tahap]/page.tsx`: tugas bernomor di atas; Wilayah tim + peta jadi panel lipat di bawah (PPL).
- `app/sigap/korwil/page.tsx`: judul memakai nama sebelum koma.
- Angka KK proporsional di semua layar: `lib/portal/korwilMonitor.ts` (`lapanganTim` + `kkProporsionalTim`), `lib/portal/pendataan.ts`, `app/api/portal/pendataan/route.ts` + `lib/pendataan.ts` (`proporsional`), `app/sigap/pendataan/page.tsx`. Tim Budi: 183 dari 461. didata = realisasi + tidak ditemukan; Monitoring Korwil menampilkannya terpisah. Aturan lama Lembar ("target = Sub SLS yang diajukan") digantikan untuk angka tim.

## Putaran 2 (8 berkas) -- sudah di laptop
- `lib/sigapPrioritas.ts`: `kodeModul` pada tugas utama; `peringatanDariInduk` (Kesediaan belum dikonfirmasi) dan `translokDariInduk` (kartu Transport Lokal). `lib/sigapTugasUtama.ts`: field `kodeModul`.
- `app/portal/Beranda.tsx` + `app/portal/KartuTranslok.tsx` (baru): peringatan Kesediaan di atas kartu utama; kartu Transport Lokal sendiri di bawah kartu utama (5 langkah mini, 2 kekurangan teratas, satu tombol). Tidak muncul bila kartu utama sudah Transport Lokal itu / konfirmasi itu.
- Modal siaran: `lib/siaranPetugas.ts` `modalBerlakuUntukPeran` + `lib/portal/siaranPetugas.ts` -- modal yang tombolnya menuju /sigap/pendataan hanya untuk PML/PPL (korwil tidak melihatnya; Gantuang Ciri id 3 dan "Data keluarga tersedia" id 2). Modal Zoom (id 4) tetap untuk semua. Tanpa migrasi, tanpa mengubah data. Push Gantuang Ciri yang sudah terkirim tidak bisa ditarik.
- `[tahap]/page.tsx`: Rekap identifikasi = tautan sebaris tepat di bawah tugas Lembar Identifikasi (atau Lembar Pendataan bila tahap tak memuat Identifikasi); tombol melayang dihapus untuk semua peran.
- Uji: `lib/__tests__/sigapPrioritas.test.ts` (11 uji). Total 60 uji lulus.

## Draf migrasi (TIDAK dijalankan) -- tab Pemeriksaan PML
`draf-migrasi/20261019c_pengawasan_pml.sql` (di folder keluaran sesi): satu tabel baru `bencana_pengawasan_pml` (kk_id, pml_akun_id, ppl_akun_id, tanggal, jawaban jsonb 7 pertanyaan, perlu_koreksi), RLS tanpa policy. Menunggu "setuju" user. Setelah itu: lembar pengawasan 7 pertanyaan + mode "Periksa / awasi" di Lembar Pendataan + tab di Monitoring Korwil.

## Belum dikerjakan
- Ringkasan hidup di tugas Monitoring Korwil (persen KK, petugas belum lengkap hari ini) -- di mockup, ditunda karena menambah beban pemuatan Beranda korwil.
- Tab "Pemeriksaan PML" (kode) -- menunggu migrasi disetujui.

## Temuan data 19 Okt
Belum ada lembar pemeriksaan PML. PML yang menandai KK lewat Lembar Pendataan: Ferianto 8 (7 di antaranya 18 Okt 14.33-14.35 WIB, urut alfabetis, semua tidak terdampak), Usyenti 2, Ardial Jaraf 1, Widya Elvera 1.
