# Draft plotting keroyokan v2 (8 Okt 2026) — tanpa menginap

Status: DRAFT usulan, belum ditulis ke database. File: Draft_Plotting_Keroyokan_88Petugas_8Okt2026.xlsx (12 sheet, mulai dari Ringkasan & Konfirmasi). Menggantikan versi 5 Okt (83 PPL + 20 PML).

## Arahan user (8 Okt)
- Pool 94 petugas: PML organik tidak dihitung kecuali Ardial Jaraf, Hariston, Ilham (tetap PML). Adriyanto tidak dihitung. Peran riil organik = korwil, dibahas kemudian.
- TIDAK ADA skema menginap: semua pulang-pergi harian; jangan usulkan menginap.
- Ilham = PML wilayah selatan (Lembah Gumanti, Danau Kembar, Pantai Cermin), berpindah antar lokasi. Tim selatan 5 PPL: Elvika oktasari, Gusna Wirda, Julia Lara Zamzamy, Rahmad Hidayat, Wahyuni Oktavia.
- 4 PPL status menolak (Febria Ramanita, Hanifah, nopi nofila, Ondri Yandi) DIHAPUS, tidak dilibatkan dalam seluruh kegiatan.
- PML yang terlibat NTP dibolehkan (mereka juga PML di NTP).
- Aturan lama tetap: 1 PML : 3-6 PPL (target 4), keragaman mirip, rumah anggota berdekatan, <5 km aman / upayakan <10 km, tim tamu dipandu akamsi (1 poin/30 menit), ambang 160, hindari olok-olok, konfirmasi dulu bila aturan tak terpenuhi.

## Roster
- 102 ber-peran di DB -> 94 sesuai arahan -> tidak diplot: Sherli Handayani (PPL NTP + menolak), Hafni Syamfitria (rumah ±19 km dari Sub SLS terdekat), 4 PPL dihapus. Diplot: 70 PPL + 18 PML = 88.

## Hasil
- 18 tim (14 tim ukuran 4; ukuran 3-5), 228 Sub SLS -> 278 porsi, beban akhir PPL 193-333 (rata-rata ±262), semua di atas ambang 160. Butuh ±112 PPL untuk ambang 160 (ada 70).
- Jarak (skor): 34% <5 km, 36% 5-10, 22% 10-15, 9% >=15 km (24 porsi, 10 PPL).
- PML jauh dari tim: Ilham ±32 km (ditetapkan user; koordinat perkiraan), Yurneti ±14 km, Mega Nana ±10 km.
- 20 blok keroyokan tanpa akamsi; 49 tugas pemandu; 12 pasangan olok-olok tersisa.

## Masih menunggu keputusan user
Kapasitas/ambang (nomor 1), porsi >=15 km (2), PML jauh lain (4), status Sherli/Hafni (7), koordinat perkiraan 7 orang dan 32 Sub SLS perlu cek KK termasuk Balai Gadang A/B (11). Belum ditanyakan: apakah 4 PPL yang dihapus juga dinonaktifkan di database.
