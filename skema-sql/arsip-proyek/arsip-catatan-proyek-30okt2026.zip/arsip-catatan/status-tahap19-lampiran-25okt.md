# Status tahap 19: papan 4 (Lampiran, tenggat, dan draf surat usulan)

Tanggal: 25 Okt 2026. Papan mockup: "Lampiran" (Lampiran.dc.html). Alamat halaman: `/sigap/revisi/lampiran?jadwal=<id>&jenis=<jenis>`.

## Yang dibangun
- **SQL `20261025t_keu_lampiran_revisi.sql`** (sudah diterapkan di produksi sebagai migrasi `keu_lampiran_revisi_t`, arsip ada di repo `skema-sql\`): tabel `keu_master_lampiran` (12 lampiran L01-L12 dengan ketentuan pada empat jenis: pok, administrasi, dipa_djpb, dipa_dja), tabel `keu_kk_lampiran` (status belum atau ada per jadwal dan kode, nomor, tanggal, catatan), fungsi `keu_kk_lampiran_set` (kewenangan `jadwal`, didaftarkan ke gerbang `keu_jalankan`), penjaga tanpa hapus dari aplikasi, RLS hanya service_role.
- **`lib/keu/lampiran.ts`** (+ `lampiran.test.ts`, 14 tes): tenggat Pasal 175 per jenis dari master waktu (`tenggat_pok`, `tenggat_dipa_djpb`, `tenggat_dipa_dja`), dimajukan ke hari kerja terakhir (ayat 18), sisa hari kerja dari "hari acuan", warna aman, mendekati (10 hari kerja atau kurang), mendesak (3 atau kurang), lewat. Sifat lampiran dari teks master (diawali "Ya" = wajib, "Tidak" = tidak diperlukan, selain itu = bila berlaku). Rekap kelengkapan. Draf surat dari baris kertas kerja.
- **Halaman `app/sigap/revisi/lampiran/page.tsx`**: tiga kartu: Tenggat Pasal 175 (tombol hari acuan + input tanggal), Lampiran untuk jenis terpilih (tombol Sudah ada atau Belum ada, hanya PPK), Draf isi surat usulan (pilih KRO, Salin draf).
- Tautan dari `/sigap/revisi`: "Lampiran, tenggat, dan draf surat usulan".

## Penyimpangan dari mockup (disengaja, perlu diketahui)
- Pencatatan lampiran memakai kewenangan `jadwal` (PPK), bukan peran operator di mockup, supaya sejalan dengan sisa alur jadwal.
- Draf surat hanya mencakup RO yang kertas kerjanya sudah dimuat (batas baca 5000 baris).
- Daftar libur `LIBUR` di `lampiran.ts` baru memuat 24-25 Des 2026; di luar itu hanya Sabtu dan Minggu yang dihitung. Perlu diperbarui tiap tahun.
- Kolom "Booked" di mockup tidak punya sumber data di SIGAP sehingga tidak ditampilkan.

## Status uji
- Sandbox: 14 tes `lampiran.test.ts`, migrasi `t` diuji (upsert, galat kode atau status tak dikenal, jadwal dilewati ditolak, hapus ditolak, non-PPK ditolak), render halaman lolos.
- Produksi: migrasi terpasang; UI halaman belum diuji di produksi (menunggu deploy). Mencatat lampiran pada jadwal 7 (fiktif) hanya bila diizinkan.
