# Delego Beban kerja: target 70, tabel mingguan, Terapkan usulan; Foto saya: bagikan sesudah terkirim (26 Okt 2026)

Status: kode di repo laptop (belum commit/push/deploy). SQL `20261026f_keu_delego_pindah.sql` BELUM dijalankan di produksi; dry-run di produksi (auto-rollback) LULUS 58. Belum diuji di HP/produksi.

## 1. Target harian 70 (mulai berlaku 26 Okt 2026)
- Dibaca dari jawaban pengguna: "Total target yang harus dicapai 70, bobot poin per pendataan keluarga tidak terdampak". Ditafsirkan: kapasitas/target harian per orang 70 poin; bobot poin per keluarga tidak berubah.
- `lib/delego/hitung.ts`: `KAPASITAS_HARIAN` 60 -> 70 (100% beban = 350 poin/minggu). Formulir Buat: isian awal target harian = 70.
- TIDAK berubah: delegasi yang sudah ada tetap berisi target_harian lama (60) karena kolom tunggal tanpa tanggal berlaku; mengubahnya mundur akan menggeser hutang hari-hari lalu. Default kolom/fungsi SQL (60) juga belum diubah (formulir selalu mengirim nilai).
- Bila delegasi berjalan juga harus 70 mulai hari ini: perlu fitur target-berlaku-mulai-tanggal (usulan, belum dikerjakan).

## 2. Tabel beban per hari (halaman Beban kerja)
- `matriksBebanHarian` / `bebanDelegasiHari` (hitung.ts): per orang per hari Senin-Jumat (Sabtu/Minggu bila ada beban), persen dari 70, kategori berlebih/sasaran/longgar/kosong. Jumlah sel = beban mingguan (diuji).
- UI kartu "Beban per hari": hari ini diberi cincin, sel berwarna + angka (tidak mengandalkan warna saja), bisa digulir horizontal di HP.

## 3. Terapkan usulan (tanpa dialog, sesuai pilihan pengguna)
- SQL `keu_dlg_pindah(p_id, p_ke, p_ver, p_akun)`: pemberi per RO; delegasi lama -> selesai dan tenggat dipotong KEMARIN (laporan tetap), atau batal bila baru mulai hari ini; delegasi baru untuk penampung mulai HARI INI sampai tenggat lama, status baru; target total baru = sisa; notifikasi ke penampung dan penerima lama; jejak lewat keu_jejak. Penolakan: bukan pemberi, status bukan baru/berjalan, versi basi, penampung tidak sah (diri sendiri/pemberi/tidak aktif/mitra bukan PML-PPL), sudah melapor hari ini, target total tercapai.
- Terdaftar di `keu_jalankan`. Uji `58_uji_delego_pindah.sql` (rollback).
- UI: tombol "Terapkan usulan" pada tiap saran (hanya bila `bolehBeri(ro)`), spanduk hasil + pesan galat. Risiko: tanpa dialog, ketukan keliru langsung berlaku (pemulihan: ubah/tambah delegasi lewat Papan).

## 4. Foto saya: Bagikan ke rekan sesudah terkirim
- `FotoSaya.tsx` (rincian foto): tombol Bagikan ke rekan sampai H+1 (`jendelaBagiFoto`), memanggil POST /api/sigap/foto/tag; `BagikanFoto.tsx` menerima `kecuali` (yang sudah diajak) dan `maks` (sisa kuota). Server sudah menolak lewat H+1.

## Langkah pengguna
1. Jalankan `20261026f_keu_delego_pindah.sql` di Supabase SQL Editor, lalu (opsional) `58_uji_delego_pindah.sql` (rollback).
2. Commit, push, deploy bersama perubahan Kamera (Periksa arah foto) dan H+1. Tulis "sudah deploy".
