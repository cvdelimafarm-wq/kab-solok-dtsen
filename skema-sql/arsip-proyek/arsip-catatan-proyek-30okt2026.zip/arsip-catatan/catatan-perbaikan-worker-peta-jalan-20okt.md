# Catatan: peta jalan tidak muncul (Pascabencana dan SPDT) - dua penyebab, dua perbaikan (20 Okt 2026 malam)

Lanjutan `claude/catatan-peta-dasar-pendataan.md`.

## Gejala
Tab Peta Lembar Pendataan (Pascabencana, juga SPDT) tetap titik di atas kisi kosong walau 18 berkas tim + manifest sudah ada di bucket `peta-dasar`. Semua 18 PML (id 96...460) punya berkas, jadi bukan soal id tim.

## Penyebab 1: worker maplibre-gl tidak ditemukan (perbaikan: paket-20okt-j, sudah terdeploy)
`maplibre-gl` 6.x hanya ESM dan memuat worker dari berkas terpisah `dist/maplibre-gl-worker.mjs`, dicari lewat `import.meta.url` modulnya sendiri dan hanya dipakai bila berawalan http(s). Setelah dipaketkan Next.js alamatnya kosong -> "Worker failed to load". Terbukti di build produksi Next.js 15.5.25 (tanpa perbaikan: status "gagal: worker"; dengan perbaikan: "siap").
Perbaikan: `public/peta/maplibre-gl-worker-6.15.0.mjs` (salinan persis worker pustaka), `ml.setWorkerUrl("/peta/maplibre-gl-worker-6.15.0.mjs")` di `PetaDasar.tsx`, galat berkata "worker" langsung "gagal" dengan alasan, header cache immutable di `next.config.js`, uji `lib/__tests__/petaDasarWorker.test.ts` (salinan harus sama dengan worker pustaka terpasang; nama berkas memuat versi). package.json tidak diubah.

## Penyebab 2: kanvas peta tinggi 0 px (perbaikan: paket-20okt-k)
Dibuktikan langsung di Railway lewat Claude in Chrome (Masuk sebagai PML Irawita, tim 96, Sub SLS Bukik Gompong 03): setelah perbaikan 1, `manifest.json`, worker, `tim-96.pmtiles` (206), dan huruf semuanya termuat, kontrol "Jalan / Titik saja / Offline" tampil, tetapi peta kosong. `maplibre-gl.css` memberi `.maplibregl-map { position: relative }` yang mengalahkan kelas Tailwind `absolute inset-0` pada div `wadah`, sehingga tinggi wadah 0 dan kanvas 300 px bawaan tidak sama dengan kartu peta (519 px). Saat wadah dipaksa `position:absolute; inset:0` lewat konsol, peta jalan tampil lengkap dan mengikuti titik.
Perbaikan: wadah di `PetaDasar.tsx` memakai gaya sebaris `position:absolute; top/right/bottom/left:0` (tidak bisa dikalahkan CSS pustaka). Uji Next.js: kanvas 390x520 sama dengan wadah. Belum di-commit/push saat catatan ini ditulis.

## Pelajaran
Pengujian terbaik ada di Railway lewat Chrome dengan "Masuk sebagai" (lihat `claude/catatan-masuk-sebagai-akun-super.md`): tombol avatar bulat di Beranda -> "Masuk sebagai siapa?" -> cari nama -> buka `/sigap/pendataan` -> Sub SLS -> tab Peta. Pemeriksaan DOM (tinggi wadah/kanvas) dan `performance.getEntriesByType('resource')` cepat menunjukkan berkas mana yang termuat.

## Belum diuji
HP nyata dan lembar SPDT (berkas peta SPDT belum dibuat; komponen yang sama sehingga ikut terperbaiki).
