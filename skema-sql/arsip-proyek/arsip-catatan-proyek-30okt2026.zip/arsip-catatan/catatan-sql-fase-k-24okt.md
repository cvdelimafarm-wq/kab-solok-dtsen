# Catatan SQL Fase G (berkas k): usulan struktur mata anggaran dan kode sementara T-nnn
Tanggal 24 Okt 2026. Berkas: `20261024k_keu_struktur_usulan.sql` (migrasi), `20261024z6_cek_kesehatan_keu_k.sql` (cek baca-saja), uji `43_uji_struktur_usulan.sql`, pelari `jalan_k.sh`. Belum dijalankan di produksi. Dasar: spesifikasi bagian 4.6, 4.7, Fase G, dan butir P1 sampai P8.

## Cara menjalankan di produksi
1. Pasang berurutan bila belum: h (45 tabel), i (48), j (51), lalu `20261024k_keu_struktur_usulan.sql` (aman diulang).
2. Jalankan `20261024z6_cek_kesehatan_keu_k.sql`: baris 1 sampai 8 harus 0, baris 12 harus 53.
3. Jalankan `20261024z_cek_kesehatan_keu.sql` yang baru: baris 4 harus "53 dari 53".

## Isi
- Dua tabel: `keu_struktur_usulan` (satu baris per usulan, semua level: program, kegiatan, KRO, RO, komponen, subkomponen, akun, item) dan `keu_struktur_usulan_riwayat` (hanya bertambah).
- Kode sementara `T-nnn` diberikan otomatis, melewati nomor yang sudah dipakai di `keu_ro`. Usulan RO yang sah didaftarkan ke `keu_ro` memakai kode itu; batal atau ditolak pusat menonaktifkannya.
- Jalur (pok, DJPb, DJA) dan kepastian ditarik dari `keu_jalur(level, sumber, khusus)` (Master jalur), bukan ditulis di kode. Komponen bertanda khusus mengikuti jalur DJA.
- Fungsi: `keu_struktur_usul`, `keu_struktur_ubah`, `keu_struktur_aksi` (ajukan, setuju_ketua, sahkan, kembalikan, batal), `keu_struktur_usulkan`, `keu_struktur_cocokkan`, `keu_struktur_padankan`, `keu_struktur_tolak_pusat`; bantu: `keu_struktur_periksa`, `keu_struktur_jalur_ada`, `keu_struktur_jalur_anak`, `keu_struktur_induk_level`, `keu_struktur_kode_baru`.
- View: `keu_v_struktur_usulan` (induk, jalur, siapa yang ditunggu, kode resmi, nomor item resmi, `boleh_komitmen`), `keu_v_struktur_ringkas`, `keu_v_ro_sementara` (pemakaian kode T-nnn oleh RAB, penugasan, kertas kerja, kekurangan), `keu_v_pok_jalur_node` (jalur teks tiap simpul POK berlaku).

## Aturan yang dipaksa basis data
- Induk (P1): Program tanpa induk; level lain tepat satu dari induk resmi (jalur pada POK berlaku, level induk harus sesuai) atau induk usulan. Induk usulan yang sudah dibatalkan atau ditolak pusat ditolak.
- Isian (P2, P3): format kode per level (dari `keu_struktur_level`), akun harus ada di Master akun, satuan baku dari Master satuan, volume dan harga lebih dari nol, uraian minimal 3 huruf, sumber dana dalam/lintas/tambahan, "khusus" hanya untuk Komponen. Kembar dengan POK berlaku ditolak (23505; item dibandingkan lewat kunci stabil), kembar dengan usulan terbuka ditolak oleh indeks unik.
- Pengusul: tingkat Tim (komponen, subkomponen, akun, item) oleh ketua tim, admin RO, atau PPK (kewenangan `str_tim`); tingkat PPK (program, kegiatan, KRO, RO) hanya PPK (`str_ppk`).
- Alur tingkat Tim: admin RO atau PPK mengajukan, lalu ketua tim setuju, lalu PPK mengesahkan; ketua yang mengajukan langsung menunggu PPK. Bila pengaju PPK, persetujuan ketua langsung mengesahkan. Pengaju tidak mengesahkan atau menyetujui usulannya sendiri. Tingkat PPK: PPK mengajukan, langsung sah. Pada RO sementara T-nnn (belum ada ketua tim) PPK langsung sah supaya tidak buntu.
- Kembalikan wajib alasan minimal 5 huruf (oleh ketua pada tahap ketua, oleh PPK pada tahap PPK); usulan dikembalikan boleh diubah dan diajukan ulang. Batal ditolak selagi ada usulan turunan berjalan.
- Mengusulkan ke pusat (PPK): jalur DJPb dan DJA wajib nomor surat; jadwal revisi harus berjenis sesuai jalur (pok: pok atau administrasi; djpb: dipa_djpb; dja: dipa_dja). Sesudah diusulkan isi beku.
- Pencocokan (P7, PPK): usulan sah atau diusulkan dibandingkan dengan POK berlaku menurut jalur; cocok menjadi `aktif` dengan kode resmi (cara "sama"), akun dan item ikut lewat induk yang sudah aktif. Usulan yang sudah diusulkan tetapi tidak ada pada POK yang terbit sesudahnya menjadi `perlu_dipadankan`. Dijalankan berulang tidak mengubah apa pun lagi.
- Pemadanan manual (P8, PPK): jalur atau kunci resmi harus ada di POK berlaku, induknya harus sama dengan induk usulan, dan satu kode resmi hanya untuk satu usulan aktif. Penolakan pusat wajib alasan dan hanya bila tidak ada turunan berjalan.
- Hanya status `aktif` yang `boleh_komitmen`. Dari aplikasi tidak ada DML langsung; status berubah hanya lewat fungsi; riwayat hanya bertambah; audit lewat `keu_jejak()`.

## Keputusan saya yang perlu Anda tinjau
1. Uraian minimal 3 huruf (bukan 4) karena POK memuat item seperti "ATK".
2. Pada RO sementara PPK langsung mengesahkan usulan tingkat Tim. Bila Anda ingin ada ketua tim untuk RO baru, tetapkan peran KETUA pada kode T-nnn dulu; alur normal berlaku lagi.
3. Pemindahan RAB, penugasan, dan kertas kerja dari kode T-nnn ke kode resmi belum otomatis. `keu_v_ro_sementara` menunjukkan pemakaiannya; fungsi pemindahan kuputuskan bersama aplikasi.
4. Pencocokan berjalan atas perintah PPK (bukan otomatis saat POK baru diimpor). Aplikasi sebaiknya memanggilnya setelah tiap impor POK.
5. Satu kode resmi hanya untuk satu usulan aktif; bila POK pusat menyatukan dua usulan, PPK menolak salah satunya sebagai penolakan pusat.

## Hasil uji (basis data uji, bukan produksi)
Rangkaian a-f, h, i, j, uji 40 sampai 42, lalu k (dua kali) dan uji 43 lulus; z6 baris 1 sampai 8 nol; z_cek baris 4 "53 dari 53". Uji 43 memeriksa: membuat usulan di tiap tingkat dengan induk resmi dan induk usulan; hak (admin RO, bendahara, anggota, mantan ketua, tanpa sesi); 25 penolakan validasi; ubah dan kembalikan; tiga jalur persetujuan (admin RO, ketua, PPK pengaju); tingkat PPK dan RO sementara terdaftar di `keu_ro`; komponen khusus jalur DJA; mengusulkan dengan nomor surat dan jadwal; POK baru nomor 12, pencocokan (aktif dan perlu dipadankan), idempoten; pemadanan manual, penolakan pusat, pembatalan RO menonaktifkan T-nnn; larangan DML langsung, RLS, hak, audit.
