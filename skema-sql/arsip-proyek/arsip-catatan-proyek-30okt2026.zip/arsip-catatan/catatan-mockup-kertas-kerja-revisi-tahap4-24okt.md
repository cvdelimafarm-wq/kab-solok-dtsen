# Catatan mockup Kertas Kerja Revisi POK, tahap 4 (24 Okt 2026)

Status: MOCKUP saja (artifact "Kertas Kerja Revisi POK SIGAP", Versi 27-33). Belum ada SQL/kode aplikasi; menunggu "setuju". Diuji lewat skrip node, belum diperiksa di browser.

## Permintaan dan hasil
1. Baris Akun di bawah RO pada tab RAB dan Matriks, item di bawahnya. RAB: header akun berisi nama akun, jumlah item, subtotal POK/RAB/selisih, checkbox pilih seluruh akun, ikon selesai/buka kembali per akun. Matriks: baris akun (subtotal akun penuh, bukan hanya item berubah); baris pasangan ganti akun kini berada di akun masing-masing (tidak lagi ditempel berdampingan).
2. Tabel dipadatkan: tinggi baris 30 -> 24, padding sel dan tombol dikurangi di kertas kerja, RAB, matriks, rincian RAB. Jadwal "Lipat per bulan" kini 4 bulan per baris (12 baris menjadi 3).
3. Tombol aksi item RAB jadi ikon 24px berpetunjuk (Rincian, Tandai selesai, RAB = Item, Salin rincian, Hapus RAB, Tempel); kolom Aksi 290px -> 184px.
4. Checkbox di kiri tiap baris (kertas kerja dan RAB) + checkbox RO/komponen/akun + pilih semua di judul kolom. Bar aksi massal muncul bila ada yang dipilih: Tandai selesai, Buka kembali, Tampilkan RAB (buka rincian; dari kertas kerja pindah ke tab RAB dengan filter "Hanya yang dipilih"), Tutup rincian, RAB = Item (yang belum), Salin rincian, Hapus RAB, Hanya yang dipilih, Bersihkan pilihan. Pilihan dibagi antar tab; di kertas kerja yang terpilih saat filter kolom aktif hanya baris yang lolos filter.

## Asumsi
- Id item kertas kerja = id item RAB (mis. 007.051.521211.01); item pasangan tanpa RAB tidak ikut pilihan.
- Hapus RAB massal hanya untuk item yang sudah punya RAB; RAB = Item massal hanya untuk yang belum.
