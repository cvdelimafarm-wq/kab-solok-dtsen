# Jendela susulan foto + laporan: Rabu 21 Okt 2026, 06.00-10.00 WIB (dibuat 20 Okt 2026)

Permintaan M. Iqbal Hadi: akses melengkapi foto yang terlewat dibuka besok 21 Okt 2026 pukul 06.00 s.d. 10.00 WIB, dengan notifikasi push dan modal, petugas diminta menyiapkan foto dari sekarang. Jawaban pilihan: foto dari awal sampai hari ini (ada petugas yang tidak memakai Kamera SIGAP hari ini); buka/tutup otomatis; seluruh petugas Pascabencana; foto DAN laporan.

## Cara kerja
- Pelaksana: pg_cron (extension baru dipasang) job `jendela-susulan-21okt`, jadwal `0 23 20 10 *` (UTC = 21 Okt 06.00 WIB), memanggil `public.sigap_buka_jendela_susulan_21okt()`. Fungsi menolak berjalan di luar 06.00-10.00 WIB (kecuali `p_paksa = true`), lalu membatalkan jadwalnya sendiri.
- Fungsi menambah baris `sigap_izin_susulan` (alasan `Jendela susulan 21 Okt 2026 06.00-10.00 WIB (permintaan admin)`, `berlaku_sampai` = 21 Okt 03.00 UTC = 10.00 WIB) untuk penugasan aktif kegiatan 1 (Pascabencana) yang belum dikunci, pada hari kerja aktif sejak `tanggal_mulai` kegiatan s.d. 20 Okt 2026 yang belum lengkap: foto < `jumlah_foto` ATAU laporan wajib tanpa baris `sigap_realisasi`. Dihitung saat job jalan (jadi hari 20 Okt ikut sesuai kondisi pukul 06.00). Uji kering 20 Okt sore: 180 hari milik 56 dari 85 penugasan (157 hari foto kurang, 172 hari laporan kurang; laporan yang "dianggap" dari pendataan bisa ikut terhitung berlebih, tidak berbahaya karena modal hanya menampilkan hari yang memang belum lengkap).
- Tanpa kolom `berlaku_mulai` dan tanpa mengubah kode pembaca izin: baris baru muncul baru pukul 06.00, jadi tidak ada perubahan di `statusKunci` (lib/sigap.ts), `kegiatan.ts`, `sigapDokumen.ts`, route perbaikan.
- Modal "Perbaiki administrasi" dan menu `/sigap/perbaikan` muncul sendiri begitu baris izin ada (jenis kekurangan "perbaikan", batas = 10.00 WIB). Tanggal yang sudah pernah diberi izin pada siaran 15 Okt IKUT dibuka lagi (permintaan "dari awal"); itu pengecualian dari aturan "sekali per tanggal" untuk foto. Laporan lewat Lembar Pendataan tetap sekali per tanggal (cek `sigap_audit` aksi `perbaikan_laporan`) dan hanya untuk KK tanpa hasil.
- Foto: Kegiatan Pascabencana bermode Kamera SIGAP (galeri ditolak), padahal kamera hanya memotret "sekarang". Perubahan kode: `FotoKegiatan` punya prop `susulan`; `translok/[token]/page.tsx` mengirim `susulan={hari.kunci === "izin"}`, sehingga tanggal berizin susulan memakai unggah foto lama (`PanelFoto`, route `/api/sigap/translok/[token]/foto`, yang tidak memeriksa mode). Foto hari berjalan tetap lewat kamera.
- Setelah 10.00 izin hangus. Hari yang masih tidak lengkap menjadi tidak dibayar (aturan lama).

## Siaran (push + modal) untuk petugas
- Dua templat baru di Kelola > Pendataan > Siaran (`app/sigap/kelola/pendataan/Siaran.tsx`): (1) PENGUMUMAN malam ini (bawaan, tanpa tombol; push "Besok 06.00-10.00: lengkapi foto yang terlewat"); (2) SUDAH DIBUKA untuk dikirim sekitar 06.00 (tombol ke `/sigap/perbaikan`).
- Pengingat push terjadwal Railway (`sigapPushJadwal`, slot pagi 07.00) belum terbukti aktif (tidak ada log `pengingat_terjadwal`), jadi push pukul 06.00 dikirim manual lewat templat (2).

## Pembatalan / darurat
- Sebelum 06.00: `select cron.unschedule('jendela-susulan-21okt');`
- Menutup lebih awal: `update sigap_izin_susulan set berlaku_sampai = now() where alasan = 'Jendela susulan 21 Okt 2026 06.00-10.00 WIB (permintaan admin)' and berlaku_sampai > now();`

## Status
- Migrasi SUDAH dijalankan di Supabase (nama `jendela_susulan_21okt_2026`); salinan arsip `supabase/migrations/20261020h_jendela_susulan_21okt.sql`.
- Kode sudah ditulis ke laptop (3 berkas), BELUM di-commit/push. WAJIB di-deploy sebelum 06.00 21 Okt, kalau tidak petugas melihat kamera untuk tanggal susulan dan tidak bisa mengunggah dari galeri.
- Belum diuji di HP. Belum dikirim: Siaran malam ini.
