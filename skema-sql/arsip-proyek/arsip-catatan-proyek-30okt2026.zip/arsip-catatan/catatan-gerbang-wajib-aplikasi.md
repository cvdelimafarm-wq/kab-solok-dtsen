# Gerbang "wajib lewat aplikasi" di HP + izin Notifikasi/Lokasi (8 Okt 2026, diperbarui 9 dan 20 Okt 2026)

Permintaan user: semua yang membuka SIGAP di HP wajib lewat aplikasi terpasang (PWA), berlaku langsung setelah deploy; notifikasi WAJIB.

## Gerbang
- Berlaku untuk HP/tablet (Android, iPhone, iPad) yang membuka lewat TAB BROWSER. Aplikasi terpasang (display-mode standalone / navigator.standalone / referrer android-app://) lolos. Laptop tidak terpengaruh.
- Jalur dikunci: "/" dan semua "/sigap/*". Dikecualikan: "/sigap/translok/*" (tautan bertoken via WhatsApp) dan modul lain (bencana, undangan, penyisiran, dashboard Wali Nagari).
- Isi halaman tidak dirender di browser; modal penuh layar tanpa tombol tutup.
- "Tidak bisa memasang?" / kode darurat disembunyikan atas permintaan user. Route `browser-darurat` masih ada tetapi tidak dipakai; `SIGAP_KODE_BROWSER` tidak perlu diisi.
- Pemeriksaan di sisi browser (arahan, bukan pengaman data). Mode "situs desktop" Chrome HP dapat melewatinya.
- Berkas: `app/components/GerbangAplikasi.tsx`, `lib/sigapGerbangApp.ts`, `app/layout.tsx`, `app/manifest.ts`.

## Halaman pasang (dirombak 9 Okt 2026)
Permintaan user: redaksi singkat, ada hook, ramah; "perbaiki agar semua masalah teratasi"; "utamakan tombol pintas seperti install agar terlihat lebih dipercaya".
- Redaksi: judul "SIGAP kini ada di layar HP Anda 📲"; "Pasang sekali, buka dengan satu ketukan. Lebih cepat, layar penuh, dan pengingat pelatihan tetap masuk walau aplikasi ditutup."
- Kartu ala toko aplikasi: logo 64 px, "SIGAP", "BPS Kabupaten Solok", lencana hijau "Aplikasi resmi", chip Gratis / Tanpa Play Store / Ringan.
- Tombol utama per jalur (`jalurPasang(ua, maxTouchPoints)` di lib, 5 uji `lib/__tests__/sigapJalurPasang.test.ts`):
  - android (Chrome, Samsung Internet, Edge, Opera): SELALU tombol "Instal SIGAP". Dialog bawaan siap -> dialog Instal. Belum datang dalam 4 detik ("Menyiapkan…") atau dibatalkan -> tombol yang sama membuka langkah cadangan menu ⋮ > Instal aplikasi + tautan "Buka di Chrome".
  - tertanam-android (WhatsApp/FB/IG): tombol "Buka di Chrome untuk instal" (intent://) + Salin tautan.
  - ios-safari: kotak "Pasang dalam 3 ketukan" (Bagikan di bawah layar > Tambahkan ke Layar Utama > Tambah).
  - ios-chrome (CriOS): langkah sama, Bagikan di kanan atas kolom alamat.
  - ios-lain (Firefox iOS, browser tertanam di iPhone): tombol "Salin tautan" -> buka di Safari.
- Sudah terpasang: `navigator.getInstalledRelatedApps` (Chrome Android) + `related_applications` (platform webapp, url manifest) di `app/manifest.ts` -> kartu hijau "SIGAP sudah terpasang, buka dari ikon".
- Perbaikan bug: `beforeinstallprompt` kini ditangkap skrip kecil di `<head>` (`app/layout.tsx`, TANGKAP_PASANG) sebelum React siap; sebelumnya bisa terlewat sehingga tombol Instal tidak muncul.

## Izin di aplikasi terpasang (`app/portal/PengaturanAwal.tsx`, logika push di `app/portal/pushKlien.ts`)
- Dipasang di `Beranda.tsx` dan `Kerangka` (`app/sigap/pelatihan/komponen.tsx`). Hanya di aplikasi terpasang di HP.
- NOTIFIKASI WAJIB: selama belum aktif, modal "Aktifkan notifikasi untuk melanjutkan" tidak bisa ditutup (tanpa "Nanti saja"). Satu tombol Aktifkan -> dialog izin bawaan HP; pilih Izinkan = langsung aktif, tidak perlu ke pengaturan.
- Bila izin pernah DITOLAK/diblokir: HP tidak mau bertanya lagi; modal menunjuk Pengaturan HP > Aplikasi > SIGAP > Notifikasi, dan memeriksa ulang otomatis saat pengguna kembali ke aplikasi (tombol "Saya sudah mengizinkan, periksa lagi").
- Tidak memblokir bila notifikasi memang tidak mungkin: kunci VAPID server belum diisi, atau browser tidak mendukung. Bila gagal karena masalah teknis (bukan ditolak) muncul "Ada kendala teknis? Lewati sementara" (hanya sesi itu).
- LOKASI (GPS): pilihan (kotak centang), "Nanti saja" 24 jam. Hanya diminta izinnya, tidak dibaca/dikirim/dilacak; koordinat baru dibaca saat presensi.
- Prasyarat: VAPID_PUBLIC_KEY/VAPID_PRIVATE_KEY di Railway.

## Perbaikan 20 Okt 2026: tombol "Aktifkan" tidak merespons (HP Yeni Siswanti)
- Gejala: modal "Aktifkan notifikasi untuk melanjutkan" tampil (Notifikasi "Wajib", Lokasi "Diblokir"), tombol Aktifkan tidak bereaksi saat diketuk.
- Penyebab dugaan (belum dipastikan di HP): `aktifkanPush` menunggu respons server (`/api/sigap/push`) SEBELUM memanggil `Notification.requestPermission()`; di sinyal lambat gerakan pengguna kedaluwarsa sehingga HP tidak menampilkan pertanyaan izin. Selain itu langkah service worker (`navigator.serviceWorker.ready`), langganan push, dan kirim ke server tidak punya batas waktu sehingga bisa menggantung tanpa pesan.
- Perbaikan: izin diminta pertama, sinkron di dalam ketukan; fungsi `denganBatas` membatasi tiap langkah (server 15 dtk, izin 45 dtk, service worker 12 dtk, langganan 20 dtk) dan menghasilkan pesan yang menyebut langkah macet; teks "Menunggu jawaban HP…" saat memproses; jalur "Lewati sementara" muncul pada kegagalan teknis.
- Cara manual untuk petugas: Pengaturan HP > Aplikasi > SIGAP > Notifikasi aktifkan (dan Izin > Lokasi > Izinkan), kembali ke SIGAP; halaman memeriksa ulang otomatis. Bila Layanan Google Play nonaktif atau Google diblokir jaringan, push tidak bisa aktif.
- Bila masih gagal setelah deploy: minta tangkapan layar pesan merah di bawah tombol.

## Catatan
Belum diuji di HP sungguhan. Peserta iPhone perlu masuk ulang di aplikasi (sesi Safari dan aplikasi terpasang terpisah). Perubahan 9 dan 20 Okt sudah ditulis ke folder repo laptop; perlu commit + push.
