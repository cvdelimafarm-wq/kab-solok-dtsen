# Catatan: Laporan realisasi PML/PPL terisi otomatis (11 Okt 2026)

Permintaan user: pada Laporan realisasi (halaman petugas Transport Lokal), data terisi otomatis dan ditandai dari data identifikasi atau pendataan, sesuai peran masing-masing.

## Keputusan user
- PML: jumlah = banyak Sub SLS yang diidentifikasi hari itu (satuan di form/PDF PML Pascabencana = "Sub SLS", bukan keluarga). Lokasi = jorong dari Sub SLS tersebut.
- PPL dan korwil: jumlah = KK berhasil (terdampak + tidak terdampak) pada hari itu; lokasi = jorong KK yang didata. Definisi sama dengan Monitoring Lapangan (hasil terakhir tiap KK per hari WIB).
- Perlakuan: terisi otomatis TAPI boleh diubah. Petugas tetap harus mengonfirmasi (laporan menentukan hak translok, jadi tidak disimpan otomatis tanpa konfirmasi). Ditegaskan user 12 Okt 2026: "konfirmasi, namun bisa diubah jika petugas memerlukannya".
- (12 Okt 2026) Penegasan di form: tombol simpan berlabel "Konfirmasi & simpan laporan" bila isian = data otomatis dan belum tersimpan; "Simpan laporan (isian diubah)" bila diubah; "Perbarui laporan" bila sudah tersimpan. Teks banner dan petunjuk ikut diubah (app/sigap/translok/[token]/page.tsx; tsc bersih). Belum disalin ke laptop (koneksi putus saat itu) / belum di-commit.

- (12 Okt 2026) Hari LAMPAU (sebelum hari ini WIB) tanpa laporan manual tetapi ada hasil identifikasi (PML) / pendataan (PPL, korwil) = laporan DIANGGAP selesai. Berlaku di: API petugas (hari lengkap & hari dibayar; flag `laporan_dianggap`), dataSpj di lib/sigapDokumen.ts (kwitansi/visum dihitung; PDF Laporan terisi dari data otomatis dengan catatan Kendala "Laporan dibuat otomatis ..."), Monitoring Lapangan (ada_laporan true + `laporan_dianggap`). Hari ini & mendatang TIDAK dianggap (petugas masih konfirmasi). Dokumentasi foto tetap wajib sesuai aturan kegiatan; hari kerja tetap harus dipilih. Fungsi murni `laporanDianggap` + 4 uji. Dihitung langsung (live), tidak disimpan ke sigap_realisasi, jadi ikut berubah bila data lapangan susulan masuk; setelah Verifikasi & Kunci, acuan hari mengikuti waktu kunci.
- Belum dicek: halaman admin lain yang membaca sigap_realisasi langsung (Admin Transport Lokal, antrean pembayaran) mungkin belum memakai aturan ini; perlu ditelusuri di repo penuh.

## Cara kerja
- Fungsi database `bencana_realisasi_otomatis(p_akun, p_peran)` (migrasi `20261011i`, SECURITY DEFINER, hanya service_role; sudah diterapkan). PML membaca `bencana_identifikasi_subsls.diisi_oleh_akun/diisi_at`; selain PML membaca `bencana_pendataan_log` + `bencana_pendataan_kk`.
- API `GET /api/sigap/translok/[token]`: tiap hari kerja memuat `otomatis` {sumber, jumlah, satuan, lokasi[], lokasi_terpotong}; penugasan memuat `satuan_laporan` dan `sumber_otomatis`. Hanya kegiatan `pascabencana*` dengan peran pml/ppl/korwil. Kegagalan baca = kosong (form tetap manual).
- Form: banner "Terisi otomatis dari data identifikasi/pendataan", tanda "otomatis" di label Lokasi dan Jumlah selama nilainya sama; bila diubah muncul "Isian berbeda dari ..." + tombol "Pakai data otomatis"; bila belum ada data: keterangan isi manual. Daftar "Status per hari kerja" menampilkan "N satuan dari data ... belum disimpan".
- PDF laporan harian (`lib/sigapDokumen.ts`) memakai satuan per peran lewat `satuanLaporan` (PML = Sub SLS).
- Kode murni + 9 uji: `lib/realisasiOtomatis.ts`, `lib/__tests__/realisasiOtomatis.test.ts`; server: `lib/portal/realisasiOtomatis.ts`.

## Batas / hal terbuka
- Lokasi maksimal 10 per laporan (batas penyimpanan yang sudah ada); sisanya dicatat sebagai "N jorong lain tidak muat".
- Angka Sub SLS PML tersimpan di kolom `jumlah_realisasi` yang sama dengan keluarga PPL; tampilan admin yang menjumlah lintas peran (mis. total realisasi di Admin Transport Lokal) belum dibedakan satuannya.
- Belum diuji di HP/peramban; belum di-commit git/push/deploy.
