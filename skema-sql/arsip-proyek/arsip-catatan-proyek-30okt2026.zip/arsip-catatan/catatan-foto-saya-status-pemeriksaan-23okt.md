# Catatan: "Foto saya" petugas — status pemeriksaan & ringkas per tanggal (23 Okt 2026)

## Keluhan
Di layar petugas ("Foto saya"), foto yang menurut admin/PML sudah diperiksa tetap berlabel merah "Ditahan, perlu diperiksa". Kartu juga panjang dan tidak dikelompokkan.

## Penyebab
`app/sigap/foto/FotoSaya.tsx` menentukan label & warna hanya dari `kepercayaan` (merah/kuning/hijau) dan mengabaikan `status_periksa` (belum | diperiksa | dipertanyakan). Data DB: semua foto `jauh_dari_wilayah` sejak 22 Okt berstatus `diperiksa`, `kepercayaan` tetap `merah` (histori), tidak ada tag `ditahan` tersisa.

## Perbaikan
- `lib/sigapFoto.ts`: tambah `statusPemeriksaan(kepercayaan, statusPeriksa)` -> `{label, nada, perhatian}`, `WARNA_NADA_PERIKSA`, tipe `NadaPeriksa`/`TampilPeriksa`.
  - diperiksa -> "Sudah diperiksa" (biru, tidak perlu perhatian)
  - dipertanyakan -> "Dipertanyakan PML/admin" (kuning)
  - belum + merah -> "Ditahan, menunggu diperiksa" (merah)
  - belum + kuning -> "Menunggu diperiksa" (kuning)
  - lainnya -> "Wajar" (hijau)
- `FotoSaya.tsx`: "Foto yang saya ambil" dikelompokkan per tanggal (terbaru dulu) dengan header "N foto · x sudah diperiksa · y menunggu"; baris ringkas `jam WIB · Foto N`, kode, chip status; kotak "Alasan menunggu pemeriksaan" hanya muncul bila status butuh perhatian; detail (gambar, catatan sistem yang sudah ditinjau, dibagikan ke siapa) dilipat. Nomor `dilepas` tampil "(cadangan)".
- `lib/__tests__/sigapFoto.test.ts`: 4 tes baru untuk `statusPemeriksaan`.

## Belum dikerjakan (opsional)
`SusunFoto.tsx` masih memakai `LABEL_KEPERCAYAAN` (merah) karena RPC-nya belum mengembalikan `status_periksa`. Bisa disusulkan.

## Verifikasi oleh pengguna
`npx tsc --noEmit`, `npx vitest run`, `npm run build`, lalu commit & deploy. SQL `20261023a` bersifat kosmetik.
