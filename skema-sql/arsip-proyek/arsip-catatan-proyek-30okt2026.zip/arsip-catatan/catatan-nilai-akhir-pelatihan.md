# Nilai Akhir & Perhitungan Kuis — Pelatihan (8 Okt 2026)

Permintaan user: nilai akhir = Pretest + Posttest + Kuis (Adu Sigap) dengan bobot; di bagian atas ada centang komponen yang diperhitungkan + bobotnya; pengaturan sama muncul 2 kali (Soal & Jadwal dan Monitoring › Pretest & Posttest); datanya mengalir ke Administrasi; kolom Kuis & Nilai akhir di Monitoring; halaman nilai di Laporan Pelatihan.

## Rumus (lib/sigapNilaiHitung.ts — murni, dipakai server & browser)
- Nilai akhir = Σ (bobot × nilai komponen)/100 untuk komponen yang DICENTANG; total bobot terpilih WAJIB 100 (bilangan bulat). Bobot komponen tidak dicentang diabaikan.
- Pretest/Posttest = skor sesi selesai (sesi kedaluwarsa difinalkan dulu). Kuis = salah satu dasar (pilihan pengelola): "% jawaban benar" (bawaan: benar/jumlah soal×100) ATAU "poin dinormalkan" (poin/(soal×1000)×100).
- Kuis dari ruang Adu Sigap berstatus SELESAI; bila peserta ikut beberapa ruang, dipakai ruang terakhir yang ia jawab (ruang kosong tidak menimpa ruang yang pernah dijawab). Ruang berjalan tidak dihitung.
- Komponen terpilih yang belum punya nilai dihitung 0 dan baris ditandai "belum lengkap"; bila semua komponen terpilih kosong → "–".
- Skema bawaan bila belum disimpan: Pretest 20 + Posttest 50 + Kuis 30, dasar % benar. (Hanya default aplikasi — user belum menetapkan bobotnya.)

## Database & berkas
- Tabel sigap_pelatihan_nilai_skema (1 baris per kegiatan; pakai_* , bobot_* , dasar_kuis; RLS on) — migrasi 20261008g_sigap_pelatihan_nilai_skema.sql, SUDAH diterapkan.
- lib/sigapNilai.ts (muatSkema, simpanSkema, muatKuisNilai via RPC sigap_kuis_papan, muatTesNilai, muatNilaiAkhir) · API app/api/sigap/pelatihan/nilai/route.ts (GET skema+kuis; POST simpan_skema; ubah = izin pelatihan.kelola kelola; lihat = pelatihan.kelola atau pelatihan.administrasi).
- UI: kelola/skemaNilai.tsx (useSkemaNilai, PanelSkemaNilai, SkemaNilaiMandiri) dipasang di kelola/page.tsx: tab Soal & Jadwal (kartu penuh di atas Presensi) dan Monitoring › Pretest & Posttest (di atas filter). Monitoring: kolom Kuis (nilai + benar/total) & Nilai akhir (+chip belum lengkap), 2 kartu rata-rata, urut kolom, ekspor Excel (kolom kuis/nilai akhir + sheet "Skema Nilai").
- Administrasi: muatPeserta(..., {nilai:true}) → kolom Pretest, Posttest, Kuis, Nilai akhir + keterangan skema (baca-saja). Peserta manual tidak punya nilai.
- Laporan Pelatihan & Laporan Instruktur: bagian "NILAI AKHIR PESERTA" (skema, tabel per peserta + rata-rata kelas, catatan belum lengkap, ringkasan Adu Sigap: jumlah peserta ikut + 3 peringkat teratas) — lib/pdf/sigap/pelatihan.ts (NilaiLaporan), data dari lib/sigapAdministrasi.ts (nilaiLaporan).

## Diuji
- 12 kasus rumus (lulus), render PDF laporan 21 peserta (2 halaman), type-check (hanya galat xlsx lingkungan). Belum diuji di browser dengan data sungguhan.
- DB: 6 ruang kuis kegiatan 3 berstatus selesai (ruang 1–2 kelas 2 percobaan berskor 0, ruang 4 kelas 2 sungguhan); 156 sesi tes.
