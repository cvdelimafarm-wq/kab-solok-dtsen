# Catatan 23 Okt 2026: Unduh massal paket SPJ (ZIP) di Verifikasi & Kunci

Kode SUDAH ditulis ke repo laptop; tsc/vitest penuh/build dijalankan user. Tanpa SQL, tanpa route server baru.

## Keputusan
Item "Kelengkapan SPJ dan paket SPJ per petugas" di tab 6 ternyata sebagian besar sudah ada (chip kelengkapan 6 dokumen + Pratinjau SPJ gabungan per petugas di Verifikasi & Kunci). Kekurangan nyata = unduh massal. User memilih "Unduh massal paket SPJ (ZIP)".

## Cara kerja
- Tombol "⬇ Paket SPJ (ZIP) · N" di kartu "SPJ per petugas" (`app/sigap/admin/TabVerifikasi.tsx`), mengikuti saringan status dan pencarian yang sedang tampil; hanya petugas dengan hari dibayar > 0.
- Dijalankan di BROWSER: tiap petugas diambil SATU per satu dari route yang sudah ada `/api/sigap/admin/dokumen?penugasan_id=..&format=gabungan&unduh=1` (izin translok.verifikasi level lihat, tidak berubah), lalu disusun jadi ZIP dengan `jszip` (dimuat malas, tanpa kompresi karena PDF). Alasan: tidak ada route server baru dan tidak menambah beban memori Railway (lihat catatan-kebocoran-memori-railway.md).
- Dibagi beberapa ZIP bila > 20 petugas (`MAKS_PER_ZIP`, memori browser); nama `Paket_SPJ_kegiatan-<id>_<tanggal>[_bagian-i-dari-n].zip`; nama berkas kembar diberi `_2`.
- Progres "Menyusun paket SPJ i/n · nama", tombol Batalkan; gagal pada satu petugas tidak menghentikan yang lain (dilewati + alasan di ringkasan). Sesi berakhir = berhenti.
- `app/sigap/admin/api.ts`: fungsi baru `ambilBlob(url)` (Blob + nama file + header X-Spj-Dilewati). `lib/sigapUnduhMassal.ts` (logika murni) + 10 tes.
- `lib/sigapPendataanTab.ts`: item "segera" paket SPJ dihapus; keterangan sub Verifikasi & Kunci diperbarui.

## Uji setelah deploy
Tab 6 -> Verifikasi & Kunci: tombol ZIP dengan 2-3 petugas (cari nama), buka ZIP: satu PDF per petugas; petugas tanpa dokumen muncul di "dilewati"; Batalkan di tengah; filter "Sudah dikunci" (pakai berkas beku); > 20 petugas menghasilkan beberapa ZIP (browser mungkin meminta izin unduh banyak berkas).

# Daftar uji terpadu pasca-deploy (perubahan 23 Okt 2026)
Sebelum push: `npx tsc --noEmit`, `npx vitest run`, `npm run build`.
1. Translok petugas: "Rapikan nomor foto" dengan akun yang panduannya belum selesai; tab Arsip (usap tanggal, filter Belum lengkap, Unduh tanggal ini, Lengkapi); Unduh SPJ centang Visum mode satu hari.
2. Foto: tombol "📷 Ganti foto N" di hari ini (mode ganti, Kirim, foto lama jadi cadangan); hari susulan tetap uploader lama.
3. Plotting tim di HP: chip status di bawah keterangan; tombol tidak tertutup FAB Kolam wilayah (belum ada ruang kosong di dasar daftar).
4. Kelola Pendataan: tujuh tab; tab 2 (Penugasan & ST), tab 5 (Identifikasi, Lapangan, Foto), tab 6 (Monitoring, Verifikasi & Kunci, Tarif, Pengadaan); alamat lama /sigap/kelola/identifikasi|lapangan|foto|translok|pengadaan dan /sigap/kontrak tetap terbuka; `?sub` ikut alamat dan direset saat pindah tab.
5. Akun tanpa izin translok melihat pesan izin di sub transport lokal.
