# Rekap: review prompt audit navigasi/data SIGAP (23 Okt 2026) + pekerjaan lama yang belum selesai

Disusun 23 Okt 2026 sore. Status prompt audit: BELUM dikerjakan sama sekali (tidak ada TombolKembali, tidak ada teks "Keluar simulasi" di kode).

## A. Review prompt audit

### Terverifikasi di kode (read-only)
- "Kegiatan baru" dobel: `app/sigap/admin/page.tsx` baris ±244, ±312, ±330 (tiga tombol) + satu aksi palet Ctrl+K. Benar.
- Tombol oranye "Kembali" di mode Lihat sebagai: `app/components/BannerLihatSebagai.tsx` baris ±90. Benar (komentar kode menyebut "Kembali ke akun saya").
- Kartu Admin Delego berujung "Tautan Delego belum diatur": `app/sigap/kelola/delego/page.tsx`. Benar.
- Tombol kembali bervariasi: bentuk kembali tersebar di ±10 berkas (admin/page, kegiatan/[id], kegiatan/[id]/Induk, translok/[token], perencanaan, MonLapangan, MonIdentifikasi, KelolaFoto, delego, KameraSigap) dan `?dari=` dipakai di 7 berkas; helper navigasi ada di `lib/sigapNavigasi.ts` (`indukDari`) dan `app/portal/navigasi.ts` (`keAtas`). Komponen bersama belum ada.
- Tombol "Unduh SPJ" melayang: SUDAH dihapus total hari ini (permintaan user), jadi butir 8 Tahap 1 gugur.

### Kemungkinan usang (audit ditulis sebelum deploy 23 Okt)
- "/sigap/kelola/pendataan, /foto tanpa tombol kembali (hanya logo)": sejak 23 Okt halaman pendataan dibingkai Shell + sidebar (Beranda admin) dan foto/identifikasi/lapangan/pengadaan disematkan sebagai tab. Cek ulang setelah deploy sebelum mengerjakan butir 3 dan 5.
- "Halaman Layer 2/3, Lembar Pendataan, Kamera" tetap perlu diperiksa.

### Catatan risiko / ketidaksesuaian
1. Gerbang "tiap tahap harus lolos pengujian": tsc, vitest, build dijalankan USER (tidak ada shell di laptop). Claude hanya bisa tsc terarah di sandbox (tidak lengkap). Usul: satu tahap = satu commit = satu deploy (Railway: jangan memicu deploy berulang).
2. `?dari=`: wajib divalidasi (hanya path internal diawali "/", tolak "//", skema, backslash) agar tidak jadi open redirect; tulis fungsi murni + tes.
3. Tahap 1 butir 4 (translok lama): token ada di alamat dan tautan WhatsApp sengaja bebas gerbang; perubahan Kembali/logo tidak boleh memutus tautan token. Konsisten dengan usulan 14 Okt (N-01) tetapi tidak sama dengan N-02 (alamat bertingkat, ditunda).
4. Tahap 2 butir 1 `/dashboard`: kemungkinan terkait keputusan keamanan yang masih terbuka (dashboard_progress dan seruti_progress masih memakai kunci anon; `/dashboard` memang aplikasi usulan DTSEN dengan login nama + PIN sendiri). Selidiki baca-saja dulu seperti diminta.
5. Tahap 2 butir 4 (emoji -> ikon garis, tiga varian tombol): menyentuh banyak berkas; pekerjaan hari ini (Arsip, tombol sub tab, Kelola Pendataan) memakai emoji dan kelas tombol lokal. Kerjakan SETELAH Tahap 1, dengan satu komponen tombol bersama, bukan sapu rata.
6. Tahap 2 butir 2 (glosarium) dan Tahap 3 butir 1-2: butuh keputusan istilah/definisi dari user; angka berbeda belum tentu salah (definisi penyebut). Laporkan dulu, jangan ubah rumus.
7. Tahap 2 butir 3 (Tahap 1 dari 2 vs 3 dari 4): sumbernya kemungkinan penomoran tahap per peran (`sigapTahap.ts`, kegiatan [id]/[tahap]/page.tsx); selidiki dulu.
8. Tahap 3 butir 3 (riwayat siaran 93/85): ada kemungkinan penyebut dihitung dari penerima sekarang, bukan saat kirim; perbaikan mungkin butuh kolom/migrasi (tulis sebagai berkas migrasi, jangan jalankan).
9. Tahap 3 butir 7: kartu "segera" (sanggahan/pengawasan PML, penutupan wilayah, honor, perjalanan dinas) sudah dikelompokkan sebagai item "segera" di tab Kelola Pendataan; sisa pekerjaan = satu gaya "Segera hadir" yang seragam di sidebar dan tab, dan menandai RO contoh di /sigap/kelola/perencanaan (data uji, tersimpan di peramban).
10. Tumpang tindih dengan pekerjaan hari ini: penyederhanaan tombol ganda tab Arsip (selesai), "Status per hari kerja" vs Arsip per tanggal (belum, menunggu keputusan).

### Urutan usulan
Tahap 1 (komponen TombolKembali + Beranda + Keluar simulasi + Kegiatan baru dobel + /bencana kerangka) -> deploy+uji -> Tahap 2 (butir 1 selidiki; glosarium butuh keputusan) -> Tahap 3 baca-saja dan laporan keputusan.

## B. Pekerjaan lama yang belum selesai (gabungan seluruh catatan Project)

### B1. Verifikasi dan deploy (menunggu user)
- [ ] `npx tsc --noEmit`, `npx vitest run`, `npm run build` untuk seluruh perubahan 23 Okt: Ganti foto; Kelola Pendataan tersemat (tab 2, 5, 6 + Pengadaan); Unduh massal SPJ (ZIP); jarak foto > 10 km jadi kuning (`lib/sigapFoto.ts` + tes); tab Arsip translok (baris diketuk, FAB dihapus); Rapikan nomor foto/Arsip per tanggal.
- [ ] Commit, push, deploy SEKALI.
- [ ] SQL `supabase/migrations/20261023a_foto_jauh_wilayah_jadi_kuning.sql` dijalankan setelah deploy (50 foto lama -> kuning, 5 tag dilepas, 14 tag nomor terisi tetap ditahan).
- [ ] Daftar uji terpadu pasca-deploy (catatan-unduh-massal-spj-23okt, catatan-pemeriksaan-tersemat-23okt, catatan-arsip-baris-ketuk-23okt, catatan-jarak-wilayah-jadi-kuning-23okt) + `daftar-uji-pasca-deploy-22okt.md` bagian A-E (termasuk D2: QR domain portal, Siaran perubahan target harian 60 poin, Yeni aktifkan notifikasi, Unduh SPJ satu hari/rentang).
- [ ] Pantau memori Railway 1-2 hari setelah klien Supabase bersama (target 300-600 MB).

### B2. SQL / migrasi yang belum diterapkan atau belum disetujui
- [ ] `claude/skema-sql/20261022a..k` (tkl_fondasi, keu_anggaran, kual_jejak_tumbuh, mitra_kontrak_seleksi, sdm_kinerja, tkl_kendali_data_audit, pelengkap_*, kamus_komentar): belum diterapkan; RAB berversi dan persetujuan antar akun menunggu ini.
- [ ] Migrasi `20261019c` (pengawasan PML / sanggahan): belum disetujui user.
- [ ] Keamanan: `dashboard_progress` dan `seruti_progress` belum dicabut dari anon (putuskan apakah /dashboard dan /seruti masih dipakai); rotasi kunci Supabase/Railway ditunda sampai build stabil.

### B3. Fitur yang masih "segera" / berupa tautan
- Sanggahan dan pengawasan PML; Penutupan wilayah; Honor; Perjalanan dinas; Ruang keputusan; Audit dan bukti; Diseminasi.
- Masih tautan, belum tersemat: /bencana (555 KB), Kelola Pelatihan, Perencanaan (94 KB, parameter alamat bentrok dengan ?tab/?sub).
- Anggaran (RAB): ada di Perencanaan (data di peramban); penyimpanan DB menunggu migrasi.
- Plotting tim di HP: ruang kosong di dasar daftar agar FAB Kolam wilayah tak menutup tombol.

### B4. Keputusan / masukan yang ditunggu dari user
- Nomor surat baru dan tanggal ST Anggun Permata Munef (masih B-1448, 22 Okt-10 Nov 2026).
- Tujuan tombol "Beranda" di Kelola Pendataan (kemungkinan /sigap/kelola/translok?tab=beranda).
- 14 foto jarak jauh yang tag-nya masih ditahan (nomor sudah terisi): biarkan PML memutuskan lewat tab Periksa.
- Gabungkan "Status per hari kerja" (tab Hari Kerja translok) dengan Arsip per tanggal? (tautan ?tab=hari_kerja&tgl= memakainya).
- Kalibrasi RAB: rentang per versi, cadangan 5%, pola bayar; kode program RO resmi.
- Dokumen Induk SIGAP v2: 11 pertanyaan terbuka (nama modul anggaran/SPJ, tempat SIGAP PEDIA, alamat baru, dll.).

## C. Hal yang sudah selesai sesi ini (agar tidak dikerjakan ulang)
Ganti foto; Kelola Pendataan tersemat tab 5/2/6 + Pengadaan; Unduh massal SPJ ZIP; ST supervisor Anggun (PDF); jarak foto > 10 km = kuning (kode+tes+SQL); tab Arsip: baris diketuk, FAB dihapus, penyederhanaan tombol ganda.

## D. Keputusan user (23 Okt 2026, sore) dan tindak lanjutnya

1. ST Anggun Permata Munef: nomor tetap B-1448 (nomor 1448 memang miliknya); tanggal tidak diubah (22 Okt-10 Nov 2026). Tidak ada tindakan.
2. Tujuan "Beranda" di Kelola Pendataan = Beranda admin SIGAP (`/sigap/kelola/translok?tab=beranda`). Item sidebar "Beranda" sudah ke sana (`Shell.pindahMenu`). Yang dibereskan: tautan ke `/` di Shell (logo, menu avatar, palet Ctrl+K) yang berlabel "Beranda SIGAP" diganti "Portal utama" supaya tidak ada dua "Beranda" berbeda arti.
3. Gabung "Status per hari kerja" ke Arsip per tanggal: DONE di kode. Daftar dihapus dari tab Hari Kerja (tinggal kalender); tautan lama `?tab=hari_kerja&tgl=` (pengingat/push) kini membuka tab Arsip pada tanggal itu, bagian laporan/foto ikut terbuka bila `?fokus=`.
4. 14 foto jarak jauh: sudah diperiksa user. Cek DB: semua foto jauh_dari_wilayah sejak 22 Okt berstatus diperiksa dan tidak ada tag yang masih ditahan, jadi bagian "lepas tag" di SQL 20261023a tidak lagi berfungsi (tak ada baris); bagian penurunan kepercayaan ke kuning hanya kosmetik.
5. Kalibrasi RAB (rentang per versi, cadangan 5%, pola bayar): ditunda; dicoba dulu dengan satu RO data nyata.
6. Dokumen Induk SIGAP v2: "setuju semua" dibaca sebagai menyetujui seluruh USULAN Claude di dokumen itu: nama modul "Anggaran & SPJ"; Monitoring -> Pengendalian; Transport lokal -> Administrasi & SPJ; Referensi dihapus; alamat baru `/sigap/kelola/monitoring` dan `/sigap/kelola/spj` dengan pengalihan 307 dari alamat lama; 11 artboard = Tahap 1. Belum ada kode untuk ini (perlu dikerjakan sebagai paket sendiri; konfirmasi bila ada butir yang sebenarnya tidak disetujui).
