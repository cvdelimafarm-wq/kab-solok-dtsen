# Foto landscape terbalik 180° dan tata letak HP (24 Okt 2026)

Status: kode SUDAH ditulis ke folder proyek (D:\02 BPS Kabupaten Solok\2026\13 Usul DTSEN). BELUM di-commit, di-push, atau dites di HP. tsc dan vitest repo belum dijalankan (hanya cek sintaks + uji logika di sandbox).

## 1. Foto terbalik (penyebab sebenarnya)
- Dugaan awal (sharp tanpa .rotate()) SALAH: lib/sigapFotoCap.ts sudah memanggil .rotate().
- Penyebab: fitur "landscape otomatis" (21 Okt) di KameraSigap.potret(). Layar terkunci tegak, arah HP dibaca dari sensor (miring: 1 = HP ke kiri, -1 = ke kanan). Arah putar kanvas TERTUKAR: HP ke kiri memutar bingkai searah jarum jam (seharusnya berlawanan), HP ke kanan sebaliknya. Akibatnya SEMUA foto landscape dari HP yang dimiringkan terbalik 180°; cap server tetap tegak karena dicetak sesudah piksel jadi.
- Bukti: uji piksel di Chromium (sisi bingkai berwarna) menunjukkan sisi "atas dunia" jatuh di bawah pada kedua arah; matriks baru menaruhnya di atas.
- Perbaikan: lib/sigapFotoPutar.ts (matriksPutarBingkai, murni) + uji lib/__tests__/sigapFotoPutar.test.ts; KameraSigap.tsx memakai ctx.setTransform.
- Asumsi: tanda sensor (x > 0 = HP diputar ke kiri) sesuai standar Android Chrome; iOS sudah dibalik di kode. UI kontrol yang diputar (rotate 90deg untuk putar = 1) konsisten dengan asumsi ini.
- Foto lama yang sudah terbalik TIDAK ikut diperbaiki (piksel dan cap sudah tergabung). Usulan: tombol "Putar 180°" untuk PML/admin sebagai putaran tampilan saja (kolom derajat baru), belum dibuat.

## 2. Tata letak HP
- Penyebab sempit: empat lapis jarak/bingkai (kartu Arsip p-4, kotak tanggal p-3.5, kartu FotoKegiatan p-4 + border, SusunFoto border + p-3) ≈ 60 px per sisi.
- Diubah: SusunFoto prop `polos` (tanpa bingkai bila sudah di dalam kartu FotoKegiatan); p-4 -> p-3 sm:p-4 pada Arsip dan FotoKegiatan; kotak tanggal p-3.5 -> p-2.5 sm:p-3.5; slot foto aspect-[4/3] dan h-full (tinggi seragam); label break-normal (tidak pecah "Berangk/at"); teks "Kosong" di dasar slot (tidak bentrok dengan lencana nomor); foto cadangan diringkas dan diberi huruf (Cadangan A, B).
- Berkas: app/sigap/foto/{SusunFoto,FotoKegiatan,KameraSigap}.tsx, app/sigap/translok/[token]/page.tsx, lib/sigapFotoPutar.ts.
- Tab abu-abu di tepi kanan tangkapan layar adalah elemen sistem HP (juga muncul di aplikasi lain), bukan bagian SIGAP.

## Uji sesudah deploy
1. Potret landscape dengan HP diputar ke kiri, lalu ke kanan, kamera belakang dan depan: foto di Foto saya dan Periksa harus tegak, cap terbaca.
2. Kisi foto di Arsip pada lebar 360, 390, 412 px dan huruf sistem 130%: tinggi kartu sama, tidak ada kata terpecah.
