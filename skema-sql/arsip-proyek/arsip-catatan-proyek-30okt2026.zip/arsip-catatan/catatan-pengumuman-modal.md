# Catatan: Modal Pengumuman peserta (8 Okt 2026)

Menggantikan modal "PERHATIAN pergantian lokasi (Ully Hotel)" yang tertanam di kode. Kini diatur panitia: Kelola Pelatihan > tab "📢 Pengumuman". Mockup disetujui user.

## Aturan (pilihan user)
- Format isi: toolbar sederhana + pratinjau. Penanda: `**tebal**`, `==sorot==`, `[teks](https://tautan)`, baris `- ` = daftar. Tanpa HTML (aman); tautan hanya https.
- Modal berlapis: antrian berurutan ("1 dari n", tombol Lanjut → / Saya mengerti), urutan diatur ↑↓. Antrian ditentukan sekali saat halaman Langkah dibuka.
- Per modal: judul, jenis (info biru / perhatian kuning / penting merah), aktif, frekuensi (tiap halaman dibuka / sekali per peserta — dicatat di browser, berlaku lagi bila modal diubah), jadwal mulai-berakhir (WIB), sasaran kelas & peran (PPL/PML), tombol tautan (label + URL).
- Tidak ada penghapusan permanen; modal dimatikan lewat status aktif. Maks 30 modal. Perubahan dicatat di sigap_audit.
- Modal lama (Ully Hotel) dimasukkan ke tabel sebagai id 1, NONAKTIF.

## Teknis
- Tabel `sigap_pengumuman` (migrasi 20261008j, sudah diterapkan). API admin: /api/sigap/pelatihan/admin/pengumuman (GET, POST simpan/urut/aktif). Hub /api/sigap/pelatihan mengirim `pengumuman` (sudah difilter jadwal & sasaran).
- File: lib/sigapPengumuman.ts, app/sigap/pelatihan/pengumumanUi.tsx, kelola/pengumuman.tsx, page.tsx (antrian), komponen.tsx (tipe Hub).
