# Plotting identifikasi untuk FASIH (11 Okt 2026)

FASIH = aplikasi riil pendataan; SIGAP = pendukung. Identifikasi di FASIH dikerjakan PML, jadi kolom pencacah = PML. Templat FASIH identifikasi: PROVINSI, KABUPATEN/KOTA, KECAMATAN, DESA/KELURAHAN, Email Pencacah (tingkat desa, tanpa SLS/Sub SLS dan tanpa pengawas).

## Aturan (arahan pengguna)
- FASIH hanya mengizinkan 1 Sub SLS dikerjakan 1 PML.
- Seluruh Sub SLS yang ada di plotting pendataan (bencana_alokasi_subsls.pml_id) mengikuti PML itu (150).
- Sub SLS di lembar identifikasi yang tidak ada di plotting pendataan diplot ke PML pelaksana identifikasi (bencana_identifikasi_alokasi), 471 Sub SLS.
- Seluruh Sub SLS nagari terdampak (gate: 33 nagari, 202 SLS, 621 Sub SLS) harus terplot: terpenuhi.

## Hasil
- 7 Sub SLS pendataan terbagi dua PML (porsi 50:50): dipilih 1 PML (pelaksana identifikasi, lalu pendamping, lalu ID terkecil).
- Berkas: Alokasi_Pencacah_Identifikasi_FASIH.xlsx dan Rincian_Plotting_Identifikasi_PML.xlsx. Basis data tidak diubah.
- Email PML mitra dari bencana_mitra (via sigap_akun.mitra_id), huruf kecil; 4 PML organik dari berkas alokasi sebelumnya (adrianto@, ardialjaraf-pppk@, hariston-pppk@, ilham-pppk@bps.go.id). Email Dessy Meiyarni tidak mirip namanya (perlu dicek).

## Penegasan pengguna (11 Okt, siang)
Tiap Sub SLS tetap ditangani PML pada plotting pendataan (termasuk bila satu SLS terpecah ke beberapa PML, mis. Koto Gadang Talang: Ardial Jaraf, Hariston, Irawita). Hanya Sub SLS tanpa PML pendataan yang diplot lewat plotting identifikasi.
Sub SLS tanpa PML pendataan di nagari terdampak = 471: 78 wilayah kerja (228 Sub SLS) yang belum terplot (bantuan keroyokan; 77 sampel, perkiraan 4.126 KK terdampak) + 393 bukan Sub SLS terdampak menurut data saat ini (327 daftar awal, 66 bukan). 39 di antaranya sudah punya hasil identifikasi PML. Kolom "Sumber plotting PML" di berkas rincian memuat kategori ini.
Koreksi: yang terbagi dua PML di plotting pendataan adalah 7 Sub SLS (bukan 11; 11 = selisih baris alokasi).

## Tambahan 104 Sub SLS dari laporan pusat (11 Okt, siang)
Laporan FASIH pusat memuat 104 Sub SLS belum ter-assign yang tidak ada di plotting identifikasi: semuanya daftar awal pusat di 5 nagari di luar 33 nagari terdampak. Alahan Panjang (55) dan Koto Gadang Koto Anau (21) = gate "tidak terdampak"; Batu Bajanjang Lembang Jaya (13), Kinari (12), Sungai Durian (3) = belum dicek (tanpa baris gate). Keputusan pengguna: tambahkan semua 104.

## Revisi pembagian 104 Sub SLS (11 Okt, sore)
Pengguna melaporkan anomali: Ebel dan Yurneti mengidentifikasi Alahan Panjang padahal sangat berjauhan. Penyebab: pembagian pertama memakai batas beban 34 per PML dan Ilham dikecualikan, sehingga Alahan Panjang (55 Sub SLS, hanya 1,8 km dari wilayah Ilham) jatuh ke PML jauh (jarak rata-rata 24,8 km; 67 Sub SLS lebih dari 10 km lebih jauh dari PML terdekat).
Keputusan pengguna: abaikan batas beban; ini hanya identifikasi sehingga PML identifikasi boleh berbeda dari PML pendataan; 104 wilayah itu kemungkinan tidak terdampak (tidak lanjut ke pendataan).
Hasil: tiap SLS utuh ke PML dengan Sub SLS kerja terdekat. Jarak rata-rata terbobot 2,3 km, terjauh 5,6 km. Alahan Panjang 55 ke Ilham (beban Ilham 228); Batu Bajanjang ke Irawita 9 dan Adriyanto 4; Kinari ke Widya Verawati 12; Koto Gadang Koto Anau ke Yeni 12, Hariston 7, Ardial 2; Sungai Durian ke Ebel 3.
Total 725 Sub SLS = 97 baris desa x PML. Berkas: Alokasi_Pencacah_Identifikasi_FASIH_104_SubSLS.xlsx (templat khusus 104, 8 baris), Rincian_104_SubSLS_Assignment_Pusat.xlsx, serta versi 725 yang diperbarui. Dari 471 lainnya, jarak ke PML rata-rata 2-3 km sehingga tidak diubah.
