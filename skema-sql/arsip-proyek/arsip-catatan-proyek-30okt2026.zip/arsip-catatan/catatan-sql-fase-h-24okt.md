# Catatan SQL Fase D (berkas h): unggahan POK resmi, realisasi, peringatan SPAN, skor (24 Okt 2026)

Status: **siap dijalankan di produksi oleh Bapak; belum diterapkan.** Diuji di sandbox PostgreSQL 16 bersama rangkaian a-f (`uji_paket/jalan_h.sh`; berkas h dijalankan dua kali untuk memastikan aman diulang; uji `40_uji_unggah_realisasi_skor.sql` lulus). Penamaan: huruf `g` dipakai skrip data impor POK 2026, jadi skema berikutnya memakai `h`.

## Berkas
1. `fase-b/20261024h_keu_unggah_realisasi_skor.sql` (satu berkas; tabel, fungsi, view, trigger, RLS).
2. `fase-b/20261024z3_cek_kesehatan_keu_h.sql` (hanya membaca; baris P0 harus 0; jumlah tabel `keu_` menjadi 45).
3. `fase-a/20261024z_cek_kesehatan_keu.sql` diperbarui (baris 4 ikut menghitung 6 tabel h). Opsional dijalankan ulang.
4. Uji: `fase-a/uji/40_uji_unggah_realisasi_skor.sql`, `jalan_h.sh`.

## Tabel baru (6)
`keu_pok_unggah` (PDF POK resmi: diunggah -> diterima | ditolak), `keu_pok_unggah_baris` (baris datar hasil penguraian, hanya tambah), `keu_pok_unggah_padan` (pemadanan manual D-29), `keu_realisasi_unggah` (Excel GLP039; diterima | dibatalkan), `keu_realisasi_item`, `keu_item_nomor` (nomor item resmi 000252 <-> kunci stabil).

## Alur POK resmi (PPK, kewenangan `pok_pdf`)
1. `keu_pok_unggah_baru(tahun, nomor_revisi, nama_berkas, sha256, nomor_pok, tanggal_efektif, jadwal_id)`: nomor revisi wajib lebih besar dari versi berlaku; jadwal (bila diisi) harus berstatus diterapkan atau sah. Hash atau nomor yang pernah ditolak boleh dipakai lagi.
2. `keu_pok_unggah_isi(unggah, jsonb)`: satu kali; kunci JSON sama dengan kolom `keu_pok_unggah_baris` (prog_kode, keg_kode, kro_kode, ro_sub, komp_kode, sub_kode, akun_kode, uraian, volume, satuan, harga_satuan, jumlah, nama-nama, ro_volume, ro_satuan).
3. Pembanding `keu_v_pok_banding` dan `keu_v_pok_unggah_ringkas`: sama / berubah / baru / hilang / dipadankan, serta `di_luar_usulan` (perubahan pada RO yang tidak punya usulan disetujui di jadwal dasar). Baris baru + hilang yang sebenarnya satu item (redaksi berubah) dipadankan dengan `keu_pok_unggah_padankan(baris, kunci_lama)`; `keu_pok_unggah_lepas_padan` membatalkan.
4. `keu_pok_unggah_terima(unggah)`: membangun versi POK (node dan detail), membawa nomor item, membuat alias kunci untuk baris yang dipadankan, memberlakukan versi, menautkan ke catatan sah. Jadwal berjenis pok/administrasi mempertahankan pagu: total unggahan harus sama dengan POK berlaku. RO yang belum ada di Master RO menolak penerimaan. `keu_pok_unggah_tolak` (alasan minimal 5 huruf). `keu_sah_tautkan_pok(jadwal)` bila catatan sah dibuat setelah POK hasil diterima.

## Alur realisasi (bendahara, kewenangan `realisasi`)
`keu_realisasi_masuk(tahun, sampai_tanggal, nama, sha256, jsonb item)`: item memuat nomor_item, ro_kode, komponen_kode, akun_kode, uraian, pagu, lock_pagu, real_lalu, real_ini, real_sd, sisa. Identitas dicek (s.d. = lalu + ini; sisa = pagu - lock - s.d., toleransi 1). Pencocokan ke POK berlaku: lewat nomor item bila sudah dikenal, lalu lewat kunci dari teks (ro/komponen/akun/uraian + urutan kemunculan), sisanya `tidak`; `keu_realisasi_padankan(item, kunci)` memadankan manual. Satu unggahan diterima per tanggal data; `keu_realisasi_batalkan` (alasan) lalu unggah ulang. Tiap unggahan masuk antrean laporan KPA.
Realisasi per bulan = "bulan ini" dari unggahan terakhir pada bulan itu (`keu_v_realisasi_bulan`).

## Tampilan baru
`keu_v_realisasi_terbaru`, `keu_v_realisasi_ro`, `keu_v_span_peringatan` (merah: tanpa RAB, melebihi RAB, bulan tak terjadwal; kuning: RO tanpa RAB sah, nomor item belum cocok, pagu laporan beda dengan POK), `keu_v_kk_r06` (R-06: baris kertas kerja di bawah realisasi; Booked belum punya sumber data, sementara memakai realisasi s.d.), `keu_v_skor_ro`.

## Skor (RUMUS SEMENTARA, menunggu keputusan Bapak, pertanyaan terbuka 5)
Bobot dan ambang dari `keu_master_skor` (35/25/20/20; 85/70). Penarikan = 100 x (1 - jumlah |rencana - realisasi| bulanan / jumlah nilai terbesar) sampai bulan data terakhir. Volume = kedekatan POK terhadap RAB per item (rupiah). Cakupan = persen jumlah POK RO yang punya RAB. Disiplin = persen usulan yang disetujui saat jadwal tertutup. RO tanpa RAB sah: tiga komponen pertama 0. Komponen tanpa data tidak ikut rata-rata berbobot.

## Yang perlu diketahui sebelum dijalankan di produksi
- Versi POK berlaku saat ini bernomor revisi 1 (SEMENTARA). Unggahan POK resmi harus bernomor lebih besar. Bila nomor resmi ternyata 1 atau lebih kecil, kabari saya (perlu fungsi penamaan ulang versi sementara).
- Kode KRO kembar dalam satu kegiatan digabung menjadi satu node KRO saat unggahan diterima.
- Penerimaan unggahan langsung memberlakukan versi (tanpa tahap draf terpisah).
- Pengurai PDF POK dan Excel GLP039 berada di sisi aplikasi (kode berikutnya): menghasilkan JSON seperti di atas.

## Cara menjalankan di produksi
1. `list_tables` untuk memastikan 39 tabel; jalankan `20261024h_keu_unggah_realisasi_skor.sql` di SQL editor ("Run and enable RLS").
2. Jalankan `20261024z3_cek_kesehatan_keu_h.sql` (baris P0 = 0, tabel 45) dan z_cek yang diperbarui.
