# Catatan Monitoring Lapangan (11 Okt 2026)

Permintaan user: monitoring translok dan identifikasi/pendataan lapangan, bisa difilter PML/PPL/korwil, tanggal, isinya nama PPL/PML, status pengawasan/pendataan (ditandai ada hasil identifikasi atau pendataan), jumlah berhasil, status translok.

## Keputusan user
- Pemakai: admin saja (izin `bencana.admin`, level lihat cukup).
- Jumlah berhasil: PPL = KK terdampak + tidak terdampak; PML = Sub SLS yang sudah diidentifikasi. "Tidak ditemukan" tidak dihitung berhasil (ditampilkan terpisah).
- PML TIDAK dihitung KK-nya (koreksi user 11 Okt sore: "di Ardial Jaraf kenapa ada KK berhasil, padahal dia PML"). Penandaan KK oleh PML di Lembar Pendataan tetap tersimpan (tim keroyokan boleh menandai) tetapi tidak masuk angka Monitoring Lapangan; hanya tooltip/ekspor kolom "KK ditandai PML (tidak dihitung)" dan catatan kecil di kartu KPI. Pada 11 Okt, 3 PML (Ardial Jaraf, usyenti, Budi Pernandes) menandai KK; penandaan Ardial dan Budi berupa ganti-ganti hasil dalam hitungan detik (kemungkinan uji coba).
- Status translok dari tiga unsur: hari kerja dipilih, laporan harian, foto dokumentasi (aturan kegiatan Pendataan id=1: laporan wajib + 5 foto).
- Tampilan: tabel, 1 baris = 1 petugas x 1 tanggal. Kolom agregat = kumulatif orang itu sampai tanggal baris (tidak terpengaruh filter tanggal).
- SEMUA petugas PML/PPL/korwil tampil di setiap tanggal, termasuk yang belum ada hasil ("Belum ada hasil").

## Definisi status
- Status lapangan: Ada identifikasi (PML, Sub SLS > 0) / Ada pendataan (PPL atau korwil dengan KK berhasil > 0) / Belum ada hasil. PML yang hanya menandai KK = Belum ada hasil, tetapi dianggap beraktivitas agar translok tidak jadi anomali palsu.
- Status translok: Lengkap (hari kerja + hasil + laporan + foto sesuai aturan); Sebagian (hari kerja + hasil, dokumentasi belum lengkap); Anomali (ada hasil/laporan/foto tanpa hari kerja, ATAU hari kerja tanpa hasil sama sekali); Tidak ada klaim (tidak ada apa pun).
- Korwil: hari kerja tanpa hasil lapangan BUKAN anomali (mengoordinasi, bukan mendata); dokumen tanpa hari kerja tetap anomali.
- Catatan: hari berjalan bisa tampil Anomali sementara karena hasil belum masuk.

## Berkas
- Migrasi `20261011e_monitoring_lapangan.sql` (fungsi `bencana_monitoring_lapangan(p_dari, p_sampai, p_kegiatan)`, SECURITY DEFINER, hanya `service_role`, rentang maks 92 hari, tanggal WIB) dan `20261011f_adriyanto_korwil.sql` (fungsi diperbarui memuat korwil). Keduanya sudah diterapkan ke Supabase.
- `lib/lapangan.ts` (logika murni + 25 uji di `lib/__tests__/lapangan.test.ts`), `lib/portal/lapangan.ts` (server), `app/api/portal/lapangan/route.ts` (GET, ?dari&sampai), `app/sigap/kelola/lapangan/page.tsx` (halaman), item "Monitoring lapangan" di sidebar `Shell.tsx` (grup Monitoring) + palet perintah. Semua sudah disalin ke laptop.

## Adriyanto = korwil, filter Korwil (11 Okt 2026, sore)
- Keputusan user: Adriyanto (organik, id 5) bertindak sebagai korwil; status PML hanya saat pelatihan. Ia tidak punya PPL maupun Sub SLS pendataan; hanya memegang 17 SLS identifikasi (belum ada yang terisi).
- Migrasi f: `bencana_petugas.peran` id 5 `pml` -> `korwil` (tetap peserta pelatihan: dinilai dari penugasan kegiatan 3); 17 SLS identifikasinya dibagi ke PML terdekat tanpa batas beban (16 ke Irawita, 1 ke Widya Verawati; titik Irawita dan Ilham sama, seri diberikan ke Irawita yang lebih ringan); cadangan di `arsip.cadangan_idf_alokasi_adriyanto_20261011` (RLS aktif). Pemulihan: set peran kembali `pml` dan salin balik `pml_pelaksana_id` dari arsip.
- Korwil di Monitoring Lapangan = pegawai organik berakun aktif yang bukan PML/PPL (12 orang: Adrianus, Adriyanto, Arini, Deswaty, Dina, Kafsal, Lucia, Nurafiza, Riko, Riva, Uci, Witria). Ardial Jaraf, Ilham, Hariston tetap PML. Total 19 PML + 66 PPL + 12 korwil.
- Filter Peran: Semua / PML / PPL / Korwil.

## Cara baca data
- Penandaan HP yang belum terkirim (antrean offline) belum masuk angka. Hanya jumlah yang tampil, tanpa nama KK.

## Terbuka
- Perlu commit, push, dan deploy oleh user; uji di HP/laptop dengan akun admin.
- 16 SLS identifikasi pindahan di Irawita bisa dibagi ulang bila terasa berat; keanggotaan korwil selain 12 nama di atas belum dikonfirmasi.
- Apakah PML memang boleh menandai KK di Lembar Pendataan (sekarang boleh, sesuai rancangan keroyokan) belum ditegaskan user.
- Rumus poin kinerja belum ada (halaman ini hanya menampilkan data).
