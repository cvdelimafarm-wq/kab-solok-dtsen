# Catatan mockup Kertas Kerja Revisi POK, tahap 6 (24 Okt 2026)

Status: MOCKUP saja (artifact Design, Versi 35). Belum ada SQL, migrasi, atau kode aplikasi sampai Pak Iqbal menyatakan "setuju".

## Permintaan dan hasil
1. Rencana penarikan bulanan tepat di bawah RAB yang bersangkutan, bukan per item: grid "Per bulan" kini muncul langsung di bawah baris rincian pemiliknya, diikuti baris ringkasan jadwal (jumlah jadwal vs rincian, tombol Ratakan ulang). Urutan tampilan: header, baris 1, jadwal baris 1, baris 2, jadwal baris 2, "+ Baris rincian". Sebelumnya semua baris rincian tampil dulu, baru semua jadwal.
2. Modal konfirmasi sebelum setiap hapus: hapus baris rincian (tombol ×), hapus RAB item, hapus RAB massal dari bilah aksi (menyebut jumlah item dan yang dilewati karena belum punya RAB), Kembalikan ke semula, dan Lepas contoh unggahan SPAN. Modal berisi judul, penjelasan dampak, tombol Batal dan tombol merah "Ya, ...". Klik di luar modal sama dengan Batal.
3. Ukuran kartu maksimal selebar layar: pembatas lebar 1440 px pada halaman dicabut; kartu, lembar tabel, dan baris ringkasan memakai lebar penuh area konten. Tafsiran saya: yang dimaksud kartu adalah kartu ringkasan dan lembar tabel. Bila yang dimaksud lain, perlu koreksi.
4. Judul kolom di tengah: header tabel Kertas Kerja, tab RAB, rincian RAB, dan Matriks diratakan tengah (termasuk ikon cari, urut, filter).

## Pengujian
Keseimbangan tag, kunci template, uji alur bilah, dan skrip uji baru untuk urutan jadwal serta modal (batal, ya, massal, semula, SPAN) lulus. Tampilan di peramban belum diverifikasi.
