# Catatan 22-23 Okt 2026: tab Anggaran (RAB) di Perencanaan kegiatan

Status: SUDAH di-commit dan dideploy ke Railway (23 Okt; commit 03ba9b1 + perbaikan build Surat Tugas). Tanpa alamat baru, tanpa migrasi; data RAB tersimpan di browser (localStorage, kunci `sigap_uji_rab_v1`) seperti data perencanaan lain, sampai aturan disetujui dan migrasi `claude/skema-sql/20261022b_keu_anggaran.sql` diterapkan.

## Berkas
- `app/sigap/kelola/perencanaan/AnggaranTab.tsx` (baru): bagian "Anggaran (RAB)" di tingkat RO.
- `lib/anggaranRabUji.ts` (baru, logika murni) + `lib/__tests__/anggaranRabUji.test.ts` (17 tes).
- `app/sigap/kelola/perencanaan/page.tsx`: perubahan kecil (impor, tipe `Bagian` + daftar `BAGIAN`, pengenal `?bagian=anggaran`, render; "Kembalikan contoh awal" juga menghapus RAB).
- Memakai `lib/anggaranRab.ts` (29 tes) yang sudah ada.

## Perilaku
- Ringkasan: pagu POK, total RAB versi terpilih, sisa/kekurangan, rentang, vonis (sisa/kurang hampir pasti atau belum pasti), cek layak disetujui (cadangan 5%).
- Versi: v1 = salinan POK dan terkunci; hanya versi terakhir (mulai v2) yang bisa diubah (volume/harga/rentang); versi baru menyalin versi terakhir dan wajib beralasan >= 10 karakter; versi lama membeku.
- RPD per bulan versi terpilih vs v1 (pola bayar bawaan menurut jenis item; bulan mulai/selesai dipilih). Baris "v1" dan "Selisih" hanya tampil untuk versi > 1.
- Saran revisi lintas RO yang sudah punya RAB: `pasangkanRevisi`, jenis pergeseran, batas aman; kewenangan persetujuan sengaja tidak dikodekan.

## Tiga perbaikan 22 Okt (setelah uji di Chrome)
1. Label v1: chip "v1 = salinan POK, bukan untuk disetujui (mulai v2)" (terverifikasi di Chrome).
2. Baris RPD v1/Selisih disembunyikan saat versi terpilih = v1.
3. Deteksi RAB basi: `cocokDenganPok(rab, pokRo)` membandingkan v1 dengan POK sekarang (kunci baris dan pagu). Bila POK direset/dimuat ulang berbeda, muncul banner peringatan dan konfirmasi ulang. Terverifikasi lewat unit test saja (uji layar akan menghapus data uji).

## Insiden build 23 Okt
Build Railway gagal: `app/api/penyisiran/spj/surat-tugas/route.ts` mengekspor `supabaseAdmin`, `UKURAN_MAKS_BYTE`, `bersihkanNamaFile` (Next.js 15 hanya mengizinkan GET/POST/dst. dan opsi route). Dipindah ke `lib/spjSuratTugas.ts`; `[id]/file/route.ts` mengimpor dari sana. Pelajaran: jalankan `npm run build` lokal sebelum push, karena `tsc` tidak menangkap aturan ini.

## Belum / keputusan
- Penyimpanan ke database dan persetujuan antar akun (penyusun != penyetuju) menunggu migrasi 20261022a/b.
- Rentang per versi, cadangan 5%, pola bayar = usulan awal; perlu dikalibrasi tim.
- Kode program diambil dari bagian pertama kode RO (perlu dikonfirmasi bila ada kode program resmi).
