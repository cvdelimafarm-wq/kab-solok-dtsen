# Catatan perbaikan 23 Okt 2026 — Rapikan nomor foto, teks ganti foto, Unduh SPJ, Arsip per tanggal

Sumber: 4 screenshot HP dari user (akun "Melihat sebagai Haristón" dan KORWIL).

## 1. Tombol "Rapikan nomor foto" kembali ke halaman awal translok
- Penyebab (terbukti di Chrome pada produksi): tautan benar (`/sigap/translok/<token>?p=298&tab=hari_ini&tgl=2026-10-23&fokus=foto`), tetapi akun yang `onboarding_selesai = false` selalu dilempar ke "LANGKAH 1 DARI 5" panduan login pertama, dan efek penerap tautan menunggu `langkah === null`, sehingga tab/tgl/fokus tidak pernah dipakai.
- Perbaikan: `lib/sigapTautanKerja.ts` + `adaTautanKerja(search)`; `app/sigap/translok/[token]/page.tsx` memutuskan panduan SEKALI (ref `panduanDiputuskan`) dan tidak memunculkannya bila alamat membawa tautan dalam. Panduan tetap ada lewat "Lihat panduan lagi". Uji: `lib/__tests__/sigapTautanKerja.test.ts` (4 tes).

## 2. Teks "Foto ini akan menggantikan foto lama" ambigu
- Berlaku HANYA untuk satu nomor yang sedang dipilih dan sudah terisi (dipilih manual petugas). Nomor otomatis tidak pernah memilih nomor terisi. Foto lama tidak dihapus, menjadi cadangan, bisa dipasang kembali lewat kartu hari (SusunFoto).
- Di screenshot "Foto 1 terpilih, kuning, Berikutnya: Foto 2" itu foto yang SUDAH terkirim sebagai Foto 1; nomornya terbaca "terisi" dari server, bukan salah pilih.
- Perbaikan `app/sigap/foto/KameraSigap.tsx`: setelah terkirim, tombol nomor dinonaktifkan dan tampil "Foto ini sudah terkirim sebagai Foto N ✓"; teks ganti diganti menjadi "Foto N sudah terisi. Bila dikirim, foto ini MENGGANTIKAN Foto N saja; foto lamanya tidak dihapus, hanya menjadi cadangan"; foto yang sedang dipratinjau tidak lagi dihitung `terisiAntre`.

## 3. Unduh SPJ: semua jenis dokumen bisa dipilih
- Sebelumnya mode "Satu hari" menonaktifkan Surat Tugas, Kwitansi, Visum, Surat Pernyataan. Sekarang mencentangnya (atau "Pilih semua") otomatis memindahkan pilihan ke kelompok tanggal yang memuat hari itu, disertai pemberitahuan. Server tidak diubah.

## 4. Tab Arsip per tanggal (dibangun 23 Okt, setelah user setuju "cocok, lanjut")
- `lib/sigapArsipTanggal.ts` (logika murni) + `lib/__tests__/sigapArsipTanggal.test.ts` (13 tes): penilaian hari (hijau/kuning/merah/abu), tanggal awal, geser tanggal, kelompok Kwitansi/Visum/Surat Pernyataan per tanggal, arah sapuan jari.
- `app/sigap/translok/[token]/page.tsx`: komponen `ArsipPerTanggal` di tab Arsip (di atas ringkasan periode lama): deretan tanggal bisa digeser (usap kiri/kanan, tombol ‹ ›, ketuk), titik status, filter "Belum lengkap saja", kartu detail status 6 jenis dokumen pada tanggal itu, "⬇ Unduh tanggal ini" (LembarUnduh dengan `tanggalAwal`), dan "Lengkapi / perbaiki" yang membuka `KartuHari` (laporan + nomor foto). Aturan akses (hari kerja, 23.59 WIB, izin susulan, SPJ dikunci) tidak diubah; hari terkunci menampilkan alasan + tombol WhatsApp izin susulan yang sudah ada.
- `app/sigap/foto/FotoKegiatan.tsx`: prop `lampau` — pada hari terlewat (tanpa izin) kartu "Buka Kamera SIGAP" tidak ditawarkan, hanya panel nomor foto (SusunFoto).
- Panduan login pertama langkah 5 memakai `ArsipDokumen ringkasSaja` (tanpa kartu per tanggal).

## Status verifikasi
- Sandbox cloud: tsc terarah (page.tsx, FotoKegiatan, KameraSigap, lib baru) bersih kecuali artefak stub; vitest 4 + 13 tes baru lolos.
- Belum: `npx tsc --noEmit`, `npx vitest run` penuh, `npm run build` di repo (dijalankan user; sesi ini tidak punya shell di laptop).
- Uji manual setelah deploy: (a) "Rapikan nomor foto" dengan akun yang panduannya belum selesai; (b) tab Arsip: usap tanggal, filter "Belum lengkap saja", Unduh tanggal ini, Lengkapi pada hari izin susulan, hari terlewat tanpa izin (alasan + WhatsApp); (c) Unduh SPJ: centang Visum saat mode "Satu hari".
