# Catatan mockup Kertas Kerja Revisi POK, tahap 8 (24 Okt 2026)

Status: MOCKUP saja (artifact Design, Versi 37, papan baru Peta KRO Satker). Belum ada SQL atau kode aplikasi sampai Pak Iqbal menyatakan "setuju".

## Sumber konsolidasi
Dua PDF hasil pemeriksaan: "Pemeriksaan Mockup Kertas Kerja Revisi POK dan Neraca Kecukupan KRO" dan "Hasil Periksa Mockup Kertas Kerja Revisi POK dan Solusi Selisih KRO". Keduanya digabung ke satu model dan satu alur.

## Yang diterapkan ke mockup
1. Panel Kecukupan KRO terhadap RAB. Kebutuhan riil K = jumlah RAB item belum selesai dibagi faktor (bawaan 0,9, dapat diubah) ditambah RAB item selesai. Toleransi Cukup bawaan 5 persen. Dihitung per KRO dan per jenis belanja (dua digit pertama akun), hanya pada item yang sudah punya RAB; item tanpa RAB dilaporkan terpisah dan tidak dibandingkan.
2. Empat status: Kurang (POK < RAB), Tipis (RAB <= POK < K), Cukup (K <= POK <= K(1+r)), Lebih (POK > K(1+r)). Istilah "Cukup" pada PDF kedua dipetakan ke Tipis/Cukup di sini; ini perbedaan penamaan, bukan perbedaan aturan.
3. Geseran minimal (Mode Pagu Tetap): satu alur, dua tombol. "Terapkan RAB dalam batas pagu" membuka jendela usulan pemindahan; "Terapkan RAB penuh (Revisi DIPA)" membiarkan selisih bersih menjadi perubahan pagu (R-01 merah, jalur DJA). Donor tidak boleh turun di bawah RAB maupun Booked + Realisasi (R-06); item selesai jadi donor lebih dulu, lalu yang berlebih terbesar; item tanpa RAB bukan donor kecuali dicentang; penerima diurut prioritas Inti, Penting, Dapat ditunda, lalu kebutuhan terkecil; hanya dalam jenis belanja yang sama; donor dapat diganti dengan panah.
4. Dana penggenap otomatis dihapus (hanya manual; R-09 tetap). RAB tidak pernah ditulis ke POK.
5. Buku selisih dan jalur penutup: kebutuhan yang belum terdanai dicatat sebagai angka (bukan baris POK) dengan jalur: turunkan volume item Dapat ditunda, cari sumber di KRO lain pada Kegiatan yang sama (DJPb, tingkat 3), antar-Kegiatan (Eselon I, tingkat 4), pagu tambahan atau antar-Program (DJA, tingkat 5, tidak dijamin), atau tunda kegiatan.
6. Prioritas per item (Inti, Penting, Dapat ditunda), chip cadangan pada item yang sisanya tetap, aturan baru R-15, skenario contoh baru (Geseran minimal dari RAB; Geseran RAB naik/KRO kurang).
7. Papan baru Peta KRO Satker: 30 KRO dengan status kecukupan, putusan tingkat Satker, dan jalur yang mungkin. KRO 2903.BMA hidup; KRO lain ILUSTRASI.
8. Papan Versi, Status, Lampiran, Pemicu, Impor, Alur disesuaikan istilahnya.

## Kesesuaian dengan tujuan (Draf 4)
- RAB hanya acuan, tidak pernah menimpa POK: sesuai.
- Satker sebagai pengguna layanan: Satker tidak diminta mengisi rumus; sistem menyarankan, keputusan tetap di tim: sesuai.
- PMK Pasal 173 (batas kewenangan): revisi POK tidak melintasi jenis belanja; kekurangan lintas KRO atau Kegiatan diarahkan ke jalur Revisi DIPA: sesuai.

## Akibat bagi skema (jika disetujui)
- Trigger keu_rab_cek_setuju mengeluarkan status kecukupan dengan parameter faktor (0,9) dan toleransi (5 persen).
- Kolom prioritas per item; volume RO untuk R-02 dan R-04.
- View kecukupan per KRO x jenis belanja; tabel buku selisih; peta KRO Satker; R-15.

## Pertanyaan konfirmasi untuk Pak Iqbal
1. K = RAB dibagi 0,9 sudah sesuai kebiasaan?
2. Sisa dana boleh tetap di item asal tanpa baris Dana penggenap?
3. Urutan sumber donor dan prioritas sesuai kebiasaan Satker?
Juga masih terbuka: Q-26, dasar hukum R-09, perlakuan item selesai saat akun dikosongkan, pertanyaan Kanwil dan APIP.

## Pengujian
Model (t20), interaksi Main (t21), semua papan (t22) lulus di node; render Chromium lokal semua 8 papan tanpa galat dan tanpa placeholder mentah. Bug jendela geseran yang selalu tampil sudah diperbaiki (markup berada di luar elemen utama). tsc, build, commit, deploy: oleh Pak Iqbal.
