# Alamat pengelolaan /sigap/kelola/<modul> (9 Okt 2026)

Permintaan user: halaman kelola memakai pola /sigap/kelola/<modul> (pelatihan, anggaran/translok, delego, pedia, dll). Keputusan: pemetaan usulan, alamat lama dialihkan otomatis, /sigap/kelola langsung membuka modul pertama yang diizinkan.

| Alamat baru | Halaman (berkas tetap di lokasi lama) |
|---|---|
| /sigap/kelola/pelatihan | app/sigap/pelatihan/kelola |
| /sigap/kelola/translok | app/sigap/admin |
| /sigap/kelola/pedia (+ /:id) | app/sigap/pedia/kelola |
| /sigap/kelola/pengadaan (+ /:id) | app/sigap/kontrak |
| /sigap/kelola/akses | app/sigap/akses |
| /sigap/kelola/aplikasi | app/portal/admin |
| /sigap/kelola/delego | app/sigap/kelola/delego (baru; meneruskan ke portal_aplikasi.href kode delego, kini masih kosong) |
| /sigap/kelola | app/sigap/kelola/page.tsx (baru; urutan: pelatihan, translok, pengadaan, pedia, akses, aplikasi, lalu "/") |

- Mekanisme: next.config.js PETA_KELOLA -> rewrites (alamat baru -> berkas lama) + redirects 307 (alamat lama -> baru, query ikut). Diuji di aplikasi Next 15.5 mini: tidak berputar, usePathname = alamat baru.
- Semua tautan internal diganti ke alamat baru. Sidebar admin (Shell.tsx) menambah "Aplikasi & periode" dan "Delego" di grup Administrasi.
- lib/sigapNavigasi.ts: /sigap/kelola/<m>/<detail> -> induk /sigap/kelola/<m>; /sigap/kelola/* -> "/".
- portal_aplikasi.href translok (/sigap/admin) & kontrak (/sigap/kontrak) belum diubah di DB; tetap jalan lewat pengalihan.
- Bila nanti berkas dipindah fisik ke app/sigap/kelola/..., hapus entri PETA_KELOLA yang bersangkutan.

## Halaman awal = daftar kegiatan per kegiatan induk (10 Okt 2026)
Permintaan user: "pada kelola pelatihan ... tampilkan dulu list pelatihan berdasarkan kegiatan; demikian juga translok dan proses bisnis yang lain".
- Komponen bersama `app/sigap/kelola/DaftarKegiatan.tsx` + API `/api/sigap/kelola/daftar?modul=...` + konfigurasi `lib/sigapKelolaModul.ts` (MODUL_KELOLA: pelatihan, translok; uji `lib/__tests__/sigapKelolaModul.test.ts`). Kelompok dari `sigap_induk.kegiatan_ids`; sisanya "Kegiatan/Pelatihan lainnya". Kartu: status (berlangsung/akan datang/selesai/nonaktif), tanggal, jumlah peserta/petugas (penugasan aktif), "Lihat saja", "Belum tersambung".
- Kelola Pelatihan: tanpa ?kegiatan/?tab -> daftar; pilih -> tab-tab (?kegiatan=ID); tombol "← Daftar pelatihan". Modul pelatihan baru melayani SATU pelatihan (KODE_KEGIATAN_PELATIHAN); pelatihan lain tampil "Belum tersambung".
- Admin Transport Lokal: tanpa ?kegiatan/?tab -> daftar (+ tombol "Ringkasan & perlu tindakan" = tab Beranda lama, "＋ Kegiatan baru"); pilih -> tab Monitoring kegiatan itu; tombol "← Daftar kegiatan".
- Proses bisnis berikutnya: tambah entri di MODUL_KELOLA lalu pasang <DaftarKegiatan modul="...">.
- API lama `/api/sigap/pelatihan/daftar` tidak dipakai lagi (boleh `git rm app/api/sigap/pelatihan/daftar/route.ts`).
