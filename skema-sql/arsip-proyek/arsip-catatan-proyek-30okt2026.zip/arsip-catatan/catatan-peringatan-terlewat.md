# Catatan: Peringatan "kegiatan pelatihan terlewat" + status notifikasi push (8 Okt 2026)

## Permintaan user
Setelah Posttest ditutup 21.00 WIB dan Riva Hestaria (akun id 563) belum mengerjakannya: "buat warning, kegiatan terlewat hari ini sehingga kegiatan pelatihan tidak lengkap".

## Yang dibangun
- Kotak merah "Ada kegiatan pelatihan yang terlewat" di halaman Langkah Pelatihan (/sigap/pelatihan). Isi: kegiatan yang waktunya sudah ditutup dan belum dikerjakan (Pretest, Posttest, Adu Sigap, Presensi per sesi).
- Logika murni `lib/sigapTerlewat.ts` (`daftarTerlewat`).

## Notifikasi push
Sudah dibangun (lihat catatan-notifikasi-push-desain-sigap.md); perlu kunci VAPID di Railway dan tiap peserta menekan Aktifkan sekali.

## Pengingat ke mitra yang melewatkan tahapan (9 Okt 2026)
Hasil hitung data pelatihan 8 Okt (94 peserta; 85 presensi; pretest 89; posttest 87; foto 5 slot 84-89): 8 mitra + 10 organik punya tahapan terlewat.
Mitra: presensi belum tercatat = Jahar Nas, Puji Putri, Robi Alvian (kelas 1), Biki Wabihamdika, Febri Handayani (kelas 2); posttest belum = Rahmad Hidayat (kelas 1); foto 5 (Tiba di rumah) belum = Rivo Nofri Armon (kelas 3), Gusna Wirda (kelas 4).
Organik: Adriyanto, Kafsal, Lucia Veronica, Dina Marizka, Muzahar, Riva Hestaria, Adrianus, Ilham, Riko Putra Roma, Deswaty (rincian di tabel hasil query; belum dibuatkan pesan).
Pesan WhatsApp disiapkan per mitra (tombol buka WhatsApp Web, user yang menekan Kirim); BELUM dikirim.

## Kesempatan melengkapi dibuka sampai Jumat 9 Okt 2026 22.00 WIB (atas permintaan user)
- Pretest & Posttest: sigap_tes.tutup_at diundur ke 9 Okt 22.00 WIB (Posttest ulang_maks = 2).
- Foto Transport Lokal 8 Okt: izin susulan (sigap_izin_susulan) untuk 10 penugasan yang fotonya kurang, berlaku sampai 22.00 WIB.
- Presensi susulan (kode baru, perlu commit + push + deploy): sesi yang sudah ditutup boleh disusul dari MANA SAJA (tanpa cek radius/GPS), dicatat terlambat=true dan peserta diberi tahu "TERLAMBAT". Kolom baru: sigap_pelatihan_presensi.terlambat, sigap_pelatihan_pengaturan.presensi_susulan_sampai (diset 9 Okt 22.00 WIB); migrasi 20261009a_sigap_presensi_susulan.sql sudah diterapkan. Berkas: lib/sigapPresensi.ts (susulanTerbuka, keadaanHari(..., susulanSampai).susulan), lib/sigapTesDb.ts, app/api/sigap/pelatihan/presensi/route.ts, app/sigap/pelatihan/page.tsx (tombol "Catat presensi terlambat sekarang"), admin/kehadiran route + kelola/kehadiran.tsx (chip "terlambat").
- Catatan: Posttest/pretest yang diundur menyembunyikan lagi skor & pembahasan sampai tutup baru.
