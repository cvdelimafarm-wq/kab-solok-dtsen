# Status tahap 28 — Lembar kebijakan manajemen tim (25 Okt 2026)

Dasar: Skema Lengkap V1 bagian 5–7 (lembar kebijakan, templat susunan tim, kebijakan anggaran). Data fiktif 2026. Angka di Excel hanya predefined dan belum sah.

## Keputusan pengguna (25 Okt 2026)
- Pengesah paralel: SEMUA akun Ketua Tim aktif + PPK + KPA. Daftar pengesah dibekukan saat lembar diajukan.
- Lembar baru berlaku bila semua pengesah setuju (tidak ada jalan pintas KPA).
- Urutan kerja: tahap 28 (lembar kebijakan) dahulu, lalu tahap 29 (identifikasi lanjutan dan dokumen).

## Yang dibangun
- SQL `20261025zd_keu_kebijakan_tim.sql` (aman diulang, tanpa DELETE/DROP): kewenangan `kebijakan_susun` (PPK, RENC, ADMIN) dan `kebijakan_setuju`; tabel `keu_kebijakan_lembar`, `keu_kebijakan_pengesah`, `keu_kebijakan_riwayat`; pemeriksa isi `keu_kebijakan_periksa`; fungsi `keu_kebijakan_buat/simpan/aksi/hak/lengkap`; tampilan `keu_v_kebijakan`, `keu_v_kebijakan_berlaku` (pintu tunggal modul hilir), `keu_v_kebijakan_pengesah`, `keu_v_kebijakan_riwayat`; didaftarkan ke gerbang `keu_jalankan`.
- Cek kesehatan `20261025ze_cek_kesehatan_keu_kebijakan.sql` (semua baris p0 harus 0) dan uji `50_uji_kebijakan.sql` (rollback di akhir; berisi 27 kasus pemeriksa yang sama dengan tes TypeScript).
- Kode: `lib/keu/kebijakan.ts` (angka predefined, pemeriksa isi, keterangan otomatis, tujuan tautan, aksi tersedia), tes `kebijakan.test.ts` + vektor bersama `kebijakan.vektor.json`, layar `/sigap/kelola/perencanaan/kebijakan` (page, Susunan, Anggaran, Pengesahan, useKebijakan), daftar putih baca `tampilan.ts`, `gerbang.ts` (keu_kebijakan_hak sebagai fungsi baca), `baca.test.ts` (pengecualian kelima: riwayat kebijakan), tautan dari halaman Identifikasi survei.

## Alur
Draf (angka predefined, belum sah) → isi hasil rapat (tanggal, nomor notulen/SK, tujuan mutu) → Menunggu pengesahan (pengesah dibekukan) → Berlaku (terkunci; versi lama otomatis Arsip) → revisi = versi baru dari lembar berlaku. Pengesah boleh mengembalikan dengan catatan (persetujuan direset); pengaju dapat menarik selama belum ada yang setuju. Satu akun yang memegang beberapa peran cukup menyetujui sekali (semua perannya tercatat). Draf dapat dibatalkan; nomor versi tidak dipakai ulang.

## Isi lembar (jsonb utuh per versi)
Strata S1–S9 (rentang petugas menyambung otomatis, maks jabatan/orang, batas % petugas baru, sasaran pengembangan), jumlah minimal 10 jabatan per strata (tabel V1 6.1), matriks rangkap (V1 6.2), kompetensi (nilai pelatihan/seleksi minimal 70, ambang ketat 20, validasi desktop), dan 21 parameter anggaran (aturan, kebijakan ≤ aturan; jenis angka, persen, rujukan, dokumen, ya/tidak).

## Penyimpangan dari rancangan V1 (perlu diketahui)
1. Isi lembar disimpan sebagai satu jsonb per versi, bukan tabel terpisah `keu_tim_*`/`keu_kebijakan_param`. Alasan: tiap versi utuh dan tidak dapat berubah, perbandingan antarversi mudah, paritas TS–SQL cukup satu pemeriksa. Pemakai hilir membaca lewat `keu_v_kebijakan_berlaku`.
2. Tidak dibangun di tahap ini: `keu_pengecualian`, `keu_notifikasi`, `keu_gap` (menunggu pembaca hilir, tahap 30–32) dan `keu_kebijakan_rujukan` + barisnya (menunggu berkas SBM penginapan, paket fullday/fullboard, matriks SK transport). Parameter rujukan tampil "tabel rujukan belum diunggah".
3. Tidak ada butir menu baru; layar dibuka dari tautan pada halaman Identifikasi survei (menu tetap, tes menu tidak berubah).

## Hasil cek data (read-only, 25 Okt 2026)
Akun 521811, 524114, 524119, 521211, 522151, 521213 ada di master akun; peran PBJ ada; semua penugasan peran (termasuk 35 RO Ketua/AdminRO/PBJ) dipegang satu akun fiktif (354), sehingga uji produksi cukup satu persetujuan.

## Butir yang belum diputuskan (tidak menghalangi tahap 28)
- Rangkap `innas` pada S4 ke atas: mengikuti V1 secara harfiah (tidak boleh dirangkap; S1–S3 "semua jabatan").
- Dasar aturan (pasal) uang harian/translok dan arti singkatan SPKL: diisi PPK pada kolom "Dasar aturan" (peringatan, bukan galat).
- Honor instruktur internal vs eksternal (522151 vs 521213-C): tahap 29/31.
- Berkas SBM penginapan, paket fullday/fullboard, matriks SK transport: diunggah pengguna untuk tahap berikutnya.

## Verifikasi
- Lokal (Postgres 16 dengan stub skema keu): zd dijalankan dua kali (idempotent) lalu `50_uji_kebijakan` LULUS; cek kesehatan semua p0 = 0.
- vitest: kebijakan 51, identifikasi 56, baca 13 lulus; tsc bersih (di luar galat lama lib/sigap.ts, lib/keu/rab.ts pada salinan kerja); render server semua komponen tanpa galat.
- Produksi: BELUM (menunggu SQL dijalankan di Supabase, lalu commit/push/deploy oleh pengguna).

## Langkah deploy
1. Supabase SQL Editor: jalankan `Pengisiran\SQL\Tahap28\1_20261025zd_keu_kebijakan_tim.sql`, lalu `2_..ze..` (semua baris p0 harus 0).
2. Laptop: `npm test; npx tsc --noEmit; git add .; git commit; git push`, tunggu Railway selesai, ketik "sudah deploy".
3. Claude menguji produksi (akun IH, data fiktif): buka layar, buat lembar predefined, simpan, ajukan, tarik, batalkan; lalu menutup tab.
