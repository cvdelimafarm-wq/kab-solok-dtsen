# Catatan 24 Okt 2026: persiapan rotasi kunci Supabase (fase 1)

## Hasil pemeriksaan kode (repo 13 Usul DTSEN)
- Kode web tidak membaca isi kunci sebagai JWT dan tidak memakainya sebagai Bearer; semua route memakai createClient(url, kunci) dari supabase-js (lewat lib/supabaseServer.ts). Secret key baru `sb_secret_...` aman dipakai pada SUPABASE_SERVICE_ROLE_KEY tanpa ubah kode web.
- lib/sigapAkses.ts memakai SUPABASE_SERVICE_ROLE_KEY sebagai bahan tanda tangan HMAC sesi SIGAP. Mengganti kunci otomatis membuat semua sesi lama tidak sah (semua pengguna masuk ulang; PIN tidak berubah). Ini juga menutup kemungkinan pemalsuan sesi bila kunci lama bocor. Saran jangka menengah: pisahkan rahasia sesi dari kunci database (variabel baru) agar rotasi kunci DB tidak ikut memaksa masuk ulang.
- Dua skrip laptop perlu penyesuaian dan SUDAH diubah 24 Okt (perlu commit): scripts/upload-peta.mjs (dulu menolak kunci yang bukan 3 bagian JWT; sekarang menerima sb_secret_) dan scripts/hitung-jarak-rute.mjs (tidak lagi mengirim Authorization: Bearer bila kunci diawali sb_).
- Edge Functions (submit-usulan, jorong-info, bulk-create-operators, setup-pin): tidak dipanggil dari kode web. `bulk-create-operators` publik (verify_jwt=false) dan memuat rahasia admin tertanam; ia sekali-pakai dan sebaiknya DIHAPUS lewat dashboard Supabase (alat MCP tidak punya fungsi hapus). Rahasia itu tidak dicatat di sini.
- .env.example sudah memuat kunci publishable (sb_publishable_), jadi aplikasi web kemungkinan sudah tidak memakai anon key legacy. Nilai NEXT_PUBLIC_SUPABASE_ANON_KEY di Railway perlu dicek diawali sb_publishable_.

## Urutan fase 1 (belum dijalankan oleh user saat catatan ini ditulis)
1. Supabase > Project Settings > API Keys: buat secret key baru.
2. Railway: ganti SUPABASE_SERVICE_ROLE_KEY (opsional sekalian PENYISIRAN_PIN, PENYISIRAN_IDENTIFIKASI_PIN, SIGAP_KODE_BROWSER), deploy.
3. Verifikasi log Supabase (tidak ada 401/403 baru; permintaan baru memakai secret key).
4. Ganti kunci di .env.local laptop.
5. Hapus Edge Function bulk-create-operators.

## Fase 2 (setelah stabil 1-2 hari)
Nonaktifkan kunci legacy setelah memastikan tidak ada klien lain yang memakai anon key legacy (aplikasi Android PORTAL BPS, Apps Script SFM, Delego). Variabel Railway tidak memuat kunci AI/cloud, jadi sasaran utama penyerang tidak ada di workspace ini.
