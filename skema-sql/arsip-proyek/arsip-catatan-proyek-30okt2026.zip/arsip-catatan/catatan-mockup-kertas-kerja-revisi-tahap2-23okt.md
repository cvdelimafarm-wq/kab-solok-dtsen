# Catatan: mockup Kertas Kerja Revisi POK, tahap 2 (ganti akun, jadwal pencairan per bulan), 23 Okt 2026

Status: HANYA MOCKUP, lanjutan dari catatan-mockup-kertas-kerja-revisi-23okt.md. Tidak ada SQL, migrasi, atau kode aplikasi yang dijalankan atau ditulis. Menunggu "setuju" pengguna sebelum dibangun. Kanvas: https://claude.ai/artifact/6uugHF9thUYQC1JKAii7Ap (Versi 17).

## Tambahan sejak catatan pertama (semua di tab RAB dan Kertas kerja)
- Periode pencairan menggantikan "Sebar": Sekali, Bulanan (mis. M3 berarti dicairkan di minggu ke-3 tiap bulan), Triwulanan; ada bulan mulai dan sampai.
- Item/kegiatan/RO "selesai": anggaran dikosongkan sampai Booked + Realisasi; sisa menjadi dana bebas (menutup kenaikan item lain dulu, sisanya menurunkan pagu dan menaikkan jenis revisi ke DJA).
- Kolom Realisasi dan Sisa di kertas kerja, tab RAB, dan matriks. Satuan berupa dropdown yang dapat diganti (atau ketik sendiri). Salin, Duplikat, Tempel baris rincian, dan geser urutan dengan titik enam (seret) atau tombol naik/turun.

## Ganti akun (skema pasangan, usul pengguna)
- Mengganti akun item TIDAK mengubah kode akun pada baris semula. Baris di akun lama dikosongkan; baris baru dengan isi sama dibuat di akun baru dengan Semula kosong. Matriks menaruh keduanya berdampingan sebagai satu pasangan, pemicu P-03 (P-08 bila volume, harga, atau redaksi ikut berubah).
- Bila item sudah punya Booked/Realisasi: yang dipindah hanya sisanya; akun lama tetap menampung sebesar Booked + Realisasi (dibulatkan ke atas ke volume). Bila seluruh pagu item sudah terpakai, item tidak dapat dipindah.
- Baris akun lama dikunci (volume, harga, uraian) selama berpasangan; tombol "Batalkan pindah" mengembalikan keadaan semula. Mengganti tujuan lagi cukup lewat kolom ganti akun pada baris pindahan.
- Dampak pemeriksaan: R-03 (lintas jenis belanja) dihitung dari pasangan; T-04 menaikkan saran ke DJPb; R-06 tetap berlaku; impor hasil penetapan mencatat baris lama "dikosongkan: dipindah ke akun X" dan baris baru "pindahan dari akun Y" (kunci_stabil baru).
- Di tab RAB, item tetap satu baris dengan akun tujuan (akunM); pasangan baru terbentuk saat Terapkan RAB ke Menjadi.
- Konsekuensi skema (belum dibuat): baris perlu penanda pasangan (pindah_dari / pindah_ke) dan jumlah tersimpan (bukan hanya volume x harga) agar pecahan pindah tidak selisih pembulatan.

## Rencana pencairan per bulan dengan tag minggu
- Jadwal tiap baris rincian disusun per bulan (12 bulan): nilai Rp dan tag minggu M1 sampai M4 (M1 tgl 1-7, M2 8-14, M3 15-21, M4 22 sampai akhir bulan). Dibangkitkan otomatis dari periode; tiap bulan dapat diubah tangan (status Manual, tombol Ratakan ulang). Penanda ≠ bila jumlah jadwal tidak sama dengan jumlah rincian.
- Usulan tag bawaan menurut akun (ILUSTRASI, dapat diubah): honor dan jasa profesi M4; perjalanan dinas dan transport lokal M4; paket meeting M3; bahan dan persediaan M2; belanja modal M3; lainnya M3.
- Dua format tampilan, dipilih pengguna: "Ke samping" (kolom Jan sampai Des, baris M1 sampai M4) dan "Lipat per bulan" (baris nama bulan yang dapat dibuka: rincian minggu dan baris rincian yang dicairkan). Pilihan format berlaku juga untuk editor jadwal per baris rincian.
- Konsekuensi skema (belum dibuat): tabel jadwal pencairan per baris rincian (bulan, nilai, minggu); RPD dapat diturunkan dari sini.

## Perbaikan templat
- Tag penutup `sc-if` pada tab RAB hilang sejak versi sebelumnya sehingga tab Matriks bisa ikut tersembunyi; sudah diperbaiki di Versi 13. Render di browser BELUM diperiksa (tidak diminta); logika diuji lewat skrip node.

## Belum / menunggu
- Persetujuan mockup, Q-26 (RO Khusus, blokir, Belanja Operasional), dasar hukum R-09 Dana penggenap.
- Kalimat pengguna tentang item selesai terpotong ("... dikosongkan ("); asumsi yang dipakai: kelebihan anggaran dikosongkan sampai Booked + Realisasi.
