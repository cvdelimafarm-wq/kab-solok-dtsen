# Status Tahap 27a: penyesuaian identifikasi awal (25 Okt 2026)

Penyesuaian kode identifikasi awal sebelum/awal deploy tahap 27, sesuai keputusan konfirmasi V1. Data fiktif 2026.

## Yang berubah
1. **Persetujuan paralel**: PPK dan Tata Usaha boleh lebih dulu mana pun; KPA menyetujui terakhir. Status DB `sah` tidak diubah. Kolom `keu_ident.ok_ppk`, `ok_tu`, `pasca_h15`; `langkah` = jumlah persetujuan (0..2 selagi menunggu, 3 saat sah). Fungsi SQL `keu_ident_giliran`, `keu_ident_mulai_awal`.
2. **Istilah versi**: versi 1 = "Identifikasi awal"; versi >= 2 = "Terupdate vN". Modul hilir membaca versi terakhir; versi awal menjadi bahan evaluasi.
3. **Aturan H-15**: H-15 = mulai pendataan paling awal dikurangi 15 hari. Ambang 7 hari dihapus. `keu_ident_h15` kini hanya MENEGASKAN tanggal (geser <> 0 ditolak, kode 23514); pergeseran lewat revisi. Revisi dikirim sesudah H-15 -> hanya KPA yang menyetujui (`pasca_h15`), dicatat untuk evaluasi. Identifikasi awal yang disahkan sesudah H-15 tetap lewat PPK/TU/KPA, ditandai "terlambat" di riwayat.
4. **Translok** ditanya di semua peran.
5. **`kebutuhan()` sesuai matriks**: rilis & spanduk dihapus; cetak buku -> 521811; hotel paket 524114 (dalam kota) / 524119 (luar kota); 521211 hanya non-hotel; konsumsi/paket sesi luring/hybrid dan pulsa peserta hanya bila ada mitra; rapat persiapan konsumsi hanya bila `rapat.persiapan.mitra`; perlengkapan hanya pelatihan; tempat sesi wajib.

## Berkas
- Repo: `lib/keu/identifikasi.ts`, `identifikasiHilir.ts`, `tampilan.ts`, `__tests__/identifikasi.test.ts`, `__tests__/baca.test.ts` (daftarkan pengecualian `keu_v_ident_riwayat`); `app/sigap/kelola/perencanaan/identifikasi/{Formulir,Panel,page,useIdent}.tsx` dan `[id]/page.tsx`.
- SQL (Project `skema-sql/fase-b`; salinan laptop `Pengisiran\SQL\Tahap27\1_za`, `2_zc`, `3_zb`): `20261025za_keu_identifikasi.sql`, `20261025zc_keu_identifikasi_paralel.sql`, `20261025zb_cek_kesehatan_keu_ident.sql`, `49_uji_identifikasi.sql` (uji lokal).

## Hasil uji
- Lokal: vitest seluruh repo 1.383 tes (1 gagal di `baca.test.ts` karena pengecualian riwayat belum didaftarkan; sudah diperbaiki, jalankan ulang untuk memastikan). SQL 49 "LULUS 49".
- SQL za, zc, zb dijalankan manual oleh pengguna di SQL Editor Supabase (apply_migration lewat MCP tertahan konfirmasi); zb semua p0 = 0. Pemeriksaan sesudahnya: kolom zc 3, fungsi 7, view 5, gerbang `keu_jalankan` memuat fungsi ident, kewenangan 2.
- Produksi (akun IH, data fiktif "UJI Fiktif Survei Harga 27a", RO 2903.BMA.009, id 1): halaman daftar tampil dengan teks paralel/H-15; formulir tanpa rilis/spanduk, translok di semua peran, tempat dan mitra sesuai; kirim -> "Menunggu PPK dan Tata Usaha"; PPK setuju -> "Menunggu Tata Usaha" -> "Menunggu KPA" -> "Identifikasi awal" (sah v1, riwayat "terlambat" karena H-15 sudah lewat); penegasan tanggal H-15 berhasil; ajukan revisi + tambah briefing -> dikirim sesudah H-15 -> "Menunggu KPA (sesudah H-15)", PPK dan TU "Tidak diperlukan" -> KPA setuju -> "Terupdate v2". Tanpa galat konsol. Jejak DB sesuai (2 versi tersimpan).
- Catatan: baris uji fiktif id 1 tertinggal (hapus permanen memang tidak diizinkan oleh gerbang).

## Catatan / asumsi untuk dikonfirmasi
- Geser tanggal H-15 hanya lewat revisi (bukan tombol geser).
- Hotel/konsumsi hanya muncul bila ada mitra.
- Akun 521811, 524114, 524119 perlu dicek di master akun/katalog.
- Notifikasi (T28) belum dibangun.
- Blok uji "jendela depan" di 49 kedaluwarsa dan dilewati mulai 16 Nov 2026.
- Pada uji, satu akun (IH) memegang peran PPK, TU, dan KPA sekaligus sehingga tiap langkah diklik bergantian; uji dengan akun terpisah belum dilakukan.

## Belum dibangun
Lembar kebijakan manajemen tim, identifikasi lanjutan + dokumen, pembaca hilir + notifikasi, Delego/laporan harian/evaluasi/Bendahara, peringatan pelaksanaan + laporan Gap; mockup Version 7 belum diperbarui.
