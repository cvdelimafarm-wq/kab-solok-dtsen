# Catatan: Siaran ke petugas pendataan (13 Okt 2026)

Permintaan user: kirim notifikasi push ke seluruh petugas pendataan (teks dirapikan, lebih santai dan ringkas) dan munculkan modal yang cukup SATU kali konfirmasi lalu hilang.

## Teks siap pakai (INFO 1)
- Judul push: "Info 1: Data FASIH keluarga belum ada"
- Isi push (163 karakter): "Bapak/Ibu PPL, data FASIH pendataan keluarga belum ada ya. Tetap siaga, nanti kami kabari kalau sudah siap. Awali dulu 1 tim keroyokan di 1 Sub SLS yang ringan-ringan."
- Modal "INFO 1": data FASIH khusus pendataan keluarga belum ada; tetap siaga; begitu siap bisa langsung gas; awal mulai 1 tim keroyokan di 1 Sub SLS yang ringan (terdampaknya sedikit).
- Teks ini sudah terisi di formulir admin.

## Cara kerja
- Admin: Kelola > Pendataan (`/sigap/kelola/pendataan`), kartu "Siaran ke petugas pendataan". Centang Kirim notifikasi dan/atau Tampilkan modal, pratinjau modal, tombol "Kirim siaran…" lalu "Ya, kirim" (dua langkah). Izin: `bencana.admin` level kelola (admin_aplikasi, admin_bencana, pengelola_psp). Sesi "masuk sebagai" ditolak. Siaran dengan judul sama dalam 10 menit ditolak (cegah klik ganda).
- **Penerima = petugas yang ditugaskan di kegiatan Pendataan Pascabencana**: `sigap_penugasan` aktif (kegiatan `pascabencana_2026`, peran korwil/ppl/pml, bukan peserta tambahan administrasi) dengan akun aktif. Saat dibuat 85 petugas = 1 korwil + 18 PML + 66 PPL; 83 di antaranya sudah mengaktifkan notifikasi (sisanya hanya melihat modal). KOREKSI 13 Okt: versi pertama salah memakai seluruh tabel `bencana_petugas` (260 orang, termasuk ratusan mitra terdaftar yang tidak bertugas); user mengoreksi "seharusnya sekitar 90-an".
- Modal disimpan di `sigap_pengumuman` (kegiatan `pascabencana_2026`, frekuensi sekali, otomatis berakhir 14 hari). Tampil di halaman tahap yang memuat modul identifikasi/pendataan (`PengumumanPetugas.tsx`), memakai `ModalPengumuman` milik pelatihan. Konfirmasi dicatat PER AKUN di `sigap_audit` (aksi `siaran_pendataan_baca`), jadi tidak muncul lagi walau ganti HP; cadangan di localStorage. Klik di luar modal atau Esc juga dihitung konfirmasi (perilaku sama dengan modal pelatihan).
- Riwayat siaran di kartu admin: judul, waktu, pengirim, jumlah perangkat, dan berapa petugas yang sudah menekan "Saya mengerti" (dari `sigap_audit` aksi `siaran_pendataan`). Push dicatat juga di `sigap_push_log` (jenis `siaran_pendataan`).
- API: `/api/portal/siaran-petugas` (GET modal untuk pemanggil; GET ?ringkas=1 admin; POST baca / siarkan). Berkas: `lib/siaranPetugas.ts` (validasi murni, 6 uji), `lib/portal/siaranPetugas.ts`, `app/api/portal/siaran-petugas/route.ts`, `PengumumanPetugas.tsx`, `kelola/pendataan/Siaran.tsx`. Tanpa migrasi database.

## Status
- Ditulis ke laptop, tsc bersih, uji lulus. BELUM di-commit git/push/deploy, jadi BELUM terkirim: pengiriman push hanya bisa dari server yang sudah ter-deploy (kunci VAPID ada di Railway). Setelah deploy: buka Kelola > Pendataan, cek teks dan jumlah penerima (harus sekitar 85), kirim.
- Belum diuji di HP. Notifikasi hanya sampai ke petugas yang sudah mengaktifkan notifikasi (iPhone: harus Add to Home Screen).
- Modal hanya tampil di halaman tahap Pendataan/Identifikasi, belum di Beranda portal.
