# SPDT NTP 2026 — Fase 1: Lembar Pendataan (16 Okt 2026)

Status: kode ditulis ke laptop (belum di-commit/push oleh Pak Iqbal); SQL belum dijalankan. Fase 2 (Translok & Kelola Translok) dan Fase 3 (pengingat/push + "Salin sebagai gambar") menunggu "setuju".

## Keputusan pemilik
- Periode pendataan 12 Okt – 12 Nov 2026; hari translok boleh dipilih di masa depan selama periode; maks 3 hari (sementara).
- Pengingat 18/19/20 (maks 3x, modal + push) dikirim ke supervisor DAN petugas yang punya hari translok hari itu bila belum lengkap.
- Sherli Handayani diaktifkan kembali (akun 601, penugasan 137).
- Supervisor: Mailani Putri (akun 357), Arini Alva Syaadah (73), Faisal Siddiq (200); peran `supervisor_spdt_ntp`, menu `spdt.supervisor`, lingkup kegiatan 2. Penugasan PPL lama Mailani/Faisal (155/156, punya ST) TIDAK diubah; peran supervisor didahulukan di kode.
- Diasumsikan dari jawaban "setuju": peran supervisor juga ada di daftar peran admin; PML punya tab Monitoring (timnya saja); "Salin sebagai gambar" juga di Monitoring (dikerjakan bersama Fase 2/3 karena butuh data translok).

## Berkas SQL (dijalankan pemilik, berurutan)
1. `supabase/migrations/20261016a_spdt_ntp_lembar_pendataan.sql` — tabel `sigap_spdt_kk`, `sigap_spdt_buka`; menu+peran supervisor; induk `spdt_ntp` (kegiatan 2) dengan tahap `lembar_pendataan` {spdt_lembar} dan `translok` {translok:2}; aktifkan Sherli.
2. `supabase/migrations/20261016b_spdt_ntp_kk_seed.sql` — 811 KK dari Excel `SPDT_NTP_Maps_DSRT.xlsx` (sheet Maps). Berhenti bila tabel sudah berisi; diperiksa 811 baris, semua punya akun PPL/PML dan koordinat.
Pemetaan PML Excel→akun: YESSI ADRIANI→727, APRILLA INSAN SUCI→64, RAHMI FEBRINA SARI→513, MEGA NANA→368. Dana Nokeladio ada di dua PML (94 dan 370): PML disimpan per baris KK.

## Kode
- `lib/spdtNtp.ts` (murni + uji `lib/__tests__/spdtNtp.test.ts`), `lib/portal/spdt.ts` (server).
- API: `/api/portal/spdt-kk` (GET daftar KK menurut peran; POST catat koordinat dibuka), `/api/portal/spdt-monitoring` (supervisor & PML).
- Halaman `/sigap/spdt` (tab Monitoring/Peta/Daftar KK; PPL hanya Peta & Daftar KK) di `app/sigap/spdt/`.
- Diubah: `lib/sigapTahap.ts` (modul `spdt_lembar`, `Induk.spdt`), `lib/portal/induk.ts` (supervisor tanpa penugasan tetap melihat induk; induk SPDT tidak muncul bagi petugas bencana), `app/portal/siapkan.ts`, `app/portal/dataBersama.ts`.
- Akses: PPL = KK dengan ppl_akun_id dirinya; PML = pml_akun_id dirinya; Supervisor = semua. Mode "masuk sebagai" tidak mencatat.
- Monitoring Fase 1: login hari ini (dari `sigap_log_sesi`), jumlah koordinat dibuka hari ini (dari `sigap_spdt_buka`). Kolom translok per hari menyusul Fase 2.
- 72 titik berakurasi > 50 m diberi tanda "GPS kurang akurat".

## Uji
287 uji lulus (22 berkas), `tsc` bersih pada berkas baru/diubah. Tampilan belum diuji di peramban/HP.

## Rencana Fase 2 (menunggu setuju)
Translok SPDT NTP: pilih hari translok (maks 3, dalam periode), laporan manual (jumlah KK, perkiraan durasi, kendala/solusi) + 5 foto (batas 23.59), wajib hanya di hari translok; Kelola Translok (maks hari PPL/PML/Supervisor, bisa lewat `sigap_penugasan.maks_hari`); supervisor perlu penugasan `supervisor` agar punya Lembar Translok sendiri; tarif supervisor belum ada di `sigap_kegiatan_tarif` (perlu keputusan).
