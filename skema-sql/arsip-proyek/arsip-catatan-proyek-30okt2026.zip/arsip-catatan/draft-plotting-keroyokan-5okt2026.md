# Draft plotting petugas sistem keroyokan (5 Okt 2026)

Status: DRAFT usulan, belum ditulis ke database. File: Draft_Plotting_Keroyokan_Bencana.xlsx (11 sheet, diawali Ringkasan & Konfirmasi).

## Aturan dari user
- 1 PML membawahi 3-6 PPL (upayakan 4); keragaman PPL antar tim mirip; asal rumah anggota tim berdekatan.
- Daerah kekurangan petugas (mis. Junjung Sirih) dibantu 1-2 tim yang bergerombol (bukan 1-2 orang sendirian).
- Jarak <5 km dianggap aman; upayakan <10 km.
- Tim tamu dipandu akamsi dari tim lain; beban pemandu 1 poin per 30 menit; nama & jobdesk ditandai.
- Ambang beban per PPL tetap 160.
- Konfirmasi dulu bila aturan tidak bisa dipenuhi; hindari kasus "olok-olok".

## Hasil model
- 20 tim (13 tim berukuran 4; ukuran 3-6), 228 Sub SLS dipecah 278 porsi, beban akhir PPL 185-258 (rata-rata ±221).
- Jarak: 34% skor <5 km, 34% 5-10 km, 22% 10-15 km, 9% >=15 km.
- Tidak terpenuhi: kapasitas (butuh ±112 PPL untuk ambang 160, ada 83), batas 10 km, PML 2 tim selatan tinggal 28 dan 55 km, 18 blok tanpa akamsi, sisa kasus olok-olok vs "sendirian".

## Asumsi
- Jarak jalan = 1,35 x garis lurus (OSRM tidak terjangkau dari sandbox) -> hitung ulang dengan OSRM saat impor.
- Pemandu: 5 jam (hari pertama tim tamu di simpul) = 10 poin, maks 2 tugas per PPL.
- Koordinat 4 PPL (Amelia, Devi Kardila, Febri Handayani, Rini Nofsiska Sari) dan 3 PML (Hariston, Ilham, Yeni siswanti) diperkirakan.

## Menunggu keputusan user
Lihat sheet Ringkasan & Konfirmasi bagian B (nomor 1-9).
