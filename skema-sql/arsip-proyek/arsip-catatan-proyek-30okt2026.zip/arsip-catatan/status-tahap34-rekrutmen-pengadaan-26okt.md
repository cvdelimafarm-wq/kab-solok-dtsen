# Status Tahap 34: rekrutmen mitra dan draf pengadaan (26 Okt 2026)

Sudah di-commit, di-push, di-deploy, dan diuji di produksi (26 Okt 2026, akun 354, data fiktif). Hanya membaca data; TIDAK ada SQL baru dan tidak ada tabel baru.

## Keputusan yang dipakai
- Pengguna memilih: "Rekrutmen mitra + draf pengadaan" lebih dulu (dua pembaca hilir `keu_v_ident_acuan` yang belum tersambung).
- Hanya membaca dan menyarankan; tidak ada yang tertulis, tidak ada yang memblokir. Surat tugas atau SPK tetap dibuat dan diterbitkan di layar dokumen lanjutan.
- Bila identifikasi lanjutan belum disimpan, halaman memakai perkiraan dari identifikasi awal (`awalLanjutan`) dan menyatakannya jelas.

## Halaman baru
`/sigap/kelola/perencanaan/identifikasi/[id]/kebutuhan` (dua kartu):
- **A. Rekrutmen mitra**: kebutuhan per peran (kebutuhan, tercatat, kepka, seleksi, SPK terbit, tenggat) dan daftar mitra dengan status: Menunggu seleksi, Menunggu nama dari kepka, Peran belum dipilih, Siap dibuatkan SPK, SPK konsep, SPK terbit (dari dokumen `tugas` per petugas). Tenggat SPK = hari mulai pelatihan paling awal yang diikuti perannya, atau mulai pendataan bila tidak ada kelas. Catatan: mitra kurang atau lebih dari kebutuhan peran, jumlah masih Perkiraan, mitra baru (pastikan terdaftar di master mitra), tenggat terlewat. Tautan ke SPK (`lanjutan/dokumen?jenis=tugas&kunci=`), lanjutan, dan Pelaksanaan.
- **B. Draf pengadaan**: item dari kelas (paket meeting hotel 524114/524119, konsumsi tanpa paket 521211, perlengkapan pelatihan, pulsa peserta), konsumsi rapat tatap muka, penggandaan PAPI, pulsa petugas lapangan FASIH, cetak buku di kabupaten (521811). Tiap item: volume, tanggal dibutuhkan (+ "n hari lagi"), tempat dan paket, nilai HANYA bila tarif ada di lembar kebijakan (tarif = batas tertinggi), dan daftar "perlu dilengkapi". Tombol "Salin daftar sebagai teks" (cadangan: kotak teks bila peramban menolak menyalin). Tautan ke tab RAB RO.
- Tautan masuk ditambahkan pada halaman Identifikasi lanjutan dan halaman Pelaksanaan.

## Berkas
- Baru: `lib/keu/rekrutmen.ts`, `lib/keu/pengadaan.ts`, `lib/keu/__tests__/rekrutmen.test.ts` (16 tes), `lib/keu/__tests__/pengadaan.test.ts` (20 tes), `app/sigap/kelola/perencanaan/identifikasi/[id]/kebutuhan/{page,Kartu}.tsx`.
- Diubah (satu tautan masing-masing): `identifikasi/[id]/lanjutan/page.tsx`, `identifikasi/[id]/pelaksanaan/page.tsx`.
- Salinan kode di Project: `kode-aplikasi/keu/lib/{rekrutmen,pengadaan}.ts`, tes, dan `app-sigap-...-kebutuhan-{page,Kartu}.tsx`.

## Verifikasi
- vitest folder uji sementara: 126 lulus (rekrutmen 16, pengadaan 20, usulanRab 27, kebijakan 63). tsc strict bersih untuk berkas baru.
- Uji render server dengan data contoh: lulus, tanpa "undefined" atau NaN.
- **Produksi (26 Okt 2026, Chrome, identifikasi fiktif id 1 "UJI Fiktif Survei Harga 27a", RO 2903.BMA.009):**
  - Halaman Kebutuhan tampil: chip "Lanjutan Final v1" dan "Lembar kebijakan versi 2"; kartu A menyatakan "Tidak ada mitra pada identifikasi lanjutan: rekrutmen tidak aktif" (benar: hanya 1 petugas PML organik); kartu B menampilkan 1 item (Konsumsi rapat evaluasi tatap muka, akun 521211, tarif Rp 40.000, nilai kosong, "Perlu dilengkapi: tanggal rapat belum ditetapkan; jumlah peserta rapat belum diidentifikasi"). Tanpa galat konsol.
  - Tautan masuk ada di halaman Lanjutan ("Rekrutmen mitra dan draf pengadaan →") dan di halaman Pelaksanaan ("Rekrutmen dan pengadaan →").
  - Tahap 33 (tab RAB RO 2903.BMA.009): kartu usulan menulis "tarif dan jendela dari lembar kebijakan versi 2"; kartu "Rencana realisasi" menampilkan Rp 640.000 pada Mar minggu 4 ("3 (1 di RAB)"); baris translok Survei Harga Kemahalan Konstruksi: RAB Rp 640.000 (kurang Rp 40.000 dari pagu). Tanpa galat konsol.
  - Belum teramati di produksi: kartu A dengan mitra nyata (status SPK, tenggat) dan nilai rupiah pengadaan; baru tercakup oleh tes dan uji render. Tombol "Buat lembar dari angka predefined" tidak terlihat karena lembar v2 Berlaku (diverifikasi lewat kode/tes saja).

## Batas dan catatan
- Metode dan nilai pengadaan ditentukan PPK atau pejabat pengadaan (cek aturan); halaman tidak menerapkan ambang apa pun.
- Volume konsumsi rapat, penggandaan PAPI, perlengkapan, pulsa lapangan, dan cetak buku belum tercatat pada identifikasi, jadi tampil sebagai "perlu dilengkapi".
- Tarif paket meeting (SBM) masih menunggu tabel rujukan; nilai paket hotel kosong sampai ada.
- Status pengadaan (diajukan, diproses, selesai) dan pemilihan penyedia belum ada; draf ini belum disimpan ke database.
- Pencocokan nama mitra ke master mitra/akun belum dilakukan di halaman ini (sudah ada di halaman Pelaksanaan untuk penugasan).

## Antrean berikutnya
1. Uji kartu A dengan mitra nyata: tambah petugas Mitra fiktif (kepka/seleksi) pada lanjutan id 1 atau identifikasi fiktif baru, lalu cek status dan tenggat.
2. Bila diinginkan: simpan status pengadaan (tabel + SQL) dan kaitkan ke RAB.
3. Sisa lama: uji lanjutan dengan identifikasi ber-H-15 masa depan; hal kecil (label "Ubah / Isi ST", peringatan Gap ke Kelola translok, teks `RabInline.tsx`, padanan baris POK impor, R-06); halaman Perencanaan lama (uji coba, data di peramban); tabel rujukan SBM/transport menunggu berkas.
