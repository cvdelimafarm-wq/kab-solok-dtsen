# Foto terbalik: empat arah, langkah Periksa arah, belajar per HP, diagnosa orientasi (26 Okt 2026)

Status: kode ditulis; lulus 17 tes fungsi dan tsc pada berkas yang disentuh. BELUM di-deploy, BELUM diuji di HP. Versi terbaru KameraSigap.tsx (dengan langkah Periksa arah foto) ada di Project (`claude/kode-aplikasi/kamera/app-sigap-foto-KameraSigap.tsx`); penulisan ke laptop menunggu koneksi pulih.

## Temuan
- Tangkapan layar 25 dan 26 Okt: foto landscape berisi terbalik 180 derajat, cap (HTML/server) tegak. Pada foto 26 Okt 10.49: HP miring ke KIRI, layar kamera terbaca tegak (jadi arah sensor yang dibaca = benar), tetapi isi foto terbalik.
- Diperiksa di produksi (26 Okt, bundel page-f844166ed8cd9aa7.js): perbaikan 24 Okt SUDAH aktif (matriks putar [0,-1,1,0,0,w] untuk HP kiri, [0,1,-1,0,h,0] untuk kanan). Artinya perhitungan teori (bingkai tegak terhadap HP) tidak cocok dengan bingkai yang diberikan kamera HP ini. Penyebab pasti belum diketahui; butuh data tiap merek HP.
- Celah lain: HP terbalik (atas ke bawah) dulu dianggap tegak; pratinjau tidak punya cara mengoreksi.

## Perubahan
- `lib/sigapFotoPutar.ts`: empat arah (`arahDariGravitasi`, histeresis), `matriksKuartal` (putar manual), `kunciKondisi` (s0/s1/s-1/s2 atau l<sudut layar>), `kuartalAkhir`, belajar per kondisi (`catatKoreksi`, `perbaruiBelajar`, `bacaBelajarPeta`). Dua koreksi 180 derajat pada satu kondisi (lebih banyak daripada foto yang dibiarkan) menambah putaran 180 derajat pada kondisi itu di HP tersebut; penghitung diulang dari nol saat berubah.
- `app/sigap/foto/KameraSigap.tsx`: memakai fungsi di atas; simpanan belajar di localStorage `sigap-foto-belajar:<akun>`; sesudah foto terkirim, mengirim diagnosa orientasi; baris diagnosa "v4".
- (BARU, permintaan 26 Okt) LANGKAH 1 "Periksa arah foto": sesudah memotret, yang tampil lebih dulu hanya foto + tombol Putar kiri / Putar 180° / Putar kanan + "Arah sudah benar, lanjut" + "Buang & ulangi". Nomor foto, Bagikan ke rekan, hitung mundur kirim otomatis, dan tombol Kirim baru tampil setelah "Arah sudah benar, lanjut". Hitung mundur 10 detik baru mulai saat itu (dulu mulai saat memotret). Sesudah lanjut, ada tombol "Periksa arah foto lagi (putar)". Foto tetap tersimpan sebagai draf di HP sejak dipotret; bila layar ditinggalkan di langkah 1, foto terkirim otomatis dengan arah seperti yang tampak. Cap resmi tetap dicetak server sesudah Kirim, mengikuti arah akhir foto.
- BARU `app/api/sigap/foto/orientasi/route.ts`: POST {foto_id, diag} -> catatan `sigap_audit` aksi `foto.orientasi` (tanpa foto/koordinat; hanya kunci kondisi, sudut/tipe layar, ukuran bingkai, kamera depan/belakang, nilai sensor, putaran dasar/dipakai, putaran manual). Putaran manual 180 derajat = putaran otomatis salah. Tanpa SQL baru.
- `lib/__tests__/sigapFotoPutar.test.ts`: 17 tes.

## Sesudah deploy
1. Beberapa foto landscape (kiri, kanan), depan dan belakang. Bila terbalik: di Langkah 1 ketuk Putar 180 derajat lalu "Arah sudah benar, lanjut"; dua kali di kondisi yang sama = HP belajar.
2. Baca data: `select created_at, akun_id, detail from sigap_audit where aksi='foto.orientasi' order by id desc;` (kunci, layar_lebar, sudut_layar, bingkai, hadap, kuartal_dasar, kuartal_dipakai, kuartal_manual).
3. Dari data itu rumus dasar yang benar per merek/kondisi ditetapkan, lalu pembelajaran per HP tidak lagi diperlukan.

Foto lama yang sudah terbalik tidak ikut diperbaiki (piksel dan cap sudah menyatu).
