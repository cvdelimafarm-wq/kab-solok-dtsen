# Catatan SQL Fase B kertas kerja revisi POK (24 Okt 2026)

Status: **siap dijalankan di produksi oleh Bapak sesudah Fase A; belum diterapkan.** Diuji di database sandbox (PostgreSQL 16, tabel stub meniru `sigap_akun` dan `sigap_audit`). Rangkaian lengkap a, b, c, d, e, f beserta semua uji lulus (17 berkas lewat `uji/jalan.sh semua`) dan migrasi dapat dijalankan ulang tanpa galat.

## Berkas dan urutan jalan
Folder `claude/skema-sql/fase-b/` (Fase A tetap di `fase-a/`):
1. `20261024d_keu_rab.sql` — RAB per RO: `keu_rab` (draf, menunggu ketua, menunggu PPK, disetujui, dikembalikan, digantikan, dibatalkan), `keu_rab_riwayat`, `keu_rab_item`, `keu_rab_baris`, `keu_rab_jadwal` (12 bulan per rincian, sekali/bulanan/triwulan, tag minggu M1-M4, ubah manual). Fungsi `keu_rab_aksi` (ajukan, setuju_ketua, sahkan, kembalikan, batalkan), `keu_rab_baru` (versi baru dari RAB lama, kunci alias dipetakan), `keu_rab_hapus_baris`; view status item, selisih jadwal, kebutuhan pencairan, ringkasan.
2. `20261024e_keu_revisi.sql` — `keu_revisi_jadwal` (empat jenis), `keu_revisi_usulan` (per jadwal dan RO), riwayat usulan, `keu_revisi_sah` (nomor dan tanggal dokumen, versi sistem), antrean `keu_laporan_kpa`. Fungsi `keu_jadwal_aksi` (buka, tutup, terapkan, sah, lewati, pulihkan), `keu_jadwal_bulanan` (bawaan tanggal 10, tutup dua hari kemudian), `keu_usulan_aksi`; view ringkasan, paket, tenggat.
3. `20261024f_keu_kertas_kerja.sql` — `keu_master_param` (faktor K dan toleransi), `keu_kk_baris`, `keu_kk_geseran`, `keu_kk_keputusan_kro`; fungsi `keu_kk_muat_ro`, `keu_kk_pasangkan`, `keu_kk_hapus_baris`, `keu_kk_putuskan`; view baris dengan pemicu P-01..P-08, ringkasan per RO, kecukupan KRO, buku selisih, geseran tidak sesuai, pemeriksaan R-xx; gerbang penerapan.
4. `20261024z_cek_kesehatan_keu.sql` (diperbarui, jumlah tabel mengikuti fase terpasang) dan `20261024z2_cek_kesehatan_keu_bdf.sql` — hanya membaca; baris P0 harus 0.
Folder `claude/skema-sql/fase-a/uji/`: tambahan `30_uji_rab.sql`, `31_uji_jadwal_usulan_sah.sql`, `32_uji_kertas_kerja.sql`, `12_uji_rangkap_peran.sql` (kini tidak bergantung urutan), `jalan.sh` versi baru (`./jalan.sh semua <folder-a> <folder-b>`).
Setelah selesai: jumlah tabel `keu_` menjadi 39 (25 dari a-c, 5 dari d, 5 dari e, 4 dari f).

## Cara kerja inti
- **Hak akses** sama dengan Fase A: aplikasi mengisi `app.akun_id` per transaksi; penjaga tabel memeriksa kewenangan. Saat kosong (SQL editor/migrasi) penulisan tidak diperiksa tetapi aturan data (status, constraint) tetap berlaku.
- **Alur persetujuan RAB dan usulan** (D-02, D-03): admin RO ajukan, ketua setuju, PPK sahkan; ketua mengajukan sendiri langsung ke PPK; PPK yang merangkap ketua langsung disetujui; pengaju tidak menyetujui sendiri; kembalikan wajib alasan minimal lima huruf. Status hanya berubah lewat fungsi.
- **Jadwal** (D-25): hanya PPK. Sah wajib nomor dan tanggal dokumen; sah menaikkan versi sistem, mencatat versi POK dasar, dan menambah antrean laporan ke KPA. Pulihkan hanya selama jendela belum lewat. Usulan hanya dibuat atau diajukan saat jadwal dibuka.
- **Kertas kerja** disimpan per jadwal dan RO (bukan per usulan) agar geseran antar-RO dalam satu KRO dapat dicatat. Kolom Semula diisi dari POK berlaku dan terkunci; akun, redaksi, dan satuan item POK resmi tidak diedit langsung (D-11, D-13): ganti lewat `keu_kk_pasangkan` (lama dikurangi atau dikosongkan, baru berisi salinan). `pindah_ke` dihitung dari `pindah_dari` sehingga hanya ada satu sumber kebenaran. Jumlah memakai jumlah tersimpan POK bila volume dan harga tidak berubah (29 baris POK dibulatkan).
- **Siapa boleh mengubah**: PPK selama jadwal dibuka atau terkumpul; ketua tim dan admin RO hanya untuk RO sendiri, hanya saat dibuka, dan tidak bila usulan RO itu sedang diproses atau sudah disetujui.
- **Pemicu** P-01..P-08 dihitung di view dengan aturan yang sama seperti mockup (`kk-logic.js`).
- **Pemeriksaan** (`keu_v_kk_periksa`): R-01 total pagu, R-03 jenis belanja, R-05 pagu KRO, R-07 belanja pegawai, R-08 baris blokir, R-09 penggenap, R-15 kecukupan KRO, R-16 kelompok belanja. Pada Mode Pagu Tetap (Revisi POK dan Administrasi) R-01, R-03, R-05, R-16 berwarna merah; pada Revisi DIPA menjadi info (R-01 hijau pada jalur DJA). **Merah menghalangi jadwal berstatus diterapkan** (gerbang).
- **Kecukupan KRO** (D-28): K = RAB item belum selesai dibagi faktor + RAB item selesai; Kurang bila POK di bawah RAB, Tipis di bawah K, Cukup sampai K x (1 + toleransi), selebihnya Lebih. Faktor 0,9 dan toleransi 5 persen ada di `keu_master_param` (hanya pemegang kewenangan master yang mengubah; jejak ke audit). Dihitung per KRO dan kelompok belanja, hanya item yang punya RAB.
- **Keputusan PPK per KRO** (D-15): semua, sebagian (jumlah wajib dan tidak melebihi kekurangan), atau tunda; hanya bila KRO memang kekurangan; dapat diubah selama jendela terbuka.
- **Dana penggenap** (D-09): hanya akun 52xxxx, satu baris per akun dan komponen dalam satu RO, tidak pernah minus (D-30).
- **Tabel riwayat** (`keu_rab_riwayat`, `keu_revisi_usulan_riwayat`) hanya dapat ditambah dari aplikasi; `keu_laporan_kpa` dapat berubah status tetapi tidak dihapus; baris dan usulan tidak dapat dihapus dari aplikasi.
- **Jejak audit**: tiap ubah, tiap baris baru, dan tiap hapus baris baru tercatat; memuat 600-an baris POK ke kertas kerja sengaja tidak membanjiri jejak.

## Belum dihitung (sengaja)
R-02 dan R-04 (volume RO dan sumber dana) menunggu kolom di Fase D/G; R-06 (pagu baris tidak di bawah Booked + Realisasi) menunggu data realisasi Fase D; R-10 sampai R-14 informatif atau lampiran (Fase E). R-17 dipenuhi oleh struktur: jumlah tidak minus dan satu penggenap per akun dan komponen.
RO sementara `T-nnn` tidak punya KRO sehingga tidak ikut pemeriksaan tingkat KRO sampai kodenya dipadankan (Fase G).

## Temuan saat menulis
1. Penjaga hapus pada `keu_revisi_usulan` awalnya tidak ada (hanya terhenti oleh kunci asing); kini ditolak dari aplikasi.
2. Tabel riwayat awalnya dapat diubah oleh sesi aplikasi; kini append-only (`keu_catat_saja`).
3. Uji rangkap peran (`12_`) tergantung urutan; kini memakai RO tersendiri sehingga dapat dijalankan di mana saja.
4. Penggenap diselaraskan dengan pertanyaan terbuka 6: satu per akun dan komponen, bukan per akun per RO.

## Cara menjalankan di produksi
1. Pastikan Fase A sudah terpasang dan hasil `z_cek` bersih (`list_tables` terlebih dahulu).
2. Jalankan berurutan `d`, lalu `e`, lalu `f`. Tiap berkas aman diulang.
3. Jalankan `z_cek_kesehatan_keu.sql` (baris 4 harus `39 dari 39`) dan `z2_cek_kesehatan_keu_bdf.sql` (baris P0 harus 0). Laporkan hasilnya.
4. Sampai penugasan (ketua tim, admin RO, PPK) diisi, hak aplikasi belum berjalan di DB; kertas kerja dapat diisi lewat SQL editor.

## Berikutnya
Menurut spesifikasi bagian 5, sisa SQL: Fase D (unggahan dan banding POK resmi, unggahan realisasi GLP039, skor), Fase E (Administrasi per item), Fase F (kekurangan RAB dan tambahan pagu), Fase G (struktur usulan T-nnn). Jadwal dan pengesahan (Fase C spesifikasi) sudah termasuk di berkas `e`. Penomoran berkas migrasi berlanjut `g`, `h`, dan seterusnya; lalu kode aplikasi per modul.
