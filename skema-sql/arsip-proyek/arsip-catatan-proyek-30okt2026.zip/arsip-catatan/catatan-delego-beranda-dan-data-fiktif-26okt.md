# Delego: ikon di Kegiatan saya dan data fiktif akun 354 (26 Okt 2026)

## Ikon Delego di Beranda HP
- Berkas: `app/portal/Beranda.tsx` (sudah ditulis ke laptop; perlu commit, push, deploy).
- Di bagian "Kegiatan saya" (grid 3 kolom) ditambah ikon "Delego" (cincin putus-putus hijau, tanda merek Delego, sub "Tugas dan laporan"). Mengetuk membuka `/sigap/delego/saya` (tampilan HP hijau).
- Sementara hanya tampil untuk akun super (`data.super_akun`), yaitu akun Ketua Tim. Untuk membuka ke semua petugas: ganti `tampilDelego` menjadi `true`, atau saring lewat hak Delego.
- Hitungan "n kegiatan" ikut bertambah satu. Tidak ada tabel atau API baru.

## Data fiktif untuk akun 354 (M. Iqbal Hadi), sampai 15 Nov 2026
Dimasukkan langsung ke `keu_dlg_delegasi` (identifikasi fiktif 1, RO 2903.BMA.009, pemberi dan penerima sama-sama 354 karena fungsi `keu_dlg_buat` melarang mendelegasikan ke diri sendiri dan tidak ada akun pemberi lain). Jejak audit tercatat (+3).

| id | Judul | Peran | Target/hari | Masa |
|---|---|---|---|---|
| 2 | UJI Fiktif Pengolahan data survei harga | pegawai | 30 | 26 Okt sampai 15 Nov |
| 3 | UJI Fiktif Pemeriksaan kualitas data (PML) | pml | 20 | 26 Okt sampai 15 Nov |
| 4 | UJI Fiktif Penyusunan laporan tahap akhir | pegawai | 10 (total 70) | 9 Nov sampai 15 Nov |

Semua berstatus baru, belum ada laporan, tanpa notifikasi. Beban minggu pertama 50 dari 60 poin per hari (83%), minggu terakhir 60 (100%). Id 1 (UJI Fiktif Pencacahan blok 1, mitra Fuji Zahara) berstatus batal. Bila selesai diuji, batalkan dengan alasan lewat Papan > Detail > Status (jangan dihapus).

## Tambahan 26 Okt 09:25: tiga set yang sama untuk rekan
Set yang sama (3 kegiatan UJI Fiktif, 26 Okt sampai 15 Nov) dimasukkan untuk Mailani Putri (akun 357, id 5-7), Nurafiza Thamrin (akun 464, id 8-10), dan Dina Marizka (akun 160, id 11-13). Pemberi 354, dimasukkan langsung sehingga tidak ada notifikasi ke mereka. Batalkan dengan alasan bila selesai diuji (jangan dihapus).
