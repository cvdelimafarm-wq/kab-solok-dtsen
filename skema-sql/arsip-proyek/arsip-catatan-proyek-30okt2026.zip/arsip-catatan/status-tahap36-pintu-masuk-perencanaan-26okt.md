# Tahap 36 — Pintu masuk Perencanaan (26 Okt 2026)

Tugas #32. Alamat `/sigap/kelola/perencanaan` kini membuka halaman penunjuk (`PintuMasuk.tsx`), bukan lagi uji coba Alur GSBPM.

## Isi
- Urutan lima langkah: Identifikasi, Persetujuan, Identifikasi lanjutan, Kebutuhan dan usulan RAB, Pelaksanaan dan Gap.
- Tautan: Identifikasi survei, Lembar kebijakan manajemen tim, Notifikasi, Anggaran per RO (/sigap/ro).
- Tombol "Buka uji coba" hanya untuk Admin Aplikasi (izin portal.kelola level kelola).

## Yang TIDAK berubah
- Uji coba lama tidak dihapus. Daftar RO-nya di `?uji=1`; semua tautan lama `?ro=...&keg=...&tahap=...` tetap berfungsi.
- Data uji coba (localStorage) tidak disentuh. Tidak ada SQL, tidak ada perubahan basis data.
- Menu samping: butir "Alur GSBPM" (admin saja) masih mengarah ke alamat yang sama, sehingga kini mendarat di pintu masuk. Belum diubah.

## Berkas
- baru: app/sigap/kelola/perencanaan/PintuMasuk.tsx
- diubah: app/sigap/kelola/perencanaan/page.tsx (+ `uji` pada Posisi, cabang `masuk`, Bingkai, jejak)

## Verifikasi
- Uji render PintuMasuk (3 tes) lulus; tsc bersih untuk PintuMasuk. page.tsx belum diketik-periksa penuh di sandbox (banyak ketergantungan); periksa `npx tsc --noEmit` di repo.
- Belum diuji di produksi.

## Usulan lanjutan (belum dikerjakan)
- Ubah butir menu "Alur GSBPM" menjadi "Perencanaan" (terbuka untuk semua) di lib/sigapMenuV2.ts + tesnya, agar pintu masuk terlihat oleh bukan admin.
