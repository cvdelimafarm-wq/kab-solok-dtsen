# Tahap 16: Tambah level mata anggaran (papan 16), 24 Okt 2026

Halaman baru `/sigap/struktur`. Tautan masuk: tombol "Tambah level mata anggaran (usulan struktur)" di Jadwal revisi (`/sigap/revisi`). STATUS: terdeploy dan diuji di produksi (24 Okt 2026).

## Berkas
- `lib/keu/struktur.ts` + `lib/keu/__tests__/struktur.test.ts` (26 uji): rantai induk, pilihan induk bertingkat, pemeriksaan isian, jalur, status, aksi yang tersedia, argumen fungsi, pemadanan, riwayat.
- `app/sigap/struktur/page.tsx` (rangka, KPI, kartu Subkomponen, pemuatan data, hak), `Form.tsx` (bagian 1), `Daftar.tsx` (bagian 2 + aksi alur), `Statis.tsx` (bagian 3 sampai akhir).
- `lib/keu/tampilan.ts`: ditambah `keu_v_struktur_riwayat`. `baca.test.ts`: pengecualian kedua untuk tampilan riwayat.
- SQL `20261024r_keu_v_struktur_riwayat.sql` (SUDAH dijalankan di produksi): tampilan baca-saja riwayat usulan struktur, hanya service_role.

## Yang memutuskan adalah basis data
Semua aturan sudah ada di fungsi `keu_struktur_usul/aksi/ubah/usulkan/padankan/tolak_pusat/cocokkan` (lewat gerbang `keu_jalankan`). Halaman hanya memberi pemeriksaan awal, menyalakan tombol menurut `keu_boleh`, dan memanggil fungsi.
Alur status basis data: draf, dikembalikan, menunggu_ketua, menunggu_ppk, sah, diusulkan, perlu_dipadankan, aktif, dibatalkan, ditolak_pusat.
Kewenangan: str_tim (Komponen, Subkomponen, Akun, Item), str_ppk (Program, Kegiatan, KRO, RO), rab/draf/setuju_ketua (per RO), sahkan (PPK).

## Selisih dari mockup (disengaja)
1. Status mengikuti basis data (10 status, bukan 7): ada "dikembalikan", "dibatalkan", "ditolak pusat"; langkah "sah" dan "diusulkan" dipisah (PPK menyatakan usulan diteruskan, nomor surat wajib untuk DJA/DJPb).
2. "POK resmi terbit: kode sama/berbeda" diganti tombol PPK "Cocokkan dengan POK berlaku" (fungsi `keu_struktur_cocokkan`): kode sama langsung aktif, kode berbeda menjadi "Perlu dipadankan", lalu PPK memilih padanan dari daftar simpul/item POK (bukan mengetik, tidak ditebak).
3. Induk dipilih lewat daftar bertingkat (RO, Komponen, Akun) dari jalur POK berlaku, ditambah usulan induk yang belum aktif; mockup memakai tombol chip dan hanya RO yang dikelola.
4. Akun diusulkan di bawah Komponen saja (jalur POK memuat akun di bawah komponen; di bawah Subkomponen pencocokan tidak akan menemukan padanan).
5. Tenggat jalur dibaca dari Master waktu (bukan teks tetap). Riwayat dibaca dari `keu_struktur_usulan_riwayat`, bukan "sesi ini".
6. Ditambah: Ubah isian (draf/dikembalikan, `keu_struktur_ubah`), Kembalikan dengan alasan, Batalkan dengan alasan (tanpa hapus), Catat ditolak pusat.
7. Duplikat item terhadap POK berlaku diperiksa basis data (kunci stabil), di layar hanya terhadap usulan berjalan.
8. Tombol Batalkan selalu menyala untuk status yang boleh dibatalkan (pembuat usulan tidak dikenali di layar); basis data menolak yang tidak berhak dengan pesan.

## Uji
`npx vitest run lib/keu` = 302 lulus; `tsc` bersih; uji render komponen lulus.

### Uji produksi (24 Okt 2026, Iqbal 354, RO fiktif 2906.BMA.005)
- Halaman tampil: KPI (7 level, usulan, 3 jalur), form, tabel jalur, 8 langkah, S1 sampai S6.
- Pilih RO menyaring Komponen (051, 052) dan Akun (hanya akun di komponen terpilih): LULUS.
- Item uji (uraian "uji alur struktur (fiktif)", volume 1 OK, harga 1000): semua 6 butir pemeriksaan Lulus, jalur Revisi POK.
- Simpan menghasilkan draf T-001; Ajukan langsung menghasilkan "Sah" (Iqbal = ketua tim sekaligus PPK); "Nyatakan diusulkan" menghasilkan "Diusulkan, menunggu POK resmi"; "Catat ditolak pusat" tanpa alasan ditolak ("Alasan minimal 5 huruf"), dengan alasan menghasilkan "Ditolak pusat". Riwayat mencatat keempat langkah dengan nama pelaku. Tidak ada galat konsol.
- Toggle Subkomponen tidak disentuh. Tidak ada data nyata terpengaruh (T-001 kini berstatus ditolak pusat, tidak dihapus).
- Tidak terjangkau uji: Batalkan (hilang setelah status "diusulkan", sesuai desain), Kembalikan, Cocokkan dengan POK berlaku (menyentuh seluruh usulan, ditunda), Padankan manual, akun non-PPK (tombol sahkan mati).
- Catatan UX kecil: pesan "Alasan minimal 5 huruf" tetap tampil setelah alasan diketik sampai tombol ditekan; sebaiknya dihapus saat mengetik (perbaikan kecil, belum dikerjakan).

## Urutan berikutnya
Papan 6 (Impor), 7 (Versi/RPD/dampak), 4 (Lampiran), 5 (Status/riwayat); periksa 11/12/13/15 terhadap mockup.
Nomor berkas SQL berikutnya: s.
