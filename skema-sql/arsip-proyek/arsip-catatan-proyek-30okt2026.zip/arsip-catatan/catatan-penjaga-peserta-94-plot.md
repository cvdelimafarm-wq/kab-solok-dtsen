# Penjaga: hanya 94 peserta pelatihan yang boleh masuk plot (9 Okt 2026)

Arahan user: seluruh petugas di luar 94 peserta pelatihan TIDAK boleh ada di plot, sekarang maupun nanti.

## Definisi "94 peserta"
Penugasan aktif `sigap_penugasan.kegiatan_id = 3` -> `sigap_akun.petugas_bencana_id`. 93 terhubung ke `bencana_petugas`; 1 lagi Muzahar (PML organik, tidak ada di `bencana_petugas`).

## Yang dilakukan (SELESAI, terverifikasi di DB)
- Sherli Handayani (60) dan Dahlia Afriyanti (471): `bencana_petugas.aktif=false`, akun SIGAP dan penugasan dinonaktifkan (migrasi `nonaktifkan_sherli_dahlia`; cadangan `bencana_alokasi_subsls_cad_dahlia_20261009`).
- 9 non-peserta dikeluarkan dari alokasi/tim (SQL `20261009v`, dijalankan user): 413 Annisa Suryani, 390 Fenny Anda Listi, 365 Hafni Syamfitria, 99 Julia Lara Zamzamy, 470 Mega Okra susanti, 394 Mira apridayanti, 473 Nurlathifa Harmi, 400 Salsa Billa Duwita Putri, 471 Dahlia. 8 porsi dilepas -> alokasi 169 -> 161; atasan_id dikosongkan. Cadangan: `bencana_alokasi_subsls_cad_nonpeserta_20261009`, `bencana_petugas_atasan_cad_nonpeserta_20261009`.
- Penjaga DB (SQL `20261009w`, dijalankan user): fungsi `bencana_peserta_pelatihan(pid)`, trigger `alokasi_hanya_peserta` (bencana_alokasi_subsls, ppl_id/pml_id) dan `atasan_hanya_peserta` (bencana_petugas, atasan_id). Insert/ubah non-peserta ditolak (check_violation); mengosongkan atasan_id boleh. Sudah diuji: kedua penolakan bekerja.

## Dampak / tindak lanjut (dibahas nanti oleh user)
- Tim Budi Pernandes tinggal 2 PPL, Rifa Amelia 0 PPL (di bawah aturan 3-6). Ayu Sepriani, Widya Verawati, Ilham tinggal 3-4 PPL.
- Abdul Latif, Indah Permata Sari, Rifa Amelia (PML) juga bukan peserta pelatihan -> tidak bisa dipakai sebagai pengganti.
- Pergantian/pengisian tim ditunda sampai user siap. Fitur Bantuan Keroyokan nanti terkena penjaga yang sama.
- DDL/DELETE pada bencana_alokasi_subsls lewat MCP menggantung; SQL destruktif dan trigger dijalankan user di SQL Editor.
