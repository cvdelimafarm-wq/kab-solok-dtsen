# Catatan 23 Okt 2026 (lanjutan) — Ganti foto, Plotting tim di HP, berkas FASIH

Lanjutan dari catatan-perbaikan-translok-foto-spj-23okt.md (poin 1–4).

## 5. Tambahan sore 23 Okt — Tombol "Ganti foto N" (replace langsung)
- `app/sigap/foto/SusunFoto.tsx`: tiap nomor yang sudah terisi mendapat tombol "📷 Ganti foto N" (tautan ke `/sigap/foto?kegiatan=<id>&nomor=<N>`). Hanya muncul bila akses dibuka, BUKAN hari izin susulan, dan tanggalnya = hari ini (WIB).
- `app/sigap/foto/page.tsx`: membaca `?nomor=` -> prop `nomorGanti` ke `KameraSigap`.
- `app/sigap/foto/KameraSigap.tsx`: mode ganti — banner "Mode ganti foto: Foto N" + tombol "Batal ganti"; jepretan diarahkan ke nomor itu, tanpa hitung mundur kirim otomatis (petugas menekan Kirim); "Buang & ulangi" mempertahankan mode; mode direset setelah kirim berhasil / tutup pratinjau. Foto lama tidak dihapus, menjadi cadangan (perilaku server tidak diubah).
- Hari susulan / hari lampau tetap lewat uploader lama.
- Belum diuji di HP/aplikasi nyata. Uji: buka kartu hari ini -> "Ganti foto 1" -> jepret -> Kirim -> cek Foto 1 berganti & foto lama muncul di cadangan.

## 6. Tambahan 23 Okt — kartu Sub SLS Plotting tim di HP
- `app/sigap/pendataan/PlottingTim.tsx`: chip status ("Sudah keluar di FASIH", "Dari kolam") dan "Non aktif" ditaruh di bawah keterangan pada layar sempit; di kanan hanya layar `sm:` ke atas. Belum: ruang kosong di dasar daftar agar FAB "Kolam wilayah" tak menutup tombol.

## 7. Berkas FASIH Pengawas-Pencacah (infrastruktur)
- `Pengawas-Pencacah-Infrastruktur-20261023.xlsx` (26 baris, pengawas tunggal 1303.nella@dummy.sobat.id, email pencacah huruf kecil, kode wilayah teks mengikuti `barisTemplatFasih`). Disalin ke Downloads laptop.
