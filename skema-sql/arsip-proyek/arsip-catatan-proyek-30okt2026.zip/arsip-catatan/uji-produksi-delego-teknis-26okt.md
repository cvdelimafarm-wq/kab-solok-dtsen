# Uji produksi Delego teknis (tahap 39), 26 Okt 2026 sore

Diuji lewat Claude in Chrome (https://bps-solokkab.up.railway.app), akun 354 (Ketua Tim), data fiktif berjudul "UJI Fiktif ...", penerima mitra Fuji Zahara (akun 239).

## Pemeriksaan pemasangan (SELECT)
5 tabel baru, 10 fungsi baru, 8 jenis seed, 1 kelompok TIM-KESRA, 3 jadwal pg_cron aktif (delego-pengingat-1800, delego-rutin-0600, delego-tenggat-15m). Menu "Katalog pekerjaan" dan "Pekerjaan berulang" tampil di sidebar dan tab HP.

## Lulus
- Katalog pekerjaan: 8 jenis + kelompok Pekerjaan tim tampil; poin dan perkiraan menit benar.
- Buat delegasi "Pekerjaan tim" (Evaluasi pelaksanaan, jumlah 1): pratinjau "1 laporan x 28 = 28 poin, 10 hari kerja = 2,8 poin/hari"; hasil, tinjau, 4 langkah bawaan terisi otomatis; tersimpan (id 31), tampil di Papan dengan penanda jenis, "Hasil belum diserahkan", "Langkah 0/4".
- Centang langkah oleh pemberi (3/4) tampil; progres bar ikut.
- Serah hasil (versi 1, atas nama penerima uji lewat fungsi gateway) -> kartu pindah ke Berjalan, penanda "Hasil menunggu tinjau", notifikasi delegasi_hasil ke Ketua.
- Tinjau: "Minta revisi" dengan catatan -> status "Perlu revisi", catatan tampil, notifikasi delegasi_tinjau ke penerima. Serah versi 2 -> "Terima hasil" -> delegasi otomatis selesai (id 31), langkah terkunci, notifikasi "Hasil Anda diterima".
- Lonceng: notifikasi hasil kerja tampil; klik mengalihkan ke Papan.
- Pekerjaan mendadak (id 32, Memeriksa dokumen x2, jam tenggat 19.30): penanda "Mendadak", "Tenggat pukul 19:30 WIB, sisa 1 jam 27 menit" (kuning). Pengingat 2 jam sebelum tenggat benar-benar terkirim oleh cron 15 menit (notifikasi delegasi_tenggat, kolom pengingat_tenggat_at terisi).
- Pekerjaan berulang: templat mingguan Senin tersimpan; `keu_dlg_rutin_jalan()` dipanggil dua kali: pertama dibuat 1 (id 33), kedua dibuat 0 / sudah ada 1 (idempoten). Notifikasi delegasi baru terkirim.
- Beranda tim, Papan, Delegasi saya, Katalog, Berulang, Riwayat di lebar 390 px: tidak meluap, header + chip + tab bawah terbaca.
- Hak ditegakkan database: pemberi boleh mencentang langkah; serah hasil oleh pemberi ditolak ("Hanya penerima yang dapat menyerahkan hasil kerja").

## Temuan
1. Tidak ada jalan bagi PML/pemberi menyerahkan hasil mewakili mitra yang tidak memegang ponsel (database menolak, layar "Mitra yang boleh saya laporkan" hanya punya tombol Lapor). Perlu keputusan: izinkan serah hasil mewakili (ditandai "diwakili") atau cukup mitra memakai laporan harian.
2. Kartu Pekerjaan berulang menulis "Berikutnya: Sen 26 Okt" padahal jadwal hari itu sudah jalan (06.00); seharusnya tanggal berikutnya (Sen 2 Nov). Kosmetik.
3. Serah hasil dan unggah foto hasil oleh penerima tidak bisa diuji di layar (tidak ada akun penerima); sisi penerima hanya diuji di tes smoke dan lewat fungsi database.

## Pembersihan
Delegasi 32 dan 33 dibatalkan (alasan tercatat), templat berulang id 1 dinonaktifkan; delegasi 31 selesai. Tidak ada yang dihapus. Delegasi fiktif id 2-13 (uji sebelumnya) belum dibatalkan.
