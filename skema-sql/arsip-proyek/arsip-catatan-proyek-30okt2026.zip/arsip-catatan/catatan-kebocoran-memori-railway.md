# Catatan kebocoran memori kab-solok-dtsen (Railway) — 17 Okt 2026

## Gejala (laporan Railway Usage Alert, periode 2 Okt–2 Nov)
- Memori = 18.361 GB-menit = $4,25 (84% tagihan). CPU < 0,1 vCPU. ~468 ribu request/minggu.
- Grafik memori kab-solok-dtsen bergerigi: ~500 MB naik sampai 2,0–2,7 GB lalu turun saat restart/deploy.

## Penyebab (terbukti)
- Hampir setiap route API membuat klien Supabase baru per request: `createClient(url, serviceKey)` TANPA opsi `auth`
  (lib/portal/server.ts `dbPortal()`, app/api/sigap/aktivitas, saya, admin, masuk, tutup, translok, bencana/*, penyisiran/*, lib/sigapTesDb.ts, lib/pedia/server.ts, dst).
- Di Node, auth-js (v2.116.0, GoTrueClient.js baris 4717-4723) memanggil `startAutoRefresh()` bila `autoRefreshToken` aktif (bawaan) -> `setInterval` 30 detik
  yang menahan klien di memori selamanya (unref hanya mencegah proses tertahan, bukan melepas objek).
- Ukur (supabase-js 2.116.0, Node, 20.000 klien): bawaan = 11,69 KB/klien tertahan (228 MB); dengan `{auth:{autoRefreshToken:false,persistSession:false,detectSessionInUrl:false}}` = 0,16 KB/klien (3 MB).
- 468 ribu request/minggu x 11,7 KB ≈ 5,3 GB/minggu -> cocok dengan gerigi grafik (turun saat redeploy).

## Perbaikan yang diusulkan (menunggu "setuju")
1. Berkas baru `lib/supabaseServer.ts`: satu klien service-role bersama (singleton) + opsi auth dimatikan.
2. Ganti semua `createClient(...)` service-role di app/ dan lib/ dengan fungsi itu.
3. Opsional: `NODE_OPTIONS=--max-old-space-size=768` dan batas RAM di Railway sebagai pengaman.
4. Target: memori stabil ~300-600 MB; tagihan memori turun >70%.

## Pertanyaan untuk user (hanya bisa dilihat di dashboard Railway)
- Pembagian memori per service (kab-solok-dtsen vs osrm).
- Service duplikat `kab-solok-dtsen` di proyek serene-fulfillment / angelic-fascination / upbeat-essence masih dipakai?
- OSRM (Sumatera Barat, MLD) masih dibutuhkan? Permintaan 4xx kemungkinan dari pemanggilan rute (lib/portal/skorKinerja.ts memakai OSRM_BASE_URL, timeout 4 detik).
