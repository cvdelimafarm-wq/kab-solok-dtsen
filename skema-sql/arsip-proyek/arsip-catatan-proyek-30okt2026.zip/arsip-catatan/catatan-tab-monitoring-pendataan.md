# Catatan: Tab Monitoring di Kelola Pendataan (Fase 1–4) — 18–19 Okt 2026

Status 19 Okt: SEMUA FASE selesai, diuji di cloud (52 uji lulus, tsc dengan stub bersih, render HP 360/390 px & desktop), dan SUDAH DITULIS ke folder laptop `13 Usul DTSEN` (16 berkas baru + page.tsx diubah; mtime page.tsx cocok, tidak ada yang tertimpa). Iqbal yang menjalankan `npx vitest run`, commit & push. Tanpa migrasi, hanya-baca. User menjawab "Lanjut sampai selesai" setelah Fase 1 → Fase 2–4 dikerjakan sekaligus.

## Isi tab (dropdown Variabel, 4 pilihan)
1. Progres petugas — rekap PPL / PML / Tim (target tim = KK semua Sub SLS aktif plotting+kolam, tanpa non aktif; target PPL = target tim ÷ jumlah PPL; didata = terdampak + tidak terdampak yang ditandai PPL; tidak ditemukan terpisah; Sub SLS bersama dihitung sekali pada total; rekap PML memakai progres identifikasi).
2. Transport lokal — hari Lengkap / Sebagian / Kosong per orang, Anomali kolom terpisah. Kosong = hari kerja dipilih tetapi laporan DAN foto belum ada; Anomali = ada hasil/laporan/foto tanpa hari kerja dipilih. Rekap PPL/PML/Tim, rentang tanggal, urutan.
3. Poin kinerja per hari — matriks PPL × tanggal mulai 15 Okt (5/1/1 poin per km, maks 15 poin jarak, target 45), jarak OSRM (anggaran waktu 9 dtk + cache; sisa pakai perkiraan ≈ lalu muat ulang otomatis), total poin, hari ≥ 45, hutang.
4. Perkiraan kebutuhan anggaran — realisasi O-K (hutang kumulatif, dibulatkan ke bawah, hari kerja lengkap; PML/korwil 1 O-K per hari kerja lengkap), perkiraan sisa (sisa KK × poin per KK + jarak 2×1,3×garis lurus rumah→pusat KK tersisa), sisa hari dua versi (dibagi rata vs tiap PPL tuntaskan sendiri) dibanding batas 10 Nov (+7 hari tenggang); parameter: dasar laju (sejak mulai / 3 hari terakhir / target 45), pola hari kerja (Sen–Sab default), sertakan PML & korwil. Tarif & kuota dari sigap_kegiatan_tarif (PPL Rp170.000, kuota 3.458 O-K; PML kuota 980; korwil tanpa kuota).

## Berkas (BARU 16, UBAH 1)
lib/pendataanMonitor.ts, lib/monitorKinerja.ts, lib/portal/pendataanMonitor.ts, lib/portal/pendataanKinerja.ts, 3 berkas uji di lib/__tests__, API /api/portal/pendataan/monitoring dan /monitoring/kinerja (izin bencana.admin lihat), UI Monitoring.tsx (pemilih variabel), MonProgres/MonTransport/MonPoin/MonAnggaran.tsx, monUi.tsx, useKinerja.ts. UBAH: app/sigap/kelola/pendataan/page.tsx (2 tab, ?tab=monitoring&v=...).

## Tampilan HP (PWA; Iqbal & korwil pemegang izin)
< 768px: tabel → kartu per orang (tanpa gulir samping), kontrol 2 kolom, tombol 44 px, catatan dilipat, pilihan urutan capaian.

## Penyelarasan aturan (19 Okt)
Setelah membaca lib/skorKinerja.ts & lib/skorRute.ts di laptop: model realisasi (hutang kumulatif) ternyata setara hitungRealisasi; satu perbedaan diperbaiki — poin jarak berlaku bila ada KK ditandai apa pun hasilnya (termasuk tidak ditemukan, 0 poin). Ada uji kesetaraan yang mengimpor @/lib/skorKinerja (gagal bila aturan asli berubah).

## Yang masih perlu dicocokkan
- Hari lengkap tanpa izinAktif (dataSpj memakainya). Hari ini dianggap lengkap sementara.
- Angka anggaran adalah PERKIRAAN pemantauan, bukan angka pembayaran.

## Data nyata 18 Okt (baca-saja, untuk kewajaran)
KK didata 4.398 dari 104.808 KK aktif; per hari ±60 petugas menandai, rata-rata poin KK per petugas ±38–45 (16–18 Okt). Lapangan 10–18 Okt (PPL): 277 hari lengkap, 89 sebagian, 166 kosong (banyak hari kerja dipilih sebelum pendataan benar-benar jalan), 62 tidak ada.
