# Audit navigasi & data SIGAP — Tahap 3 (investigasi) + Laporan akhir — 23 Okt 2026

Dasar: kode di repo laptop + SELECT di Supabase `nlwkpakyfprugqwklxiu`. Tidak ada SQL/skema ditulis atau dijalankan di seluruh Tahap 3.

## A. Temuan Tahap 3

### 1. KK "didata" 9.231 vs 9.185 (selisih 46) — penyebab: definisi berbeda, bukan galat hitung
Kondisi DB saat diperiksa (23 Okt): KK aktif berhasil didata = 9.437 (terdampak 3.814 + tidak terdampak 5.623); tidak ditemukan 43; yang ditandai PML (bukan PPL) 4.
- Definisi A "punya hasil apa pun" = 9.480 → `ringkasModulPendataan` (lib/portal/pendataan.ts, `hasil !== null`): termasuk "tidak ditemukan" dan penanda mana pun. Dipakai sebagai ukuran selesai di modul Beranda/tahap.
- Definisi B "berhasil, penanda mana pun" = 9.437 → `korwilMonitor` (Sub SLS yang dipegang satu tim).
- Definisi C "berhasil, hanya ditandai PPL" = 9.433 → `pendataanMonitor` (keputusan 18 Okt: KK yang ditandai PML tidak dihitung; tidak ditemukan terpisah).
- Selisih A−C = 47 = 43 tidak ditemukan + 4 ditandai PML; selisih 46 pada cuplikan layar berasal dari komponen yang sama pada waktu berbeda.
- Target memakai daftar KK aktif (`bencana_pendataan_kk`), bukan `jumlah_kk_total` perkiraan; keduanya bisa jauh beda per Sub SLS (mis. Selayo 000107: perkiraan 164 vs daftar 213).

### 2. Penyebut jumlah petugas 99/98/97/89/79
Kegiatan 1, penugasan aktif: semua peran 100 (korwil 13 + PML 18 + PPL 66 + supervisor 3); korwil+PML+PPL = 97 (penerima siaran); PML+PPL = 84; PPL+korwil = 79; roster bencana_petugas PPL+PML (termasuk nonaktif) = 100. Angka 99, 98, 89 tidak bisa direproduksi dari data sekarang (kemungkinan cuplikan layar saat roster lain, mis. 85 → 97 pada 20 Okt). Akar masalah: tiap layar memakai himpunan berbeda tanpa label.

### 3. Riwayat siaran pembilang > penyebut (95/85, 93/85)
Terbukti dari `sigap_audit`: penyebut `akun` disimpan SAAT KIRIM (85 untuk siaran 17–19 Okt; 97 untuk 20 Okt), pembilang menghitung SEMUA akun yang kemudian menekan "Saya mengerti" (Briefing 19 Okt: 85 saat kirim, 95 pembaca). Petugas yang baru ditugaskan ikut melihat modal (berlaku 14 hari).

### 4. Target pecahan "305,3"
`target_per_ppl = kk_target / jumlah PPL` tanpa pembulatan (lib/pendataanMonitor.ts).

### 5. "Nagari Selayo 0/0"
Tidak terulang (Selayo punya 25 Sub SLS dengan KK). Sumber 0/0 yang mungkin: Gantuang Ciri (14 Sub SLS semuanya nonaktif) dan Sub SLS tanpa daftar KK (Aie Dingin 1, Paninggahan 2, Saniang Baka 1, Sungai Nanam 1).

### 6. Korwil "28 Sub SLS" vs 9+8+12 = 29
Kelompok 1: 29 baris Sub SLS per tim, 28 unik; satu Sub SLS dipegang dua PML (Gando 01). Desain disengaja. Kelompok lain: K2 34→32, K3 20→18, K4 29→28.

### 7. Belum diinvestigasi rinci
Wording kartu PPL; menandai RO contoh di /sigap/kelola/perencanaan (data uji di peramban); gaya seragam "Segera hadir" di sidebar dan tab.

## B. Perbaikan yang SUDAH dikerjakan (setelah "lanjut", tanpa skema/SQL)
1. Riwayat siaran: `hitungKonfirmasiSiaran(pembaca, penerimaSekarang)` baru di `lib/siaranPetugas.ts` (+ tes); `ringkasSiaran` (lib/portal/siaranPetugas.ts) memakai pembaca ∩ penerima sekarang terhadap penerima sekarang; teks riwayat "X dari N petugas saat ini sudah menekan 'Saya mengerti'"; label penerima "petugas pendataan (korwil, PML, PPL)" (Siaran.tsx).
2. Target per PPL bilangan bulat (sisa terbesar, urut nama) di `lib/pendataanMonitor.ts`; jumlah target PPL tim = target tim; rata-rata tim tetap pecahan (`TimMon.target_per_ppl`). `MonProgres.tsx` tampil bulat + keterangan; tes `pendataanMonitor.test.ts` disesuaikan (Ani 22, Budi 21).
3. Korwil: catatan kaki "N Sub SLS unik; M dipegang lebih dari satu tim" (page.tsx) dan "daftar KK belum ada" untuk nagari/Sub SLS bertarget 0 (KorwilLapangan.tsx).
4. Setelah vitest user: `sigapFoto.test.ts` (>10 km = kuning, bukan merah) dan `kelola/delego/page.tsx` memakai klien bersama `@/lib/supabaseServer`.

## C. Menunggu keputusan
- Definisi "didata" di modul Beranda/tahap (`f.didata` termasuk tidak ditemukan; dipakai sebagai ukuran selesai). Pilihan: ubah teks jadi "sudah punya hasil", atau samakan ke definisi PPL berhasil. Tes `sigapTahap.test.ts:202` mengunci teks lama.
- Label penyebut petugas di layar lain selain Siaran (belum ada layar lain yang ditemukan menampilkan jumlah petugas tanpa label di kode yang saya baca).
- /dashboard tetap sesi login sendiri (Supabase Auth terpisah); penomoran tahap per peran dibiarkan (tes `sigapTahap.test.ts:58` menetapkan nomor berurutan tanpa celah).

## D. Laporan akhir ringkas (Tahap 1–3)
- Tahap 1: TombolKembali seragam + `?dari=` tervalidasi, Keluar simulasi, Kegiatan baru dobel dihapus, /bencana tombol kembali + loading, translok ?dari= + logo ke Beranda, tautan Kelola Pendataan ber-?dari=. Lihat `catatan-audit-navigasi-tahap1-tombol-kembali-23okt.md`.
- Tahap 2: kartu mati disembunyikan, daftar menu admin satu (chip peran bukan tautan), emoji → ikon garis, `BTN_T` + `PitaGeser`, chip Korwil tinggi tetap, "Monitoring Identifikasi", "Lembar Identifikasi SLS", ikon Transport Lokal pelatihan ≠ pendataan (`ikonKartu(kode, judul)` + `sigapIkonKartu.test.ts`). Lihat `catatan-audit-navigasi-tahap2-tautan-mati-ikon-23okt.md`.
- Tahap 3: lihat B.
- Pekerjaan user: `npx tsc --noEmit`, `npx vitest run`, `npm run build`; commit/push/deploy sekali; uji manual per peran (PML, PPL, Korwil, Admin) di HP.
