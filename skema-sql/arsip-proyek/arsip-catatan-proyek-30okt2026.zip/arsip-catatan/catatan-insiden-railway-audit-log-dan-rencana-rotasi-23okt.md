# Catatan 23 Okt 2026: insiden keamanan Railway, audit log Supabase, rencana rotasi kunci

## Latar
Railway mengumumkan (21 Okt, 22.10 UTC) bahwa pihak tidak berwenang mungkin mengakses environment variables pelanggan (sebagian sempat terdekripsi) dan menyarankan SEMUA pengguna mengganti seluruh variabel (kunci API, kredensial) lalu memeriksa log. Semua API token Railway dicabut 22 Okt 04.39 UTC. Build kembali normal 22 Okt malam; 23 Okt 08.09 UTC status: build/deploy normal, laporan insiden awal dijanjikan sekitar tengah hari EST 23 Okt. Deploy "update" kab-solok-dtsen (proyek Railway scintillating-compassion) sempat gagal karena galat KMS sisi Railway (bukan kode); deploy aktif tetap berjalan. Gagal-deploy tidak bisa di-redeploy lewat menu; pakai Ctrl+K > Deploy Latest Commit atau commit kosong.

## Hasil audit log Supabase (nlwkpakyfprugqwklxiu), 19-23 Okt 2026 (sampai 23 Okt ~08.38 UTC)
- Semua permintaan berkunci service_role (tanda tangan GIPqec, kunci legacy HS256 terbit ~10 Sep 2026) datang dari: Railway (AS Railway, SG) dan Google LLC (SG) -- keduanya pola egress aplikasi (UA node, supabase-js, runtime node 24.21.0), juga sebelum insiden (19-20 Okt).
- Pengecualian yang perlu dikonfirmasi user: dua IP Telkomsel Indonesia memakai service_role dengan runtime node 24.19.0 (BUKAN 24.21.0 milik Railway): 182.9.193.176 (19 Okt 23.21 UTC; 20 Okt 15.02-22.28 UTC; 22 Okt 12.12-12.14 UTC, 167 permintaan: alur masuk + data admin, termasuk 1 DELETE bencana_undangan_percobaan, 1 PATCH sigap_akun, 1 POST sigap_log_sesi) dan 182.9.200.85 (22 Okt 22.51 UTC, 127 permintaan, hanya baca + 1 RPC bencana_realisasi_otomatis + 1 POST sigap_aplikasi_pakai). Polanya sama seperti server dev lokal (npm run dev) memakai kunci produksi. Belum terkonfirmasi.
- Tidak ada percobaan masuk gagal ke database (tidak ada FATAL), galat Postgres hanya galat kueri biasa (kolom tidak ada, duplikat kunci). Tidak ada pg_cron job, tidak ada rahasia di Vault, tidak ada pg_net.
- Keterbatasan: log hanya menunjukkan IP/organisasi; penyerang yang memakai infrastruktur Railway/GCP tidak bisa dibedakan. Log tidak membuktikan kunci tidak bocor, jadi rotasi tetap dilakukan.

## Temuan sampingan (Edge Functions, 4 buah, verify_jwt=false)
- `bulk-create-operators` (sekali-pakai, komentar di kodenya: "HAPUS function ini setelah dijalankan sekali") memuat rahasia admin yang tertanam di kode. Usul: hapus fungsi (menunggu izin user).
- `setup-pin` memuat kode aktivasi bersama tertanam (sengaja dibagikan lewat surat edaran). Bisa diganti kapan saja dengan redeploy.
- `submit-usulan`, `jorong-info`: belum diperiksa isinya.
- Keempatnya memakai SUPABASE_SERVICE_ROLE_KEY bawaan Supabase; uji setelah kunci legacy dinonaktifkan.

## Rencana rotasi (urut; belum dijalankan)
Variabel kode di Railway: SUPABASE_SERVICE_ROLE_KEY (kritis; juga dasar penanda sesi SIGAP: lib/sigapAkses.ts), NEXT_PUBLIC_SUPABASE_ANON_KEY (publik, build-time), VAPID_PRIVATE_KEY/VAPID_PUBLIC_KEY, SIGAP_CRON_SECRET, PENYISIRAN_PIN, PENYISIRAN_IDENTIFIKASI_PIN, SIGAP_KODE_BROWSER, (SIGAP_WA_ADMIN nomor biasa), plus variabel lain di tab Variables yang tidak terlihat dari kode. Proyek sudah punya kunci publishable modern (`default`), jadi jalur kunci baru tersedia: buat sb_secret_ baru -> ganti di Railway -> redeploy -> verifikasi -> nonaktifkan kunci legacy.
1. Pastikan deploy Railway sehat. 2. Konfirmasi IP Telkomsel. 3. Inventaris pemakai kunci di luar Railway (laptop .env/.env.local, scripts/upload-peta.mjs & potong-peta.mjs, skrip/Apps Script lain). 4. Buat secret key baru di Supabase (API Keys). 5. Ganti variabel di Railway sekaligus, deploy sekali malam hari (semua sesi login berakhir; PIN petugas tidak berubah). 6. Verifikasi + cek log tidak ada 401/403 baru. 7. Setelah sehat, nonaktifkan kunci legacy (anon + service_role); pastikan tidak ada lagi permintaan dengan tanda tangan GIPqec. 8. Ganti kunci di laptop, hapus fungsi bulk-create-operators.
Dampak: semua pengguna SIGAP masuk ulang; VAPID baru = petugas aktifkan notifikasi ulang (opsional, bisa ditunda); PIN Penyisiran baru = bagikan ke pengguna.
