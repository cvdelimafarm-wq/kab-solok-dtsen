# Catatan: kartu "Translok lengkap / anomali" dan rekap anomali 14 Okt 2026 (diperiksa 15 Okt 2026)

Sumber: fungsi `bencana_monitoring_lapangan` + tabel pendataan/identifikasi/realisasi (hanya dibaca).

## Kartu 0 / 84, sebagian 0, tanpa klaim 12
- Itu tampilan HARI INI (15 Okt, pagi, belum ada hasil masuk): 96 baris petugas; 84 sudah memilih hari kerja, 12 belum.
- `statusTranslok` memberi "anomali" pada hari kerja tanpa hasil lapangan, termasuk hari berjalan. Jadi pagi hari semua 84 tampil anomali.
- Usulan (siap, diuji, BELUM dikirim ke laptop; berkas di /home/claude/work/tahan-lapangan): status baru "Menunggu hasil" khusus hari ini.

## Rekap 14 Okt: 45 anomali dari 84 hari kerja (39 punya hasil)
- PML 16: 7 PML sudah menuntaskan seluruh Sub SLS jatahnya sebelum 14 Okt (Budi Pernandes, Dessy, Hariston, Yurneti, Lia, Megawati, Yeni), jadi tak ada lagi yang bisa diidentifikasi; kerja 14 Okt = pengawasan yang tidak menghasilkan data -> anomali palsu. 13 dari 16 mengisi laporan + 5 foto; 3 tidak sama sekali (Ardial Jaraf, Hariston, Ilham). Ilham masih punya sisa 159 Sub SLS. 2 PML mencatat KK di Lembar Pendataan (10 pencatatan) tetapi penandaan KK oleh PML tidak dihitung (keputusan 11 Okt).
- PPL 29: 23 belum pernah satu pun KK tercatat di Lembar Pendataan sejak 10 Okt, namun 19 dari 29 mengisi laporan + 5 foto dengan angka 5-27 KK. Dugaan: pendataan di FASIH (tidak terbaca portal) atau hasil tertahan antrean offline di HP. 6 PPL pernah mencatat di hari lain tetapi tidak pada 14 Okt.
- 14 Okt: 748 pencatatan KK oleh 37 PPL (693 berhasil).

## Usulan (menunggu "setuju")
1. Status "Menunggu hasil" untuk hari berjalan.
2. PML: hari kerja tanpa hasil identifikasi bukan anomali (diperlakukan seperti korwil, laporan/foto menentukan), atau hanya bila Sub SLS jatahnya sudah tuntas.
3. Status "Perlu dicek": laporan memuat angka tetapi lembar kosong (selisih laporan vs lembar), terpisah dari anomali.
