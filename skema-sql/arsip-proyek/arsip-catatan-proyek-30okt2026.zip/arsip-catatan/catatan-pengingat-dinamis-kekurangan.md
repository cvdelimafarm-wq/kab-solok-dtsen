# Catatan hasil: pengingat dinamis "bagian yang belum lengkap" (14 Okt 2026)

Status: kode sudah ditulis ke folder laptop `13 Usul DTSEN` (belum di-commit git; user yang commit/push). Tanpa migrasi, tanpa hapus data.

## Yang berubah
- `lib/sigapKekurangan.ts` (baru, murni): daftar "kekurangan" per petugas (izin susulan, foto, laporan, lembar belum ada hasil, hari terlewat, pilih hari kerja) + skor prioritas. Sumber tunggal untuk kartu Beranda, Layer 2, langkah, dan (nanti) modal.
- Kartu "Tugas aktif"/"Kerjakan sekarang" kini dinamis: judul, uraian, tombol sesuai kekurangan teratas ("Unggah foto 3–5", "Periksa & simpan laporan", "Buka Lembar Pendataan"). Berlaku juga untuk kegiatan induk Pascabencana (`lib/sigapPrioritas.ts`).
- Tautan dalam `/sigap/translok/<token>?tab=&tgl=&fokus=` (whitelist): membuka tab/hari yang tepat, menggulir dan menyorot bagian foto/laporan (ring emas 6 dtk).
- Bila laporan hari ini belum ada hasil dari lembar: tombol menuju lembar sesuai peran (PML -> `/sigap/identifikasi`, PPL/korwil -> `/sigap/pendataan`). Sebelum jam 15 diarahkan ke lembar; sesudahnya ke formulir laporan.
- Hari terlewat hanya diingatkan 3 hari terakhir; ada tombol WhatsApp ke admin untuk izin susulan (butuh env `SIGAP_WA_ADMIN`).
- `hariDinilai` (lib/sigap.ts): laporan otomatis dari lembar dianggap ada saat menilai hari lengkap.
- Batas isian 500; bila angka beda dari lembar, Kendala/alasan wajib (min. 5 huruf).
- `tujuanLanjut` diperketat (anti open-redirect); sesi habis kembali ke halaman semula (`?lanjut=`); galat muat translok tidak lagi menghapus halaman.
- Tes: 176 lulus (13 berkas).

## Perlu tindakan
- Set `SIGAP_WA_ADMIN` di Railway (nomor admin anggaran; kosong = tombol WA tidak tampil). Nomor belum ditentukan.

## Belum dikerjakan (menunggu "setuju")
- Modal pengingat global + antrean modal, push terjadwal, `?sub=` Sub SLS prioritas, sisa U-09 (galat POST translok), U-16/U-12/U-13/U-02 penuh, N-04/N-06, S-01..S-04.

## Tahap lanjutan (15 Okt 2026)
Tes: 197 lulus (16 berkas). Berkas dikemas di pembaruan-15okt-2026.zip (laptop tidak terjangkau saat selesai; salin ke folder proyek).

- Modal pengingat dinamis: `app/portal/ModalPengingat.tsx` + `lib/sigapPengingat.ts`. Dipasang di Beranda. Sekali per kekurangan (kunci kode|judul), tunda 2 jam, maks 3/hari (mendesak boleh +2), hanya skor >= 70 dan bukan hari terlewat, hilang bila lengkap, tidak muncul saat mode simulasi / antrean offline menunggu / dialog lain terbuka. Status tersimpan di localStorage per akun (`sigap_pengingat_v1:<nama>`).
- Sub SLS prioritas: tombol lembar kini `?utama=1`. Pendataan membuka Sub SLS terakhir yang masih ada sisa, atau sisa KK terbanyak (`lib/sigapSubPrioritas.ts`); Identifikasi menampilkan filter "Belum". Alamat dirapikan dengan replaceState.
- U-09: POST translok (route, foto, dokumen) memakai `lib/sigapGalat.ts` (pesan umum ke HP, rincian di log server).
- Push terjadwal: `app/api/sigap/pengingat-push/route.ts` + `lib/sigapPushJadwal.ts`. Pagi 07.00 (izin, pilih hari kerja), siang 13.00 dan sore 17.00 (kekurangan hari ini, skor >= 72), malam 22.15 (mendesak). Maks 3 push/akun/hari, kekurangan sama tidak dikirim dua kali, jam senyap 23.00-05.59. Riwayat di `sigap_push_log` (jenis `pengingat_terjadwal`), tanpa migrasi.

### Pengaturan server yang dibutuhkan
- `SIGAP_CRON_SECRET` (acak, min. 16 karakter). `VAPID_PUBLIC_KEY`/`VAPID_PRIVATE_KEY` (sudah dipakai notifikasi pelatihan). `SIGAP_WA_ADMIN`.
- Railway Cron (POST dengan header `Authorization: Bearer <SIGAP_CRON_SECRET>`): `?slot=pagi` cron `0 0 * * *`; `?slot=siang` `0 6 * * *`; `?slot=sore` `0 10 * * *`; `?slot=malam` `15 15 * * *` (UTC). Tambahkan `&uji=1` untuk uji kering.
