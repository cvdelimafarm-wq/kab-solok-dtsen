# Batalkan keluarga baru di Lembar Pendataan (21 Okt 2026)

Pemicu: PPL (akun 91) menambah KK "GUSNIMAR" di Jorong Lubuak Aguang 01 (KK id 105047, 20 Okt 09.02 UTC) lewat tombol "+ Keluarga baru", padahal KK itu sudah ada di prelist (KK id 45613, keberadaan_awal 5, belum didata). Hasil tambahan sempat tercatat "terdampak".

## Yang dibuat
- Migrasi `20261021c_batalkan_keluarga_baru.sql` (SUDAH diterapkan ke Supabase): `bencana_pendataan_nonaktifkan(p_akun, p_kk, p_alasan)` sekarang boleh dipakai PML tim ATAU PPL penambah (selama Sub SLS masih wilayah timnya dan hasil belum ditimpa rekan). Hanya KK hasil tambah (ditambah_oleh_akun terisi); KK unggahan FASIH ditolak (`bukan_hasil_tambah`). Pembatalan lunak: aktif=false + nonaktif_oleh/at/alasan. Diuji dalam transaksi yang dibatalkan (tercatat, idempoten `sudah`, bukan_hasil_tambah, bukan_pml_tim, kk_tidak_ada).
- API: POST /api/portal/pendataan `{ aksi:"batalkan_baru", kk_id, alasan? }`; audit `pendataan.batal_kk_baru`.
- UI (app/sigap/pendataan/page.tsx): tiap kartu KK hasil tambahan di tab Daftar KK diberi lencana "Keluarga baru" + tombol "Batalkan + keluarga baru" dengan konfirmasi di tempat (Ya, batalkan / Tidak); tombol yang sama di lembar detail KK. Tersembunyi di mode perbaikan. Butuh sinyal (tidak lewat antrean offline). Setelah berhasil daftar KK dimuat ulang.
- Lib: `bisaBatalkanKkBaru`, `periksaBatalKkBaru` (lib/pendataan.ts), `batalkanKkBaru` + `daftarKk` kini menyertakan `ditambah_oleh_akun` (lib/portal/pendataan.ts). Tes: lib/__tests__/batalKkBaru.test.ts (11 tes; 48 lulus bersama pendataan.test.ts dan tambahKkLokasi.test.ts).

## Status
Kode disalin ke repo laptop, BELUM di-commit/deploy. Data Gusnimar (105047) belum diubah; setelah deploy bisa dibatalkan lewat tombol, lalu 45613 ditandai sesuai kenyataan.
