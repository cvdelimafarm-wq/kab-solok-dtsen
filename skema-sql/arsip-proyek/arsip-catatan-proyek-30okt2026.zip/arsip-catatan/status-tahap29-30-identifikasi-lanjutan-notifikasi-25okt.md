# Status tahap 29 dan 30: identifikasi lanjutan, dokumen turunan, notifikasi, keputusan KPA (25 Okt 2026)

Status: selesai dibangun dan lulus uji lokal. BELUM dideploy dan BELUM diuji di produksi. Berkas kode belum sampai ke laptop karena laptop tidak terhubung ke sesi saat berkas ini dibuat; semua berkas sudah ada di Project dan siap ditaruh begitu laptop tersambung.

## Tahap 29: identifikasi lanjutan dan dokumen turunan
Halaman `/sigap/kelola/perencanaan/identifikasi/[id]/lanjutan` (tautan dari halaman identifikasi awal yang sudah sah).
- Isi lanjutan satu jsonb per identifikasi: wilayah tugas; kelas briefing dan pelatihan (periode, metode, tempat, nama dan alamat tempat, paket, OH, tanggal, peserta per peran, Fix/Perkiraan); jumlah per peran (organik, mitra, translok, penginapan, Fix/Perkiraan); daftar petugas (nama atau menyusul, peran, organik/mitra, sumber mitra kepka/seleksi, petugas baru, jabatan).
- Status otomatis: Final bila semua kelas Fix, semua jumlah peran Fix, jumlah tercatat sama dengan jumlah peran, dan tidak ada nama menyusul; selain itu Draf. Alasan Draf tampil dan dapat diklik menuju kartunya.
- Tiap penyimpanan yang mengubah isi membuat versi baru (salinan tidak berubah). Versi mencatat versi identifikasi awal dasar, lembar kebijakan yang berlaku, dan penanda sesudah H-15. Perubahan pada lanjutan Final sesudah H-15 wajib beralasan (minimal 10 huruf).
- Peringatan terhadap lembar kebijakan (minimal per jabatan, rangkap, persen petugas baru, maks. peserta kelas, hotel luar kota) tidak memblokir.
- Rincian kebutuhan dan biaya: jumlah rupiah hanya muncul bila volume dan tarif sama-sama diketahui; sisanya tampil dengan catatan. Angka belum sah.
- Dokumen turunan (halaman `.../lanjutan/dokumen?jenis=&kunci=`): undangan per kelas, satu surat pengantar nagari, surat tugas (organik) atau SPK (mitra) per petugas. Nomor surat diisi manual, penandatangan dipilih per dokumen (Kepala, PPK, Tata Usaha, ketua tim RO), konsep bertanda air "KONSEP", terbit hanya bila lanjutan Final, dapat dicabut dengan alasan. Cetak lewat tombol cetak peramban.
- SQL: `20261025zf` (tabel keu_ident_lanjutan, _versi, keu_ident_dokumen; pemeriksa dan penentu status kembaran TS; fungsi keu_lanjutan_simpan dan keu_ident_dokumen_simpan; tampilan keu_v_ident_lanjutan, _versi, keu_v_ident_petugas, keu_v_ident_dokumen, keu_v_ident_ttd) dan cek kesehatan `zg`.

## Tahap 30: notifikasi, keputusan KPA, pintu hilir
- Notifikasi otomatis (pemicu basis data), penerima menurut peran aktif:
  - Lanjutan bergeser dari Draf ke Final sebelum H-15: PPK, TU, Bendahara, KPA, PBJ. Bila RO tidak punya PBJ, PPK menggantikan.
  - Lanjutan dibuat atau diubah sesudah H-15: KPA dan PPK.
  - Nama petugas yang semula menyusul terisi: PPK (cukup tercatat dan diberi tahu, tanpa persetujuan penuh).
  - Lembar kebijakan menunggu pengesahan: setiap pengesah yang belum menyetujui.
  - Pengecualian diajukan: KPA. Keputusan KPA: pengaju dan PPK.
- Halaman `/sigap/kelola/perencanaan/notifikasi` (daftar, tandai dibaca, tandai semua) dan lencana jumlah belum dibaca pada judul halaman Identifikasi, Kebijakan, dan Lanjutan. Tidak ada butir menu sidebar baru.
- Keputusan KPA (`keu_pengecualian`): setiap versi lanjutan sesudah H-15 otomatis membuat permintaan keputusan KPA (setuju/tolak + catatan; tolak wajib catatan). TIDAK memblokir: versi tetap dibaca modul hilir (diuji). Pengecualian pelanggaran kebijakan atau rangkap yang disengaja diajukan manual dengan alasan, dapat ditarik pengaju, diputus hanya oleh KPA; peringatan yang dikecualikan diberi tanda. Semua tercatat di riwayat identifikasi dan menjadi bahan evaluasi.
- Pintu baca hilir `keu_v_ident_acuan`: identifikasi sah, form sah, lanjutan terbaru bila ada (sumber 'lanjutan' atau 'awal'), versi lembar kebijakan yang dipakai. Kartu "Dibaca modul hilir" di halaman lanjutan meringkas apa yang akan diambil RAB/revisi, draf pengadaan, rencana realisasi, rekrutmen, Delego dan evaluasi, serta Bendahara, dengan versi sumbernya.
- SQL: `20261025zh` dan cek kesehatan `zi`.

## Penyimpangan dari rancangan V1 (perlu diketahui)
1. Pembaca hilir baru berupa pintu data dan ringkasan di layar. Modul RAB, pengadaan, rencana realisasi, rekrutmen, Delego, dan Bendahara belum diubah agar membaca pintu itu; itu dikerjakan per modul pada tahap 31 dan sesudahnya.
2. `keu_gap` (temuan) belum dibangun: pengisinya adalah peringatan pelaksanaan (tahap 32), jadi tabelnya dibuat bersama produsernya. Peringatan keras ke PPK mengikuti tahap itu.
3. `keu_kebijakan_rujukan` (tabel SBM penginapan dan matriks SK transport) belum dibangun karena berkas rujukan belum diunggah pengguna. Baris rincian terkait tampil dengan catatan "tarif belum tersedia".
4. Persetujuan KPA atas perubahan sesudah H-15 diputuskan: keputusan dicatat, tidak memblokir (jawaban pengguna 25 Okt 2026).
5. Notifikasi juga dikirim kepada pelaku bila pelaku sendiri memegang peran penerima (tidak dikecualikan), agar uji dengan satu akun fiktif tetap bermakna.

## Butir yang masih terbuka
- Kota pada kepala surat memakai "Arosuka" (asumsi; ubah di `Kertas` bila tidak tepat) dan susunan surat bersifat konsep karena format baku kantor belum ditetapkan.
- Jabatan bawaan penandatangan (Ketua Tim, Pejabat Pembuat Komitmen, Kepala BPS Kabupaten Solok, Tata Usaha) dapat diubah pada tiap dokumen.
- Arti singkatan SPKL; dasar aturan uang harian dan translok; honor instruktur 522151 atau 521213-C; berkas SBM penginapan, paket fullday/fullboard, matriks SK transport.
- Peran PBJ ada di produksi (lingkup RO); penerima PBJ dialihkan ke PPK bila RO tidak punya PBJ.

## Verifikasi
- Basis data lokal (Postgres 16 dengan stub skema): zf, zh dijalankan dua kali (idempoten); `51_uji_lanjutan` LULUS; `52_uji_notifikasi` LULUS; `50_uji_kebijakan` tetap LULUS; cek kesehatan zg dan zi semua p0 = 0.
- vitest: lanjutan, lanjutanDokumen, notifikasi, baca lulus (paritas TS–SQL dijaga 71 kasus bersama); tsc bersih di luar galat lama lib/sigap.ts dan lib/keu/rab.ts pada salinan kerja; render server semua kartu dan surat tanpa galat.
- Produksi: BELUM.

## Langkah deploy
1. Supabase SQL Editor, berurutan: `Pengisiran\SQL\Tahap29\1_20261025zf_...sql`, `2_..zg..` (p0 semua 0), `Pengisiran\SQL\Tahap30\1_20261025zh_...sql`, `2_..zi..` (p0 semua 0).
2. Laptop: `npm test; npx tsc --noEmit; git add .; git commit; git push`, tunggu Railway selesai, ketik "sudah deploy".
3. Claude menguji produksi (akun IH, data fiktif): lanjutan Draf lalu Final, versi, dokumen konsep/terbit/cabut, keputusan KPA, notifikasi; lalu menutup tab dan tidak meninggalkan data berlaku.
