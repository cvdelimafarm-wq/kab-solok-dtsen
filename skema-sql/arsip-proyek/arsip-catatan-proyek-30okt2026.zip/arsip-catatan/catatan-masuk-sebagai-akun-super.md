# Fitur "Masuk sebagai" untuk akun super (10 Okt 2026; diubah 11 Okt 2026 menjadi SIMULASI)

## PERUBAHAN 11 Okt 2026 (berlaku sekarang)
Keputusan user: "hanya lihat, tapi usahakan saya bisa simulasi pengisian seperti upload foto atau mengetik identifikasi dll. tapi datanya tidak dikirim".
- `app/portal/simulasi.ts` (baru): dipasang sejak modul dimuat (diimpor BannerLihatSebagai di layout). Dalam mode "masuk sebagai", fetch/XMLHttpRequest/sendBeacon non-GET ke `/api/*` atau unggah langsung ke Supabase Storage TIDAK dikirim; pemanggil menerima jawaban tiruan 200 `{ ok: true, simulasi: true }`. Pengecualian: `/api/sigap/masuk` (Ganti/Kembali) dan `/api/portal/sso`. Tiap penulisan yang ditahan memicu event `sigap-simulasi` → catatan kecil di bawah spanduk.
- `middleware.ts` (lapis kedua, server): matcher kini juga `/api/:path*`; penulisan dengan sesi 4 bagian (`akunId.exp.aktorId.tanda`) dijawab tiruan tanpa diteruskan ke route (pengecualian sama).
- Identifikasi: tombol Simpan aktif; `kirimAtauAntre` dalam mode simulasi hanya menerapkan hasil ke simpanan lokal (tampil tersimpan), tidak masuk antrean, tidak dikirim. `kirimAntrean` tidak berjalan saat simulasi.
- Teks diseragamkan: spanduk "simulasi, tidak ada data yang dikirim"; pemilih akun & halaman identifikasi menyebut mode simulasi.
- Perbaikan sesi: sesi asli yang kedaluwarsa kini ditimpa saat masuk sebagai (dulu "Ganti" diam & "Kembali" mengeluarkan akun); login biasa membuang semua `sigap_sesi_asli*`/`sigap_lihat_sebagai` (`hapusLihatSebagai`); spanduk hanya tampil bila sesi aktif sah; "Ganti" tanpa sesi asli menampilkan pesan + tombol Masuk lagi; ganti/kembali akun membuang `sigap_cache_v2`; 401 di mode ini kembali ke akun super (sesi asli tidak ikut dihapus).
- Batas: layar yang mengharapkan isi jawaban tertentu sesudah menyimpan (mis. foto translok) bisa tidak berubah setelah "simpan" simulasi karena jawaban tiruan tidak berisi data.

## Cara kerja dasar (10 Okt 2026)
- Penanda `sigap_akun.super boolean` (migrasi `20261010a_sigap_akun_super.sql`; true hanya untuk akun 354). Cabut: `update sigap_akun set super=false where id=354`.
- Sesi biasa `akunId.exp.tanda`; sesi "masuk sebagai" `akunId.exp.aktorId.tanda` (aktor ikut ditandatangani HMAC). Fungsi di `lib/sigapAkses.ts`: `bacaSesiLengkap`, `sesiLengkapDariHeader`, `aktorDariHeader`; `buatSesi(akunId, aktorId?)`.
- API `/api/sigap/masuk`: `masuk` mengembalikan `super`; aksi `daftar_sebagai` dan `masuk_sebagai` (butuh sesi akun super; dicatat di `sigap_audit`). Ganti PIN ditolak selama mode ini. `/api/portal/identifikasi` POST menolak sesi beraktor.
- Klien: `app/portal/PilihSebagai.tsx`, `app/portal/Masuk.tsx`, `app/portal/sesi.ts` (`sigap_sesi_asli`, `sigap_lihat_sebagai`), `app/components/BannerLihatSebagai.tsx` (dipasang di `app/layout.tsx`).
