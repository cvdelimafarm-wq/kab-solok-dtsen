# Catatan mockup Kertas Kerja Revisi POK, tahap 7 (24 Okt 2026)

Status: MOCKUP saja (artifact Design, Versi 36). Belum ada SQL atau kode aplikasi sampai Pak Iqbal menyatakan "setuju".

## Permintaan dan hasil
1. Kolom Satuan pada blok MENJADI (tab Kertas kerja): kolom "Sat" ditambahkan setelah Vol dan sebelum Harga. Isinya kolom ketik dengan daftar saran satuan (set, OK, OJP, PAKET, dan lainnya), awalnya sama dengan satuan Semula. Bila diubah, sel diberi tanda perubahan seperti kolom Menjadi lain. Header kolom punya cari, urut, dan filter seperti kolom lain. Judul grup MENJADI kini mencakup 4 kolom, grup PERUBAHAN dan KETERSEDIAAN bergeser satu kolom. Tombol "Kembali ke semula" ikut mengosongkan satuan yang diubah.
2. Judul kolom tab RAB: ikon urutkan dihapus dari semua kolom; cari dan filter tetap ada. Tombol pembersih menjadi "Hapus filter kolom".

## Catatan
- Satuan Menjadi pada mockup hanya tersimpan di tampilan; aturan R-02 (satuan RO tidak berubah) mengenai satuan RO, bukan satuan item, sehingga tidak terpengaruh. Di aplikasi nyata perubahan satuan item perlu masuk kolom Menjadi pada skema revisi (butuh keputusan Pak Iqbal).
- Pengujian: keseimbangan tag, kunci template, uji alur bilah dan modal lulus; tampilan peramban belum diverifikasi.
