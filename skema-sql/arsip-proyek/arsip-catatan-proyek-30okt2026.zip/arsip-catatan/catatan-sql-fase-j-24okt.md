# Catatan SQL Fase F (berkas j): catatan kekurangan RAB dan tambahan pagu
Tanggal 24 Okt 2026. Berkas: `20261024j_keu_kekurangan.sql` (migrasi), `20261024z5_cek_kesehatan_keu_j.sql` (cek baca-saja), uji `42_uji_kekurangan.sql`, pelari `jalan_j.sh`. Belum dijalankan di produksi.

## Cara menjalankan di produksi
1. Pasang berurutan bila belum: h (45 tabel), i (48 tabel), lalu `20261024j_keu_kekurangan.sql` (aman diulang).
2. Jalankan `20261024z5_cek_kesehatan_keu_j.sql`: baris 1 sampai 9 harus 0, baris 14 harus 51.
3. Jalankan `20261024z_cek_kesehatan_keu.sql` yang baru: baris 4 harus "51 dari 51".

## Isi
- Tiga tabel: `keu_kekurangan` (catatan), `keu_tambahan_pagu` (tambahan pagu resmi per RO), `keu_kekurangan_putus` (riwayat keputusan, hanya bertambah).
- Alur catatan: tercatat, lalu ditunda (tetap terbuka), dipenuhi, ditolak, atau ditarik. Yang sudah dipenuhi, ditolak, atau ditarik beku; hanya penautan ke item RAB yang masih bisa diisi (sekali).
- Alur tambahan pagu: terbuka, lalu diputus atau dibatalkan. Hanya satu tambahan terbuka per RO; nomor dokumen kembar pada jalur dan RO yang sama ditolak.
- Fungsi: `keu_kekurangan_catat`, `keu_kekurangan_ubah`, `keu_kekurangan_tarik`, `keu_tambahan_pagu_catat`, `keu_tambahan_pagu_batal`, `keu_kekurangan_saran` (K4), `keu_kekurangan_putuskan`, `keu_kekurangan_tautkan_rab`.
- View: `keu_v_kekurangan`, `keu_v_kekurangan_ro` (ringkasan per RO, termasuk tambahan yang menunggu), `keu_v_kekurangan_kro` (per KRO dan kelompok belanja, bahan PPK untuk D-15), `keu_v_tambahan_pagu`.

## Aturan yang dipaksa basis data
- Mencatat, mengubah, menarik: kewenangan `kek_catat` pada RO itu (ketua tim dan admin RO). Anggota tim, bendahara, PPK yang bukan ketua RO itu ditolak (D-07).
- Mencatat atau membatalkan tambahan pagu: PPK (kewenangan `sahkan`), dengan nomor dokumen, tanggal, dan jalur DJA atau DJPb; jadwal revisi, bila diisi, harus berjenis sesuai jalur.
- Memutuskan: kewenangan `kek_putus` pada RO itu (ketua tim). Satu panggilan harus mencakup SEMUA catatan terbuka RO itu (termasuk yang pernah ditunda); id ganda atau dari RO lain ditolak; tolak wajib alasan minimal 5 huruf; total yang dipenuhi tidak boleh melebihi tambahan (penggenap tidak minus). Semua atau tidak sama sekali.
- Sisa tambahan dicatat sebagai `sisa_penggenap` pada tambahan itu. SIGAP tidak menulis baris RAB atau POK; aplikasi memakai angka ini saat menyusun baris dana penggenap, dan catatan dipenuhi ditautkan ke item RAB buatan ketua tim (akun dan RO harus sama).
- Saran urutan: prioritas (urutan di Master), lalu tanggal catat; ambil bila masih muat, seperti mockup. Hanya saran, tidak mengikat.
- Dari aplikasi tidak ada DML langsung; status berubah hanya lewat fungsi alur (juga dari editor SQL).

## Keputusan saya yang perlu Anda tinjau
1. Satu tambahan terbuka per RO supaya tidak ambigu tambahan mana yang diputuskan. Bila dua surat revisi datang berdekatan, jumlahkan atau putuskan yang pertama dulu.
2. Memutuskan harus sekaligus untuk semua catatan terbuka (mengikuti mockup yang memblokir bila ada yang belum diputuskan).
3. PPK tidak memutuskan catatan kecuali merangkap ketua tim RO itu (sesuai matriks kewenangan yang ada).
4. Komponen pada catatan opsional (mockup tidak memuatnya); tahun mengikuti POK berlaku terbaru.

## Hasil uji (basis data uji, bukan produksi)
Rangkaian a-f, h, uji 40, i dan uji 41, lalu j (dua kali) dan uji 42 lulus; z5 baris 1 sampai 9 nol. Uji 42 memeriksa: hak catat dan tarik (6 akun), validasi isian, catatan kembar, ubah sebagian, tarik dan catat ulang; tambahan pagu (hak, validasi, jadwal tak sesuai, satu terbuka per RO, batal, catat ulang); saran urutan; keputusan (10 jenis penolakan tanpa efek samping, lalu penuhi/tolak dengan sisa Rp 360.000); siklus tunda lalu penuhi pada tambahan berikutnya (riwayat tunda,penuhi); tambahan tanpa catatan; penautan RAB; rekap KRO; larangan DML langsung dan pembekuan; RLS, hak, audit.
