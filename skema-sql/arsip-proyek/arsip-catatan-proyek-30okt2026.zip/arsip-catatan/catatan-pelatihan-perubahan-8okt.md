# Perubahan Pelatihan 8 Okt 2026 — langkah foto, filter monitoring, tab Administrasi

Melengkapi claude/modul-sigap-pelatihan.md (bagian Langkah & Admin Monitoring di sana adalah kondisi 7 Okt; yang di bawah ini menggantikannya).

## Langkah foto Transport Lokal dipecah (halaman peserta /sigap/pelatihan)
- Urutan Langkah kini 1–7: baca undangan · pelajari instrumen · pretest · presensi · **unggah 3 foto sebelum Posttest** (slot 1–3: Berangkat, Tiba di lokasi, Kegiatan) · posttest · **unggah 2 foto sesudah Posttest** (slot 4–5: Pulang, Tiba di rumah).
- Tiap foto boleh diunggah satu per satu (halaman /sigap/translok/<token> memang per slot); batas 23.59 WIB hari yang sama. Kotak pemandu & progres ("x dari 7") ikut menyesuaikan.
- Kode: FOTO_SEBELUM_POSTTEST = 3 dan bagiFoto(total) di lib/sigapPresensi.ts; langkah baru kode foto_awal / foto_akhir di app/sigap/pelatihan/page.tsx. Tidak ada perubahan DB.

## Monitoring Pelatihan: filter seragam + judul kolom berfilter
- Berkas baru app/sigap/pelatihan/kelola/monitorKit.tsx (BarFilterMonitoring, ThKontrol, useFilterMon, urutkan).
- Keempat sub-tab (Pretest & Posttest, Akses Pelatihan, Presensi, Transport Lokal) memakai bar filter yang sama: Jenis (Organik/Mitra) · Kelas · Peran · Status · Cari nama · Reset, plus keterangan "menampilkan N dari M peserta".
- Judul kolom berfilter seperti tabel Bencana › Alokasi Petugas/Kegiatan Petugas: 🔍 cari (kolom Nama), ⋮ urut naik/turun + filter centang (Terapkan). Header dan bar memakai state yang sama.
- Kartu angka di sub-tab Akses/Presensi/Transport Lokal mengikuti filter Jenis/Kelas/Peran/Nama (bukan status). Akses: filter Kecamatan, bawaan "Belum akses". Transport Lokal: status tambahan "foto sebelum/sesudah posttest belum lengkap", kolom foto "3 | 2".
- API admin/kehadiran kini mengirim jenis_akun (presensi, translok, akses).
- Diuji Playwright (data contoh): filter bar & header, urut, cari, reset; langkah foto tampil 7 langkah.

## Tab "Administrasi" di Kelola Pelatihan (8 Okt 2026, mockup disetujui user)
Fungsi: panitia/instruktur kelas memantau status pengisian Transport Lokal peserta, mencetak SPJ 6 jenis (checkbox per jenis) untuk semua/sebagian petugas, menambah peserta manual dari gabungan Mitra+organik, dan mencetak kelengkapan pelatihan: Daftar Hadir (otomatis dari presensi), Form Daftar Hadir TTD basah (kosong), Laporan Pelatihan, Laporan Pelatihan Instruktur. Keluaran: PDF gabungan atau ZIP per petugas.
- **Izin & cakupan**: menu baru `pelatihan.administrasi` (kelola: Admin Anggaran, PJ Kegiatan, Admin Aplikasi, Instruktur Pelatihan, Panitia Pelatihan; lihat: Bendahara). Akun yang HANYA berperan Instruktur Pelatihan = kelas miliknya (tabel sigap_kuis_instruktur_kelas); peran lain = semua kelas.
- **Kelas instruktur (update 8 Okt)**: Nurafiza (464) kelas 1 · Iqbal (354) kelas 2 · Faisal (200) kelas 3 · Anggun (49) kelas 4. Anggun belum punya akun/PIN (belum bisa login).
- **Peran baru `panitia_pelatihan`** (akses semua kelas; pelatihan.kelola = lihat): Oryza Maria Ulva (478), Alex Kandria (23), Wisnu Dwi Jayanto (710; satu-satunya Wisnu di data).
- **Peserta manual** = sigap_penugasan.sumber='administrasi' + 1 baris sigap_hari_kerja pada 2026-10-08; dikecualikan dari tes/kuis/presensi/monitoring lewat FILTER_BUKAN_ADMINISTRASI (lib/sigapTesDb.ts). "Keluarkan" hanya menonaktifkan (aktif=false), tidak menghapus. Batasan: UNIQUE(akun_id, tanggal) pada sigap_hari_kerja — akun yang sudah punya hari kerja 8 Okt di kegiatan lain tidak bisa ditambahkan.
- **Narasi laporan** disimpan di tabel baru sigap_pelatihan_laporan (per kelas & jenis: ringkasan, kendala, catatan). Narasi kosong dicetak sebagai garis untuk tulis tangan.
- **Berkas**: migrasi 20261008d_sigap_pelatihan_administrasi.sql (sudah diterapkan ke DB); lib/pdf/sigap/pelatihan.ts (4 generator); lib/sigapAdministrasi.ts (cakupan, status translok, data laporan, buatCetak); app/api/sigap/pelatihan/administrasi/route.ts; app/sigap/pelatihan/kelola/administrasi.tsx; tab ditambahkan di kelola/page.tsx; filter di lib/sigapTesDb.ts, pelatihan/admin/route.ts, admin/kehadiran/route.ts.
- SPJ memakai mesin buatSpjPdf (lib/sigapDokumen.ts) — hasil identik dgn Verifikasi & Kunci, berkas beku dipakai bila sudah dikunci.
- **Lampiran foto kegiatan (8 Okt 2026, SUDAH ADA)**: panel "Foto kegiatan" di bawah narasi pada tab Administrasi — panitia/instruktur kelas mengunggah foto (maks 8 per kelas, maks 15 MB/foto, keterangan opsional, bisa ubah keterangan & hapus). Foto dirapikan di server (sharp: rotasi EXIF, maks 1600 px, JPEG q80), disimpan di bucket privat sigap-files path pelatihan-laporan/<kegiatan>/<kelas>/. Satu set foto per kelas dipakai KEDUA laporan (Laporan Pelatihan & Laporan Pelatihan Instruktur), dicetak sebagai halaman "LAMPIRAN FOTO KEGIATAN" (grid 2 kolom × 3 baris, caption bernomor). Tabel: sigap_pelatihan_laporan_foto (migrasi 20261008e_sigap_pelatihan_laporan_foto.sql, sudah diterapkan). API: app/api/sigap/pelatihan/administrasi/foto/route.ts (POST multipart, DELETE ?id, PATCH keterangan) + GET bagian=foto di administrasi/route.ts; helper siapkanAdministrasi/kelasBoleh ada di lib/sigapAdministrasi.ts.
- Belum ada (v1): hasil Adu Sigap (kuis) pada laporan; Surat Tugas untuk peserta manual (SPJ-nya dilewati dgn catatan "belum ada Surat Tugas").
