# Unggah daftar KK dari ekspor FASIH-SM (11 Okt 2026)

Pelengkap `rancangan-pendataan-keroyokan.md`. Pengguna mengunggah CSV ekspor FASIH-SM "1303 - Pendataan" (prelist keluarga DTSEN) sebagai sumber daftar KK; sistem menyaring otomatis.

## Keputusan pengguna
- Penyaringan otomatis: hanya Sub SLS sampel DAN Keberadaan_Keluarga = 1 (Ditemukan), 2 (Baru), 5 (Tidak dapat ditemui sampai akhir pendataan), 6 (Keluarga khusus). Status 0 (Tidak Ditemukan/STOP), 3, 4 dilewati.
- "Sub SLS sampel" = daftar awal di master wilayah (`bencana_wilayah.daftar_awal = true`, 636 dari 1.084). Konsekuensi: contoh CSV (Surian / Lubuk Rasam, 1303040001000100) bukan daftar awal sehingga akan disaring keluar; 23 Sub SLS yang sudah punya tim tetapi bukan daftar awal juga keluar (dari 150 Sub SLS ber-tim, 127 daftar awal).
- Kolom yang dikirim ke server hanya yang dipakai lembar: IDSUBSLS, ASSIGNMENT_ID, Nama_Kepala_Keluarga + nama setelah "/" pada Nama_Keluarga_FasihSM (anggota lain), nomor urut dari Kode_Identitas ("... - DTSEN - 15"), Alamat_Domisili (patokan), Geotag, kode keberadaan awal. NIK, Nomor KK, tanggal lahir, pendapatan, kondisi rumah dibuang di peramban.

## Keanehan format ekspor (sudah ditangani di `lib/pendataan.ts`)
- Baris yang kolom catatannya bertanda kutip dibungkus satu kali lagi (seluruh baris di dalam "..." dengan kutip digandakan); pembaca CSV biasa melihatnya sebagai satu kolom. `bacaCsvFasih` membuka bungkus dan menyambung catatan berbaris-baru.
- Kode diawali apostrof (`'1303040001000100`, juga NIK/KK/Geotag). Geotag = `'-1.30,100.98`.
- Awalan status tidak seragam ("1. Ditemukan"); "Tidak Ditemukan" memuat kata "Ditemukan", jadi awalan angka didahulukan.
- Koordinat rusak atau di luar Kab. Solok tidak menggugurkan KK; KK masuk tanpa titik.

## Skema
Migrasi `20261011b_pendataan_kk_kolom_sumber.sql` (diterapkan): `bencana_pendataan_kk.sumber_id` (ASSIGNMENT_ID), `no_urut`, `keberadaan_awal`; indeks unik (kegiatan_id, sumber_id) untuk baris aktif. Unggah ulang ekspor yang lebih baru MEMPERBARUI nama/alamat/koordinat KK yang sama tanpa menyentuh hasil pendataan; ID penugasan yang pindah Sub SLS ditolak. KK yang di ekspor baru berubah menjadi status tersaring tidak otomatis dinonaktifkan (belum ada aturannya).

## Status
Kode ditulis dan disalin ke repo laptop, belum di-commit/deploy. 32 uji lulus; contoh CSV pengguna (9 baris, 7 diterima, 2 STOP) terbaca benar sebelum disaring daftar awal.
