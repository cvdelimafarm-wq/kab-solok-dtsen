# Berbagi foto Kamera SIGAP dibuka sampai H+1 (26 Okt 2026)

Permintaan M. Iqbal Hadi: fitur berbagi foto dibuka paling lama sampai H+1, sehingga pada H+1 petugas masih bisa berbagi foto. Belum di-deploy.

## Perubahan
- `lib/sigapFoto.ts`: `BATAS_HARI_BAGI = 1` dan `jendelaBagiFoto(tanggalFoto, hariIni)` (memakai `dalamToleransiKirim`).
- `app/api/sigap/foto/tag/route.ts`: pemotret menambah tag hanya bila tanggal foto masih dalam H..H+1 (403 bila lewat).
- `app/api/sigap/foto/tag/keputusan/route.ts`: penerima tag (tim / luar tim) menekan Terima dengan `cekAksesIsian(..., { toleransiOfflineHari: BATAS_HARI_BAGI })`, jadi alasan "terlewat" (23.59 WIB hari foto) dilonggarkan sampai akhir H+1. Hari kerja, kunci SPJ/arsip, dan periode tetap berlaku. Tag pemotret untuk nomor fotonya sendiri TIDAK dilonggarkan. Menolak tag tidak dibatasi.
- `lib/__tests__/sigapFoto.test.ts`: 2 tes baru (51 tes lulus).
- Tanpa perubahan SQL: `sigap_foto_tempatkan` tidak punya batas waktu sendiri.

## Catatan
- Penerima yang menerima pada H+1 tidak ditandai "susulan" (sama seperti foto tanpa sinyal).
- Batas H+2 dan seterusnya tetap butuh izin susulan admin.
