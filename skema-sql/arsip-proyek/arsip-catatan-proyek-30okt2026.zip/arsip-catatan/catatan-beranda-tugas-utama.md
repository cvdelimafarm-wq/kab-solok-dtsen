# Beranda HP: tugas utama + ikon cepat (8 Okt 2026)

Permintaan user (dengan tangkapan layar beranda lama): saat pertama login tampilkan menu/navigasi yang paling berhubungan dan mendesak, tampilan mengikuti mockup poin 3 "Tugas utama + ikon cepat" (kanvas Konsep Ikon SIGAP > Beranda HP variasi kartu).

## Tampilan
- Header gradasi navy: petak logo, SIGAP + kepanjangan, avatar inisial emas, tombol Keluar; tanggal (WIB), "Halo, {nama tanpa gelar}", chip peran satu baris yang bisa digeser.
- Kartu putih menimpa header: label emas (mis. TUGAS HARI INI), lencana waktu (mis. "sisa 02:34", "tutup 21.00"), petak ikon gradasi biru, judul + uraian, bar progres bersegmen, satu tombol biru penuh.
- "Menu": ikon cepat 4 kolom (petak putih 56 px, titik emas = ada tugas aktif), urut: tugas yang sama dengan kartu utama, tugas lain, referensi, riwayat (diredupkan). "Pengelolaan": ikon cepat untuk admin.
- Kartu notifikasi hijau dipindah ke bagian bawah; spanduk PIN awal 1303 tetap muncul di bawah kartu utama.

## Pemilihan tugas utama (`lib/sigapTugasUtama.ts`, 17 uji lolos)
Skor tertinggi menang. Pelatihan: kuis live 100 > tes sedang dikerjakan 98 > tes dibuka 92 > presensi sesi dibuka 90 > foto kurang pada hari pelatihan 80 > baca undangan 60 > pelajari instrumen 55 > tes menyusul 40 > semua selesai 10. Kegiatan lain dari kartu beranda: Transport Lokal 50 (masa tenggang 45), bencana 48, penyisiran 42, operator DTSEN 41; arsip dan "belum mulai" bukan tugas mendesak. Tanpa tugas: "Tidak ada tugas mendesak".
Data pelatihan diambil klien dari `/api/sigap/pelatihan` (jam server dipakai untuk sisa waktu), disegarkan tiap menit saat layar terlihat; gagal -> beranda tetap jalan.
Menu pelatihan ditambahkan di sisi klien: peserta -> Langkah pelatihan, Undangan, Instrumen; pengelola -> Kelola Pelatihan (sebelumnya beranda portal tidak punya kartu pelatihan).

## Berkas
`app/portal/Beranda.tsx` (ditulis ulang), `app/portal/IkonMenu.tsx` (baru, ikon garis), `lib/sigapTugasUtama.ts` (baru).

## Belum
Belum diuji di HP. Tugas Transport Lokal memakai status periode (belum membaca kelengkapan laporan harian). Perlu commit + push + deploy.
