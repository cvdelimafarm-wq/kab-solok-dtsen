# Catatan: Login lebih jelas, saran nama, ganti PIN 1303 (8 Okt 2026)

## Latar
28 dari 29 pegawai organik masih memakai PIN awal bersama 1303. Sebagian pegawai gagal login karena nama yang diketik tidak persis, dan pesan galat lama ("Nama atau PIN salah...") tidak menyebut penyebabnya.

## Yang dibangun
- **Saran nama (typeahead)** di kolom nama halaman Masuk: ketik 3 huruf, muncul maks 8 nama (hanya nama + label Pegawai/Mitra). Memilih saran = login ke akun itu lewat `akun_id`. Tanpa memilih: teks dicocokkan longgar (nama penuh -> tanpa gelar -> bagian nama yang hanya cocok ke 1 akun); bila >1 akun cocok, diminta memilih.
- **Pesan galat per penyebab** (`kode` + `error` dari server, teks di `lib/sigapMasukNama.ts`): nama_tidak_ditemukan (TIDAK menghitung percobaan), nama_ambigu (+ daftar saran), pin_belum_dibuat (TIDAK menghitung), pin_salah (sisa percobaan dari 5), terkunci (jam buka kunci WIB, 30 menit), sementara_kedaluwarsa, belum_ditugaskan (PIN benar tapi belum punya tugas/peran).
- **Ganti PIN 1303 cepat**: layar `app/portal/GantiPinCepat.tsx` (dua kolom 4 digit, tersimpan otomatis begitu sama, tombol "Nanti saja"). Muncul sesudah login bila PIN yang dipakai 1303 (`saran_ganti_pin`), dan spanduk kuning + tombol "Ganti PIN sekarang" di Beranda selama akun masih ber-PIN 1303 (`pin_bawaan` dari `/api/portal/beranda`).
- Aksi API baru di `/api/sigap/masuk`: `cari_nama` (dibatasi 40 permintaan/menit per IP, cache daftar nama 60 detik di memori), `ganti_pin_awal` (Bearer sesi; hanya jika hash PIN masih 1303; PIN baru tidak boleh 1303 atau mudah ditebak: 1111, 1234, 4321, 1212).
- `ganti_pin` (PIN sementara) kini juga menolak PIN mudah ditebak. `reset_pin` (Lupa PIN) kini membuka kunci percobaan salah.
- Kunci percobaan salah sekarang memakai nama akun sebenarnya (`sigap_pin:<normNama(akun.nama)>`), selaras dengan tombol Reset PIN admin.

## Database
`sigap_akun.pin_bawaan boolean not null default false` (sudah diterapkan; migrasi `20261008k_sigap_pin_bawaan.sql`). 28 akun ditandai true. Penanda dicek ulang terhadap hash sebenarnya (`masihPinAwal` di `lib/sigapPin.ts`) sehingga penanda basi membersihkan diri. Dibersihkan juga di simpanPinBaru, buat_pin, dan resetPinOlehAdmin.

## Berkas
lib/sigapMasukNama.ts (baru, murni), lib/sigapPin.ts, app/api/sigap/masuk/route.ts, app/api/portal/beranda/route.ts, app/portal/Masuk.tsx, Beranda.tsx, GantiPinCepat.tsx (baru), supabase/migrations/20261008k_sigap_pin_bawaan.sql.

## Catatan / belum
- Belum diuji di browser/data asli; perlu commit + push + deploy.
- Ganti PIN bersifat boleh ditunda ("Nanti saja"); selama masih 1303, siapa pun yang tahu 1303 bisa masuk ke akun itu. Opsi lanjutan: wajibkan ganti PIN saat login.
- `verifikasi` / `lupa_verifikasi` masih memakai `cariAkun` lama (cocok nama persis/tanpa gelar), belum memakai saran nama.
