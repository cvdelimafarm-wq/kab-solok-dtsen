# Tahap 37 — Delego (modul web bawaan SIGAP, tema hijau) — 26 Okt 2026

Status: kode sudah ada di laptop (belum commit/push/deploy). SQL belum dijalankan di produksi. Belum diuji di produksi (ditunda, sekalian dengan tahap 35–36).

## Keputusan pengguna
- Ketua Tim mendelegasikan LANGSUNG ke wakil, pegawai, PML, dan PPL (setara, tanpa perantara). "PJ bidang" hanya label pada delegasi.
- Desain sama dengan SIGAP, warna hijau profesional. Saat masuk menu Delego (web dan HP) seluruh tampilan berganti hijau dengan merek Delego (DelegoShell terpisah); SIGAP tetap biru di luar itu.
- Data terintegrasi dengan SIGAP (akun, RO, identifikasi, lanjutan final, hak keu_boleh, lonceng notifikasi).

## Yang dikerjakan
- SQL `20261026c_keu_delego.sql`: 6 tabel keu_dlg_*, 9 fungsi tulis, 4 fungsi baca, kewenangan delegasi_beri/delegasi_lihat, jenis notifikasi delegasi_*, izin keu_jalankan. Tanpa hapus permanen, jejak lewat keu_jejak.
- Uji `57_uji_delego.sql` (rollback) dan cek `20261026d_cek_kesehatan_keu_delego.sql` (baca saja). Dry-run seluruh migrasi + uji di produksi dengan auto-rollback: LULUS 57.
- Web: `/sigap/delego` (Beranda tim, Papan, Buat, Laporan tim, Beban kerja, Pembinaan dan skor) dan sisi pribadi (Delegasi saya, Lapor harian, Riwayat, Penilaian saya). Mobile: header hijau, tab bawah.
- Logika murni `lib/delego/hitung.ts` (17 tes), tsc strict bersih, 12 tes tampilan lulus.
- Integrasi: `lib/keu/gerbang.ts` (4 fungsi baca di FUNGSI_BACA), `lib/keu/notifikasi.ts` (label delegasi_*), `app/sigap/admin/Shell.tsx` (menu Delego selalu tampil), `app/sigap/kelola/delego/page.tsx` (redirect ke /sigap/delego).

## Asumsi (cek aturan)
Kapasitas 60 poin/orang/hari; hari kerja Sen–Jum tanpa kalender libur; laporan susulan sampai 7 hari (lewat itu hanya pemberi); batas lapor 23:59 WIB, pengingat 18:00; catatan lisan pada hutang ≥20 poin atau 2 hari kerja tanpa laporan; beban sasaran 80–100%/minggu; skor 4 komponen bobot sama (25); tangga pembinaan 5 langkah (langkah 5 tidak pernah disarankan otomatis); PML boleh melapor mewakili mitra pada RO yang sama. Sistem menyarankan, manusia memutuskan.

## Catatan
- Link Delego lama (aplikasi terpisah via portal_aplikasi kode "delego") tidak lagi dipakai dari menu Kelola. Bila kartu Delego di portal memakai href itu, ubah ke `/sigap/delego`.
- Skor dan pembinaan terlihat oleh semua pemegang `delegasi_lihat` (Ketua, ADMINRO, PPK, KPA, ADMIN), bukan hanya Ketua Tim.
- Bukti laporan hanya teks (tanpa unggah foto) di tahap ini. Tidak ada kalender libur nasional.
- Tidak ada pengingat otomatis terjadwal (pengingat 18:00 hanya penanda di layar); notifikasi dikirim saat delegasi dibuat/diubah/ditanggapi/pembinaan/penghargaan.

## Langkah pengguna
1. Jalankan `20261026c_keu_delego.sql` di Supabase, lalu `20261026d_cek_kesehatan_keu_delego.sql` (semua "p0" harus 0). Opsional `57_uji_delego.sql` (rollback).
2. Commit, push, deploy tahap 35–37.
3. Uji produksi sekalian (fiktif): Delego (buat → lapor → tanggapi → pembinaan), status pengadaan, kartu rekrutmen, tombol lembar predefined, Pintu Masuk Perencanaan.
