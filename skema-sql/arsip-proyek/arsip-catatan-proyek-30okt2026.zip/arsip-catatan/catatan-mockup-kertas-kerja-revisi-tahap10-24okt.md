# Catatan mockup Kertas Kerja Revisi POK, tahap 10 (24 Okt 2026): aturan redaksi, klik kode RAB, kekurangan dan penggenap

Status: MOCKUP saja (artifact Design, Versi 39). Belum ada SQL atau kode aplikasi sampai Pak Iqbal menyatakan "setuju". Lanjutan catatan tahap 9.

## Aturan baru dari Pak Iqbal: redaksi item POK resmi tidak diedit langsung
- Item yang sudah menjadi POK resmi tidak dapat diedit uraiannya. Mengganti redaksi harus lewat: kosongkan anggaran item lama, lalu tambah item baru dengan redaksi baru. Contoh dari Pak Iqbal: "Honor petugas pendataan lapangan Survei Harga Produsen Identifikasi Komoditas Utama, 24 DOK x 48.000" menjadi "Honor petugas pengawasan lapangan ..." dengan volume dan harga sama.
- Item yang belum menjadi POK (item baru, draf RAB atau POK) tetap dapat diedit langsung.
- Di mockup: kolom uraian item resmi terkunci; tombol pensil "Ganti redaksi" membuka jendela berisi redaksi lama, isian redaksi baru, dan pratinjau. Penerapan mengosongkan item lama (kecuali bagian yang sudah tertampung Booked + Realisasi) dan membuat item baru pada akun yang sama, kolom Semula kosong, sebagai pasangan lama dan baru. Bila seluruh pagu item sudah terpakai (Booked + Realisasi) atau sudah dikosongkan, redaksi tidak dapat diganti.
- Pemicu: pasangan redaksi saja diberi P-02 (redaksi diganti); bila akun atau angka ikut berubah menjadi P-08. Skenario T-15 dan contoh RAB penuh sudah memakai mekanisme pasangan ini. Perubahan redaksi lewat RAB penuh (tombol Terapkan RAB penuh) juga menjadi pasangan, bukan edit langsung.
- Konsekuensi skema: baris perlu penanda pasangan yang tidak hanya untuk ganti akun (pindah_dari, pindah_ke tetap berlaku bila akun sama); impor hasil penetapan mencatat baris lama "dikosongkan" dan baris baru dengan kunci stabil baru.
- Pertanyaan terbuka: apakah pasangan redaksi di jalur resmi diperlakukan sebagai P-02 saja atau sebagai gabungan P-06 dan P-07 (item ditambah dan item dikurangi)? Perlu dicek ke Kanwil.

## Tab RAB
- Klik kode item (mis. 051.521211.01) membuka atau menutup rincian RAB, sama seperti tombol buka. Area klik kotak centang dipersempit hanya di sekitar kotaknya (15 px), tidak lagi mencakup kode.

## Pertanyaan: skema penggenap bila anggaran kurang (RAB lebih besar dari POK)
Jawaban yang diberikan sesuai mockup: penggenap tidak pernah minus; kekurangan ditutup geseran minimal dalam KRO dan jenis belanja yang sama dengan sumber berurutan (baris Dana penggenap, item selesai, item berlebih di atas RAB dan Booked + Realisasi), penerima menurut kategori prioritas. Sisa kekurangan dicatat sebagai angka di Buku selisih dengan jalur penutup (turunkan volume item boleh ditunda; sumber dari KRO lain via DJPb; antar-Kegiatan atau tambah pagu via Eselon I dan DJA; tunda kegiatan), atau pakai RAB penuh (Revisi DIPA) agar selisih menjadi perubahan pagu. Menunggu keterangan Pak Iqbal apakah kantor punya kebiasaan khusus (mis. penggenap boleh dipakai "minus" sementara).

## Pengujian
Model dan interaksi Main lulus di node (t20 sampai t24); render Chromium lokal: tombol Ganti redaksi, jendela, pasangan baris, klik kode di tab RAB, kotak centang sempit; semua 8 papan tanpa galat. tsc, build, commit, deploy: oleh Pak Iqbal.
