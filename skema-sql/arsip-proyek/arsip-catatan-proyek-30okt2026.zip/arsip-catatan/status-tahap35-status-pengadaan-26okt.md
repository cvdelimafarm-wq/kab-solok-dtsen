# Status Tahap 35: status pelacakan pengadaan (26 Okt 2026)

Kode dan SQL siap, lolos tes. BELUM diterapkan: SQL belum dijalankan di produksi, berkas aplikasi belum ditulis ke folder repo di laptop (sambungan laptop terputus saat pekerjaan ini), belum di-commit dan belum di-deploy.

## Yang dibangun
Kartu "Draf pengadaan" (halaman Rekrutmen dan pengadaan, tahap 34) mendapat kolom **Pelacakan**: status tiap butir (Belum diajukan, Diajukan, Diproses, Selesai, Dibatalkan), rujukan (nomor permintaan, SPK, atau kontrak), catatan, siapa dan kapan mengubah. Status hanya CATATAN pelacakan; metode dan nilai pengadaan tetap ditentukan PPK atau pejabat pengadaan (cek aturan). Tidak ada yang memblokir.

- Kode butir TETAP (`ItemPengadaan.id`): `<id kelas>:paket|konsumsi|perlengkapan|pulsa`, `rapat:<persiapan|pelaksanaan|evaluasi>`, `papi`, `pulsa-lapangan`, `cetak-buku`. Nomor urut lama (`pg1`...) tetap dipakai hanya untuk urutan tampil, karena bergeser bila kelas ditambah.
- Hak mencatat (ditegakkan basis data): penyusun RO itu (`ident_susun`), PPK, PBJ RO itu, atau Admin. Identifikasi harus sudah sah dan tidak dibatalkan. Status "Dibatalkan" wajib beralasan (catatan minimal 5 huruf). Mengembalikan ke "Belum" boleh (tidak ada hapus). Isian sama persis = tanpa perubahan dan tanpa jejak.
- Butir yang sudah dicatat tetapi hilang dari draf (kelas dihapus atau diganti) ditampilkan sebagai catatan "tidak lagi ada pada draf"; catatannya tetap di jejak. Butir berstatus diajukan atau diproses yang masih "perlu dilengkapi" diberi peringatan (tidak memblokir).
- Bila SQL belum dijalankan: kolom Pelacakan tersembunyi dan kartu memberi tahu "Pelacakan status pengadaan belum aktif di basis data"; daftar tetap dapat dibaca dan disalin.
- Tidak ada tautan otomatis ke baris RAB; nomor permintaan atau SPK ditulis pada kolom rujukan (keputusan sederhana; dapat ditingkatkan nanti bila diinginkan).

## Berkas
- SQL baru: `skema-sql/fase-b/20261026b_keu_pengadaan_status.sql` (tabel `keu_ident_pengadaan` dan `keu_ident_pengadaan_jejak`, fungsi `keu_pengadaan_catat`, tampilan `keu_v_ident_pengadaan` dan `keu_v_ident_pengadaan_jejak`, RLS, izin gerbang). Uji: `56_uji_pengadaan.sql` (rollback di akhir).
- Aplikasi baru: `lib/keu/statusPengadaan.ts`, `lib/keu/__tests__/statusPengadaan.test.ts` (12 tes), `app/sigap/kelola/perencanaan/identifikasi/[id]/kebutuhan/useStatusPengadaan.ts`.
- Aplikasi diubah: `lib/keu/pengadaan.ts` (field `id` + `kodeTetap`), `lib/keu/tampilan.ts` (dua tampilan baru pada daftar putih), `kebutuhan/Kartu.tsx`, `kebutuhan/page.tsx`.
- Salinan di Project: `kode-aplikasi/keu/...` (nama berkas diratakan seperti sebelumnya).

## Verifikasi
- vitest folder uji sementara: statusPengadaan 12 lulus, pengadaan 20 lulus (tidak berubah), uji render halaman Kebutuhan 3 lulus (termasuk keadaan pelacakan tersedia dan tidak tersedia). tsc strict bersih untuk berkas baru.
- SQL: uji kering di produksi (transaksi lalu rollback) menjalankan migrasi dan seluruh isi `56_uji_pengadaan.sql` (RO 2903.BMA.009 sebagai pengganti RO uji): lulus tanpa galat; sesudahnya tabel dan fungsi tidak ada (rollback bersih), tidak ada identifikasi "UJI Pengadaan".

## Langkah penerapan (urutan)
1. Tulis berkas aplikasi ke repo (atau minta saya menulisnya begitu laptop tersambung): enam berkas di atas.
2. Jalankan `20261026b_keu_pengadaan_status.sql` di Supabase (SQL editor), lalu (opsional) `56_uji_pengadaan.sql` pada basis data uji.
3. Commit, push, deploy; uji di produksi: halaman `/sigap/kelola/perencanaan/identifikasi/1/kebutuhan`, ubah status butir "Konsumsi rapat evaluasi tatap muka" (data fiktif).
