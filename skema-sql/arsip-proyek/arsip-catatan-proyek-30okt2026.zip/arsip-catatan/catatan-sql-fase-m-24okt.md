# Catatan SQL berkas m: tampilan `keu_v_penugasan_ro`
Tanggal 24 Okt 2026. Berkas: `20261024m_keu_v_penugasan_ro.sql`, `20261024z8_cek_kesehatan_keu_m.sql`, uji `45_uji_penugasan_ro.sql`, pelari `jalan_m.sh`. Tidak menambah tabel (tetap 53). Hanya membuat satu tampilan; aman diulang. Belum dijalankan di produksi.

## Mengapa ada
Halaman `/sigap/ro/<KODE>` perlu menampilkan "Ketua tim", "Admin RO", dan akses tab Administrasi dengan nama orang, padahal aplikasi tidak membuka tabel `sigap_akun` mentah. Tampilan ini menggabungkan `keu_penugasan` dan `keu_akses_adm` dengan nama akun.

## Isi
Kolom: `sumber` (`penugasan` atau `akses_adm`), `id`, `ro_kode` (kosong = berlaku untuk semua RO), `peran_kode` (untuk akses Administrasi: `AKSES_ADM`), `akun_id`, `akun_nama`, `berlaku_mulai`, `berlaku_sampai`, `aktif_hari_ini` (menurut tanggal basis data). Yang sudah dibatalkan tidak tampil; yang belum mulai atau sudah lewat tampil dengan `aktif_hari_ini = false`. Hanya nama akun, tanpa NIK atau NIP.

## Hak
`security_invoker = true`; dicabut dari `anon` dan `authenticated`; `select` hanya untuk `service_role` (aplikasi sisi server, setelah memeriksa bahwa pembaca adalah pegawai organik).

## Cek dan uji
`z8` baris 1 sampai 4 harus 0; baris 5 dan 6 hanya info (penugasan aktif; RO aktif tanpa ketua tim; di produksi sekarang banyak karena penugasan belum diisi). Uji 45: hak, penugasan dibatalkan tidak tampil, belum mulai dan sudah lewat tidak aktif, mulai hari ini aktif, akses Administrasi semua RO, tanpa kolom pribadi. Seluruh rangkaian a-f, h, i, j, k, l, m dijalankan ulang dari nol.
