// lib/delego/hitung.ts
//
// (26 Okt 2026) Delego -- hitungan murni (tanpa jaringan, tanpa React): hari kerja, target dan hutang poin kumulatif, status laporan harian,
// beban kerja mingguan, usulan pemerataan, tangga pembinaan, dan skor kinerja. Sistem hanya MENYARANKAN; manusia yang memutuskan.
// Semua tanggal berbentuk "YYYY-MM-DD" (zona WIB sudah diselesaikan basis data pada `hari_ini`).
// Angka asumsi di bawah dapat diubah di satu tempat (cek aturan): kapasitas per orang per hari menurut tanggal (RIWAYAT_KAPASITAS: 60 sebelum 26 Okt 2026, 70 pada 26-28 Okt, 75 mulai 29 Okt; tidak berlaku mundur; bobot poin per keluarga tidak berubah), hari kerja Senin-Jumat.
//
// (26 Okt 2026, lanjutan) Tiga tambahan:
//  * KALENDER LIBUR: tanggal libur aktif (keu_dlg_libur) tidak dihitung hari kerja. Daftar dipasang sekali dari keu_dlg_hak lewat `aturLibur()` (keadaan modul,
//    karena hampir semua hitungan membutuhkannya); tanpa daftar, perilaku sama seperti sebelumnya (hanya Senin-Jumat / hari_kerja delegasi).
//  * TARGET BERLAKU PER TANGGAL: `riwayat_target` pada delegasi (baris pertama = target awal). Perubahan tidak berlaku surut; target kumulatif, beban, dan hutang
//    dihitung hari demi hari memakai target yang berlaku pada hari itu (`targetHarianPada`). Tanpa riwayat: memakai `target_harian` biasa.
//  * BOBOT SKOR: `skorPenerima(..., bobot)` sudah menerima bobot; bobot bawaan 25/25/25/25 dan dapat diganti pemberi (keu_dlg_bobot).

import type { Delegasi, Laporan, PeranDelegasi, Penilaian } from "./tipe";
import { faktorSkala, MULAI_SKALA_100 } from "./skala";

/** Riwayat kapasitas harian (poin per orang per hari kerja) menurut tanggal mulai. Tidak berlaku mundur: tanggal lama tetap memakai kapasitas yang berlaku saat itu. */
export const RIWAYAT_KAPASITAS: readonly { mulai: string; poin: number }[] = [
  { mulai: "0000-01-01", poin: 60 }, // sebelum 26 Okt 2026
  { mulai: "2026-10-26", poin: 70 }, // 26-28 Okt 2026
  { mulai: "2026-10-29", poin: 75 }, // 29 Okt-15 Nov 2026
  { mulai: MULAI_SKALA_100, poin: 100 }, // (14 Nov 2026, fase D) mulai 16 Nov 2026: skala 100, poin dari Master > Poin beban kerja
];
/** Kapasitas harian yang berlaku pada suatu tanggal (YYYY-MM-DD). */
export function kapasitasPada(tanggal: string): number {
  let poin = RIWAYAT_KAPASITAS[0].poin;
  for (const r of RIWAYAT_KAPASITAS) if (tanggal >= r.mulai) poin = r.poin;
  return poin;
}
/** Kapasitas harian yang berlaku hari ini (WIB) saat modul dimuat. Untuk tanggal tertentu pakai kapasitasPada. */
export const KAPASITAS_HARIAN = kapasitasPada(new Date(Date.now() + 7 * 3_600_000).toISOString().slice(0, 10));
export const HARI_KERJA_MINGGU = 5;
export const JAM_PENGINGAT = 18;
export const HUTANG_CATATAN_LISAN = 20;
export const HARI_TANPA_LAPOR_LISAN = 2;
// (14 Nov 2026, fase D) Keputusan 13 Nov: minimal 60 poin dari 100, boleh lebih dari 100 (di atas 100 tetap ditandai berlebih). Sebelumnya 80-100.
export const SASARAN_BEBAN = { min: 60, max: 100 } as const;
export const BOBOT_SKOR = { ketepatan: 25, capaian: 25, kualitas: 25, kepatuhan: 25 } as const;

export const angka = (x: string | number | null | undefined): number => {
  const n = typeof x === "number" ? x : parseFloat(String(x ?? ""));
  return Number.isFinite(n) ? n : 0;
};
export const bulat = (x: number, desimal = 0) => {
  const f = 10 ** desimal;
  return Math.round(x * f) / f;
};

// ------------------------------------------------------------------ Tanggal
const MS = 86_400_000;
const keMs = (t: string) => Date.UTC(Number(t.slice(0, 4)), Number(t.slice(5, 7)) - 1, Number(t.slice(8, 10)));
const dariMs = (ms: number) => new Date(ms).toISOString().slice(0, 10);

export const tambahHari = (t: string, n: number) => dariMs(keMs(t) + n * MS);
export const selisihHari = (a: string, b: string) => Math.round((keMs(b) - keMs(a)) / MS);
/** 1 = Senin ... 7 = Minggu */
export const hariKe = (t: string) => {
  const d = new Date(keMs(t)).getUTCDay();
  return d === 0 ? 7 : d;
};
export const awalMinggu = (t: string) => tambahHari(t, -(hariKe(t) - 1));
export const awalBulan = (t: string) => `${t.slice(0, 7)}-01`;
export const maks = (a: string, b: string) => (a >= b ? a : b);
export const mini = (a: string, b: string) => (a <= b ? a : b);

const NAMA_HARI = ["", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"];
const NAMA_BULAN = ["", "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
/** "Kam 5 Nov" */
export const tglPendek = (t: string) => `${NAMA_HARI[hariKe(t)]} ${Number(t.slice(8, 10))} ${NAMA_BULAN[Number(t.slice(5, 7))]}`;
/** "5 Nov 2026" */
export const tglLengkap = (t: string) => `${Number(t.slice(8, 10))} ${NAMA_BULAN[Number(t.slice(5, 7))]} ${t.slice(0, 4)}`;

/** Jam (pecahan) di zona WIB dari sebuah instan. */
export const jamWib = (sekarang: Date) => {
  const w = new Date(sekarang.getTime() + 7 * 3_600_000);
  return w.getUTCHours() + w.getUTCMinutes() / 60;
};
export const hariWib = (sekarang: Date) => new Date(sekarang.getTime() + 7 * 3_600_000).toISOString().slice(0, 10);

// ------------------------------------------------------------------ Kalender libur
export type Libur = { tanggal: string; nama: string; jenis: "nasional" | "cuti_bersama" | "lainnya"; aktif: boolean };

let LIBUR = new Map<string, string>();

/** Pasang daftar libur (hanya yang aktif dihitung). Dipanggil sekali saat hak Delego dimuat. Daftar kosong = tanpa kalender libur. */
export function aturLibur(daftar: Pick<Libur, "tanggal" | "nama" | "aktif">[] | null | undefined) {
  LIBUR = new Map((daftar ?? []).filter((l) => l.aktif).map((l) => [l.tanggal.slice(0, 10), l.nama]));
}
/** Nama libur pada tanggal itu, atau null. */
export const namaLibur = (t: string): string | null => LIBUR.get(t) ?? null;
export const hariLibur = (t: string) => LIBUR.has(t);
/** Hari kerja menurut `hk` (1-7) dan bukan libur. */
export const hariKerjaTanggal = (t: string, hk: number[]) => hk.includes(hariKe(t)) && !LIBUR.has(t);

/** Jumlah hari kerja (menurut `hk`, 1-7, tanpa tanggal libur) pada rentang tertutup [mulai, sampai]. */
export function hariKerjaAntara(mulai: string, sampai: string, hk: number[]): number {
  if (sampai < mulai) return 0;
  const selisih = Math.min(selisihHari(mulai, sampai), 800);
  let n = 0;
  for (let i = 0; i <= selisih; i++) if (hariKerjaTanggal(tambahHari(mulai, i), hk)) n++;
  return n;
}

// ------------------------------------------------------------------ Target dan hutang
type DasarTarget = Pick<Delegasi, "mulai" | "tenggat" | "hari_kerja" | "target_harian" | "target_total"> & { riwayat_target?: Delegasi["riwayat_target"] };

/** Target harian yang berlaku pada tanggal itu (riwayat terakhir yang berlaku mulai <= tanggal; selain itu target_harian). Belum memperhitungkan hari kerja/libur. */
export function targetHarianPada(d: Pick<Delegasi, "target_harian"> & { riwayat_target?: Delegasi["riwayat_target"] }, tanggal: string): number {
  const r = d.riwayat_target;
  if (r && r.length > 0) {
    let pakai: (typeof r)[number] | null = null;
    for (const x of r) if (x.berlaku_mulai.slice(0, 10) <= tanggal && (pakai === null || x.berlaku_mulai >= pakai.berlaku_mulai)) pakai = x;
    if (pakai) return angka(pakai.target_harian);
    return angka(r[0].target_harian);
  }
  return angka(d.target_harian);
}

/** Target pada satu tanggal: target harian yang berlaku bila itu hari kerja delegasi (bukan libur) dan masih dalam masanya; selain itu 0. */
export function targetHariIni(d: DasarTarget, tanggal: string): number {
  if (tanggal < d.mulai || tanggal > d.tenggat) return 0;
  return hariKerjaTanggal(tanggal, d.hari_kerja) ? targetHarianPada(d, tanggal) : 0;
}

/** Target kumulatif sejak mulai sampai `sampai` (tertutup), dibatasi tenggat dan target total bila ada. */
export function targetKumulatif(d: DasarTarget, sampai: string): number {
  const akhir = mini(sampai, d.tenggat);
  let t = 0;
  if (akhir >= d.mulai) {
    const selisih = Math.min(selisihHari(d.mulai, akhir), 800);
    for (let i = 0; i <= selisih; i++) t += targetHariIni(d, tambahHari(d.mulai, i));
  }
  const total = d.target_total === null || d.target_total === undefined ? null : angka(d.target_total);
  return total !== null && total > 0 ? Math.min(t, total) : t;
}

export const targetPenuh = (d: Delegasi) => (d.target_total !== null && angka(d.target_total) > 0 ? angka(d.target_total) : targetKumulatif(d, d.tenggat));

export type RingkasHariIni = {
  hariKerjaIni: boolean;
  targetHariIni: number;
  poinHariIni: number;
  sisaHariIni: number;
  poinTotal: number;
  targetSampaiKemarin: number;
  hutangKemarin: number;
  kelebihan: number;
  hutangBerjalan: number;
  persenSelesai: number;
  laporanHariIni: Laporan | null;
};

export function ringkasHariIni(d: Delegasi, laporan: Laporan[], hari: string): RingkasHariIni {
  const lap = laporan.find((l) => l.delegasi_id === d.id && l.tanggal === hari) ?? null;
  const poinHariIni = lap ? angka(lap.poin) : 0;
  const hariKerjaIni = hariKerjaTanggal(hari, d.hari_kerja) && hari >= d.mulai && hari <= d.tenggat;
  const targetHariIniNilai = hariKerjaIni ? targetHarianPada(d, hari) : 0;
  const poinTotal = angka(d.poin_total);
  const poinSampaiKemarin = Math.max(0, poinTotal - poinHariIni);
  const targetSampaiKemarin = targetKumulatif(d, tambahHari(hari, -1));
  const penuh = targetPenuh(d);
  return {
    hariKerjaIni,
    targetHariIni: targetHariIniNilai,
    poinHariIni,
    sisaHariIni: Math.max(0, targetHariIniNilai - poinHariIni),
    poinTotal,
    targetSampaiKemarin,
    hutangKemarin: Math.max(0, targetSampaiKemarin - poinSampaiKemarin),
    kelebihan: Math.max(0, poinSampaiKemarin - targetSampaiKemarin),
    hutangBerjalan: Math.max(0, targetKumulatif(d, hari) - poinTotal),
    persenSelesai: penuh > 0 ? Math.round((poinTotal / penuh) * 100) : 0,
    laporanHariIni: lap,
  };
}

export type StatusLaporan = "tidak_berlaku" | "libur" | "sudah" | "belum" | "perlu_pengingat";

/** Status kewajiban lapor satu delegasi pada `hari`. `jam` = jam WIB saat ini (pecahan). Tanggal libur (kalender atau di luar hari kerja delegasi) = "libur". */
export function statusLaporanHariIni(d: Delegasi, laporan: Laporan[], hari: string, jam: number): StatusLaporan {
  if (d.status !== "baru" && d.status !== "berjalan") return "tidak_berlaku";
  if (hari < d.mulai || hari > d.tenggat) return "tidak_berlaku";
  if (laporan.some((l) => l.delegasi_id === d.id && l.tanggal === hari)) return "sudah";
  if (!hariKerjaTanggal(hari, d.hari_kerja)) return "libur";
  return jam >= JAM_PENGINGAT ? "perlu_pengingat" : "belum";
}

/** Berapa hari kerja berturut-turut (sampai kemarin) delegasi ini tanpa laporan. */
export function hariTanpaLapor(d: Delegasi, laporan: Laporan[], hari: string): number {
  const ada = new Set(laporan.filter((l) => l.delegasi_id === d.id).map((l) => l.tanggal));
  let n = 0;
  for (let i = 1; i <= 30; i++) {
    const t = tambahHari(hari, -i);
    if (t < d.mulai) break;
    if (t > d.tenggat || !hariKerjaTanggal(t, d.hari_kerja)) continue;
    if (ada.has(t)) break;
    n++;
  }
  return n;
}

export type Tindakan = { jenis: "pengingat" | "catatan_lisan"; alasan: string };

/** Hal yang perlu perhatian pemberi pada delegasi ini (hanya saran). */
export function tindakanDisarankan(d: Delegasi, laporan: Laporan[], hari: string, jam: number): Tindakan[] {
  if (d.status !== "baru" && d.status !== "berjalan") return [];
  const out: Tindakan[] = [];
  const r = ringkasHariIni(d, laporan, hari);
  const tanpa = hariTanpaLapor(d, laporan, hari);
  if (statusLaporanHariIni(d, laporan, hari, jam) === "perlu_pengingat") out.push({ jenis: "pengingat", alasan: `Belum lapor hari ini (lewat pukul ${JAM_PENGINGAT}:00 WIB).` });
  if (r.hutangKemarin >= HUTANG_CATATAN_LISAN) out.push({ jenis: "catatan_lisan", alasan: `Hutang ${bulat(r.hutangKemarin)} poin (ambang ${HUTANG_CATATAN_LISAN}).` });
  else if (tanpa >= HARI_TANPA_LAPOR_LISAN) out.push({ jenis: "catatan_lisan", alasan: `${tanpa} hari kerja berturut-turut tanpa laporan.` });
  return out;
}

// ------------------------------------------------------------------ Beban kerja
export type KategoriBeban = "ringan" | "sasaran" | "berlebih";
export const kategoriBeban = (persen: number): KategoriBeban => (persen < SASARAN_BEBAN.min ? "ringan" : persen <= SASARAN_BEBAN.max ? "sasaran" : "berlebih");

/** Beban satu delegasi pada satu tanggal: target harian yang berlaku bila tanggal itu hari kerjanya (bukan libur) dan masih dalam masa delegasi. */
export function bebanDelegasiHari(d: Delegasi, tanggal: string): number {
  if (d.status !== "baru" && d.status !== "berjalan") return 0;
  // poin delegasi skala 75 yang jatuh pada hari skala 100 dikalikan 100/75 (lib/delego/skala.ts)
  return targetHariIni(d, tanggal) * faktorSkala(d.mulai, tanggal);
}

/** Poin per minggu yang dibebankan sebuah delegasi pada minggu (Senin-Minggu) yang memuat `hari`. */
export function bebanDelegasiMinggu(d: Delegasi, hari: string): number {
  if (d.status !== "baru" && d.status !== "berjalan") return 0;
  const awal = awalMinggu(hari);
  let total = 0;
  for (let i = 0; i < 7; i++) {
    const t = tambahHari(awal, i);
    total += targetHariIni(d, t) * faktorSkala(d.mulai, t);
  }
  return total;
}

export type OrangBeban = {
  akun: number;
  nama: string;
  jenis: "organik" | "mitra";
  beban: number;
  kapasitas: number;
  persen: number;
  kategori: KategoriBeban;
  jumlahDelegasi: number;
};

/** Kapasitas satu minggu (Senin-Jumat) yang memuat `hari`: jumlah kapasitas harian tiap hari kerja menurut tanggalnya. */
export function kapasitasMinggu(hari: string): number {
  const awal = awalMinggu(hari);
  let total = 0;
  for (let i = 0; i < HARI_KERJA_MINGGU; i++) total += kapasitasPada(tambahHari(awal, i));
  return total;
}
/** Nilai kapasitas harian yang berbeda pada minggu yang memuat `hari` (untuk keterangan layar). */
export function kapasitasHariMinggu(hari: string): number[] {
  const awal = awalMinggu(hari);
  return [...new Set(Array.from({ length: HARI_KERJA_MINGGU }, (_, i) => kapasitasPada(tambahHari(awal, i))))];
}

export function bebanPerOrang(delegasi: Delegasi[], hari: string, tambahan: { id: number; nama: string; jenis: "organik" | "mitra" }[] = []): OrangBeban[] {
  const kapasitas = kapasitasMinggu(hari);
  const peta = new Map<number, OrangBeban>();
  for (const t of tambahan) peta.set(t.id, { akun: t.id, nama: t.nama, jenis: t.jenis, beban: 0, kapasitas, persen: 0, kategori: "ringan", jumlahDelegasi: 0 });
  for (const d of delegasi) {
    if (d.status !== "baru" && d.status !== "berjalan") continue;
    const o = peta.get(d.penerima_akun) ?? { akun: d.penerima_akun, nama: d.penerima_nama, jenis: d.penerima_jenis, beban: 0, kapasitas, persen: 0, kategori: "ringan" as KategoriBeban, jumlahDelegasi: 0 };
    o.beban += bebanDelegasiMinggu(d, hari);
    o.jumlahDelegasi += 1;
    peta.set(d.penerima_akun, o);
  }
  const out = [...peta.values()];
  for (const o of out) {
    o.persen = Math.round((o.beban / o.kapasitas) * 100);
    o.kategori = kategoriBeban(o.persen);
  }
  return out.sort((a, b) => b.persen - a.persen || a.nama.localeCompare(b.nama));
}

// ------------------------------------------------------------------ Beban harian (tabel mingguan)
export type SelHarian = { tanggal: string; hk: number; poin: number; persen: number; kategori: KategoriBeban | "kosong"; libur?: string | null };
export type BarisHarian = { akun: number; nama: string; jenis: "organik" | "mitra"; sel: SelHarian[] };

/** Tabel beban per orang per hari untuk minggu (Senin-Minggu) yang memuat `hari`. Persen terhadap kapasitas hari itu (kapasitasPada). `libur` terisi bila tanggal itu libur kalender. */
export function matriksBebanHarian(orang: OrangBeban[], delegasi: Delegasi[], hari: string): { tanggal: string[]; baris: BarisHarian[]; adaAkhirPekan: boolean } {
  const awal = awalMinggu(hari);
  const tanggal = Array.from({ length: 7 }, (_, i) => tambahHari(awal, i));
  const baris = orang.map((o) => ({
    akun: o.akun,
    nama: o.nama,
    jenis: o.jenis,
    sel: tanggal.map((t) => {
      const poin = delegasi.filter((d) => d.penerima_akun === o.akun).reduce((s, d) => s + bebanDelegasiHari(d, t), 0);
      const persen = Math.round((poin / kapasitasPada(t)) * 100);
      return { tanggal: t, hk: hariKe(t), poin, persen, kategori: poin === 0 ? ("kosong" as const) : kategoriBeban(persen), libur: namaLibur(t) };
    }),
  }));
  const adaAkhirPekan = baris.some((b) => b.sel.some((s) => s.hk >= 6 && s.poin > 0));
  return { tanggal, baris, adaAkhirPekan };
}

export type UsulanPemerataan = {
  delegasiId: number;
  judul: string;
  dariAkun: number;
  dariNama: string;
  keAkun: number;
  keNama: string;
  poinMinggu: number;
  sesudahDari: number;
  sesudahKe: number;
  /** Untuk menerapkan usulan: versi delegasi saat usulan dihitung (menolak bila sudah berubah), RO-nya, dan perannya. */
  ver: number;
  roKode: string;
  peran: PeranDelegasi;
};

/** Saran memindahkan delegasi dari yang berlebih (>100%) ke yang masih longgar. Hanya saran; pemberi memutuskan dan membuat delegasi baru bila setuju. */
export function usulPemerataan(orang: OrangBeban[], delegasi: Delegasi[], hari: string): UsulanPemerataan[] {
  const sisa = new Map(orang.map((o) => [o.akun, o.beban]));
  const kap = orang[0]?.kapasitas ?? kapasitasMinggu(hari);
  const hasil: UsulanPemerataan[] = [];
  const dipakai = new Set<number>();
  for (const sumber of orang.filter((o) => o.persen > SASARAN_BEBAN.max)) {
    for (let putaran = 0; putaran < 5 && (sisa.get(sumber.akun) ?? 0) > kap; putaran++) {
      const lebih = (sisa.get(sumber.akun) ?? 0) - kap;
      const milik = delegasi
        .filter((d) => d.penerima_akun === sumber.akun && !dipakai.has(d.id) && bebanDelegasiMinggu(d, hari) > 0)
        .map((d) => ({ d, w: bebanDelegasiMinggu(d, hari) }))
        .sort((a, b) => (a.d.status === b.d.status ? 0 : a.d.status === "baru" ? -1 : 1) || a.w - b.w);
      if (milik.length === 0) break;
      const cukup = milik.find((m) => m.w >= lebih) ?? milik[milik.length - 1];
      const penampung = orang
        .filter((o) => o.akun !== sumber.akun && (sisa.get(o.akun) ?? 0) + cukup.w <= kap && (o.jenis === "organik" || cukup.d.peran_penerima === "pml" || cukup.d.peran_penerima === "ppl"))
        .sort((a, b) => (sisa.get(a.akun) ?? 0) - (sisa.get(b.akun) ?? 0))[0];
      if (!penampung) break;
      sisa.set(sumber.akun, (sisa.get(sumber.akun) ?? 0) - cukup.w);
      sisa.set(penampung.akun, (sisa.get(penampung.akun) ?? 0) + cukup.w);
      dipakai.add(cukup.d.id);
      hasil.push({
        delegasiId: cukup.d.id,
        judul: cukup.d.judul,
        dariAkun: sumber.akun,
        dariNama: sumber.nama,
        keAkun: penampung.akun,
        keNama: penampung.nama,
        poinMinggu: cukup.w,
        sesudahDari: Math.round(((sisa.get(sumber.akun) ?? 0) / kap) * 100),
        sesudahKe: Math.round(((sisa.get(penampung.akun) ?? 0) / kap) * 100),
        ver: cukup.d.ver,
        roKode: cukup.d.ro_kode,
        peran: cukup.d.peran_penerima,
      });
    }
  }
  return hasil;
}

// ------------------------------------------------------------------ Tangga pembinaan
export const TANGGA_PEMBINAAN: { langkah: number; nama: string; ket: string }[] = [
  { langkah: 1, nama: "Pengingat", ket: "Pesan pengingat singkat dari Ketua Tim atau sistem." },
  { langkah: 2, nama: "Catatan lisan", ket: "Bicara langsung; kendala dan kesanggupan dicatat." },
  { langkah: 3, nama: "Percakapan tertulis", ket: "Kesepakatan perbaikan ditulis dan diketahui kedua pihak." },
  { langkah: 4, nama: "Rencana perbaikan", ket: "Target bertahap dengan tanggal tinjau." },
  { langkah: 5, nama: "Rujuk ke pejabat berwenang", ket: "Tindak lanjut formal oleh pejabat berwenang (cek aturan); sistem hanya mencatat." },
];

export type SaranPembinaan = { langkah: number; alasan: string };

/** Langkah berikutnya yang disarankan. Langkah 5 tidak pernah disarankan otomatis. `langkahTerakhir` = langkah tertinggi yang masih berjalan. */
export function saranPembinaan(p: { hutang: number; hariTanpaLapor: number; belumLaporLewatPengingat: boolean; langkahTerakhir: number | null }): SaranPembinaan | null {
  const berat = p.hutang >= HUTANG_CATATAN_LISAN || p.hariTanpaLapor >= HARI_TANPA_LAPOR_LISAN;
  if (berat) {
    const langkah = Math.min(4, Math.max(2, (p.langkahTerakhir ?? 1) + 1));
    return { langkah, alasan: p.hutang >= HUTANG_CATATAN_LISAN ? `Hutang ${bulat(p.hutang)} poin.` : `${p.hariTanpaLapor} hari kerja tanpa laporan.` };
  }
  if (p.belumLaporLewatPengingat && (p.langkahTerakhir ?? 0) < 1) return { langkah: 1, alasan: "Belum lapor hingga lewat jam pengingat." };
  return null;
}

// ------------------------------------------------------------------ Skor kinerja
export type KomponenSkor = { kode: "ketepatan" | "capaian" | "kualitas" | "kepatuhan"; nama: string; nilai: number | null; bobot: number };
export type Skor = { total: number | null; komponen: KomponenSkor[] };

/** Skor 0-100 satu orang dari seluruh delegasinya. Komponen tanpa data dikeluarkan dan bobot sisanya dinormalkan. `bobot` dari keu_dlg_bobot (hak.bobot); bawaan 25 tiap komponen. */
export function skorPenerima(delegasi: Delegasi[], laporan: Laporan[], penilaian: Penilaian[], hari: string, bobot: Record<string, number> = BOBOT_SKOR): Skor {
  let harapan = 0;
  let tepat = 0;
  let tk = 0;
  let cap = 0;
  for (const d of delegasi) {
    if (d.status === "batal" || d.status === "usulan") continue;
    const awal = maks(d.mulai, tambahHari(hari, -34));
    const akhir = mini(tambahHari(hari, -1), d.tenggat);
    harapan += hariKerjaAntara(awal, akhir, d.hari_kerja);
    for (const l of laporan) {
      if (l.delegasi_id !== d.id || l.terlambat) continue;
      if (l.tanggal >= awal && l.tanggal <= akhir && hariKerjaTanggal(l.tanggal, d.hari_kerja)) tepat++;
    }
    const r = ringkasHariIni(d, laporan, hari);
    tk += r.targetSampaiKemarin;
    cap += Math.min(Math.max(0, r.poinTotal - r.poinHariIni), r.targetSampaiKemarin);
  }
  const terbaru = penilaian.reduce((m, p) => (p.periode > m ? p.periode : m), "");
  const dipakai = terbaru ? penilaian.filter((p) => p.periode === terbaru) : [];
  const rata = (f: (p: Penilaian) => number) => (dipakai.length ? dipakai.reduce((s, p) => s + f(p), 0) / dipakai.length : null);
  const komponen: KomponenSkor[] = [
    { kode: "ketepatan", nama: "Ketepatan lapor", nilai: harapan > 0 ? Math.min(100, Math.round((tepat / harapan) * 100)) : null, bobot: bobot.ketepatan ?? 25 },
    { kode: "capaian", nama: "Capaian terhadap target", nilai: tk > 0 ? Math.min(100, Math.round((cap / tk) * 100)) : null, bobot: bobot.capaian ?? 25 },
    { kode: "kualitas", nama: "Kualitas data (hasil periksa)", nilai: rata((p) => p.kualitas) === null ? null : Math.round(rata((p) => p.kualitas) as number), bobot: bobot.kualitas ?? 25 },
    { kode: "kepatuhan", nama: "Kepatuhan prosedur", nilai: rata((p) => p.kepatuhan) === null ? null : Math.round(rata((p) => p.kepatuhan) as number), bobot: bobot.kepatuhan ?? 25 },
  ];
  const ada = komponen.filter((k) => k.nilai !== null);
  const sumB = ada.reduce((s, k) => s + k.bobot, 0);
  const total = ada.length === 0 || sumB === 0 ? null : Math.round(ada.reduce((s, k) => s + (k.nilai as number) * k.bobot, 0) / sumB);
  return { total, komponen };
}

// ------------------------------------------------------------------ Identifikasi berubah
/** Identifikasi (keu_ident.ver) sudah naik sejak delegasi dibuat atau terakhir ditinjau pemberi. */
export const identBerubah = (d: Pick<Delegasi, "ident_id" | "ident_ver" | "ident_ver_kini" | "status">): boolean =>
  d.ident_id !== null && d.ident_ver != null && d.ident_ver_kini != null && d.ident_ver_kini > d.ident_ver && (d.status === "baru" || d.status === "berjalan" || d.status === "ditunda");

// ------------------------------------------------------------------ Ringkasan tim
export type RingkasTim = {
  aktif: number;
  sudahLapor: number;
  belumLapor: number;
  perluPengingat: number;
  hutangTotal: number;
  perluCatatan: number;
  berlebih: number;
};

export function ringkasTim(delegasi: Delegasi[], laporan: Laporan[], hari: string, jam: number): RingkasTim {
  let aktif = 0, sudah = 0, belum = 0, ingat = 0, hutang = 0, catatan = 0;
  for (const d of delegasi) {
    if (d.status !== "baru" && d.status !== "berjalan") continue;
    aktif++;
    const s = statusLaporanHariIni(d, laporan, hari, jam);
    if (s === "sudah") sudah++;
    else if (s === "belum" || s === "perlu_pengingat") belum++;
    if (s === "perlu_pengingat") ingat++;
    hutang += ringkasHariIni(d, laporan, hari).hutangKemarin;
    if (tindakanDisarankan(d, laporan, hari, jam).some((t) => t.jenis === "catatan_lisan")) catatan++;
  }
  const berlebih = bebanPerOrang(delegasi, hari).filter((o) => o.kategori === "berlebih").length;
  return { aktif, sudahLapor: sudah, belumLapor: belum, perluPengingat: ingat, hutangTotal: bulat(hutang), perluCatatan: catatan, berlebih };
}
